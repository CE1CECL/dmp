check device
install vcredist_x86 2008 SP1.exe
MCP Installer.msi
Player : mpc-hc-t5-fix-Qvu-MKV-FLV.exe