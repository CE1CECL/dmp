! GAPFile Version 3.0
GAPFile Version 3.0
Units: Mills
*CAP_LIBRARY 
*END_CAP_LIBRARY

*APERTURES2 257
10  Rectangle Sq w:210.00 h:80.00 a:0.0
11  Rectangle Sq w:80.00 h:210.00 a:0.0
12  Rectangle Sq w:216.00 h:86.00 a:0.0
13  Rectangle Sq w:86.00 h:216.00 a:0.0
14  Round d:28.00
15  Thermal Simple od:10.00 id:7.50 sa:45 a:0.0
16  Round d:22.00
17  Round d:20.00
18  Round d:30.00
19  Round d:24.00
20  Round d:46.00
21  Round d:50.00
22  Round d:200.00
23  Thermal Simple od:200.00 id:150.00 sa:45 a:0.0
24  Round d:157.00
25  Round d:167.00
26  Rectangle Sq w:100.00 h:60.00 a:0.0
27  Rectangle Sq w:60.00 h:100.00 a:0.0
28  Rectangle Sq w:106.00 h:66.00 a:0.0
29  Rectangle Sq w:66.00 h:106.00 a:0.0
30  Rectangle Sq w:20.00 h:50.00 a:0.0
31  Rectangle Sq w:50.00 h:20.00 a:0.0
32  Rectangle Sq w:26.00 h:56.00 a:0.0
33  Rectangle Sq w:56.00 h:26.00 a:0.0
34  Rectangle Sq w:20.00 h:90.00 a:0.0
35  Rectangle Sq w:90.00 h:20.00 a:0.0
36  Rectangle Sq w:26.00 h:96.00 a:0.0
37  Rectangle Sq w:96.00 h:26.00 a:0.0
38  Round d:113.00
39  Thermal Simple od:113.00 id:84.75 sa:45 a:0.0
40  Round d:73.00
41  Round d:79.00
42  Round d:197.00
43  Round d:121.00
44  Thermal Simple od:121.00 id:90.75 sa:45 a:0.0
45  Round d:203.00
46  Round d:118.00
47  Round d:40.00
48  Round d:80.00
49  Round d:48.00
50  Thermal Simple od:48.00 id:36.00 sa:45 a:0.0
51  Round d:34.00
52  Rectangle Sq w:55.00 h:90.00 a:0.0
53  Rectangle Sq w:90.00 h:55.00 a:0.0
54  Rectangle Sq w:61.00 h:96.00 a:0.0
55  Rectangle Sq w:96.00 h:61.00 a:0.0
56  Rectangle Sq w:70.00 h:80.00 a:0.0
57  Rectangle Sq w:80.00 h:70.00 a:0.0
58  Rectangle Sq w:76.00 h:86.00 a:0.0
59  Rectangle Sq w:86.00 h:76.00 a:0.0
60  Rectangle Sq w:50.00 h:70.00 a:0.0
61  Rectangle Sq w:70.00 h:50.00 a:0.0
62  Rectangle Sq w:56.00 h:76.00 a:0.0
63  Rectangle Sq w:76.00 h:56.00 a:0.0
64  Round d:120.00
65  Thermal Simple od:120.00 id:90.00 sa:45 a:0.0
66  Round d:100.00
67  Round d:110.00
68  Square s:100.00 a:0.0
69  Round d:85.00
70  Thermal Simple od:85.00 id:63.75 sa:45 a:0.0
71  Round d:65.00
72  Round d:75.00
73  Square s:65.00 a:0.0
74  Square s:71.00 a:0.0
75  Rectangle Sq w:177.00 h:60.00 a:0.0
76  Rectangle Sq w:60.00 h:177.00 a:0.0
77  Rectangle Sq w:183.00 h:66.00 a:0.0
78  Rectangle Sq w:66.00 h:183.00 a:0.0
79  Rectangle Sq w:71.00 h:80.00 a:0.0
80  Rectangle Sq w:80.00 h:71.00 a:0.0
81  Rectangle Sq w:77.00 h:86.00 a:0.0
82  Rectangle Sq w:86.00 h:77.00 a:0.0
83  Rectangle Sq w:30.00 h:30.00 a:0.0
84  Rectangle Sq w:40.00 h:40.00 a:0.0
85  Rectangle Sq w:36.00 h:36.00 a:0.0
86  Rectangle Sq w:42.00 h:42.00 a:0.0
87  Rectangle Sq w:118.00 h:47.00 a:0.0
88  Rectangle Sq w:47.00 h:118.00 a:0.0
89  Rectangle Sq w:124.00 h:53.00 a:0.0
90  Rectangle Sq w:53.00 h:124.00 a:0.0
91  Rectangle Sq w:50.00 h:50.00 a:0.0
92  Rectangle Sq w:56.00 h:56.00 a:0.0
93  Thermal Simple od:75.00 id:56.25 sa:45 a:0.0
94  Round d:55.00
95  Round d:61.00
96  Rectangle Sq w:55.00 h:70.00 a:0.0
97  Rectangle Sq w:70.00 h:55.00 a:0.0
98  Rectangle Sq w:61.00 h:76.00 a:0.0
99  Rectangle Sq w:76.00 h:61.00 a:0.0
100  Rectangle Sq w:43.00 h:71.00 a:0.0
101  Rectangle Sq w:71.00 h:43.00 a:0.0
102  Rectangle Sq w:49.00 h:77.00 a:0.0
103  Rectangle Sq w:77.00 h:49.00 a:0.0
104  Rectangle Sq w:292.00 h:260.00 a:0.0
105  Square s:52.00 a:0.0
106  Square s:58.00 a:0.0
107  Rectangle Sq w:40.00 h:50.00 a:0.0
108  Rectangle Sq w:50.00 h:40.00 a:0.0
109  Rectangle Sq w:46.00 h:56.00 a:0.0
110  Rectangle Sq w:56.00 h:46.00 a:0.0
111  Rectangle Sq w:63.00 h:51.00 a:0.0
112  Rectangle Sq w:51.00 h:63.00 a:0.0
113  Rectangle Sq w:69.00 h:57.00 a:0.0
114  Rectangle Sq w:57.00 h:69.00 a:0.0
115  Rectangle Sq w:14.00 h:44.00 a:0.0
116  Rectangle Sq w:44.00 h:14.00 a:0.0
117  Round d:90.00
118  Thermal Simple od:90.00 id:67.50 sa:45 a:0.0
119  Square s:70.00 a:0.0
120  Round d:70.00
121  Square s:90.00 a:0.0
122  Square s:80.00 a:0.0
123  Rectangle Sq w:180.00 h:120.00 a:0.0
124  Rectangle Sq w:120.00 h:180.00 a:0.0
125  Thermal Simple od:130.00 id:97.50 sa:45 a:0.0
126  Rectangle Sq w:160.00 h:100.00 a:0.0
127  Rectangle Sq w:100.00 h:160.00 a:0.0
128  Rectangle Sq w:166.00 h:106.00 a:0.0
129  Rectangle Sq w:106.00 h:166.00 a:0.0
130  Round d:180.00
131  Thermal Simple od:180.00 id:135.00 sa:45 a:0.0
132  Rectangle Sq w:160.00 h:65.00 a:0.0
133  Rectangle Sq w:65.00 h:160.00 a:0.0
134  Rectangle Sq w:166.00 h:71.00 a:0.0
135  Rectangle Sq w:71.00 h:166.00 a:0.0
136  Rectangle Sq w:27.00 h:40.00 a:0.0
137  Rectangle Sq w:40.00 h:27.00 a:0.0
138  Rectangle Sq w:33.00 h:46.00 a:0.0
139  Rectangle Sq w:46.00 h:33.00 a:0.0
140  Round d:140.00
141  Thermal Simple od:140.00 id:105.00 sa:45 a:0.0
142  Round d:125.00
143  Round d:131.00
144  Rectangle Sq w:83.00 h:118.00 a:0.0
145  Rectangle Sq w:118.00 h:83.00 a:0.0
146  Rectangle Sq w:89.00 h:124.00 a:0.0
147  Rectangle Sq w:124.00 h:89.00 a:0.0
148  Rectangle Sq w:32.00 h:80.00 a:0.0
149  Rectangle Sq w:80.00 h:32.00 a:0.0
150  Rectangle Sq w:38.00 h:86.00 a:0.0
151  Rectangle Sq w:86.00 h:38.00 a:0.0
152  Rectangle Sq w:20.00 h:45.00 a:0.0
153  Rectangle Sq w:45.00 h:20.00 a:0.0
154  Rectangle Sq w:26.00 h:51.00 a:0.0
155  Rectangle Sq w:51.00 h:26.00 a:0.0
156  Thermal Simple od:55.00 id:41.25 sa:45 a:0.0
157  Round d:35.00
158  Round d:45.00
159  Rectangle Sq w:40.00 h:32.00 a:0.0
160  Rectangle Sq w:32.00 h:40.00 a:0.0
161  Rectangle Sq w:46.00 h:38.00 a:0.0
162  Rectangle Sq w:38.00 h:46.00 a:0.0
163  Rectangle Sq w:27.00 h:60.00 a:0.0
164  Rectangle Sq w:60.00 h:27.00 a:0.0
165  Rectangle Sq w:33.00 h:66.00 a:0.0
166  Rectangle Sq w:66.00 h:33.00 a:0.0
167  Rectangle Sq w:24.00 h:75.00 a:0.0
168  Rectangle Sq w:75.00 h:24.00 a:0.0
169  Rectangle Sq w:30.00 h:81.00 a:0.0
170  Rectangle Sq w:81.00 h:30.00 a:0.0
171  Thermal Simple od:197.00 id:147.75 sa:45 a:0.0
172  Round d:177.00
173  Round d:183.00
174  Round d:78.00
175  Thermal Simple od:78.00 id:58.50 sa:45 a:0.0
176  Round d:58.00
177  Round d:126.00
178  Thermal Simple od:80.00 id:60.00 sa:45 a:0.0
179  Square s:60.00 a:0.0
180  Round d:60.00
181  Round d:66.00
182  Round d:145.00
183  Thermal Simple od:145.00 id:108.75 sa:45 a:0.0
184  Thermal Simple od:131.00 id:98.25 sa:45 a:0.0
185  Round d:91.00
186  Round d:97.00
187  Thermal Simple od:110.00 id:82.50 sa:45 a:0.0
188  Rectangle Sq w:14.00 h:80.00 a:0.0
189  Rectangle Sq w:80.00 h:14.00 a:0.0
190  Rectangle Sq w:20.00 h:86.00 a:0.0
191  Rectangle Sq w:86.00 h:20.00 a:0.0
192  Round d:160.00
193  Thermal Simple od:160.00 id:120.00 sa:45 a:0.0
194  Round d:146.00
195  Round d:64.00
196  Square s:55.00 a:0.0
197  Rectangle Sq w:12.00 h:50.00 a:0.0
198  Rectangle Sq w:50.00 h:12.00 a:0.0
199  Rectangle Sq w:18.00 h:56.00 a:0.0
200  Rectangle Sq w:56.00 h:18.00 a:0.0
201  Rectangle Sq w:71.00 h:60.00 a:0.0
202  Rectangle Sq w:60.00 h:71.00 a:0.0
203  Rectangle Sq w:77.00 h:66.00 a:0.0
204  Rectangle Sq w:66.00 h:77.00 a:0.0
205  Round d:148.00
206  Thermal Simple od:148.00 id:111.00 sa:45 a:0.0
207  Round d:128.00
208  Thermal Simple od:70.00 id:52.50 sa:45 a:0.0
209  Square s:50.00 a:0.0
210  Round d:56.00
211  Rectangle Sq w:72.00 h:20.00 a:0.0
212  Rectangle Sq w:20.00 h:72.00 a:0.0
213  Rectangle Sq w:78.00 h:26.00 a:0.0
214  Rectangle Sq w:26.00 h:78.00 a:0.0
215  Rectangle Sq w:72.00 h:12.00 a:0.0
216  Rectangle Sq w:12.00 h:72.00 a:0.0
217  Rectangle Sq w:78.00 h:18.00 a:0.0
218  Rectangle Sq w:18.00 h:78.00 a:0.0
219  Round d:16.00
220  Rectangle Sq w:10.00 h:70.00 a:0.0
221  Rectangle Sq w:70.00 h:10.00 a:0.0
222  Rectangle Sq w:16.00 h:76.00 a:0.0
223  Rectangle Sq w:76.00 h:16.00 a:0.0
224  Square s:51.00 a:0.0
225  Round d:51.00
226  Square s:57.00 a:0.0
227  Round d:57.00
228  Rectangle Sq w:20.00 h:80.00 a:0.0
229  Rectangle Sq w:80.00 h:20.00 a:0.0
230  Rectangle Sq w:26.00 h:86.00 a:0.0
231  Rectangle Sq w:86.00 h:26.00 a:0.0
232  Rectangle Sq w:110.00 h:200.00 a:0.0
233  Rectangle Sq w:200.00 h:110.00 a:0.0
234  Rectangle Sq w:116.00 h:206.00 a:0.0
235  Rectangle Sq w:206.00 h:116.00 a:0.0
236  Round d:103.00
237  Thermal Simple od:103.00 id:77.25 sa:45 a:0.0
238  Round d:63.00
239  Round d:69.00
240  Round d:74.00
241  Thermal Simple od:74.00 id:55.50 sa:45 a:0.0
242  Round d:43.00
243  Round d:49.00
244  Round d:18.00
245  Round d:6.00
246  Round d:8.00
247  Round d:10.00
248  Round d:16.00
249  Round d:5.00
250  Round d:4.00
251  Round d:25.00
252  Round d:20.00
253  Round d:30.00
254  Round d:4.02
255  Round d:12.01
256  Round d:5.98
257  Round d:12.00
258  Round d:11.81
259  Round d:2.00
260  Round d:7.87
261  Round d:15.00
262  Round d:18.00
263  Round d:5.50
264  Round d:24.00
265  Round d:14.00
266  Round d:22.00
*END_APERTURES


