if exist D:\WINCE600\OSDesigns\MXTECO\MXTECO\RelDir\Vortex86DX_60B_x86_Release\nlscfg.inf del /f /q D:\WINCE600\OSDesigns\MXTECO\MXTECO\RelDir\Vortex86DX_60B_x86_Release\nlscfg.inf
xcopy /q /c D:\WINCE600\OSDesigns\MXTECO\MXTECO\Wince600\Vortex86DX_60B_x86\oak\Files\nlscfg.inf D:\WINCE600\OSDesigns\MXTECO\MXTECO\RelDir\Vortex86DX_60B_x86_Release
