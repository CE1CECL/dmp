/* This file is auto generated, version 1 */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#1 Wed Jul 14 16:05:42 CST 2010"
#define LINUX_COMPILE_TIME "16:05:42"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "shawn-desktop"
#define LINUX_COMPILE_DOMAIN
#define LINUX_COMPILER "gcc version 4.4.3 (Ubuntu 4.4.3-4ubuntu5) "
