#define UTS_RELEASE "2.6.34.1-vortex86-sg"
