#ifndef VIDEOCOLORENHANCEPAGE_H
#define VIDEOCOLORENHANCEPAGE_H
#include <QtGui>
#include <QWidget>
#include <QList>
#include "GlobalVars.h"

class QLabel ;
class QSlider ;
class QPushButton ;
class QStringList ;
class QVBoxLayout ;
class QHBoxLayout ;

class VideoColorEnhancePage : public QWidget
{
	Q_OBJECT

	signals :
		void changeToWidget(int) ;
		void defaultSet() ;

	public slots :
		void processWidgetChange() ;
		void setToDefault() ;
		void updateHue() ;
        void updateSaturation() ;
        void updateBrightness() ;
        void updateContrast();

	public :
		VideoColorEnhancePage(QWidget *parent=0) ;
		~VideoColorEnhancePage() ;

	private :
		// ui components.
		QLabel		*title ;
		QLabel		*sliderDesc[4] ; // description for brightness, contrast and gamma.
		QSlider		*slider[4] ; // slider for brightness, contrast and gamma.
		QLabel      *explain;
		QPushButton	*restoreBtn;

		// Data
		QStringList VideoDesc;
		QList<int> VideoDescValue;

        // Pointer to AppSetting.
		int *piHue;
        int *piSaturation;
        int *piBright;
        int *piContrast;

		// layout managers.
		QVBoxLayout	*Layout;
    	QHBoxLayout *SliderLayout[4];
    	QVBoxLayout *SliderGrpLayout;
} ;

#endif
