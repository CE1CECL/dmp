#include "CrtSetting.h"
#include "math.h"
#include "setting.h"

// -----------------------------------------------------------------------------
// Global variable.
// -----------------------------------------------------------------------------
extern setting AppSetting ; // Declare in qtMain.cpp

CrtSetting::CrtSetting(QWidget *parent) : QWidget(parent)
{    
    // Assign pointer
	pbBrightness = &AppSetting.CRT.bBrightness;
	pbContrast = &AppSetting.CRT.bContrast;
	pbGamma = &AppSetting.CRT.bGamma;

	//
	// init. data
	//
	crtSettingDesc<<tr("Brightness :")<<tr("Contrast :")<<tr("Gamma :") ;
    crtSettingDescValue<<*pbBrightness<<*pbContrast<<*pbGamma;
	
	tbl = (GammaTbl *) malloc(4*sizeof(DWORD) + 2*sizeof(USHORT) + sizeof(UCHAR)*256*4) ; // store Gamma table.
	// Initialization Gamma table.
 	tbl->device = B_CRT ; // For CRT.
	tbl->dwSize = sizeof(VIDEO_CLUT) + (sizeof(UCHAR)*4*256) ;
	int size = sizeof(DWORD) ;
	tbl->table = (PVIDEO_CLUT) (((BYTE*)tbl)+3*size) ; 
	tbl->table->FirstEntry = 0 ;
	tbl->table->NumEntries = 256 ;
	initGamaTbl(tbl) ;
	qDebug("[RDC Utility] : tbl ptr is %X", (int)tbl) ;

	//
	// init. ui components.
	//
	crtDesc = new QLabel(tr("CRT Setting :")) ;

	gaCurveLabel = new QLabel(this) ;
	gaCurvePixmap = new QPixmap(120, 120) ;
	gaCurvePixmap->fill() ;
	gaCurveLabel->setPixmap(*gaCurvePixmap) ;

	for (int i=0 ; i<3 ; i++)
	{
		sliderDesc[i]	= new QLabel(crtSettingDesc.at(i), this) ;
		slider[i]	= new QSlider(Qt::Horizontal, this) ;
		slider[i]->setMinimum(CRTSLIDER_MIN) ;
		slider[i]->setMaximum(CRTSLIDER_MAX) ;
		slider[i]->setValue(crtSettingDescValue.at(i)) ;
	} ;

	restoreBtn	= new QPushButton(tr("Restore"), this) ;
	okBtn		= new QPushButton(tr("Ok"), this) ;

	//
	// layout managers.
	//
	layout	= new QVBoxLayout(this) ;

	sliderArea = new QVBoxLayout() ;
	for (int j=0 ; j<3 ; j++)
	{
		sliderLayout[j]	= new QHBoxLayout() ;
		sliderLayout[j]->addWidget(sliderDesc[j], 1, Qt::AlignTop) ;
		sliderLayout[j]->addWidget(slider[j], 5, Qt::AlignTop) ;
		sliderArea->addLayout(sliderLayout[j], 1) ;
	} ;

	curveLayout = new QVBoxLayout() ;
	curveLayout->addWidget(gaCurveLabel, 1, Qt::AlignVCenter) ;
	curveLayout->addSpacing(20) ;

	middleLayout = new QHBoxLayout() ;
	middleLayout->addLayout(curveLayout, 1) ;
	middleLayout->addLayout(sliderArea, 5) ;

	btnLayout	= new QHBoxLayout() ;
	btnLayout->addWidget(restoreBtn) ;
	btnLayout->addWidget(okBtn) ;

	layout->addWidget(crtDesc, 1, Qt::AlignTop) ;
	layout->addLayout(middleLayout, 4) ;
	layout->addLayout(btnLayout) ;

	//
	// connect signal and slot.
	//
	connect(okBtn, SIGNAL(clicked()), this, SLOT(processWidgetChange())) ;
	connect(restoreBtn, SIGNAL(clicked()), this, SLOT(setToDefault())) ;
	for (int i=0 ; i<3 ; i++)
		connect(slider[i], SIGNAL(valueChanged(int)), this, SLOT(updateGammaCurve())) ;

    // Update gamma curve
    updateGammaCurve();
} ;

CrtSetting::~CrtSetting()
{

} ;

void CrtSetting::processWidgetChange()
{
	emit changeToWidget(0) ;
} ;

void CrtSetting::setToDefault()
{
	slider[0]->setValue(CRTSLIDER_DEFAULT_VALUE);
	slider[1]->setValue(CRTSLIDER_DEFAULT_VALUE);
	slider[2]->setValue(CRTSLIDER_DEFAULT_VALUE);
	
    emit defaultSet() ;
} ;

void CrtSetting::updateGammaCurve(void)
{
	// init.
	double Bright, Contrast, Gamma;
	
	*pbBrightness = Bright = slider[0]->value() ;
	*pbContrast = Contrast = slider[1]->value() ;
	*pbGamma = Gamma = slider[2]->value() ;
	
	QPainter painter(gaCurvePixmap) ;
	QPen pen(Qt::black, 3, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
	QBrush brush(Qt::white);
	int width = 120 ;
	int height = 120 ;
	int origx = 0 ;
	int origy = 119 ;
	int nextx = origx ;
	int nexty = origy ;

	qDebug("[RDC Utility] : Bright : %g, Contrast : %g, Gamma : %g", Bright, Contrast, Gamma) ;

	// Set new gamma value
	SetNewGamma(Gamma/100, Bright/100, Contrast/100, tbl) ;
	UT_SetGamma(tbl) ; // Set new gamma into hw.

	// Update gamma curve	
	painter.setPen(pen);
	painter.setBrush(brush);
    painter.drawRect(QRect(0, 0, 119, 119));
	
	for (int i=0 ; i<256 ; i++)
	{
		origx = nextx ;
		origy = nexty ;
		nextx = ((double)i/256)*width ;
		nexty = 120 - ((double)(tbl->table->LookupTable[i].RgbArray.Red)/256)*(double)height ;

		if (nextx >= 120)
			nextx = 119 ;

		if (nexty <= 120)
			120 ;

		painter.drawLine(origx, origy, nextx, nexty) ;
	} ;
	painter.end() ;

	// update pixmap.
	gaCurveLabel->setPixmap(*gaCurvePixmap) ;
} ;

void CrtSetting::initGamaTbl(GammaTbl *gamatbl)
{	
	for (int i=0 ; i<256 ; i++)
	{
		gamatbl->table->LookupTable[i].RgbArray.Red = i ;
		gamatbl->table->LookupTable[i].RgbArray.Green = i ;
		gamatbl->table->LookupTable[i].RgbArray.Blue = i ;
		gamatbl->table->LookupTable[i].RgbArray.Unused = 0 ;
	} ;
} ;

void CrtSetting::SetNewGamma(float flGamma, float flBright, float flContrast, GammaTbl *gammaTbl)
{
    qDebug("[RDC Utility] : Enter SetNewGamma") ;
    
	double	dbIndex = 0.0;
	double	dbRampValue = 0.0;
	double	dbTempContrast = 0.0;
	float	flNewGamma = 0.0 ;
	int	nTemp = 0;
	int	nBright = 0;
	int	nContrast = 0;

	for (int i=0 ; i<256 ; i++)
	{
		dbIndex = ( (double)i ) / 255.0 ;

		if ( flGamma > 1.0f )
		{
			flNewGamma = (( flGamma - 1.0f ) * 2.0f ) + 1.0f;
		}
		else
		{
			flNewGamma = flGamma;
		}
		dbRampValue = pow( dbIndex, 1.0 / (double)flNewGamma ) * 255.0;

		nTemp = (int) ( dbRampValue + 0.005 );

		dbTempContrast	= (double)(( flContrast - 1.0 ) * 150.0 );
		nContrast	= (int) ( ( ((double) i ) / 255.0 ) * dbTempContrast );
		nTemp		= nTemp + nContrast;

		nBright = (int)(( flBright - 1.0 ) * 150.0 );
		nTemp = nTemp + nBright;

		if (nTemp > 255)
			nTemp = 255 ;
		else if (nTemp < 0)
			nTemp = 0 ;

		gammaTbl->table->LookupTable[i].RgbArray.Red	= 
		gammaTbl->table->LookupTable[i].RgbArray.Green	= 
		gammaTbl->table->LookupTable[i].RgbArray.Blue	= nTemp ;
		gammaTbl->table->LookupTable[i].RgbArray.Unused	= 0 ;
	} ;

	qDebug("[RDC Utility] : Leave SetNewGamma") ;
} ;
