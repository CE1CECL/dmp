#ifndef LCDSETTING_H
#define LCDSETTING_H
#include <QtGui>
#include <QWidget>
#include "GlobalVars.h"
#include "Escape.h"

class QSlider ;
class QPushButton ;
class QVBoxLayout ;
class QHBoxLayout ;

class LcdSetting : public QWidget
{
	Q_OBJECT

	signals :
		void changeToWidget(int) ;
		void alignedTick(int) ;
		void defaultSet() ;
		void pwmLevelSet(int) ;

	public slots :
		void processWidgetChange() ;
		void makeAlignTick(int) ;
		void setToDefault() ;
		void setPWMLevel(int) ;

	public :
		LcdSetting(QWidget *parent=0) ;
		~LcdSetting() ;

	private :
		// ui components.
		QLabel		*pwmDesc ;
		QLabel      *brightDesc, *darkDesc;
		QSlider		*pwmSlider ;
		QPushButton	*defaultBtn ;
		QPushButton	*okBtn ;

		// Pointer to global AppSetting.
		int *piPwm;

		// layout managers.
		QVBoxLayout	*layout ;
		QHBoxLayout *descLayout;
		QVBoxLayout *midLayout;
		QHBoxLayout	*btnLayout ;
} ;

#endif

