#ifndef PARAMETER_H
#define PARAMETER_H

// -----------------------------------------------------------------------------
// Parameter definition (ASCII)
// -----------------------------------------------------------------------------
#define PARA_SWITCH       "-switch"
#define PARA_SRT_SWITCH   "-s"
#define PARA_RESTROE_DLG  "-confirm"
#define PARA_HELP         "-help"
#define PARA_SRT_HELP     "-h"
#define PARA_VERSION      "-version"
#define PARA_SRT_VERSION  "-v"
#define PARA_ACT_DEVICE   "-actdev"
#define PARA_CON_DEVICE   "-condev"
#define PARA_CUR_MODE     "-curmode"

// -----------------------------------------------------------------------------
// Parameter definition (Regular express version)
// -----------------------------------------------------------------------------
#define PARA_REG_SWITCH       "-[sS][wW][iI][tT][cC][hH]"
#define PARA_REG_SRT_SWITCH   "-[sS]"
#define PARA_REG_RESTROE_DLG  "-[cC][oO][nN][fF][iI][rR][mM]"
#define PARA_REG_CRT          "[cC][rR][tT]"
#define PARA_REG_LCD          "[lL][cC][dD]"
#define PARA_REG_TV           "[tT][vV]"
#define PARA_REG_HELP         "-[hH][eE][lL][pP]"
#define PARA_REG_SRT_HELP     "-[hH]"
#define PARA_REG_VERSION      "-[vV][eE][rR][sS][iI][oO][nN]"
#define PARA_REG_SRT_VERSION  "-[vV]"
#define PARA_REG_ACT_DEVICE   "-[aA][cC][tT][dD][eE][vV]"
#define PARA_REG_CON_DEVICE   "-[cC][oO][nN][dD][eE][vV]"
#define PARA_REG_CUR_MODE     "-[cC][uU][rR][mM][oO][dD][eE]"

#endif
