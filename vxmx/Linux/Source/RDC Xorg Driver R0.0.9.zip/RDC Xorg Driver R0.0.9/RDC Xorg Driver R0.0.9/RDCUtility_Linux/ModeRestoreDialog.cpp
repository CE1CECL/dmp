#include "ModeRestoreDialog.h"

// Global variable.
extern setting AppSetting ;

ModeRestoreDialog::ModeRestoreDialog(QWidget *parent) : QDialog(parent)
{
    // Init. string
    sprintf(MsgBuf, "Do you want to keep this resolution?\nTesting the new settings. If you don't repsond in 20 seconds the previous settings will be restored.");
    
    Message     = new QLabel(MsgBuf);
	restoreBtn	= new QPushButton(tr("Use previous resolution"), this) ;
	okBtn		= new QPushButton(tr("Keep resolution"), this) ;
	timer       = new QTimer();

	timer->setInterval(1000); // 1 second interval.

	//
	// layout managers.
	//
	layout	= new QVBoxLayout(this) ;
	BtnLayout = new QHBoxLayout();

	BtnLayout->addWidget(restoreBtn);
	BtnLayout->addWidget(okBtn);

	layout->addWidget(Message);
	layout->addLayout(BtnLayout);

	//
	// connect signal and slot.
	//
	connect(okBtn, SIGNAL(clicked()), this, SLOT(Keep())) ;
	connect(restoreBtn, SIGNAL(clicked()), this, SLOT(Restore())) ;
	connect(timer, SIGNAL(timeout()), this, SLOT(CountDown())) ;
} ;

ModeRestoreDialog::~ModeRestoreDialog()
{

}

void ModeRestoreDialog::Keep()
{
    // Stop count down;
    timer->stop();
    qDebug("[RDC Utility] : Timer stop") ;

    done(TRUE);

    emit Kept();
} ;

void ModeRestoreDialog::Restore()
{
    qDebug("[RDC Utility] : Enter ModeRestoreDialog::Restore()") ;

    // Stop count down;
    timer->stop();
    qDebug("[RDC Utility] : Timer stop") ;
    
    //
	// Show dialog if user click restore. Restore to previous mode and device.
	//
	XRRScreenSize size;
	UTDEVICELIST actDevice;

	size = AppSetting.GetPreviousModeDim();
	actDevice = AppSetting.GetPreviousDev();
	qDebug("[RDC Utility] : actDevice.MERGE = %d", actDevice.MERGE) ;
	UtilSetMode(actDevice, size.width, size.height);

    // Terminate dialog with FALSE.    
	done(FALSE);

    emit Restored();
}

void ModeRestoreDialog::CountDown()
{
    if (iPeriod >= 0)
    {
        sprintf(MsgBuf, "Do you want to keep this resolution?\nTesting the new settings. If you don't repsond in %d seconds \nthe previous settings will be restored.", iPeriod--);
        Message->setText(MsgBuf);
    }
    else
    {
        Restore();
    };
}

int ModeRestoreDialog::exec()
{    
    qDebug("[RDC Utility] : Enter ModeRestoreDialog::exec()") ;
    
    iPeriod = 20; // 20 seconds
	timer->start();
	qDebug("[RDC Utility] : Timer start") ;
    
    return QDialog::exec();
};
