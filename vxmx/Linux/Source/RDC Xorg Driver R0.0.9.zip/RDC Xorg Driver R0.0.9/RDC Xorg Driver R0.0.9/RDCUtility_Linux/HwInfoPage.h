#ifndef HWINFOPAGE_H
#define HWINFOPAGE_H
#include <QtGui>
#include <QWidget>

class QGroupBox ;
class QLabel ;
class QVBoxLayout ;

class HwInfoPage : public QWidget
{
	public :
		HwInfoPage() ;
		~HwInfoPage() ;    

	private :
		// ui components.
		QGroupBox	*hwinfoGB ;
		QGroupBox	*biosVerGB ;
		QGroupBox	*videoMemGB ;
		QGroupBox	*clockGB ;
		QLabel		*hwinfoLabel[3] ;
		QLabel		*biosVerLabel ;
		QLabel		*videoMemLabel ;
		QLabel		*clockLabel[2] ;

		// layout managers.
		QVBoxLayout	*layout ;
		QVBoxLayout	*hwinfoGBLayout ;
		QVBoxLayout *biosVerGBLayout ;
		QVBoxLayout *videoMemGBLayout ;
		QVBoxLayout *clockGBLayout ;
} ;

#endif
