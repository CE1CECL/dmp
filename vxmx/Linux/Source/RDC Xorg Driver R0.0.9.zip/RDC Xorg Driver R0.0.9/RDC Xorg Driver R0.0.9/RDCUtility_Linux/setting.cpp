#include "setting.h"
#include <stdio.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>

// -----------------------------------------------------------------------------
// constructor of class setting
// Initialization.
// -----------------------------------------------------------------------------
setting::setting()
{
    // Initialize to default value.
    SetToBuildinDefault();
    
    // Reading setting file and load into class.
    // If there is a config file, value will be override by this.
    //LoadSetting();
    
	//
	// Initial member variables.
	// 
	dualMode = false ;

	// Check device display number capability
	GetRDCDeviceCaps() ;
	if (dwCaps && CAPS_ONE_DISPLAY)
		iMaxSelected = MAX_1_SELECTED ;
	else
		iMaxSelected = MAX_2_SELECTED ;

	// new tabP1rbtn array.
	tabP1rbtn = new ddstatus[iMaxSelected] ;

	// init tabP1rbtn member
	for (int i=0 ; i<iMaxSelected ; i++)
	{
		tabP1rbtn[i].id = 0 ;	// init id to be NULL
		tabP1rbtn[i].last = false ;	// init last to be false ;
	} ;
} ;

// -----------------------------------------------------------------------------
// destructor of class setting
// -----------------------------------------------------------------------------
setting::~setting()
{
    // Save value back to CONFIG_FILE
    //DumpToConfig();

	delete [] tabP1rbtn ;
} ;

// -----------------------------------------------------------------------------
// DumpToConfig()
// Save to config file.
// -----------------------------------------------------------------------------
int setting::DumpToConfig()
{
    FILE *pfd;
    long size;
    char *pContent;
    char szBuf[64];

    pfd = fopen(CONFIG_PATH, "w+");

    // Display device
    fprintf(pfd, "[%s]\n", DSPDEV_SECTION);
    fprintf(pfd, "%s=%d;\n", DSPDEV_ACTIVE, ActDevicelist.MERGE);
    fprintf(pfd, "%s=%d;\n", DSPDEV_ACT_WIDTH, iScrWidth);
    fprintf(pfd, "%s=%d;\n\n", DSPDEV_ACT_HEIGHT, iScrHeight);

    // CRT
    fprintf(pfd, "[%s]\n", CRT_SECTION);
    fprintf(pfd, "%s=%d;\n", CRT_BRIGHT, CRT.bBrightness);
    fprintf(pfd, "%s=%d;\n", CRT_CONTRAST, CRT.bContrast);
    fprintf(pfd, "%s=%d;\n\n", CRT_GAMMA, CRT.bGamma);
    
    // LCD
    fprintf(pfd, "[%s]\n", LCD_SECTION);
    fprintf(pfd, "%s=%d;\n\n", LCD_PWM, LCD.iPwm);

    // TV
    fprintf(pfd, "[%s]\n", TV_SECTION);
    fprintf(pfd, "%s=%d;\n", TV_TYPE, TV.info.wType);
    fprintf(pfd, "%s=%d;\n", TV_CONTYPE, TV.info.bConnector);
    fprintf(pfd, "%s=%d;\n", TV_BRIGHT, TV.bBrightness);
    fprintf(pfd, "%s=%d;\n", TV_CONTRAST, TV.bContrast);
    fprintf(pfd, "%s=%d;\n", TV_GAMMA, TV.bGamma);
    fprintf(pfd, "%s=%d;\n\n", TV_CCRS, TV.bCCRS);

    // Video color enhancement
    fprintf(pfd, "[%s]\n", VIDCOL_SECTION);
    fprintf(pfd, "%s=%d;\n", VID_HUE, VColorEnhance.iHue);
    fprintf(pfd, "%s=%d;\n", VID_SATU, VColorEnhance.iSaturation);
    fprintf(pfd, "%s=%d;\n", VID_BRIGHT, VColorEnhance.iBrightness);
    fprintf(pfd, "%s=%d;\n\n", VID_CONTRAST, VColorEnhance.iContrast);
    
    fclose (pfd);

    return true;
};

// -----------------------------------------------------------------------------
// SetToBuildinDefault()
// -----------------------------------------------------------------------------
int setting::SetToBuildinDefault()
{
    // CRT
    CRT.bBrightness = CRT_BRIGHT_DEFAULT;
    CRT.bContrast   = CRT_CONTRAST_DEFAULT;
    CRT.bGamma      = CRT_GAMMA_DEFAULT;

    // LCD
    LCD.iPwm        = LCD_PWM_DEFAULT;

    // TV
    TV.info.wType   = TV_TYPE_DEFAULT;
    TV.info.bConnector = TV_CONNECTOR_DEFAULT;
    TV.bBrightness  = TV_BRIGHT_DEFAULT;
    TV.bContrast    = TV_CONTRAST_DEFAULT;
    TV.bGamma       = TV_GAMMA_DEFAULT;
    TV.bCCRS        = TV_CCRS_DEFAULT;

    // Video color enhancement
    VColorEnhance.iBrightness = VIDEO_BRIGHT_DEFAULT;
    VColorEnhance.iContrast   = VIDEO_CONTRAST_DEFAULT;
    VColorEnhance.iHue        = VIDEO_HUE_DEFAULT;
    VColorEnhance.iSaturation = VIDEO_SATURATION_DEFAULT;

    return true;
};

// -----------------------------------------------------------------------------
// LoadSetting
// -----------------------------------------------------------------------------
int setting::LoadSetting()
{
    int fd;
    mode_t mode;
    long size;
    char *pContent;

    mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;

    // Test /etc/RDC is exist?
    if (!opendir(CONFIG_DIR))
    {
        if (errno == ENOENT)
        {
            if (mkdir(CONFIG_DIR, mode) == -1)
            {
                qDebug("[RDC Utility] : Create directory fail!");
                return false;
            };
        };
    };

    // Exist! open config file.
    fd = open(CONFIG_PATH, O_CREAT, mode);

    // Open file fail.
	if (fd == -1)
	{
	    qDebug("[RDC Utility] : Open config file fail!");
		return false;
    };

	// Get file size
	size = lseek(fd, 0, SEEK_END);
	lseek(fd, 0, SEEK_SET);

	// Allocate larger memory to store content.
	// Because we replace ';' with 2 '\0' and it will overflow in some case.
	pContent = new char[2*size];

	// Read content.
	read(fd, pContent, size);

	// Parse and fire command
	ParseCfgFile(pContent, size);

	// Release handle and memory.
	close(fd);
	delete pContent;

	return true;
};

// -----------------------------------------------------------------------------
// ParseCfgFile
// -----------------------------------------------------------------------------
int setting::ParseCfgFile(char *ptr, long size)
{
    char *pszCurToken;	    // Current token indicator
    char *SecName;
    char *pszToken, *pszValue;
    int iTokenToBufLen = 0;	// The amount of all token length, not > lsize

    // Phase 1 : Remove comments
	CommentRemover(ptr, size, '#');

	// Phase 2 : Remove space characters. (' ', '\t', '\n' ... etc)
	SpaceRemover(ptr, size);

	// Phase 3 : Replace '=' with '\0' and ';' with '\0''\0'
	SeperateToken(ptr, size);

	// Phase 4 : Make all lower case to upper case.
	for (int i=0 ; i<size ; i++)
	{
        if (isalpha(ptr[i]))
            ptr[i] = toupper(ptr[i]);
	};

	// Phase 5 :
	for (int j=0 ; j<size ; j++)
	{
        if (ptr[j] == ']')
            ptr[j] = '\0';
	};

	// Phase 6 : Parsing keyword and value of one section in every iteration.
	pszCurToken = ptr;
	while (iTokenToBufLen < size)
	{
	    // Every section must start with "[....]"
	    if (pszCurToken[0] == '[')
	    {
	        SecName = new char[strlen(pszCurToken)];
	        strcpy(SecName, pszCurToken+1); // Skip '['
            //ReplaceChar(SecName, ']', '\0');
	    }
	    else
	    {
	        printf("Statment is not correct!\n");
			return false;
	    };
	        
		// pointer to next token (the arguments).
		iTokenToBufLen += strlen(pszCurToken) + 1;
		pszCurToken += strlen(pszCurToken) + 1;

        // If the section is empty, continue it. Otherwise process members.
		while (pszCurToken[0] != '[')
		{
		    if (iTokenToBufLen >= size)
		        break;
		        
            // Process section member.
            pszToken = pszCurToken;
   			iTokenToBufLen += strlen(pszCurToken) + 1;
   			pszCurToken += strlen(pszCurToken) + 1;
   			pszValue = pszCurToken;

   			ParseLine(SecName, pszToken, pszValue);

    	   	// If the next token is not zero string, error occured.
    		// zero string means ';' reached.
    		iTokenToBufLen += strlen(pszCurToken) + 1;
   			pszCurToken += strlen(pszCurToken) + 1;
    		if (!strcmp(pszCurToken,""))
    		{
    			pszCurToken += 1;
    			iTokenToBufLen += 1; // for two '\0'
    			//iTokenToBufLen += strlen(pszCurToken) + 1;
    		}
    		else
    		{
    			printf("Argument count is not correct!\n");
    			return false;
    		};
		};

		// Release memory.
    		delete SecName;

        qDebug("[RDC Utility] : Current section is %s", SecName);
		qDebug("[RDC Utility] : iTokenToBufLen, size : %d, %d", iTokenToBufLen ,size);
	};	
};

// -----------------------------------------------------------------------------
// CommentRemover
// -----------------------------------------------------------------------------
int setting::CommentRemover(char *pBuffer, long &lsize, char keyword)
{
	char *pszNoCommentBuf = new char[lsize];
	long lNewSize = 0;
	bool bEncounterComment = false;

	// Remove comment.
	for (int i=0 ; i<lsize ; i++)
	{
		// Encounter the comment leading word.
		if (pBuffer[i] == keyword)
		{
			bEncounterComment = true;
			continue;
		};

		// When reach '\n' means the end of comment.
		if (pBuffer[i] == '\n' && bEncounterComment)
		{
			bEncounterComment = false;
			continue;
		};

		if (bEncounterComment)
			continue;
		else
		{
			pszNoCommentBuf[lNewSize] = pBuffer[i];
			lNewSize++;
		};
	};

	// Copy modified content back to original buffer.
	for (int j=0 ; j<lNewSize ; j++)
		pBuffer[j] = pszNoCommentBuf[j];

	lsize = lNewSize;

	// Release memory.
	delete pszNoCommentBuf;

	return true;
};

// -----------------------------------------------------------------------------
// SpaceRemover
// -----------------------------------------------------------------------------
int setting::SpaceRemover(char *pBuffer, long &lsize)
{
	char *pszNoSpaceBuf = new char[lsize];
	long lNewSize = 0;

	// Remove space.
	for (int i=0 ; i<lsize ; i++)
	{
		if (pBuffer[i] == ' ' || pBuffer[i] == '\t' || pBuffer[i] == '\n')
			continue;
		else
		{
			pszNoSpaceBuf[lNewSize] = pBuffer[i];
			lNewSize++;
		};
	};

	// Copy modified content back to original buffer.
	for (int j=0 ; j<lNewSize ; j++)
		pBuffer[j] = pszNoSpaceBuf[j];

	lsize = lNewSize;

	// Release memory.
	delete pszNoSpaceBuf;

	return true;
};

// -----------------------------------------------------------------------------
// SeperateToken
// -----------------------------------------------------------------------------
int setting::SeperateToken(char *pBuffer, long &lsize)
{
	// Result may be slightly greater than original buffer.
	// So we give it twice size of original buffer.
	char *pszNewBuf = new char[2*lsize];
	long lNewSize = 0;

	// Remove space.
	for (int i=0 ; i<lsize ; i++)
	{
		// '=' case
		if (pBuffer[i] == '=')
		{
			pszNewBuf[lNewSize] = '\0';
			lNewSize++;
			continue;
		};
		
		// ';' case
		if (pBuffer[i] == ';')
		{
			pszNewBuf[lNewSize] = '\0';
			lNewSize++;
			pszNewBuf[lNewSize] = '\0';
			lNewSize++;
			continue;
		};

		// Normal case
		pszNewBuf[lNewSize] = pBuffer[i];
		lNewSize++;
	};

	// Copy modified content back to original buffer.
	for (int j=0 ; j<lNewSize ; j++)
		pBuffer[j] = pszNewBuf[j];

	lsize = lNewSize;

	// Release memory.
	delete pszNewBuf;

	return true;
};

// --------------------------------------------------------------------
// ReplaceChar()
// Replace OrgWord with NewWord.
// --------------------------------------------------------------------
int setting::ReplaceChar(char *pszStr, char OrgWord, char NewWord)
{
    int uiCount = 0;
    int size = strlen(pszStr);
    
    for (int i=0 ; i<size ; i++)
    {
        if (pszStr[i] == OrgWord)
        {
            pszStr[i] = NewWord;
            uiCount++;
        };
    };

    return uiCount;
};

// -----------------------------------------------------------------------------
// ParseLine()
// New settings need to add in this function.
//
// char *pszSection : Section name.
// char *pszToken   : Item name.
// char *pszValue   : Item value.
// -----------------------------------------------------------------------------
int setting::ParseLine(char *pszSection, char *pszToken, char *pszValue)
{
    qDebug("[RDC Utility] : Enter ParseLine()") ;
    qDebug("[RDC Utility] : [%s] %s = %s", pszSection, pszToken, pszValue) ;

    // Display device
    if (!strcmp(pszSection, DSPDEV_SECTION))
    {
        if (!strcmp(pszToken, DSPDEV_ACTIVE))
            ActDevicelist.MERGE = atoi(pszValue);

        if (!strcmp(pszToken, DSPDEV_ACT_WIDTH))
            iScrWidth = atoi(pszValue);

        if (!strcmp(pszToken, DSPDEV_ACT_HEIGHT))
            iScrHeight = atoi(pszValue);
    };
    
    // CRT
    if (!strcmp(pszSection, CRT_SECTION))
    {
        if (!strcmp(pszToken, CRT_BRIGHT))
            CRT.bBrightness = atoi(pszValue);

        if (!strcmp(pszToken, CRT_CONTRAST))
            CRT.bContrast= atoi(pszValue);

        if (!strcmp(pszToken, CRT_GAMMA))
            CRT.bGamma = atoi(pszValue);
    };

    // LCD
    if (!strcmp(pszSection, LCD_SECTION))
    {
        if (!strcmp(pszToken, LCD_PWM))
            LCD.iPwm = atoi(pszValue);
    };

    // TV
    if (!strcmp(pszSection, TV_SECTION))
    {
        if (!strcmp(pszToken, TV_TYPE))
            TV.info.wType = atoi(pszValue);

        if (!strcmp(pszToken, TV_CONTYPE))
            TV.info.bConnector = atoi(pszValue);
    
        if (!strcmp(pszToken, TV_BRIGHT))
            TV.bBrightness = atoi(pszValue);

        if (!strcmp(pszToken, TV_CONTRAST))
            TV.bContrast = atoi(pszValue);

        if (!strcmp(pszToken, TV_GAMMA))
            TV.bGamma = atoi(pszValue);

        if (!strcmp(pszToken, TV_CCRS))
            TV.bCCRS = atoi(pszValue);
    };

    // Video color enhancement
    if (!strcmp(pszSection, VIDCOL_SECTION))
    {
        if (!strcmp(pszToken, VID_HUE))
            VColorEnhance.iHue = atoi(pszValue);

        if (!strcmp(pszToken, VID_SATU))
            VColorEnhance.iSaturation = atoi(pszValue);

        if (!strcmp(pszToken, VID_BRIGHT))
            VColorEnhance.iBrightness = atoi(pszValue);

        if (!strcmp(pszToken, VID_CONTRAST))
            VColorEnhance.iContrast = atoi(pszValue);
    };

    qDebug("[RDC Utility] : Leave ParseLine()") ;
    
    return true;
};

// -----------------------------------------------------------------------------
// chkDualMode()
// -----------------------------------------------------------------------------
bool setting::chkDualMode(void)
{
	//dualMode = UT_QuerySamm() ; // Not implement yet.

	return dualMode ;
} ;

// -----------------------------------------------------------------------------
// chkSupportDspDevice()
// -----------------------------------------------------------------------------
bool setting::chkSupportDspDevice(void)
{
	UT_QuerySupportDevice(&lpDeviceList) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// supportDspDevice()
// -----------------------------------------------------------------------------
UTDEVICELIST setting::supportDspDevice(void)
{
	return lpDeviceList ;
} ;

// -----------------------------------------------------------------------------
// chkConnectedDspDevice()
// -----------------------------------------------------------------------------
bool setting::chkConnectedDspDevice(void)
{
	UT_QueryConnectDevice(&lpDeviceConnectedList) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// connectDspDevice()
// -----------------------------------------------------------------------------
UTDEVICELIST setting::connectDspDevice(void)
{
	return lpDeviceConnectedList ;
} ;

// -----------------------------------------------------------------------------
// chkActiveDspDevice
// -----------------------------------------------------------------------------
bool setting::chkActiveDspDevice(void)
{
	 UT_QueryActDevice(&lpDeviceActiveList) ;

	return true ;
};

// -----------------------------------------------------------------------------
// activeDspDevice
// -----------------------------------------------------------------------------
UTDEVICELIST setting::activeDspDevice(void)
{
	return lpDeviceActiveList ;
};

// -----------------------------------------------------------------------------
// convertMergeToID()
// -----------------------------------------------------------------------------
bool setting::convertMergeToID(UTDEVICELIST merge, int *actBtn, int num)
{

	int i = 0 ;
	if (merge.MERGE & 1)
	{
		if (num != 0)
		{
			actBtn[i] = IDB_RLCD ;
			num-- ;
			i++ ;
		} ;
	} ;
	if (merge.MERGE & 2)
	{
		if (num != 0)
		{
			actBtn[i] = IDB_RDVI ;
			num-- ;
			i++ ;
		} ;
	} ;
	if (merge.MERGE & 4)
	{
		if (num != 0)
		{
			actBtn[i] = IDB_RCRT ;
			num-- ;
			i++ ;
		} ;
	} ;
	if (merge.MERGE & 8)
	{
		if (num != 0)
		{
			actBtn[i] = IDB_RHDMI ;
			num-- ;
			i++ ;
		} ;
	} ;
	if (merge.MERGE & 16)
	{
		if (num != 0)
		{
			actBtn[i] = IDB_RHDTV ;
			num-- ;
			i++ ;
		} ;
	} ;
	if (merge.MERGE & 32)
	{
		if (num != 0)
		{
			actBtn[i] = IDB_RTV ;
			num-- ;
			i++ ;
		} ;
	} ;

	for (int j=0 ; j<num ; j++)
	{
		tabP1rbtn[j].id = actBtn[j] ;
		if (j == (num-1))
			tabP1rbtn[j].last = true ;
		else
			tabP1rbtn[j].last = false ;
	} ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// getMergeValue()
// -----------------------------------------------------------------------------
WORD setting::getMergeValue(void)
{
	int merge, dd1, dd2 ;
	merge = dd1 = dd2 = 0 ;

	for (int i=0 ; i<iMaxSelected ; i++)
	{
		int tmp = 0 ;
		if (tabP1rbtn[i].id == IDB_RCRT)
			tmp = 4 ;
		else if (tabP1rbtn[i].id == IDB_RLCD)
			tmp = 1 ;
		else if (tabP1rbtn[i].id == IDB_RTV)
			tmp = 32 ;
		else if (tabP1rbtn[i].id == IDB_RHDTV)
			tmp = 16 ;
		else if (tabP1rbtn[i].id == IDB_RDVI)
			tmp = 2 ;
		else if (tabP1rbtn[i].id == IDB_RHDMI)
			tmp = 8 ;

		if (i == 0)
			dd1 = tmp ;
		else
			dd2 = tmp ;
	} ;
	merge = dd1 | dd2 ;

	return merge ;
} ;

// -----------------------------------------------------------------------------
// getSupportDspDeviceNum()
// -----------------------------------------------------------------------------
int setting::getSupportDspDeviceNum(UTDEVICELIST *dl)
{
	int count = 0 ;

	UTDEVICELIST tmp ;
	if (dl != 0)
		tmp = *dl ;
	else
		tmp = lpDeviceList ;

	if (tmp.MERGE & 1)
		count += 1 ;
	if (tmp.MERGE & 2)
		count += 1 ;
	if (tmp.MERGE & 4)
		count += 1 ;
	if (tmp.MERGE & 8)
		count += 1 ;
	if (tmp.MERGE & 16)
		count += 1 ;
	if (tmp.MERGE & 32)
		count += 1 ;

	numOfdd = count ;

	return numOfdd ;
} ;

// -----------------------------------------------------------------------------
// getConnectDspDeviceNum()
// -----------------------------------------------------------------------------
int setting::getConnectDspDeviceNum(UTDEVICELIST *conDev)
{
	int count = 0 ;

	UTDEVICELIST tmp ;
	if (conDev != 0)
		tmp = *conDev ;
	else
		tmp = lpDeviceConnectedList ;

	if (tmp.MERGE & 1)
		count += 1 ;
	if (tmp.MERGE & 2)
		count += 1 ;
	if (tmp.MERGE & 4)
		count += 1 ;
	if (tmp.MERGE & 8)
		count += 1 ;
	if (tmp.MERGE & 16)
		count += 1 ;
	if (tmp.MERGE & 32)
		count += 1 ;

	numOfCon = count ;

	return numOfCon ;
} ;

// -----------------------------------------------------------------------------
// isDeviceSupported()
// -----------------------------------------------------------------------------
bool setting::isDeviceSupported(int deviceID)
{
	if ((deviceID == IDBC_LCD) && (lpDeviceList.MERGE & B_LCD))
		return true ;
	else if ((deviceID == IDBC_CRT) && (lpDeviceList.MERGE & B_CRT))
		return true ;
	else if ((deviceID == IDBC_TV) && (lpDeviceList.MERGE & B_TV))
		return true ;
	else if ((deviceID == IDBC_DVI) && (lpDeviceList.MERGE & B_DVI))
		return true ;
	else if ((deviceID == IDBC_HDTV) && (lpDeviceList.MERGE & B_HDTV))
		return true ;
	else if ((deviceID == IDB_RHDMI) && (lpDeviceList.MERGE & B_HDMI))
		return true ;
	else
		return false ;
} ;

// -----------------------------------------------------------------------------
// isDeviceConnected()
// -----------------------------------------------------------------------------
bool setting::isDeviceConnected(int deviceID)
{
    qDebug("[RDC Utility] : Enter isDeviceConnected") ;
    
	if ((deviceID == IDBC_LCD) && (lpDeviceConnectedList.MERGE & B_LCD))
		return true ;
	else if ((deviceID == IDBC_CRT) && (lpDeviceConnectedList.MERGE & B_CRT))
		return true ;
	else if ((deviceID == IDBC_TV) && (lpDeviceConnectedList.MERGE & B_TV))
		return true ;
	else if ((deviceID == IDBC_DVI) && (lpDeviceConnectedList.MERGE & B_DVI))
		return true ;
	else if ((deviceID == IDBC_HDTV) && (lpDeviceConnectedList.MERGE & B_HDTV))
		return true ;
	else if ((deviceID == IDB_RHDMI) && (lpDeviceConnectedList.MERGE & B_HDMI))
		return true ;
	else
		return false ;
} ;

// -----------------------------------------------------------------------------
// isDeviceActivated
// -----------------------------------------------------------------------------
bool setting::isDeviceActivated(int deviceID)
{
    qDebug("[RDC Utility] : Enter isDeviceActivated") ;
    qDebug("[RDC Utility] : deviceID = %d", deviceID) ;
    qDebug("[RDC Utility] : lpDeviceActiveList.MERGE = %d", lpDeviceActiveList.MERGE) ;
    
    if ((deviceID == IDBC_LCD) && (lpDeviceActiveList.MERGE & B_LCD))
        return true ;
    else if ((deviceID == IDBC_CRT) && (lpDeviceActiveList.MERGE & B_CRT))
        return true ;
    else if ((deviceID == IDBC_TV) && (lpDeviceActiveList.MERGE & B_TV))
        return true ;
    else if ((deviceID == IDBC_DVI) && (lpDeviceActiveList.MERGE & B_DVI))
        return true ;
    else if ((deviceID == IDBC_HDTV) && (lpDeviceActiveList.MERGE & B_HDTV))
        return true ;
    else if ((deviceID == IDB_RHDMI) && (lpDeviceActiveList.MERGE & B_HDMI))
        return true ;
    else
        return false ;
} ;

// -----------------------------------------------------------------------------
// Maintain the inner struct to represent the status of radio button in 
// Tab Page 1 (Display device).
// -----------------------------------------------------------------------------
int setting::makeJust2Selected(int id)
{
	bool exist = false ;
	int num = 0 ;
	int tmp ;

	// Check if the current pressed radio button is in tabP1rbtn[]
	// if exist, set exist to TRUE and num to the position in tabP1rbtn.
	for (int i=0 ; i<iMaxSelected ; i++)
	{
		if (tabP1rbtn[i].id == id)
		{
			exist = true ;
			num = i ;
		}
	} ;

	if (exist) // exist
	{
		tabP1rbtn[num].id = 0 ;
		tabP1rbtn[num].last = true ;
		if (num == 0)
			tabP1rbtn[iMaxSelected-1].last = false ;
		else
			tabP1rbtn[0].last = false ;

		return id ;
	}
	else  // don't exist.
	{
		if (tabP1rbtn[0].id == 0)
		{
			tabP1rbtn[0].id = id ;
			tabP1rbtn[0].last = false ;
			//tabP1rbtn[1].last = TRUE ;
			tabP1rbtn[iMaxSelected-1].last = true ;
		}
		else
		{
			for (int k=0 ; k<iMaxSelected ; k++)
			{
				if (tabP1rbtn[k].last == true)
				{
					tmp = tabP1rbtn[k].id ;
					tabP1rbtn[k].id = id ;
					tabP1rbtn[k].last = false ;

					if (k == 0)
					{
						//tabP1rbtn[1].last = TRUE ;
						tabP1rbtn[iMaxSelected-1].last = true ;
					}
					else
						tabP1rbtn[0].last = true ;
			
					return tmp ;
				} ;
			} ;
		} ;
	} ;

	return 0 ;
} ;

// -----------------------------------------------------------------------------
// Translate the device into number. 
// -----------------------------------------------------------------------------
int setting::ConverDevintoNum(UTDEVICELIST merge)
{
	int count = 0 ;

	UTDEVICELIST tmp = merge ;

       do{        
        tmp.MERGE>>=1;
        count++;
       }while(tmp.MERGE!=0);

	return (count-1);
}

// -----------------------------------------------------------------------------
// Save the device mode for setting. 
// -----------------------------------------------------------------------------
void setting::SaveCurActDev(UTDEVICELIST merge)
{
    ActDevicelist = merge;
}
// -----------------------------------------------------------------------------
// Save the device mode for setting. 
// -----------------------------------------------------------------------------
UTDEVICELIST setting::QueryCurActDev(void)
{
    UT_QueryActDevice(&ActDevicelist);
    return ActDevicelist;
}

// -----------------------------------------------------------------------------
// GetDeviceCaps()
// -----------------------------------------------------------------------------
int setting::GetRDCDeviceCaps()
{
    UTHWINFO hw_info ;

    // Initial dwCaps to 0
    dwCaps = 0 ; 

    // Get device info
    //UT_QueryHWInfo(&hw_info) ; // not implement yet.

    switch (hw_info.wDeviceID)
    {   
        case M3306_DEVICE_ID :
            dwCaps |= CAPS_ONE_DISPLAY ;
            break ;
    } ; 

	// for debug
    dwCaps |= CAPS_ONE_DISPLAY ;

	return dwCaps ;
} ;

// -----------------------------------------------------------------------------
// SetPreviousDev()
// -----------------------------------------------------------------------------
void setting::SetPreviousDev(UTDEVICELIST devlst)
{
    PreDevLst.MERGE = devlst.MERGE;
}

// -----------------------------------------------------------------------------
// SetPreviousBtn()
// -----------------------------------------------------------------------------
void setting::SetPreviousBtn(UTDEVICELIST devlst)
{
    PreBtn.MERGE = devlst.MERGE;
}

// -----------------------------------------------------------------------------
// GetPreviousDev()
// -----------------------------------------------------------------------------
UTDEVICELIST setting::GetPreviousDev(void)
{
    return PreDevLst;
}

// -----------------------------------------------------------------------------
// GetPreviousDev()
// -----------------------------------------------------------------------------
UTDEVICELIST setting::GetPreviousBtn(void)
{
    return PreBtn;
}

// -----------------------------------------------------------------------------
// SetPreviousMode()
// -----------------------------------------------------------------------------
void setting::SetPreviousMode(int mode)
{
    iPreMode = mode;
}

// -----------------------------------------------------------------------------
// GetPreviousMode()
// -----------------------------------------------------------------------------
int setting::GetPreviousMode(void)
{
    return iPreMode;
}

// -----------------------------------------------------------------------------
// SetPreviousModeDim()
// -----------------------------------------------------------------------------
void setting::SetPreviousModeDim(XRRScreenSize md)
{
    PreModeDim.width = md.width;
    PreModeDim.height = md.height;
}

// -----------------------------------------------------------------------------
// GetPreviousMode()
// -----------------------------------------------------------------------------
XRRScreenSize setting::GetPreviousModeDim(void)
{
    return PreModeDim;
}
