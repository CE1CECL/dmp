#ifndef SETTING_H
#define SETTING_H
#include "GlobalVars.h"
#include "Escape.h"
#include "UtilFunc.h"

#include <QtGlobal>
#include <X11/Xmd.h>
#include <X11/Xlib.h>
#include <X11/Xlibint.h>
#include <X11/extensions/Xrandr.h>

// -----------------------------------------------------------------------------
// Config file
// -----------------------------------------------------------------------------
#define CONFIG_FILE     "utility.conf"
#define CONFIG_DIR      "/etc/RDC/"
#define CONFIG_PATH     "/etc/RDC/utility.conf"

#define GENERAL_SECTION "[GENERAL]"
#define DSPDEV_SECTION  "[DISPLAY DEVICE]"

#define DSPDEV_SECTION  "DSP_DEVICE"
    #define DSPDEV_ACTIVE   "ACTIVE_DEVICE"
    #define DSPDEV_ACT_WIDTH    "ACTIVE_WIDTH"
    #define DSPDEV_ACT_HEIGHT   "ACTIVE_HEIGHT"

#define CRT_SECTION     "CRT"
    #define CRT_BRIGHT      "BRIGHTNESS"
    #define CRT_CONTRAST    "CONTRAST"
    #define CRT_GAMMA       "GAMMA"
    
#define LCD_SECTION     "LCD"
    #define LCD_PWM         "PWM"
    
#define TV_SECTION      "TV"
    #define TV_TYPE         "TYPE"
    #define TV_CONTYPE      "CONNECTORTYPE"
    #define TV_BRIGHT       "BRIGHTNESS"
    #define TV_CONTRAST     "CONTRAST"
    #define TV_GAMMA        "GAMMA"
    #define TV_CCRS         "CCRS"
    
#define HWINFO_SECTION  "HARDWARE INFO"
#define VIDCOL_SECTION  "VIDEO_COLOR_ENHANCEMENT"
    #define VID_HUE         "HUE"
    #define VID_SATU        "SATURATION"
    #define VID_BRIGHT      "BRIGHTNESS"
    #define VID_CONTRAST    "CONTRAST"

// -----------------------------------------------------------------------------
// Tab page 1 : display device
// -----------------------------------------------------------------------------
struct ddstatus
{
	int		id ;		// the id of radio button.
	bool	last ;		// indicate is this is the last selected radio button.
} ;

// -----------------------------------------------------------------------------
// Structure to store info in CRT setting page.
// -----------------------------------------------------------------------------
typedef struct _CRTSetting
{
    BYTE bBrightness;
    BYTE bContrast;
    BYTE bGamma;
} CRTSetting, *pCRTSetting;

// -----------------------------------------------------------------------------
// Structure to store info in TV setting page.
// -----------------------------------------------------------------------------
typedef struct _TVSetting
{
    BYTE bBrightness;
    BYTE bContrast;
    BYTE bGamma;
    BYTE bCCRS;
    TVINFO info;
} TVSetting, *pTVSetting;

// -----------------------------------------------------------------------------
// Structure to store info in LCD setting page.
// -----------------------------------------------------------------------------
typedef struct _LCDSetting
{
    int iPwm;
} LCDSetting, *pLCDSetting;

// -----------------------------------------------------------------------------
// Structure to store info in video color enhance page.
// -----------------------------------------------------------------------------
typedef struct _VideoColorEnhance
{
    int iHue;
    int iSaturation;
    int iBrightness;
    int iContrast;
} VideoColorEnhance, *pVideoColorEnhance;

// -----------------------------------------------------------------------------
// Setting Class
// used to record whole utility setting.
// -----------------------------------------------------------------------------
class setting
{
	public :
		setting() ;
		~setting() ;

		int             LoadSetting();
		int             ParseCfgFile(char *, long);
		int             CommentRemover(char *, long &, char);
		int             SpaceRemover(char *, long &);
		int             SeperateToken(char *, long &);
		int             ReplaceChar(char *, char, char);
		int             ParseLine(char *, char *, char *);
		int             SetToBuildinDefault();
		int             DumpToConfig();
		bool			chkDualMode(void) ;	// check is it in dual mode.
		bool			chkSupportDspDevice(void) ;	// get supported display device.
		UTDEVICELIST	supportDspDevice(void) ;
		bool			chkConnectedDspDevice(void) ;
		UTDEVICELIST	connectDspDevice(void) ;
		bool			chkActiveDspDevice(void);
		UTDEVICELIST	activeDspDevice(void);
		bool			convertMergeToID(UTDEVICELIST, int *, int) ;
		WORD			getMergeValue(void) ;	// make new UTDEVICELIST MERGE to used to set UT_SetPrimaryDevice(WORD MERGE)
		int				getSupportDspDeviceNum(UTDEVICELIST *) ;	// set numOfdd and return number of supported display device.
		int				getConnectDspDeviceNum(UTDEVICELIST *) ;
		bool			isDeviceSupported(int) ;
		bool			isDeviceConnected(int) ;
		bool            isDeviceActivated(int) ;
		int				makeJust2Selected(int) ;	// maintain the inner variable represent the selection condition of radio button.
		//bool			outputToConfig(void) ;	// output the setting to config file.
		int             ConverDevintoNum(UTDEVICELIST merge);// convert for number
        void            SaveCurActDev(UTDEVICELIST merge); // Save act device info.
        UTDEVICELIST    QueryCurActDev(void); // Query act device info.
		int				GetRDCDeviceCaps(void);

        //
		// Previous mode relative
		//
		void            SetPreviousDev(UTDEVICELIST);
		void            SetPreviousBtn(UTDEVICELIST);
		UTDEVICELIST    GetPreviousDev(void);
		UTDEVICELIST    GetPreviousBtn(void);
        void            SetPreviousMode(int);        
        int             GetPreviousMode(void);
        void            SetPreviousModeDim(XRRScreenSize);        
        XRRScreenSize   GetPreviousModeDim(void);

        // ---------------------------------------------------------------------
        // Public member
        // ---------------------------------------------------------------------

        // Display device
        UTDEVICELIST	ActDevicelist;
        int             iScrWidth, iScrHeight; // Store the width and height of current active device.

        // CRT setting
        CRTSetting      CRT;
        
        // TV setting
		TVSetting       TV;

		// LCD setting
		LCDSetting      LCD;

		// Video color enhance
		VideoColorEnhance   VColorEnhance;

	private :
		UTDEVICELIST	lpDeviceList ;
		UTDEVICELIST	lpDeviceConnectedList ;
		UTDEVICELIST	lpDeviceActiveList ;
		UTHWINFO		*lphwinfo ;
		int				numOfdd ;	// the number of display device.
		int				numOfCon ;	// the number of connected device.
		bool			dualMode ;	// TRUE : in dual mode, false : not in dual mode
		int				iMaxSelected ; // Max selection of display on this device.
		int				dwCaps ;

		// ui status.
		ddstatus		*tabP1rbtn ;	// inner variable represent the selection condition of radio button.

		// Mode relative
		UTDEVICELIST    PreDevLst, PreBtn;
		int             iPreMode; // previous mode index
		XRRScreenSize   PreModeDim; // dimension of previous
 } ;

#endif
