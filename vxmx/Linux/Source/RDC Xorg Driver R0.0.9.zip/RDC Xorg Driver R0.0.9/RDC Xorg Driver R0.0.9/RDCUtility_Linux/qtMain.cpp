#include <QApplication>
#include "MainWindow.h"
#include "Escape.h"
#include "setting.h"
#include "GlobalVars.h"

// Global setting class variable.
setting AppSetting ;

// -----------------------------------------------------------------------------
// main : entry point
// -----------------------------------------------------------------------------
int main(int argc, char *argv[])
{
    qDebug("[RDC Utility] : Enter main()");

    // -------------------------------------------------------------------------
    // If user isn't root, return false.
    // -------------------------------------------------------------------------
    if (getuid() != 0)
    {
        printf("[RDC Utility] : This program need root priviledge!\n");
        return false;
    };
	
	// init share memory
	if (!initShareMem())
	    return false;

    // -------------------------------------------------------------------------
    // Parameter flow
    // -------------------------------------------------------------------------
    if (argc > 1)
    {
        // If have input parameters, parse them.
    	qDebug("[RDC Utility] : Parameter count : %d", argc-1);
    	
        return ParameterPaser(argc, argv);
	}
	// -------------------------------------------------------------------------
	// Normal flow
	// -------------------------------------------------------------------------
	else
	{	    
	    // init qt.
        QApplication app(argc, argv);
        
	    // Show utility version.
    	printf(RDC_UTILITY_VERSION);
    	
        MainWindow *mw = new MainWindow();
    	mw->setMinimumSize(WIDTH, HEIGHT);
        mw->show();

        return app.exec();
    };
} ;
