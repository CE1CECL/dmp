#include "VideoColorEnhancePage.h"
#include "Escape.h"
#include "setting.h"

// -----------------------------------------------------------------------------
// Global variable.
// -----------------------------------------------------------------------------
extern setting AppSetting ; // Declare in qtMain.cpp

VideoColorEnhancePage::VideoColorEnhancePage(QWidget *parent) : QWidget(parent)
{
	// Assign pointer
	piHue = &AppSetting.VColorEnhance.iHue;
    piSaturation = &AppSetting.VColorEnhance.iSaturation;
    piBright = &AppSetting.VColorEnhance.iBrightness;
    piContrast = &AppSetting.VColorEnhance.iContrast;

    //
	// init. data
	//
	VideoDesc<<tr("Hue :")<<tr("Saturation :")<<tr("Brightness :")<<tr("Contrast :") ;
	VideoDescValue<<*piHue<<*piSaturation<<*piBright<<*piContrast;

	//
	// init. ui components.
	//
	title = new QLabel(tr("Video Setting :")) ;

	for (int i=0 ; i<4 ; i++)
	{	    
		sliderDesc[i] = new QLabel(VideoDesc.at(i), this) ;
		slider[i]	= new QSlider(Qt::Horizontal, this) ;

        // Hue need special treatment.
		if (VideoDesc.at(i).contains("hue", Qt::CaseInsensitive))
		{
            slider[i]->setMinimum(HUE_SLIDER_MIN) ;
    		slider[i]->setMaximum(HUE_SLIDER_MAX) ;
    		slider[i]->setValue(VideoDescValue.at(i)) ;
		}
		else
		{
    		slider[i]->setMinimum(SLIDER_VIDEO_MIN) ;
    		slider[i]->setMaximum(SLIDER_VIDEO_MAX) ;
    		slider[i]->setValue(VideoDescValue.at(i)) ;
		};
	} ;

    explain = new QLabel(tr("Please drag the scrollbar to adjust."));
	restoreBtn	= new QPushButton(tr("Restore"), this) ;

	//
	// layout managers.
	//
	Layout	= new QVBoxLayout(this) ;

	SliderGrpLayout = new QVBoxLayout() ;
	for (int j=0 ; j<4 ; j++)
	{
		SliderLayout[j]	= new QHBoxLayout() ;
		SliderLayout[j]->addWidget(sliderDesc[j], 1, Qt::AlignTop) ;
		SliderLayout[j]->addWidget(slider[j], 5, Qt::AlignTop) ;
		SliderGrpLayout->addLayout(SliderLayout[j], 1) ;
	} ;

	Layout->addWidget(title, 1, Qt::AlignTop) ;
	Layout->addLayout(SliderGrpLayout, 4) ;
	Layout->addWidget(explain, 1, Qt::AlignLeft);
	Layout->addWidget(restoreBtn) ;

	//
	// connect signal and slot.
	//
	connect(restoreBtn, SIGNAL(clicked()), this, SLOT(setToDefault())) ;
	connect(slider[0], SIGNAL(valueChanged(int)), this, SLOT(updateHue())) ;
    connect(slider[1], SIGNAL(valueChanged(int)), this, SLOT(updateSaturation())) ;
	connect(slider[2], SIGNAL(valueChanged(int)), this, SLOT(updateBrightness())) ;
	connect(slider[3], SIGNAL(valueChanged(int)), this, SLOT(updateContrast())) ;
} ;

VideoColorEnhancePage::~VideoColorEnhancePage()
{

} ;

void VideoColorEnhancePage::processWidgetChange()
{
	emit changeToWidget(0) ;
} ;

void VideoColorEnhancePage::setToDefault()
{   
    slider[0]->setValue(HUE_DEFAULT_VALUE);
    slider[1]->setValue(VIDEO_DEFAULT_VALUE) ;
    slider[2]->setValue(VIDEO_DEFAULT_VALUE) ;
    slider[3]->setValue(VIDEO_DEFAULT_VALUE);

    emit defaultSet() ;
} ;

void VideoColorEnhancePage::updateHue()
{
    *piHue = slider[0]->value() ;

    UT_SetVideoHue(piHue);
};

void VideoColorEnhancePage::updateSaturation()
{
    *piSaturation = slider[1]->value() ;

    UT_SetVideoSaturation(piSaturation);
};

void VideoColorEnhancePage::updateBrightness()
{
    *piBright = slider[2]->value() ;

    UT_SetVideoBrightness(piBright);
};

void VideoColorEnhancePage::updateContrast()
{
    *piContrast = slider[3]->value() ;

    UT_SetVideoContrast(piContrast);
};
