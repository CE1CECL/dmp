#ifndef ESCAPE_H
#define ESCAPE_H

#include <X11/Xmd.h>
#include <X11/Xlib.h>
#include <X11/Xlibint.h>
#include <X11/extensions/recordstr.h>
#include <X11/extensions/Xext.h>
#include <X11/extensions/extutil.h>

// user defined type.
typedef unsigned char		BYTE;
typedef	unsigned short		WORD;
typedef unsigned long		DWORD;
typedef unsigned char		UCHAR;
typedef unsigned short		USHORT;
typedef unsigned long		ULONG;
typedef unsigned char		CARD8;
typedef unsigned short		CARD16;
typedef unsigned long		CARD32;

// -----------------------------------------------------------------------------
// Escape return value
// -----------------------------------------------------------------------------
#define UT_FAIL					0x0000
#define UT_SUCCESS				0x0001
#define UT_MODESET				0x0002
#define UT_REBOOT				0x0004
#define UT_INVALID				0x1FFF
#define UT_NOT_IMPLEMENT        0xFFFF

// Escape function define
#define UT_QUERY_SUPPORT_DEVICE     0x1001
#define UT_QUERY_CONNECT_DEVICE		0x1002
#define UT_SET_DEVICE_ACT			0x1003
#define UT_QUERY_PRIMARY_DEVICE		0x1004
#define UT_SET_PRIMARY_DEVICE		0x1005
#define UT_QUERY_ACT_DEVICE			0x1006
//#define UT_QUERY_SAMM				0x1007

#define UT_SET_GAMMA				0X1101
#define UT_QUERY_GAMMA				0X1102
#define UT_SET_LCD_PWM				0X1103
#define UT_QUERY_LCD_PWM			0X1104
#define UT_QUERY_LCD_SIZE		    0X1105

#define UT_QUERY_HW_INFO			0x1201
#define UT_QUERY_BIOS_VERSION		0x1202
#define UT_QUERY_MEM_INFO			0x1203
#define UT_QUERY_CLK_SPEED			0x1204
#define UT_QUERY_SAMM				0x1205

#define UT_SET_TV_INFO				0x1401
#define UT_QUERY_TV_INFO			0x1402
#define UT_SET_TV_CCRS_LEVEL        0x1403
#define UT_QUERY_TV_CCRS_LEVEL      0x1404

#define UT_QUERY_VIDEO_CONTRAST     0X1501
#define UT_SET_VIDEO_CONTRAST       0X1502
#define UT_QUERY_VIDEO_BRIGHT       0X1503
#define UT_SET_VIDEO_BRIGHT         0X1504
#define UT_QUERY_VIDEO_HUE          0X1505
#define UT_SET_VIDEO_HUE            0X1506
#define UT_QUERY_VIDEO_SATURATION   0X1507
#define UT_SET_VIDEO_SATURATION     0X1508

// Escape jpeg decoder function define
#define UT_DECODER_JPEG_ENTRY			0x2001

// Escape jpeg eecoder function define
#define UT_ENCODER_JPEG_ENTRY			0x2101

#define UT_GET_USERMODE_DIRECTACCESS	0x2200

// -----------------------------------------------------------------------------
// Display devices definition by index (Maximum to 15)
// -----------------------------------------------------------------------------
#define NONE_IDX    0
#define LCD_IDX     1
#define DVI_IDX     2
#define CRT_IDX     3
#define HDMI_IDX    4
#define HDTV_IDX    5
#define TV_IDX      6
// Reserved 7
#define LCD2_IDX    8
#define DVI2_IDX    9
#define CRT2_IDX    10
#define HDMI2_IDX   11
#define HDTV2_IDX   12
#define TV2_IDX     13
// Reserved 14
// Reserved 15

// -----------------------------------------------------------------------------
// Display devices definition by Bits
// -----------------------------------------------------------------------------
#define B_LCD     0x00000001
#define B_DVI     0x00000002
#define B_CRT     0x00000004
#define B_HDMI    0x00000008
#define B_HDTV    0x00000010
#define B_TV      0x00000020

// -----------------------------------------------------------------------------
// Struct define
// -----------------------------------------------------------------------------
typedef union
{
	struct
	{
		WORD LCD ;
		WORD DVI ;
		WORD CRT ;
		WORD HDMI ;
		WORD HDTV ;
		WORD TV ;
		WORD LCD2 ;
		WORD DVI2 ;
		WORD CRT2 ;
		WORD HDMI2 ;
		WORD HDTV2 ;
		WORD TV2 ;
		WORD RESERVE ;
	} TABLE ;
	WORD MERGE ;
} UTDEVICELIST;

typedef UTDEVICELIST DEVICELIST ;


typedef struct _UTHWINFO
{
	WORD wVenderID;
	WORD wDeviceID;
	WORD wSubSystemID;
	WORD wSubVenderID ;
	WORD wRevision;
} UTHWINFO;

// Bios date structure.
typedef struct _DATE
{
	WORD wYear;
	BYTE bMonth;
	BYTE bDate;
} DATES;

// Bios version structure.
typedef struct _UTBIOSDATA
{
	WORD	wData1;
	WORD	wData2;
	WORD	wData3;
	DATES	wDate;
} UTBIOSDATA;

// Clock info structure.
typedef struct _CLKINFO
{
	WORD MemCLK; // (The unit is MHz)
	WORD EngCLK; // (The unit is MHz)
} CLKINFO;

// -----------------------------------------------------------------------------
// LCD info structure.
// -----------------------------------------------------------------------------
typedef struct _LCDINFO
{
    WORD LCDHeight; // (The unit is lines)
    WORD LCDWidth;  // (The unit is pixels)
} LCDINFO;

typedef struct _VIDEO_CLUTDATA
{
    UCHAR Red;
    UCHAR Green;
    UCHAR Blue;
    UCHAR Unused;
} __attribute__((packed)) VIDEO_CLUTDATA, *PVIDEO_CLUTDATA;

typedef struct
{
    USHORT   NumEntries ;		// total 256 entries
    USHORT   FirstEntry ;		// start from 0
    union
	{
        VIDEO_CLUTDATA	RgbArray ;
        unsigned long		RgbLong ;
    } LookupTable[1] ;
} __attribute__((packed)) VIDEO_CLUT, *PVIDEO_CLUT;

// Gamma table structure.
typedef struct
{
	DWORD		device ;	// the device
	DWORD		dwSize;		// the size of gamma tbl
	PVIDEO_CLUT	table ;		// the table
} __attribute__((packed)) GammaTbl, *pGammaTbl;

// -----------------------------------------------------------------------------
// TV information
// -----------------------------------------------------------------------------
/* TV types */
#define TV_TYPE_NTSC	0x0000
#define TV_TYPE_PAL		0x0001

/* Connector types */
#define TV_CON_COMPOSITE	0x0001
#define TV_CON_SVIDEO		0x0002

typedef struct _TVINFO
{
	WORD wType ; // type of TV (NTSC or PAL)
	BYTE bConnector ; // type of connector (Composite or s-video)
} __attribute__((packed)) TVINFO, *PTVINFO ;

// -----------------------------------------------------------------------------
// For display Xextension
// -----------------------------------------------------------------------------
#define RDC_GFX_UT_EXTENSION_NAME       "RDCGFX_API"

#define RDCGFX_PARM_NUM		256

#define X_RDCGFXQueryVersion	0
#define X_RDCGFXCommand		1

typedef struct {
    BYTE    type;           /* X_Reply */
    BOOL    pad1;
    CARD16  sequenceNumber B16;
    CARD32  length B32;
    CARD16  majorVersion B16;   
    CARD16  minorVersion B16;   
    CARD32  pad2 B32;
    CARD32  pad3 B32;
    CARD32  pad4 B32;
    CARD32  pad5 B32;
    CARD32  pad6 B32;
} xRDCGFXQueryVersionReply;
#define	sz_xRDCGFXQueryVersionReply	sizeof(xRDCGFXQueryVersionReply)

typedef struct {
    CARD8   reqType;
    CARD8   RDCGFXReqType;
    CARD16  length B16;
    CARD32  util_cmd_id;
    CARD32  *inBuffer;
    CARD32  inBufferSize;
    CARD32  *outBuffer;
    CARD32  outBufferSize;
    CARD32  result_header;
    CARD32  pad ;  // add to make the length of request be 8 DWORDs.
} xRDCGFXCommandReq;
#define sz_xRDCGFXCommandReq	sizeof(xRDCGFXCommandReq)

// -----------------------------------------------------------------------------
// Escape function declare
// -----------------------------------------------------------------------------
int 		initShareMem() ;
BOOL		UT_CheckRDCExtension(Display *dsp, const char *, int *opCode, int *Event, int *Err) ;
//BOOL		UT_QueryHwInfo(UTHWINFO* lphwinfo) ;
//BOOL		UT_QuerySamm() ;
//BOOL		UT_QueryGamma(GammaTbl *table) ;
BOOL		UT_SetGamma(GammaTbl *) ;
//BOOL		UT_QueryLcdPWM(BYTE *) ;
BOOL		UT_SetLcdPWM(BYTE *) ;
BOOL        UT_QueryLCDInfo(LCDINFO *pLCDInfo);
BOOL		UT_QuerySupportDevice(UTDEVICELIST *) ;
int			UT_SetDeviceAct(UTDEVICELIST *) ;
//BOOL		UT_SetPrimaryDevice(WORD *) ;
BOOL		UT_QueryConnectDevice(UTDEVICELIST *) ;
//UTDEVICELIST	UT_QueryPrimaryDevice(void) ;
BOOL		UT_QueryActDevice(UTDEVICELIST *) ;
//BOOL		UT_QueryHWInfo(UTHWINFO *) ;
//BOOL		UT_QueryBiosVersion(UTBIOSDATA *) ;
BOOL		UT_QueryBiosVersion(unsigned int &version) ;
BOOL		UT_QueryMemInfo(DWORD &dwMemSize) ;
BOOL		UT_QueryClockSpeed(CLKINFO *ClkInfo) ;

// Video color enhance
BOOL        UT_QueryVideoContrast(int *) ;
BOOL        UT_SetVideoContrast(int *) ;
BOOL        UT_QueryVideoBrightness(int *) ;
BOOL        UT_SetVideoBrightness(int *) ;
BOOL        UT_QueryVideoHue(int *) ;
BOOL        UT_SetVideoHue(int *) ;
BOOL        UT_QueryVideoSaturation(int *) ;
BOOL        UT_SetVideoSaturation(int *) ;

// TV relative
int         UT_SetTVInfo(PTVINFO);
BOOL        UT_QueryTVInfo(PTVINFO);
BOOL        UT_SetTvCCRS(BYTE *);
BYTE        UT_QueryTvCCRS(void);

#endif
