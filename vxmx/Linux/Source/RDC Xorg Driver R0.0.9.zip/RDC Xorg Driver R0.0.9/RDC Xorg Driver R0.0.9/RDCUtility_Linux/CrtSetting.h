#ifndef CRTSETTING_H
#define CRTSETTING_H
#include <QtGui>
#include <QWidget>
#include "Escape.h"
#include "GlobalVars.h"

class QLabel ;
class QSlider ;
class QPushButton ;
class QStringList ;
class QVBoxLayout ;
class QHBoxLayout ;

class CrtSetting : public QWidget
{
	Q_OBJECT

	signals :
		void changeToWidget(int) ;
		void defaultSet() ;

	public slots :
		void processWidgetChange() ;
		void setToDefault() ;
		void updateGammaCurve() ;

	public :
		CrtSetting(QWidget *parent=0) ;
		~CrtSetting() ;
		void initGamaTbl(GammaTbl *) ;
		void SetNewGamma(float , float , float , GammaTbl *) ;

	private :
		// ui components.
		QLabel		*crtDesc ;
		QLabel		*gaCurveLabel ; // Label to contain gaCurvePixmap.
		QPixmap		*gaCurvePixmap ; // Gamma curve will draw on this pixmap.
		QLabel		*sliderDesc[3] ; // description for brightness, contrast and gamma.
		QSlider		*slider[3] ; // slider for brightness, contrast and gamma.
		QPushButton	*restoreBtn ;
		QPushButton	*okBtn ;

		// data components.
		GammaTbl 	*tbl ;
		QStringList	crtSettingDesc ;
		QList<BYTE> crtSettingDescValue;
		BYTE        *pbBrightness, *pbContrast, *pbGamma;

		// layout managers.
		QVBoxLayout	*layout ;
		QVBoxLayout	*sliderArea ;
		QHBoxLayout	*sliderLayout[3] ;
		QVBoxLayout	*curveLayout ;
		QHBoxLayout	*middleLayout ;
		QHBoxLayout	*btnLayout ;		
} ;

#endif
