#include "MainTabWidget.h"

MainTabWidget::MainTabWidget() : QTabWidget()
{
	// init. components.
	displayPage	= new DispStackedPage() ;
	hwInfoPage	= new HwInfoPage() ;
	//videoPage = new VideoColorEnhancePage();

	// add tab page.
	addTab(displayPage, tr("Display Device")) ;
	addTab(hwInfoPage, tr("Hardware Information")) ;
	//addTab(videoPage, tr("Video Color Enhancement"));

	connect(this, SIGNAL(applyBtnClick()), displayPage, SLOT(applyBtnClicked())) ;
} ;

MainTabWidget::~MainTabWidget()
{

} ;

void MainTabWidget::applyBtnClicked()
{
	emit applyBtnClick() ;
} ;
