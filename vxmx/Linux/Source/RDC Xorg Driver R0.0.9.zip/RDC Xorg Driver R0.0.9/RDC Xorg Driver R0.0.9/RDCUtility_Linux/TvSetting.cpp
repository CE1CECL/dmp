#include "TvSetting.h"
#include "math.h"
#include "setting.h"
#include "ModeRestoreDialog.h"

// -----------------------------------------------------------------------------
// Global variable.
// -----------------------------------------------------------------------------
extern setting AppSetting ; // Declare in qtMain.cpp

TvSetting::TvSetting(QWidget *parent) : QWidget(parent)
{
    // Query TV info and CCRS.
    UT_QueryTVInfo(&AppSetting.TV.info);
    AppSetting.TV.bCCRS = UT_QueryTvCCRS();
    
    // Assign pointer
    pwType = &AppSetting.TV.info.wType;
    pbConnector = &AppSetting.TV.info.bConnector;
	pbBrightness = &AppSetting.TV.bBrightness;
	pbContrast = &AppSetting.TV.bContrast;
	pbGamma = &AppSetting.TV.bGamma;
	pbCCRS = &AppSetting.TV.bCCRS;
		
	//
	// init. data
	//
	TvSettingDesc<<tr("Brightness :")<<tr("Contrast :")<<tr("Gamma :")<<tr("CCRS :") ;
    TvSettingDescValue<<*pbBrightness<<*pbContrast<<*pbGamma<<*pbCCRS;
	
	tbl = (GammaTbl *) malloc(4*sizeof(DWORD) + 2*sizeof(USHORT) + sizeof(UCHAR)*256*4) ; // store Gamma table.
	
	// Initialization Gamma table.
 	tbl->device = B_TV ; // For TV.
	tbl->dwSize = sizeof(VIDEO_CLUT) + (sizeof(UCHAR)*4*256) ;
	int size = sizeof(DWORD) ;
	tbl->table = (PVIDEO_CLUT) (((BYTE*)tbl)+3*size) ; 
	tbl->table->FirstEntry = 0 ;
	tbl->table->NumEntries = 256 ;
	initGamaTbl(tbl) ;
	qDebug("[RDC Utility] : tbl ptr is %X", (int)tbl) ;

	//
	// init. ui components.
	//
	TvDesc = new QLabel(tr("TV Setting :")) ;
	TvType = new QLabel(tr("Type :"));
	TvConnector = new QLabel(tr("Connector type :"));

    // Gamma
	for (int i=0 ; i<3 ; i++)
	{
		sliderDesc[i]	= new QLabel(TvSettingDesc.at(i), this) ;
		slider[i]	= new QSlider(Qt::Horizontal, this) ;
		slider[i]->setMinimum(TVSLIDER_MIN) ;
		slider[i]->setMaximum(TVSLIDER_MAX) ;
		slider[i]->setValue(TvSettingDescValue.at(i)) ;
	} ;

	// CCRS
	sliderDesc[3]	= new QLabel(TvSettingDesc.at(3), this) ;
	slider[3]	= new QSlider(Qt::Horizontal, this) ;
	slider[3]->setMinimum(0) ;
	slider[3]->setMaximum(3) ;
	slider[3]->setValue(*pbCCRS) ;

    // TV type and connector components.
    pRBtnNTSC = new QRadioButton(tr("NTSC"));
    pRBtnPal = new QRadioButton(tr("PAL"));
    pRBtnComposite = new QRadioButton(tr("Composite"));
    pRBtnSVideo = new QRadioButton(tr("S-Video"));
    pRBtnComposite->setAutoExclusive(false);
	pRBtnSVideo->setAutoExclusive(false);

	if (*pwType == TV_TYPE_NTSC)
	    pRBtnNTSC->setChecked(true);
    else if (*pwType == TV_TYPE_PAL)
        pRBtnPal->setChecked(true);

    if (*pbConnector & TV_CON_COMPOSITE)
        pRBtnComposite->setChecked(true);

    if (*pbConnector & TV_CON_SVIDEO)
        pRBtnSVideo->setChecked(true);	
    
	restoreBtn	= new QPushButton(tr("Restore"), this) ;
	okBtn		= new QPushButton(tr("Ok"), this) ;

	//
	// layout managers.
	//
	Layout	= new QVBoxLayout(this) ;

    typeGrp = new QGroupBox(tr("Type :")); 
	TvTypeRBtnLayout = new QHBoxLayout();
	TvTypeRBtnLayout->addWidget(pRBtnNTSC);
	TvTypeRBtnLayout->addWidget(pRBtnPal);
	typeGrp->setLayout(TvTypeRBtnLayout);

    connectorGrp = new QGroupBox(tr("Connector type :")); 
	TvConnectRBtnLayout = new QHBoxLayout();
	TvConnectRBtnLayout->addWidget(pRBtnComposite);
	TvConnectRBtnLayout->addWidget(pRBtnSVideo);
	connectorGrp->setLayout(TvConnectRBtnLayout);

	RBtnGrpLayout = new QVBoxLayout();
	RBtnGrpLayout->addWidget(typeGrp);
	RBtnGrpLayout->addWidget(connectorGrp);

	SliderGrpLayout = new QVBoxLayout() ;
	for (int j=0 ; j<4 ; j++)
	{
		SliderLayout[j]	= new QHBoxLayout() ;
		SliderLayout[j]->addWidget(sliderDesc[j], 1, Qt::AlignTop) ;
		SliderLayout[j]->addWidget(slider[j], 5, Qt::AlignTop) ;
		SliderGrpLayout->addLayout(SliderLayout[j], 1) ;
	} ;

	RBtnSliderLayout = new QHBoxLayout();
	RBtnSliderLayout->addLayout(RBtnGrpLayout);
	RBtnSliderLayout->addLayout(SliderGrpLayout);

	BtnLayout	= new QHBoxLayout() ;
	BtnLayout->addWidget(restoreBtn) ;
	BtnLayout->addWidget(okBtn) ;

	Layout->addLayout(RBtnSliderLayout);
	Layout->addLayout(BtnLayout);

	//
	// connect signal and slot.
	//
	connect(pRBtnNTSC, SIGNAL(clicked()), this, SLOT(updateTvInfo()));
	connect(pRBtnPal, SIGNAL(clicked()), this, SLOT(updateTvInfo()));
	connect(pRBtnComposite, SIGNAL(clicked()), this, SLOT(updateTvInfo()));
	connect(pRBtnSVideo, SIGNAL(clicked()), this, SLOT(updateTvInfo()));
	for (int i=0 ; i<3 ; i++)
		connect(slider[i], SIGNAL(valueChanged(int)), this, SLOT(updateGamma())) ;
	// CCRS
	connect(slider[3], SIGNAL(valueChanged(int)), this, SLOT(updateCCRS()));
	connect(okBtn, SIGNAL(clicked()), this, SLOT(processWidgetChange())) ;
	connect(restoreBtn, SIGNAL(clicked()), this, SLOT(setToDefault())) ;
} ;

TvSetting::~TvSetting()
{

} ;

void TvSetting::processWidgetChange()
{
    if (bTvChanged)
    {
        int ret;
        UTDEVICELIST actDevice;

        // Set TV information.
        ret = UT_SetTVInfo(&(AppSetting.TV.info));
        
        actDevice.MERGE = B_TV;
      	ret = UtilSetMode(actDevice);

    	if (ret == RRSetConfigSuccess)
        {
            ModeRestoreDialog dlg;
            dlg.exec();
        }
    };
        
	emit changeToWidget(0) ;
} ;

void TvSetting::setToDefault()
{
	slider[0]->setValue(TVSLIDER_DEFAULT_VALUE);
    slider[1]->setValue(TVSLIDER_DEFAULT_VALUE);
    slider[2]->setValue(TVSLIDER_DEFAULT_VALUE);
	slider[3]->setValue(0);

    emit defaultSet() ;
} ;

void TvSetting::updateGamma(void)
{
	// init.
	double Bright, Contrast, Gamma;
	
	*pbBrightness = Bright = slider[0]->value() ;
	*pbContrast = Contrast = slider[1]->value() ;
	*pbGamma = Gamma = slider[2]->value() ;
	qDebug("[RDC Utility] : Bright : %d, Contrast : %d, Gamma : %d", Bright, Contrast, Gamma) ;

	// Set new gamma value
	SetNewGamma(Gamma/100, Bright/100, Contrast/100, tbl) ;
	UT_SetGamma(tbl) ; // Set new gamma into hw.
} ;

void TvSetting::initGamaTbl(GammaTbl *gamatbl)
{
	
	for (int i=0 ; i<256 ; i++)
	{
		gamatbl->table->LookupTable[i].RgbArray.Red = i ;
		gamatbl->table->LookupTable[i].RgbArray.Green = i ;
		gamatbl->table->LookupTable[i].RgbArray.Blue = i ;
		gamatbl->table->LookupTable[i].RgbArray.Unused = 0 ;
	} ;
} ;

void TvSetting::SetNewGamma(float flGamma, float flBright, float flContrast, GammaTbl *gammaTbl)
{
    qDebug("[RDC Utility] : Enter SetNewGamma") ;
    
	double	dbIndex = 0.0;
	double	dbRampValue = 0.0;
	double	dbTempContrast = 0.0;
	float	flNewGamma = 0.0 ;
	int	nTemp = 0;
	int	nBright = 0;
	int	nContrast = 0;

	for (int i=0 ; i<256 ; i++)
	{
		dbIndex = ( (double)i ) / 255.0 ;

		if ( flGamma > 1.0f )
		{
			flNewGamma = (( flGamma - 1.0f ) * 2.0f ) + 1.0f;
		}
		else
		{
			flNewGamma = flGamma;
		}
		dbRampValue = pow( dbIndex, 1.0 / (double)flNewGamma ) * 255.0;

		nTemp = (int) ( dbRampValue + 0.005 );

		dbTempContrast	= (double)(( flContrast - 1.0 ) * 150.0 );
		nContrast	= (int) ( ( ((double) i ) / 255.0 ) * dbTempContrast );
		nTemp		= nTemp + nContrast;

		nBright = (int)(( flBright - 1.0 ) * 150.0 );
		nTemp = nTemp + nBright;

		if (nTemp > 255)
			nTemp = 255 ;
		else if (nTemp < 0)
			nTemp = 0 ;

		gammaTbl->table->LookupTable[i].RgbArray.Red	= 
		gammaTbl->table->LookupTable[i].RgbArray.Green	= 
		gammaTbl->table->LookupTable[i].RgbArray.Blue	= nTemp ;
		gammaTbl->table->LookupTable[i].RgbArray.Unused	= 0 ;
	} ;

	qDebug("[RDC Utility] : Leave SetNewGamma") ;
} ;

void TvSetting::updateCCRS()
{
    *pbCCRS = slider[3]->value() ;

    UT_SetTvCCRS(pbCCRS);
};

void TvSetting::updateTvInfo()
{
    *pwType = 0;
    *pbConnector = 0;

    // TV type
    if (pRBtnNTSC->isChecked())
        *pwType = TV_TYPE_NTSC;
    else if (pRBtnPal->isChecked())
        *pwType = TV_TYPE_PAL;

    // TV connector
    if (pRBtnComposite->isChecked())
        *pbConnector |= TV_CON_COMPOSITE;
    
    if (pRBtnSVideo->isChecked())
        *pbConnector |= TV_CON_SVIDEO;

    // If setting is changed, set bTvChanged to true.
    if (*pwType || *pbConnector) // if not 0.
        bTvChanged = true;
};

void TvSetting::show()
{
    bTvChanged = false;
    QWidget::show();
};
