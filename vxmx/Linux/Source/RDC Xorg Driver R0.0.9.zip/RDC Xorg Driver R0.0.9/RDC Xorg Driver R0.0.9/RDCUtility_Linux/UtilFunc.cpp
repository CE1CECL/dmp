#include <QtGui>
#include "Escape.h"
#include "UtilFunc.h"
#include "setting.h"
#include "ModeRestoreDialog.h"
#include "GlobalVars.h"
#include "Parameter.h"

// Global variable.
extern setting AppSetting ;

// -----------------------------------------------------------------------------
// UtilSetMode()
// 
// iDevIndex : Display devices definition by index (Maximum to 15)
// iModWidth : width of mode
// iModHeight : height of mode
// -----------------------------------------------------------------------------
int UtilSetMode(UTDEVICELIST actDevice, int iModWidth, int iModHeight)
{
    qDebug("[RDC Utility] : Enter UtilSetMode()");

    qDebug("[RDC Utility] : iModWidth = %d", iModWidth);
    qDebug("[RDC Utility] : iModHeight = %d", iModHeight);

    Display *dpy ;
    int ret ;
    Rotation cur_rotation ;
    int cur_rate ;
    int cur_size ;
    int screen;
    int drawable;
    int nsize ;
    XRRScreenSize *ss ;
    XRRScreenConfiguration *sc ;
    int iCRTMode, iLCDMode, iTVMode, iMidMode;
    int iCRTDefMode, iLCDDefMode, iTVDefMode;
    LCDINFO LCDInfo;
    int iLCDFitH, iLCDFitW;
    WORD wLCDW, wLCDH, wCRTW, wCRTH, wTVW, wTVH;
    UTDEVICELIST curDevice; // store current device.
    int *piActDevWidth = &AppSetting.iScrWidth;
    int *piActDevHeight = &AppSetting.iScrHeight;
    
    int iDevIndx = actDevice.MERGE;

    //
    // Store current active device
    //
    UT_QueryActDevice(&curDevice) ;
    AppSetting.SetPreviousDev(curDevice);
	qDebug("[RDC Utility] : Previous active device : %X", curDevice.MERGE) ;

    //
	// Set new active device
	//
	UT_SetDeviceAct(&actDevice) ;

    //
    // If active device is LCD, get LCD fit mode.
    //
    if (iDevIndx & B_LCD)
    {
        UT_QueryLCDInfo(&LCDInfo);
        iLCDFitW = LCDInfo.LCDWidth;
        iLCDFitH = LCDInfo.LCDHeight;
    }
    else        
        iLCDFitW = iLCDFitH = -1;

    //
    // If user call with new width and height, use them first. Even it is not supported.
    //
    if (iDevIndx & B_LCD && iModWidth != MODE_NOT_ASSIGN && iModHeight != MODE_NOT_ASSIGN)
    {
        *piActDevWidth = wLCDW = iModWidth;
        *piActDevHeight = wLCDH = iModHeight;
    }
    else
    {
        *piActDevWidth = wLCDW = iLCDFitW;
        *piActDevHeight = wLCDH = iLCDFitH;
    };
    
    if (iDevIndx & B_CRT && iModWidth != MODE_NOT_ASSIGN && iModHeight != MODE_NOT_ASSIGN)
    {
        *piActDevWidth = wCRTW = iModWidth;
        *piActDevHeight = wCRTH = iModHeight;
    }
    else
    {
        *piActDevWidth = wCRTW = CRT_DEF_WIDTH;
        *piActDevHeight = wCRTH = CRT_DEF_HEIGHT;
    };

    if (iDevIndx & B_TV && iModWidth != MODE_NOT_ASSIGN && iModHeight != MODE_NOT_ASSIGN)
    {
        *piActDevWidth = wTVW = TV_DEF_WIDTH; // TV will always set to 800x600 currently.
        *piActDevHeight = wTVH = TV_DEF_HEIGHT;
    }
    else
    {
        *piActDevWidth = wTVW = TV_DEF_WIDTH;
        *piActDevHeight = wTVH = TV_DEF_HEIGHT;
    };

    //
    // Get local display
    //
    dpy = XOpenDisplay("") ;
    qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;

    // Lock display, XLib macro.
    // not sure if we need "LockDisplay()" or not.
    //LockDisplay(dpy) ;
    //qDebug("[RDC Utility] : LockDisplay") ;
    
    screen = DefaultScreen(dpy);
    qDebug("[RDC Utility] : DefaultScreen() : %X", screen) ;
    drawable = RootWindow(dpy, screen); //int drawable = 69 ;
    qDebug("[RDC Utility] : RootWindow() : %X", drawable) ;
    sc = XRRGetScreenInfo(dpy, drawable) ;
    qDebug("[RDC Utility] : XRRGetScreenInfo()") ;
    cur_rate = XRRConfigCurrentRate(sc) ;
    qDebug("[RDC Utility] : XRRConfigCurrentRate() : %d", cur_rate) ;
    cur_size = XRRConfigCurrentConfiguration(sc, &cur_rotation) ;
    AppSetting.SetPreviousMode(cur_size); // Store the previous mode in Global.
    qDebug("[RDC Utility] : XRRConfigCurrentConfiguration() Current size : %d", cur_size) ;
    
    int count = ScreenCount(dpy);
    qDebug("[RDC Utility] : Screen count is %d", count);
    
    //ss = XRRConfigSizes(sc, &nsize) ; // Just return value in XRRScreenConfiguration
    ss = XRRSizes(dpy, screen, &nsize); // Will call _XRRValidateCache() to refresh XRRScreenConfiguration
    
    // Iterating all modes.
    iCRTMode = iLCDMode = iTVMode = iMidMode = MODE_INDEX_NOT_FOUND;
    iCRTDefMode = iLCDDefMode = iTVDefMode = MODE_INDEX_NOT_FOUND;
    
    for (int i=0 ; i<nsize ; i++)
    {
        qDebug("[RDC Utility] : Mode %d, (%d, %d)", i, ss[i].width, ss[i].height);
    
        // Get CRT mode number
        if (ss[i].width == wCRTW && ss[i].height == wCRTH)
            iCRTMode = i;
        
        // Get LCD mode number
        if (ss[i].width == wLCDW && ss[i].height == wLCDH)
            iLCDMode = i;

        // Get TV mode number
        if (ss[i].width == wTVW && ss[i].height == wTVH)
            iTVMode = i;
        
        // Get temp mode (640x480)
        if (ss[i].width == TEMP_MODE_WIDTH && ss[i].height == TEMP_MODE_HEIGHT)
            iMidMode = i;

        // Get CRT default mode
        if (ss[i].width == CRT_DEF_WIDTH && ss[i].height == CRT_DEF_HEIGHT)
            iCRTDefMode = i;

        // Get LCD default mode
        if (ss[i].width == LCD_DEF_WIDTH && ss[i].height == LCD_DEF_HEIGHT)
            iLCDDefMode = i;

        // Get TV default mode
        if (ss[i].width == TV_DEF_WIDTH && ss[i].height == TV_DEF_HEIGHT)
            iTVDefMode = i;

        if (AppSetting.GetPreviousMode() == i)
            AppSetting.SetPreviousModeDim(ss[i]);
    };

    qDebug("[RDC Utility] : wLCDW = %d", wLCDW);
    qDebug("[RDC Utility] : wLCDH = %d", wLCDH);
    qDebug("[RDC Utility] : wCRTW = %d", wCRTW);
    qDebug("[RDC Utility] : wCRTH = %d", wCRTH);
    
    // If mode not found then using default mode, if default not found just return false.
    if ((iDevIndx & B_LCD) && iLCDMode == MODE_INDEX_NOT_FOUND)
    {
        qDebug("[RDC Utility] : LCD mode not found, using default!");
        if (iLCDDefMode != MODE_INDEX_NOT_FOUND)
            iLCDMode = iLCDDefMode;
        else
            return false;
    }
    if ((iDevIndx & B_CRT) && iCRTMode == MODE_INDEX_NOT_FOUND)
    {
        qDebug("[RDC Utility] : CRT mode not found, using default!");
        if (iCRTDefMode != MODE_INDEX_NOT_FOUND)
            iCRTMode = iCRTDefMode;
        else
            return false;
    }
    if ((iDevIndx & B_TV) && iTVMode == MODE_INDEX_NOT_FOUND)
    {
        qDebug("[RDC Utility] : TV mode not found, using default!");
        if (iTVDefMode != MODE_INDEX_NOT_FOUND)
            iTVMode = iTVDefMode;
        else
            return false;
    }
    if (iMidMode == MODE_INDEX_NOT_FOUND)
    {
        qDebug("[RDC Utility] : Middle mode not found, return!");
        qDebug("[RDC Utility] : Exit UtilSetMode()");
        return false;
    }
    
    // Assign mode.
    qDebug("[RDC Utility] : Index of active device is %d", iDevIndx);
    if (iDevIndx & B_LCD)
    {
        qDebug("[RDC Utility] : Active device is LCD");
        qDebug("[RDC Utility] : LCD mode is %d", iLCDMode);
        cur_size = iLCDMode; // Fit mode
    }
    else if (iDevIndx & B_CRT)
    {
        qDebug("[RDC Utility] : Active device is CRT");
        qDebug("[RDC Utility] : CRT mode is %d", iCRTMode);
        cur_size = iCRTMode; // 800x600
    }
    else if (iDevIndx & B_TV)
    {
        qDebug("[RDC Utility] : Active device is TV");
        qDebug("[RDC Utility] : CRT mode is %d", iTVMode);
        cur_size = iTVMode; // 800x600
    }
    else
        qDebug("[RDC Utility] : No active device found !!!");
    
    qDebug("[RDC Utility] : Current mode is %d", cur_size);
    ret = XRRSetScreenConfigAndRate(dpy, sc, drawable, (SizeID) iMidMode, cur_rotation, cur_rate, CurrentTime) ;
    XSync(dpy, false) ;
    XRRFreeScreenConfigInfo(sc) ;
    qDebug("[RDC Utility] : Refresh rate : %d", cur_rate) ;
    qDebug("[RDC Utility] : Size index : %d", cur_size) ;
    qDebug("[RDC Utility] : Rotation : %d", cur_rotation) ;
    qDebug("[RDC Utility] : Return value is %d", ret) ;
    
    XRRScreenConfiguration *sc1 ;
    sc1 = XRRGetScreenInfo(dpy, drawable) ;
    
    // Change to the original mode
    ret = XRRSetScreenConfigAndRate(dpy, sc1, drawable, (SizeID) cur_size, cur_rotation, cur_rate, CurrentTime) ;
    
    XSync(dpy, false) ;
    XRRFreeScreenConfigInfo(sc1) ;
    
    //UnlockDisplay(dpy) ;
    SyncHandle() ;
    
    // Flush Display.
    XFlush(dpy) ;
    XCloseDisplay(dpy) ;
    
    return ret ;
};

// -----------------------------------------------------------------------------
// ParameterPaser()
// -----------------------------------------------------------------------------
int ParameterPaser(char argc, char *argv[])
{
    qDebug("[RDC Utility] : Enter ParameterPaser");
    
    QStringList argvLst;
    int index;

    // Save all arguments into string list.
    for (int i=1 ; i<argc ; i++) // skip execute filename
        argvLst <<argv[i] ;

    //
    // Parsing parameter
    //

    /*
     Switch parameter
     */
    index = argvLst.indexOf(QRegExp(PARA_REG_SWITCH));
    if (index != -1) // -1 if no item matched
    {
        UTDEVICELIST actDev;
        WORD *iDev;
        int iW, iH;
        int ret;
        bool bShowDlg = false;
        LCDINFO LCDInfo;
        
        actDev.MERGE = 0;
        iDev = &actDev.MERGE;
        iW = iH = 0;

        // Device parameter
        if (argvLst[index+1].contains(QRegExp(PARA_REG_LCD)))
            *iDev |= B_LCD;
        else if (argvLst[index+1].contains(QRegExp(PARA_REG_CRT)))
            *iDev |= B_CRT;
        else if (argvLst[index+1].contains(QRegExp(PARA_REG_TV)))
            *iDev |= B_TV;

        // Get H and V size, if not assigned using default values.
        if (*iDev & B_LCD)
        {
            UT_QueryLCDInfo(&LCDInfo);
            iW = LCDInfo.LCDWidth;
            iH = LCDInfo.LCDHeight;
        }
        else if (*iDev & B_CRT)
        {
            iW = CRT_DEF_WIDTH;
            iH = CRT_DEF_HEIGHT;
        }
        else if (*iDev & B_TV)
        {
            iW = TV_DEF_WIDTH;
            iH = TV_DEF_HEIGHT;
        };
        
        if ((index+2) < argvLst.size()) // Test if index+2 exist?
        {
            if (!argvLst[index+2].startsWith("-"))
            {
                iW = argvLst[index+2].toInt();
                iH = argvLst[index+3].toInt();
            };
        };

        // show confirm dialog or not.
        if (argvLst.indexOf(QRegExp(PARA_REG_RESTROE_DLG)) != -1)
            bShowDlg = true;

        // Set mode if active device != 0
        if (actDev.MERGE != 0)
            ret = UtilSetMode(actDev, iW, iH);

        if (ret == RRSetConfigSuccess && bShowDlg)
        {
            ModeRestoreDialog dlg;
            return dlg.exec();
        }
    }

    /*
     help parameter
     */
    index = argvLst.indexOf(QRegExp(PARA_REG_HELP));
    if (index != -1) // -1 if no item matched
        Usage();

    /*
     Version parameter
     */
    index = argvLst.indexOf(QRegExp(PARA_REG_VERSION));
    if (index != -1) // -1 if no item matched
        Version();

    /*
     Actdev parameter
     */
    index = argvLst.indexOf(QRegExp(PARA_REG_ACT_DEVICE));
    if (index != -1) // -1 if no item matched
        ReportActiveDevice();

    /*
     Condev parameter
     */
    index = argvLst.indexOf(QRegExp(PARA_REG_CON_DEVICE));
    if (index != -1) // -1 if no item matched
        ReportConnectDevice();

    /*
     Curmode parameter
     */
    index = argvLst.indexOf(QRegExp(PARA_REG_CUR_MODE));
    if (index != -1) // -1 if no item matched
        ReportCurrentMode();

    return TRUE;
}

// -----------------------------------------------------------------------------
// Usage()
// print help messages.
// -----------------------------------------------------------------------------
void Usage(void)
{
    qDebug("[RDC Utility] : Enter Usage()");
    
    QStringList usage;
    
    usage <<"Usage: "<<RDC_UTILITY_NAME<<" [arguments]\n"\
          <<"Arguments:\n"\
          <<"    "<<PARA_HELP<<" :Show this message\n"\
          <<"    "<<PARA_VERSION<<" :Show version information\n"\
          <<"    "<<PARA_SWITCH<<" [lcd | crt | tv] hsize vsize ["<<PARA_RESTROE_DLG<<"] :Switch device\n"\
          <<"        "<<"Switch to LCD and set 800x600 mode without confirm dialog\n"\
          <<"        =>"<<RDC_UTILITY_NAME<<" "<<PARA_SWITCH<<" lcd 800 600\n"\
          <<"        "<<"Switch to LCD and set 800x600 mode with confirm dialog\n"\
          <<"        =>"<<RDC_UTILITY_NAME<<" "<<PARA_SWITCH<<" lcd 800 600 -confirm\n"\
          <<"        TV will always set to 800x600 currently.\n"\
          <<"    "<<PARA_SWITCH<<" [lcd | crt] ["<<PARA_RESTROE_DLG<<"] :Switch device\n"\
          <<"        "<<"If no hsize and vsize asigned, CRT will set to 800x600\n"\
          <<"        "<<"LCD will set to fit mode.\n"\
          <<"    "<<PARA_ACT_DEVICE<<" :Report current active device\n"\
          <<"        "<<"1 :LCD, 4 :CRT, 32 :TV\n"\
          <<"    "<<PARA_CON_DEVICE<<" :Report connect devices in bit or form.\n"\
          <<"        "<<"5 means (1 | 4), LCD and CRT are connected.\n"\
          <<"    "<<PARA_CUR_MODE<<" :Report current display mode\n"\
          <<"        "<<"Format : hsize vsize\n"\
          <<"\nIf no argument is asigned, it will enter GUI mode.\n";
    
    // print it out
    for (QStringList::Iterator it = usage.begin(); it != usage.end(); ++it)
    {
        printf("%s", (*it).toAscii().data());
    }
};

// -----------------------------------------------------------------------------
// Show version info.
// -----------------------------------------------------------------------------
void Version(void)
{
    printf(RDC_UTILITY_VERSION);
};

// -----------------------------------------------------------------------------
// Print current active device on screen.
// -----------------------------------------------------------------------------
void ReportActiveDevice()
{
    UTDEVICELIST actDev;
    
    UT_QueryActDevice(&actDev) ;

    printf("%d\n", actDev.MERGE);
};

// -----------------------------------------------------------------------------
// Print current connect device on screen.
// -----------------------------------------------------------------------------
void ReportConnectDevice()
{
    UTDEVICELIST conDev;
    
    UT_QueryConnectDevice(&conDev) ;

    printf("%d\n", conDev.MERGE);
};

// -----------------------------------------------------------------------------
// Print current hsize and vsize on screen.
// -----------------------------------------------------------------------------
void ReportCurrentMode()
{
    Display *dpy ;
    Rotation cur_rotation ;
    int curModeIdx ;
    int screen;
    int drawable;
    int nsize ;
    XRRScreenSize *ss ;
    XRRScreenConfiguration *sc ;
    
    //
    // Get local display
    //
    dpy = XOpenDisplay("") ;    
    screen = DefaultScreen(dpy);
    drawable = RootWindow(dpy, screen);
    sc = XRRGetScreenInfo(dpy, drawable);
    curModeIdx = XRRConfigCurrentConfiguration(sc, &cur_rotation);
    ss = XRRSizes(dpy, screen, &nsize);

    //
    // Get hsize and vsize by mode index.
    //
    printf("%d", ss[curModeIdx].width);
    printf(" ");
    printf("%d\n", ss[curModeIdx].height);

    //
    // Clean
    //
    XSync(dpy, false) ;
    XRRFreeScreenConfigInfo(sc) ;
    
    //UnlockDisplay(dpy) ;
    SyncHandle() ;
    
    // Flush Display.
    XFlush(dpy) ;
    XCloseDisplay(dpy) ;
};
