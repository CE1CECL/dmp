#ifndef GLOBALVAR_H
#define GLOBALVAR_H

// -----------------------------------------------------------------------------
// Driver relative.
// -----------------------------------------------------------------------------
#define IN_BUF_SIZE     4096
#define OUT_BUF_SIZE    4096
#define IN_BUF_NAME     "/RDC/GFX/shm/inBuf"
#define OUT_BUF_NAME    "/RDC/GFX/shm/outBuf"

// -----------------------------------------------------------------------------
// Mode relative
// -----------------------------------------------------------------------------
#define CRT_DEF_WIDTH     800
#define CRT_DEF_HEIGHT    600
#define TV_DEF_WIDTH      800
#define TV_DEF_HEIGHT     600
#define LCD_DEF_WIDTH     800
#define LCD_DEF_HEIGHT    600
#define TEMP_MODE_WIDTH   640
#define TEMP_MODE_HEIGHT  480

// -----------------------------------------------------------------------------
// Strings
// -----------------------------------------------------------------------------
#define RDC_UTILITY_VERSION "RDC Graphic Utility\nVersio 0.8\n"
#define RDC_UTILITY_NAME    "RDCUtility_Linux"

// -----------------------------------------------------------------------------
// Device ID (Defined in Pci.h of driver)
// -----------------------------------------------------------------------------
#define RDC_VENDOR_ID       0x17F3
#define M2011_DEVICE_ID     0x2011
#define M2010_A0_VENDOR_ID  0x25F0
#define M2010_A0_DEVICE_ID  0x17F3
#define M3306_DEVICE_ID     0x2010
#define FpgaChip            0x1

// -----------------------------------------------------------------------------
// Device capabilities
// -----------------------------------------------------------------------------
#define CAPS_ONE_DISPLAY		0x00000001

// -----------------------------------------------------------------------------
// Main window
// -----------------------------------------------------------------------------
#define WIDTH				620		// the width of the main window
#define HEIGHT				400		// the height of the main window

// -----------------------------------------------------------------------------
// String constants.
// -----------------------------------------------------------------------------
#define MAX_LOADSTRING	100		// Max string length.
#define MAX_STRING		256

// -----------------------------------------------------------------------------
// Slider ui constanat
// -----------------------------------------------------------------------------
#define SLIDER_MAX			200		// Max slider position.
#define SLIDER_MIN			20		// Min slider position.
#define LCDSLIDER_MAX		100		// for LCD
#define LCDSLIDER_MIN		-100	// for LCD

#define MAX_1_SELECTED		1
#define MAX_2_SELECTED		2		// the number of the concurrent selection 
									// of radio button in tab page 1 (display device).
#define COLOR_NUMBER		256

#define BITMAP_WIDTH		128
#define BITMAP_HEIGHT		128

#define BTN_WIDTH	BITMAP_WIDTH
#define BTN_HEIGHT	BITMAP_HEIGHT

#define DEVICE_NUMBER  5

#define IDB_RLCD 0
#define IDB_RDVI 1
#define IDB_RCRT 2
#define IDB_RHDMI 3
#define IDB_RHDTV 4
#define IDB_RTV 5

#define IDBC_LCD 0
#define IDBC_DVI 1
#define IDBC_CRT 2
#define IDBC_HDMI 3
#define IDBC_HDTV 4
#define IDBC_TV 5

// -----------------------------------------------------------------------------
// Linux version.
// -----------------------------------------------------------------------------
// Number of suppoted display device
#define NUM_SUPPORT_DSP_DEV 6

// LCD Setting
#define LCDSLIDER_MAX           100
#define LCDSLIDER_MIN           -100
#define LCDSLIDER_TICK_INTERVAL     20
#define LCDSLIDER_SINGLE_INTERVAL   20
#define LCDSLIDER_PAGE_INTERVAL     20
#define LCDSLIDER_DEFAULT_VALUE     0
#define LCD_PWM_DEFAULT             LCDSLIDER_DEFAULT_VALUE

// CRT Setting
#define CRTSLIDER_MAX               200
#define CRTSLIDER_MIN               20
#define CRTSLIDER_DEFAULT_VALUE     100
#define CRT_BRIGHT_DEFAULT          CRTSLIDER_DEFAULT_VALUE
#define CRT_CONTRAST_DEFAULT        CRTSLIDER_DEFAULT_VALUE
#define CRT_GAMMA_DEFAULT           CRTSLIDER_DEFAULT_VALUE

// TV Setting
#define TVSLIDER_MAX               200
#define TVSLIDER_MIN               20
#define TVSLIDER_DEFAULT_VALUE     100

#define TV_TYPE_DEFAULT             TV_TYPE_NTSC
#define TV_CONNECTOR_DEFAULT        TV_CON_COMPOSITE | TV_CON_SVIDEO
#define TV_BRIGHT_DEFAULT           TVSLIDER_DEFAULT_VALUE
#define TV_CONTRAST_DEFAULT         TVSLIDER_DEFAULT_VALUE
#define TV_GAMMA_DEFAULT            TVSLIDER_DEFAULT_VALUE
#define TV_CCRS_DEFAULT             TVSLIDER_DEFAULT_VALUE

// Video color enhance setting
#define HUE_SLIDER_MAX             180
#define HUE_SLIDER_MIN             -180
#define SLIDER_VIDEO_MAX           20000
#define SLIDER_VIDEO_MIN           0
#define HUE_DEFAULT_VALUE          0
#define VIDEO_DEFAULT_VALUE        10000

#define VIDEO_HUE_DEFAULT          HUE_DEFAULT_VALUE
#define VIDEO_SATURATION_DEFAULT   VIDEO_DEFAULT_VALUE
#define VIDEO_BRIGHT_DEFAULT       VIDEO_DEFAULT_VALUE
#define VIDEO_CONTRAST_DEFAULT     VIDEO_DEFAULT_VALUE

// Display device
#define LCD_ID  0
#define DVI_ID  1
#define CRT_ID  2
#define HDMI_ID 3
#define HDTV_ID 4
#define TV_ID   5

// Icon dimension
#define ICON_WIDTH  128
#define ICON_HEIGHT 128

#endif
