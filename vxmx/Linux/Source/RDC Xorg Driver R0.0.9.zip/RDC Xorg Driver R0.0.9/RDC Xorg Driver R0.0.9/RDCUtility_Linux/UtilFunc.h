#ifndef UTILFUNC_H
#define UTILFUNC_H


// -----------------------------------------------------------------------------
// Constant
// -----------------------------------------------------------------------------
#define MODE_INDEX_NOT_FOUND -1
#define MODE_NOT_ASSIGN -1

int UtilSetMode(UTDEVICELIST actDevice, 
                int iModWidth=MODE_NOT_ASSIGN, 
                int iModHeight=MODE_NOT_ASSIGN);
                
int ParameterPaser(char argc, char *argv[]);
void Usage(void);
void Version(void);
void ReportActiveDevice(void);
void ReportConnectDevice(void);
void ReportCurrentMode(void);
#endif
