#include "MainWindow.h"
#include <QX11Info>

MainWindow::MainWindow() : QWidget()
{
	// init. components.
	tab		= new MainTabWidget() ;
	okBtn		= new QPushButton(tr("Quit")) ;
	//cancelBtn	= new QPushButton(tr("Cancel")) ;
	applyBtn	= new QPushButton(tr("Apply")) ;

	// init. layout.
	btnLayout = new QHBoxLayout() ;
	layout = new QVBoxLayout ;

	// arrange components.
	btnLayout->addWidget(okBtn) ;
	//btnLayout->addWidget(cancelBtn) ;
	btnLayout->addWidget(applyBtn) ;
	layout->addWidget(tab) ;
	layout->addLayout(btnLayout) ;
	setLayout(layout) ;
	setWindowTitle(tr("RDC Graphic Utility")) ;

	// connect signal and slot.
	connect(applyBtn, SIGNAL(clicked()), tab, SLOT(applyBtnClicked())) ;
	connect(okBtn, SIGNAL(clicked()), this, SLOT(close())) ;
} ;

MainWindow::~MainWindow()
{

} ;
