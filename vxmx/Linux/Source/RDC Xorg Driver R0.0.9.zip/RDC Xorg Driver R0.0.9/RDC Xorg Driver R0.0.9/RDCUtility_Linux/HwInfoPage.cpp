#include "HwInfoPage.h"
#include "Escape.h"

class QMessageBox ;

HwInfoPage::HwInfoPage() : QWidget()
{
	// Get hardware info value
	unsigned int BiosVer = 0;
	DWORD MemInfo = 0;
	CLKINFO ClkInfo ;
	ClkInfo.EngCLK = 0;
	ClkInfo.MemCLK = 0;

	QString BiosVerStr, PrjStr, MajStr, MinStr ;
	QString MemInfoStr ;
	QString EngClkStr, MemClkStr ;

    /*
     Get Bios version.
     
     [31:24] : Branch version number
     [23:8]  : Customer Index
     [7:0]   : Release version number
     */
	UT_QueryBiosVersion(BiosVer) ;
	qDebug("[RDC Utility] : BiosVer : %X\n", BiosVer) ;
	PrjStr.setNum(BiosVer>>24);
	MajStr.setNum((BiosVer & 0x00FFFF00)>>8);
	MinStr.setNum(BiosVer & 0x000000FF);
	BiosVerStr = PrjStr + '.' + MajStr + '.' + MinStr;

	UT_QueryMemInfo(MemInfo) ;  // Get video memory size.
	MemInfo = (MemInfo/(1024*1024)) ;  // Convert from byte to MB
	qDebug("[RDC Utility] : MemInfo : %d MB\n", (int) MemInfo) ;
	MemInfoStr.setNum(MemInfo, 10) ;

	UT_QueryClockSpeed(&ClkInfo) ;  // Get Engine and Memory clock info.
	EngClkStr.setNum(ClkInfo.EngCLK, 10) ;
	MemClkStr.setNum(ClkInfo.MemCLK, 10) ;
	
	// init. components and assign description string.
	hwinfoGB	= new QGroupBox(tr("Hardware Information"), this) ;
	biosVerGB	= new QGroupBox(tr("Bios"), this) ;
	videoMemGB	= new QGroupBox(tr("Video Memory"), this) ;
	//clockGB		= new QGroupBox(tr("Clock"), this) ;

	hwinfoLabel[0]	= new QLabel(tr("Manufacturer : RDC"), this) ;
	hwinfoLabel[1]	= new QLabel(tr("Model : RDC Graphic Card"), this) ;
	//hwinfoLabel[2]	= new QLabel(tr("Driver Version : "), this) ;

	biosVerLabel	= new QLabel(QString(tr("Bios Version : "))+BiosVerStr.toUpper(), this) ;
	videoMemLabel	= new QLabel(QString(tr("Video Memory Size : "))+MemInfoStr+QString("MB"), this) ;
	//clockLabel[0]	= new QLabel(QString(tr("Memory Clock : "))+MemClkStr+QString("MHz"), this) ;
	//clockLabel[1]	= new QLabel(QString(tr("Core Clock : "))+EngClkStr+QString("MHz"), this) ;
	
	// init. layout.
	layout			= new QVBoxLayout(this) ;
	hwinfoGBLayout		= new QVBoxLayout() ;
	biosVerGBLayout		= new QVBoxLayout() ;
	videoMemGBLayout	= new QVBoxLayout() ;
	//clockGBLayout		= new QVBoxLayout() ;

	hwinfoGB->setLayout(hwinfoGBLayout) ;
	biosVerGB->setLayout(biosVerGBLayout) ;
	videoMemGB->setLayout(videoMemGBLayout) ;
	//clockGB->setLayout(clockGBLayout) ;

	for (int i=0 ; i<2 ; i++) // "Driver Version is hided currently.
		hwinfoGBLayout->addWidget(hwinfoLabel[i]) ;

	biosVerGBLayout->addWidget(biosVerLabel) ;
	videoMemGBLayout->addWidget(videoMemLabel) ;

	/*for (int j=0 ; j<2 ; j++)
		clockGBLayout->addWidget(clockLabel[j]) ;*/

	// arrange layout.
	layout->addWidget(hwinfoGB, 2) ;
	layout->addWidget(biosVerGB, 1) ;
	layout->addWidget(videoMemGB, 1) ;
	//layout->addWidget(clockGB, 2) ;
} ;

HwInfoPage::~HwInfoPage()
{

} ;
