#ifndef DISPSTACKEDPAGE_H
#define DISPSTACKEDPAGE_H
#include <QtGui>
#include <QStackedWidget>
#include "DispDevPage.h"
#include "LcdSetting.h"
#include "CrtSetting.h"
#include "TvSetting.h"

class DispStackedPage : public QStackedWidget
{
	Q_OBJECT

	signals :
		void applyBtnClick() ;

	public slots :
		void applyBtnClicked() ;

	public :
		DispStackedPage(QWidget *parent=0) ;
		~DispStackedPage() ;

	private :
		// ui components.
		DispDevPage     *disPage ;
		LcdSetting		*lcdSettingPage ;
		CrtSetting		*crtSettingPage ;
		TvSetting       *tvSetting;
} ;

#endif
