#ifndef MAINTABWIDGET_H
#define MAINTABWIDGET_H

#include <QtGui>
#include <QTabWidget>
#include "DispStackedPage.h"
#include "HwInfoPage.h"
#include "VideoColorEnhancePage.h"

class MainTabWidget : public QTabWidget
{
	Q_OBJECT

	signals :
		void applyBtnClick() ;

	public slots :
		void applyBtnClicked() ;

	public :
		MainTabWidget() ;
		~MainTabWidget() ;

	private :
                // ui components.
                DispStackedPage	*displayPage ;
                HwInfoPage      *hwInfoPage ;
                VideoColorEnhancePage *videoPage;
} ;

#endif
