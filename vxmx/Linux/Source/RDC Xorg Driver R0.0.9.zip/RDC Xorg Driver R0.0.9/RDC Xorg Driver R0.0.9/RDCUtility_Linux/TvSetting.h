#ifndef TVSETTING_H
#define TVSETTING_H
#include <QtGui>
#include <QWidget>
#include "Escape.h"
#include "GlobalVars.h"

class QLabel ;
class QSlider ;
class QPushButton ;
class QStringList ;
class QVBoxLayout ;
class QHBoxLayout ;

class TvSetting : public QWidget
{
	Q_OBJECT

	signals :
		void changeToWidget(int) ;
		void defaultSet() ;

	public slots :
		void processWidgetChange() ;
		void setToDefault() ;
		void updateGamma();
		void updateCCRS();
		void updateTvInfo();

	public :
		TvSetting(QWidget *parent=0) ;
		~TvSetting() ;
		void initGamaTbl(GammaTbl *) ;
		void SetNewGamma(float , float , float , GammaTbl *) ;
		void show();

	private :
		// ui components.
		QLabel		*TvDesc ;
		QLabel      *TvType;
		QLabel      *TvConnector;
		QLabel		*sliderDesc[4] ; // description for brightness, contrast and gamma.
		QSlider		*slider[4] ; // slider for brightness, contrast and gamma.
		QRadioButton    *pRBtnNTSC, *pRBtnPal;
		QRadioButton    *pRBtnComposite, *pRBtnSVideo;
		QGroupBox   *typeGrp, *connectorGrp;
		QPushButton	*restoreBtn;
		QPushButton	*okBtn;

		// data components.
		GammaTbl 	*tbl;
		QStringList	TvSettingDesc;
		QList<BYTE> TvSettingDescValue;

		// Pointer to global AppSetting.
		WORD        *pwType;
		BYTE        *pbConnector;
		BYTE        *pbBrightness, *pbContrast, *pbGamma, *pbCCRS;
		bool        bTvChanged;
		TVINFO      TvInfo;

		// layout managers.
		QVBoxLayout	*Layout;
    	QHBoxLayout *RBtnSliderLayout;
    	QVBoxLayout *RBtnGrpLayout;
    	QHBoxLayout *SliderLayout[4];
    	QVBoxLayout *SliderGrpLayout;
    	QHBoxLayout *TvTypeRBtnLayout;
    	QHBoxLayout *TvConnectRBtnLayout;
    	QHBoxLayout *BtnLayout;
} ;

#endif

