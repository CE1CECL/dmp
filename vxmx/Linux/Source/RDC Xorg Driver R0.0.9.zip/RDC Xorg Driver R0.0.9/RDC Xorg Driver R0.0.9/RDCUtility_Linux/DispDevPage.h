#ifndef DISPDEVPAGE_H
#define DISPDEVPAGE_H
#include <QtGui>
#include <QWidget>
#include <QQueue>
#include "GlobalVars.h"
#include "Escape.h"
#include "ModeRestoreDialog.h"

class QLabel ;
class QPixmap ;
class QIcon ;
class QPushButton ;
class QStringList ;
class QVBoxLayout ;
class QHBoxLayout ;

class DispDevPage : public QWidget
{
	Q_OBJECT

	signals :
		void changeToWidget(int) ;
		void devSelectUpdated() ;
		void actDeviceUpdated() ;

	public slots :
		void changeToLCDSetting() ;
		void changeToCRTSetting() ;
		void changeToTVSetting() ;
		void make2Selected(bool state) ; // to make sure only 2 device could be selected at the same time.
		void updateActDevice() ;
        void show();
        void RestorePreviosBtnState();
        void PollConnectedDeviceStatus();
        
	public :
		DispDevPage() ;
		~DispDevPage() ;
        void SetFirstActDev();

    protected :
        virtual void showEvent (QShowEvent * event);

	private :    
		// ui components.
		QLabel		*descSupDev ;	// label for "Support display device"
		QPixmap		*pixs[NUM_SUPPORT_DSP_DEV] ;
		QIcon		*dispIcon[NUM_SUPPORT_DSP_DEV] ;
		QPushButton	*dspDevIcons[NUM_SUPPORT_DSP_DEV] ;	// array of icon of display device
		QRadioButton	*dspDevSel[NUM_SUPPORT_DSP_DEV] ;	// arrya of radio btns of display device
		QLabel		*descHelp ; // label for "Please select the display device you want

		// data components.
		QStringList	deviceStrLst ;
		QQueue<QRadioButton *>	devSelQueue ; // used in make2Selected().
		UTDEVICELIST    actDevice ; // store the current
		UTDEVICELIST	supDevice ; // supported device
		UTDEVICELIST	conDevice ; // connected device
		int				dwCaps ; // number of concurrent selection.
		int             iFirstActDev;

		ModeRestoreDialog *RestoreDlg;

		// layout managers.
		QVBoxLayout	*layout ;
		QVBoxLayout	*btnLayout[NUM_SUPPORT_DSP_DEV] ;
		QHBoxLayout	*devLayout ;
} ;

#endif
