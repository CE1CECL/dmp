#include "Escape.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <QtGlobal>

#include <X11/extensions/Xrandr.h>

#include "GlobalVars.h"

#include "setting.h"

extern setting AppSetting ; // Declare in qtMain.cpp


// Global variables.
CARD32 *inBufPtr, *outBufPtr ;

// -----------------------------------------------------------------------------
// initShareMem()
// This function init the share memory.
// In parameters :
//      None
// -----------------------------------------------------------------------------
int initShareMem(void)
{
    qDebug("[RDC Utility] : Enter initShareMem()");
    
	int shm_in_id, shm_out_id ;
    key_t in_key, out_key ;
    char inBufName[32] = IN_BUF_NAME ;
    char outBufName[32] = OUT_BUF_NAME ;

    in_key = ftok(inBufName, 4) ;
    out_key = ftok(outBufName, 4) ;
    
    shm_in_id = shmget(in_key, IN_BUF_SIZE, IPC_CREAT) ;
    shm_out_id = shmget(out_key, OUT_BUF_SIZE, IPC_CREAT) ;
    
    inBufPtr = (CARD32 *) shmat(shm_in_id, NULL, 0) ;
    if ((int)inBufPtr == -1)
        qDebug("[RDC Utility] : %s\n", strerror(errno));

    outBufPtr = (CARD32 *) shmat(shm_out_id, NULL, 0) ;
    if ((int)outBufPtr == -1)
        qDebug("[RDC Utility] : %s\n", strerror(errno));
        
    qDebug("[RDC Utility] : Client inBufPtr = %X", (unsigned int) inBufPtr) ;
    qDebug("[RDC Utility] : Client outBufPtr = %X", (unsigned int) outBufPtr) ;

    // Share memory allocate fail.
    if ((int)inBufPtr == -1 || (int)outBufPtr == -1)
        return false;
} ;

// -----------------------------------------------------------------------------
// UT_CheckRDCExtension()
// This function check if the rdc extension exist.
// In parameters :
//      dsp : the global display variable.
// -----------------------------------------------------------------------------
BOOL UT_CheckRDCExtension(Display *dsp, const char *, int *opCode, int *Event, int *Err)
{
    qDebug("[RDC Utility] : Enter UT_CheckRDCExtension()");
    
    return XQueryExtension(dsp, RDC_GFX_UT_EXTENSION_NAME, opCode, Event, Err) ;
} ;

// -----------------------------------------------------------------------------
// UT_SetGamma()
// This function set gamma table
// In buffer:   GammaTbl
// Out buffer:
//              NONE
// Return: UT_SUCCESS: query is success.
//         UT_FAIL: query is fail.
// -----------------------------------------------------------------------------
BOOL UT_SetGamma(GammaTbl *tbl)
{
    qDebug("[RDC Utility] : Enter UT_SetGamma()");

    GammaTbl *GTbl = (GammaTbl *) inBufPtr;

	Display         *dpy ;
    dpy = XOpenDisplay("") ; // get local display.
    qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;

    int opcode ;
    int event ;
    int error ;
    bool status ;

    status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;
    if (!status)
    {
        qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

    // Copy gamma table from tbl to inBufPtr
	GTbl->device = tbl->device ;
	GTbl->dwSize = tbl->dwSize ;
	int size = sizeof(DWORD) ;
	GTbl->table = (PVIDEO_CLUT) (((BYTE*)inBufPtr)+3*size) ;
	GTbl->table->NumEntries = tbl->table->NumEntries ;
	qDebug("[RDC Utility] : NumEntries = %d", ((GammaTbl *) inBufPtr)->table->NumEntries) ;
	GTbl->table->FirstEntry = tbl->table->FirstEntry ;
	for (int i=0 ; i<256 ; i++)
    {
        GTbl->table->LookupTable[i].RgbArray.Red = tbl->table->LookupTable[i].RgbArray.Red ; 
        GTbl->table->LookupTable[i].RgbArray.Green = tbl->table->LookupTable[i].RgbArray.Green ; 
        GTbl->table->LookupTable[i].RgbArray.Blue = tbl->table->LookupTable[i].RgbArray.Blue ; 
        GTbl->table->LookupTable[i].RgbArray.Unused = tbl->table->LookupTable[i].RgbArray.Unused ; 
    } ;

	qDebug("[RDC Utility] : Gamma table at 127 : %d", GTbl->table->LookupTable[127].RgbArray.Red) ;

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

    // Prepare send request.
    xRDCGFXCommandReq       *req ;

    // Send request.
	GetReq(RDCGFXCommand, req) ;

    req->reqType = opcode ;
    req->length = sizeof(xRDCGFXCommandReq)>>2;
    req->RDCGFXReqType = X_RDCGFXCommand ;
    req->util_cmd_id = UT_SET_GAMMA ;
    req->inBufferSize = sizeof(GammaTbl) ;

    _XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;

    UnlockDisplay(dpy) ;
    SyncHandle() ;

    // Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// UT_SetLcdPWM()
// This function set pwm level of LCD.
// In buffer:   BYTE *level (0~255)
// Out buffer:
//              NONE
// Return: UT_SUCCESS: query is success.
//         UT_FAIL: query is fail.
// -----------------------------------------------------------------------------
BOOL UT_SetLcdPWM(BYTE *level)
{
    qDebug("[RDC Utility] : Enter UT_SetLcdPWM()");
    
	// Set share memory content
	inBufPtr[0] = *level ;

	Display         *dpy ;
    dpy = XOpenDisplay("") ; // get local display.
    qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;

    int opcode ;
    int event ;
    int error ;
    bool status ;

    status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;
    if (!status)
    {
        qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

    // Lock display, XLib macro.
    LockDisplay(dpy) ;
        
    // Prepare send request.
    xRDCGFXCommandReq       *req ;
        
	// Send request.
    GetReq(RDCGFXCommand, req) ;
        
    req->reqType = opcode ;
    req->length = sizeof(xRDCGFXCommandReq)>>2;
    req->RDCGFXReqType = X_RDCGFXCommand ;
    req->util_cmd_id = UT_SET_LCD_PWM ;
    req->inBufferSize = sizeof(UCHAR) ;
       
    _XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
    qDebug("[RDC Utility] : LCD PWM Level : %d", *level) ;
        
    UnlockDisplay(dpy) ;
    SyncHandle() ;
        
    // Flush Display.
    XFlush(dpy) ;
    XCloseDisplay(dpy) ;
        
	return true ;
} ;

// -----------------------------------------------------------------------------
// UT_QuerySupportDevice()
// This function query the list of support device.
// In buffer:   NONE
// Out buffer:  
//              UTDEVICELIST *actDevList
// Return: UT_SUCCESS: query is success.
//         UT_FAIL: query is fail.
// -----------------------------------------------------------------------------
BOOL UT_QuerySupportDevice(UTDEVICELIST *actDevList)
{
    qDebug("[RDC Utility] : Enter UT_QuerySupportDevice()");
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;
	if (!status)
    {
		actDevList->MERGE = 37 ; // for debug
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq	*req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_QUERY_SUPPORT_DEVICE ;
	req->outBufferSize = sizeof(unsigned long) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;
	actDevList->MERGE = ((UTDEVICELIST *) outBufPtr)->MERGE ;
	qDebug("[RDC Utility] : support MERGE = %d", actDevList->MERGE);
#ifdef TEST
	actDevList->MERGE = 37 ; // for debug
#endif

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// UT_QueryConnectDevice()
// This function query the list of support device.
// In buffer:   NONE
// Out buffer:  
//              UTDEVICELIST *actDevList
// Return: UT_SUCCESS: query is success.
//         UT_FAIL: query is fail.
// -----------------------------------------------------------------------------
BOOL UT_QueryConnectDevice(UTDEVICELIST *conDevList)
{
    qDebug("[RDC Utility] : Enter UT_QueryConnectDevice()");
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
		conDevList->MERGE = 33 ; // for debug
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq	*req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_QUERY_CONNECT_DEVICE ;
	req->outBufferSize = sizeof(unsigned long) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;
	conDevList->MERGE = ((UTDEVICELIST *) outBufPtr)->MERGE ;
	qDebug("[RDC Utility] : connect MERGE = %d", conDevList->MERGE);
#ifdef TEST
	conDevList->MERGE = 37;
#endif

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// UT_SetDeviceAct()
// This function set active device.
// In buffer:   UTDEVICELIST *actDevList
// Out buffer:  
//              NONE
// Return: UT_SUCCESS: query is success.
//         UT_FAIL: query is fail.
// -----------------------------------------------------------------------------
int UT_SetDeviceAct(UTDEVICELIST *actDevList)
{
    qDebug("[RDC Utility] : Enter UT_SetDeviceAct()");
    
    // input assign.
    ((UTDEVICELIST *) inBufPtr)->MERGE = actDevList->MERGE ;
    qDebug("[RDC Utility] : In Escape actDevList : %d", ((UTDEVICELIST *) inBufPtr)->MERGE) ;

    // Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
    Display         *dpy ;
    dpy = XOpenDisplay("") ; // get local display.
    qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;

    int opcode ;
    int event ;
    int error ;
    bool status ;

    status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;
    if (!status)
    {
        qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

    // Lock display, XLib macro.
    LockDisplay(dpy) ;

    // Prepare send request.
    xRDCGFXCommandReq *req ;

    // Send request.
    GetReq(RDCGFXCommand, req) ;

    req->reqType = opcode ;
    req->length = sizeof(xRDCGFXCommandReq)>>2;
    req->RDCGFXReqType = X_RDCGFXCommand ;
    req->util_cmd_id = UT_SET_DEVICE_ACT ;
    req->inBufferSize = sizeof(UTDEVICELIST) ;

    _XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
    qDebug("[RDC Utility] : Got reply") ;

    UnlockDisplay(dpy) ;
    SyncHandle() ;

    // Flush Display.
    XFlush(dpy) ;
    XCloseDisplay(dpy) ;

    return true ;
} ;

// -----------------------------------------------------------------------------
// UT_QueryActDevice()
// This function query the list of support device.
// In buffer:   NONE
// Out buffer:  
//              UTDEVICELIST *actDevList
// Return: UT_SUCCESS: query is success.
//         UT_FAIL: query is fail.
// -----------------------------------------------------------------------------
BOOL UT_QueryActDevice(UTDEVICELIST *actDevList)
{
    qDebug("[RDC Utility] : Enter UT_QueryActDevice()");
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
		actDevList->MERGE = 4 ; // for debug
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq	*req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_QUERY_ACT_DEVICE ;
	req->outBufferSize = (sizeof(UCHAR)*2) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;
	actDevList->MERGE = ((UTDEVICELIST *) outBufPtr)->MERGE ;
	qDebug("[RDC Utility] : active MERGE = %d", actDevList->MERGE);
#ifdef TEST
	actDevList->MERGE = 4;
#endif

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	// Save current active device into global setting.
	AppSetting.ActDevicelist = *actDevList;

	return true ;
} ;

// -----------------------------------------------------------------------------
// UT_QueryBiosVersion()
// This function query Bios version info.
// In buffer:	None
// Out buffer:	
//		UTBIOSDATA *biosVer
// Return: UT_SUCCESS: query is success.
//         UT_FAIL: query is fail.
// -----------------------------------------------------------------------------
BOOL UT_QueryBiosVersion(unsigned int &version)
{
    qDebug("[RDC Utility] : Enter UT_QueryBiosVersion()");
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq	*req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_QUERY_BIOS_VERSION ;
	req->outBufferSize = sizeof(unsigned long) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;
	version = outBufPtr[0] ;
	qDebug("[RDC Utility] : version : %X", version) ;

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// UT_QueryMemInfo()
// This function query video memory size info.
// In buffer:   None
// Out buffer:  
//              DWORD dwMemSize
// Return: UT_SUCCESS: query is success.
//         UT_FAIL: query is fail.
// -----------------------------------------------------------------------------
BOOL UT_QueryMemInfo(DWORD &dwMemSize)
{
    qDebug("[RDC Utility] : Enter UT_QueryMemInfo()");
    
	Display         *dpy ;
    dpy = XOpenDisplay("") ; // get local display.
    qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;

    int opcode ;
    int event ;
    int error ;
    bool status ;

    status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;
    if (!status)
    {
        qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

    // Lock display, XLib macro.
    LockDisplay(dpy) ;
        
    // Prepare send request.
    xRDCGFXCommandReq       *req ;
        
    // Send request.
    GetReq(RDCGFXCommand, req) ;
        
	req->reqType = opcode ;
    req->length = sizeof(xRDCGFXCommandReq)>>2;
    req->RDCGFXReqType = X_RDCGFXCommand ;
    req->util_cmd_id = UT_QUERY_MEM_INFO ;
    req->outBufferSize = sizeof(unsigned long) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
    dwMemSize = outBufPtr[0] ;
    qDebug("[RDC Utility] : Video memory size : %X", (unsigned int) dwMemSize) ;

    UnlockDisplay(dpy) ;
    SyncHandle() ;

    // Flush Display.
    XFlush(dpy) ;
    XCloseDisplay(dpy) ;
        
    return true ;
} ;

// -----------------------------------------------------------------------------
// UT_QueryClockSpeed()
// This function query engine and memory info.
// In buffer:   None
// Out buffer:  
//              CLKINFO *ClkInfo
// Return: UT_SUCCESS: query is success.
//         UT_FAIL: query is fail.
// -----------------------------------------------------------------------------
BOOL UT_QueryClockSpeed(CLKINFO *ClkInfo)
{
    qDebug("[RDC Utility] : Enter UT_QueryClockSpeed()");
    
	Display         *dpy ;
    dpy = XOpenDisplay("") ; // get local display.
    qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;

    int opcode ;
    int event ;
    int error ;
    bool status ;

    status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;
    if (!status)
    {
        qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

    // Prepare send request.
	xRDCGFXCommandReq       *req ;

    // Send request.
    GetReq(RDCGFXCommand, req) ;

    req->reqType = opcode ;
    req->length = sizeof(xRDCGFXCommandReq)>>2;
    req->RDCGFXReqType = X_RDCGFXCommand ;
    req->util_cmd_id = UT_QUERY_CLK_SPEED ;
    req->outBufferSize = sizeof(CLKINFO) ;

    _XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
    ClkInfo->EngCLK = ((CLKINFO *) outBufPtr)->EngCLK ;
    ClkInfo->MemCLK = ((CLKINFO *) outBufPtr)->MemCLK ;
    qDebug("[RDC Utility] : Whole : %X", (unsigned int) outBufPtr[0]) ;
    qDebug("[RDC Utility] : Engine Clock : %d", ClkInfo->EngCLK) ;
    qDebug("[RDC Utility] : Memory Clock : %d", ClkInfo->MemCLK) ;

    UnlockDisplay(dpy) ;
    SyncHandle() ;

    // Flush Display.
    XFlush(dpy) ;
    XCloseDisplay(dpy) ;

    return true ;
} ;

// -----------------------------------------------------------------------------
// UT_QueryLCDInfo()
// This function query the H and V of LCD panel.
// In buffer:   NONE
// Out buffer:  
//              LCDINFO
// Return: UT_SUCCESS: query is success.
//         UT_FAIL: query is fail.
// -----------------------------------------------------------------------------
BOOL UT_QueryLCDInfo(LCDINFO *pLCDInfo)
{
    qDebug("[RDC Utility] : Enter UT_QueryLCDInfo()");
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq *req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_QUERY_LCD_SIZE ;
	req->outBufferSize = (sizeof(LCDINFO)) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;
	pLCDInfo->LCDHeight = ((LCDINFO *) outBufPtr)->LCDHeight;
	pLCDInfo->LCDWidth = ((LCDINFO *) outBufPtr)->LCDWidth;
	qDebug("[RDC Utility] : LCD height = %d", pLCDInfo->LCDHeight);
	qDebug("[RDC Utility] : LCD width = %d", pLCDInfo->LCDWidth);

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// This function set TV type and connector
// In buffer: (in)  TVInfo
// Out buffer: (in) none
// Return: UT_SUCCESS: query is success.
//         UT_FAIL:    query is fail.
// -----------------------------------------------------------------------------
int UT_SetTVInfo(PTVINFO pTVInfo)
{
    qDebug("[RDC Utility] : Enter UT_SetTVInfo()");

    PTVINFO pTv = (PTVINFO) inBufPtr;
    pTv->wType = pTVInfo->wType;
    pTv->bConnector = pTVInfo->bConnector;
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq *req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_SET_TV_INFO ;
	req->inBufferSize = (sizeof(TVINFO)) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
};

// -----------------------------------------------------------------------------
// This function qurey TV information
// In buffer: (in)  none
// Out buffer: (in) TVInfo
// Return: UT_SUCCESS: query is success.
//         UT_FAIL:    query is fail.
// -----------------------------------------------------------------------------
BOOL UT_QueryTVInfo(PTVINFO pTVInfo)
{
    qDebug("[RDC Utility] : Enter UT_SetTVInfo()");

    PTVINFO pTvInfo = (PTVINFO) outBufPtr;
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq *req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_QUERY_TV_INFO ;
	req->outBufferSize = (sizeof(TVINFO)) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;

	// Copy value.
	pTVInfo->wType = pTvInfo->wType;
	pTVInfo->bConnector = pTvInfo->bConnector;

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
};

// -----------------------------------------------------------------------------
// Set TV CCRS
// -----------------------------------------------------------------------------
BOOL UT_SetTvCCRS(BYTE *value)
{
    qDebug("[RDC Utility] : Enter UT_SetTVInfo()");

    BYTE *pbCCRS = (BYTE *) inBufPtr;
    *pbCCRS = *value;
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq *req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_SET_TV_CCRS_LEVEL ;
	req->inBufferSize = (sizeof(BYTE)) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// Query TV CCRS
// -----------------------------------------------------------------------------
BYTE UT_QueryTvCCRS(void)
{
    qDebug("[RDC Utility] : Enter UT_QueryTvCCRS()");

    BYTE *pbCCRS = (BYTE *) outBufPtr;
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq *req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_QUERY_TV_CCRS_LEVEL ;
	req->outBufferSize = (sizeof(BYTE)) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return *pbCCRS ;
} ;

// -----------------------------------------------------------------------------
// Set contrast in video color enhance.
// -----------------------------------------------------------------------------
BOOL UT_SetVideoContrast(int *value)
{
    qDebug("[RDC Utility] : Enter UT_SetVideoContrast()");

    int *pulContrast = (int *) inBufPtr;
    *pulContrast = *value;
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq *req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_SET_VIDEO_CONTRAST ;
	req->inBufferSize = (sizeof(ULONG)) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// Query contrast in video color enhance.
// -----------------------------------------------------------------------------
BOOL UT_QueryVideoContrast(int* value)
{
    qDebug("[RDC Utility] : Enter UT_QueryVideoContrast()");

    value = (int *) outBufPtr;
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq *req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_QUERY_VIDEO_CONTRAST ;
	req->outBufferSize = (sizeof(ULONG)) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// Set brightness in video color enhance.
// -----------------------------------------------------------------------------
BOOL UT_SetVideoBrightness(int *value)
{
    qDebug("[RDC Utility] : Enter UT_SetVideoBrightness()");

    int *pulContrast = (int *) inBufPtr;
    *pulContrast = *value;
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq *req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_SET_VIDEO_BRIGHT ;
	req->inBufferSize = (sizeof(ULONG)) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// Query brightness in video color enhance.
// -----------------------------------------------------------------------------
BOOL UT_QueryVideoBrightness(int* value)
{
    qDebug("[RDC Utility] : Enter UT_QueryVideoBrightness()");

    value = (int *) outBufPtr;
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq *req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_QUERY_VIDEO_BRIGHT ;
	req->outBufferSize = (sizeof(ULONG)) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// Set hue in video color enhance.
// -----------------------------------------------------------------------------
BOOL UT_SetVideoHue(int *value)
{
    qDebug("[RDC Utility] : Enter UT_SetVideoHue()");

    int *pulContrast = (int *) inBufPtr;
    *pulContrast = *value;
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq *req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_SET_VIDEO_HUE ;
	req->inBufferSize = (sizeof(ULONG)) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// Query hue in video color enhance.
// -----------------------------------------------------------------------------
BOOL UT_QueryVideoHue(int* value)
{
    qDebug("[RDC Utility] : Enter UT_QueryVideoHue()");

    value = (int *) outBufPtr;
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq *req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_QUERY_VIDEO_HUE ;
	req->outBufferSize = (sizeof(ULONG)) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// Set saturation in video color enhance.
// -----------------------------------------------------------------------------
BOOL UT_SetVideoSaturation(int *value)
{
    qDebug("[RDC Utility] : Enter UT_SetVideoSaturation()");

    int *pulContrast = (int *) inBufPtr;
    *pulContrast = *value;
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq *req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_SET_VIDEO_SATURATION ;
	req->inBufferSize = (sizeof(ULONG)) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;

// -----------------------------------------------------------------------------
// Query saturation in video color enhance.
// -----------------------------------------------------------------------------
BOOL UT_QueryVideoSaturation(int* value)
{
    qDebug("[RDC Utility] : Enter UT_QueryVideoSaturation()");

    value = (int *) outBufPtr;
    
	// Query if the RDC_GFX_UT_EXTENSION_NAME is present or not.
	Display		*dpy ;
	dpy = XOpenDisplay("") ; // get local display.
	qDebug("[RDC Utility] : dpy : %X", (unsigned int) dpy) ;
	
	int opcode ;
	int event ;
	int error ;
	bool status ;

	status = UT_CheckRDCExtension(dpy, RDC_GFX_UT_EXTENSION_NAME, &opcode, &event, &error) ;	
	if (!status)
    {
	    qDebug("[RDC Utility] : RDC extension doesn't exist") ;
        return status;
    };

	// Lock display, XLib macro.
	LockDisplay(dpy) ;

	// Prepare send request.
	xRDCGFXCommandReq *req ;

	// Send request.
	GetReq(RDCGFXCommand, req) ;

	req->reqType = opcode ;
	req->length = sizeof(xRDCGFXCommandReq)>>2;
	req->RDCGFXReqType = X_RDCGFXCommand ;
	req->util_cmd_id = UT_QUERY_VIDEO_SATURATION ;
	req->outBufferSize = (sizeof(ULONG)) ;

	_XReply(dpy, (xReply *) req, (sizeof(xRDCGFXCommandReq)-sizeof(xGenericReply))>>2, xFalse) ;
	qDebug("[RDC Utility] : Got reply") ;

	UnlockDisplay(dpy) ;
	SyncHandle() ;
		
	// Flush Display.
	XFlush(dpy) ;
	XCloseDisplay(dpy) ;

	return true ;
} ;
