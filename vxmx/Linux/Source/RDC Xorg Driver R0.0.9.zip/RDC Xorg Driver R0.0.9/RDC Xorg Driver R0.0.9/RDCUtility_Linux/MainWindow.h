#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QtGui>
#include <QWidget>
#include "MainTabWidget.h"

class QPushButton ;
class QHBoxLayout ;
class QVBoxLayout ;

class MainWindow : public QWidget
{
	public :
       	MainWindow() ;
		~MainWindow() ;

	private :
		// UI components.
		MainTabWidget	*tab ;
		QPushButton	*okBtn ;
		QPushButton	*cancelBtn ;
		QPushButton	*applyBtn ;

		// Layout managers
		QHBoxLayout	*btnLayout ;
		QVBoxLayout	*layout ;
} ;

#endif
