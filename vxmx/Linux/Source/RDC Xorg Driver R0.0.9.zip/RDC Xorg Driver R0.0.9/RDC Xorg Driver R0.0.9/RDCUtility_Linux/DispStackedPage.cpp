#include "DispStackedPage.h"

DispStackedPage::DispStackedPage(QWidget *parent) : QStackedWidget(parent)
{
	// init. ui components.
	disPage		= new DispDevPage() ;
	lcdSettingPage	= new LcdSetting() ;
	crtSettingPage	= new CrtSetting() ;
	tvSetting = new TvSetting();

	addWidget(disPage) ;
	addWidget(lcdSettingPage) ;
	addWidget(crtSettingPage) ;
	addWidget(tvSetting);
	
	// show the display device page at start up.
	setCurrentIndex(0) ;

	// connect signal and slot
	connect(disPage, SIGNAL(changeToWidget(int)), this, SLOT(setCurrentIndex(int))) ;
	connect(lcdSettingPage, SIGNAL(changeToWidget(int)), this, SLOT(setCurrentIndex(int))) ;
	connect(crtSettingPage, SIGNAL(changeToWidget(int)), this, SLOT(setCurrentIndex(int))) ;
	connect(tvSetting, SIGNAL(changeToWidget(int)), this, SLOT(setCurrentIndex(int))) ;
	connect(this, SIGNAL(applyBtnClick()), disPage, SLOT(updateActDevice())) ;
} ;

DispStackedPage::~DispStackedPage()
{

} ;

void DispStackedPage::applyBtnClicked()
{
	emit applyBtnClick() ;
} ;
