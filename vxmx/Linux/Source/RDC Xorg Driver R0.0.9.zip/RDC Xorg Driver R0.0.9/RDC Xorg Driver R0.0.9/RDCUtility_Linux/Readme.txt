* -------------------------------------------
* Qt requirements :
* -------------------------------------------
- Qt 4 or higher is needed.
- Static Linked Qt library.

* -------------------------------------------
* How to build static Qt library :
* -------------------------------------------
- Download from http://www.qtsoftware.com/downloads
- tar xvzf qt-x11-opensource-src-4.x.x.tar.gz
- cd qt-x11-opensource-src-4.x.x
- configure -static
  If you using Qt 4.5.1 add following parameters
  -no-mmx
  -no-3dnow
  -no-sse
  -no-sse2
  Qt 4.2.0 doesn't have those parameters.
  (Only Qt 4.2.0 and Qt 4.5.1 are tested currently.)
- make
- make install (must run as root)
- Qt library will be installed at /usr/local/Trolltech/qt-4.x.x generally.

* -------------------------------------------
* Compilation procedure :
* -------------------------------------------
1. qmake -project
  - get .pro project file
2. qmake
  - will generate Makefile
3. add "-lXrandr" after "LIBS" in Makefile.
4. make
