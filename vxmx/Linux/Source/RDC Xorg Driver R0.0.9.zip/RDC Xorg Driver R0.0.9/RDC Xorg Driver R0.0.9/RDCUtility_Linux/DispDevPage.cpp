#include "DispDevPage.h"
#include "math.h"
#include "setting.h"
#include "UtilFunc.h"

// -----------------------------------------------------------------------------
// Global variable.
// -----------------------------------------------------------------------------
extern setting AppSetting ; // Declare in qtMain.cpp

// -----------------------------------------------------------------------------
//  DispDevPage::DispDevPage()
// -----------------------------------------------------------------------------
DispDevPage::DispDevPage() : QWidget()
{
    // Setup by config file.
    UTDEVICELIST *ConfigActDev = &AppSetting.ActDevicelist;
    int iScrW = AppSetting.iScrWidth;
    int iScrH = AppSetting.iScrHeight;

    if (ConfigActDev->MERGE != 0)
        UT_SetDeviceAct(ConfigActDev);

	// init. data member.
	deviceStrLst<<"LCD"<<"DVI"<<"CRT"<<"HDMI"<<"HDTV"<<"TV" ; // the order is record in GlobalVars.h
	supDevice.MERGE = conDevice.MERGE = actDevice.MERGE = 0 ;
	AppSetting.chkSupportDspDevice();
	AppSetting.chkConnectedDspDevice();
	AppSetting.chkActiveDspDevice();
	supDevice = AppSetting.supportDspDevice();
	conDevice = AppSetting.connectDspDevice();
	actDevice = AppSetting.activeDspDevice();
	dwCaps = AppSetting.GetRDCDeviceCaps();
	iFirstActDev = -1;
	RestoreDlg = new ModeRestoreDialog();

	if (dwCaps == CAPS_ONE_DISPLAY)
		dwCaps = 1 ;
	else
		dwCaps = 2 ;

	// init. components.
	descSupDev = new QLabel(tr("Support Display Device"), this) ;

	for (int i=0 ; i<NUM_SUPPORT_DSP_DEV ; i++)
	{
		// Icon
		QString pix_path = QString(":/icon/") + QString::number(i) + QString(".png") ;
		pixs[i]		= new QPixmap(pix_path) ;
		dispIcon[i]	= new QIcon(pixs[i]->scaled(ICON_WIDTH, ICON_HEIGHT, Qt::IgnoreAspectRatio, Qt::SmoothTransformation)) ;
		dspDevIcons[i]	= new QPushButton("", this) ;
		dspDevIcons[i]->setFlat(true) ;	// set flat style
		dspDevIcons[i]->setIcon(*dispIcon[i]) ;	// set icon
		dspDevIcons[i]->setIconSize(QSize(ICON_WIDTH, ICON_HEIGHT)) ;	// set icon size
		// Radio button
		dspDevSel[i]	= new QRadioButton(deviceStrLst.at(i), this) ;
		dspDevSel[i]->setAutoExclusive(false) ;
		// Check if it is connected.
		if (!AppSetting.isDeviceConnected(i))
			dspDevSel[i]->setDisabled(true) ;
		// Check if it is supported.
		if (!AppSetting.isDeviceSupported(i))
		{
			dspDevIcons[i]->hide();
			dspDevSel[i]->hide();
		};
		// Check if it is activated.
		if (AppSetting.isDeviceActivated(i))
		    iFirstActDev = i;
		    
		btnLayout[i]	= new QVBoxLayout() ;
		btnLayout[i]->addWidget(dspDevIcons[i], 0, Qt::AlignHCenter) ;
		btnLayout[i]->addWidget(dspDevSel[i], 0, Qt::AlignHCenter) ;
	} ;

	descHelp = new QLabel(tr("Please choose the display device you want.\n(Click on device image for advanced settings."), this) ;

	// init. layout.
	layout = new QVBoxLayout(this) ;
	devLayout = new QHBoxLayout() ;

	for (int o=0 ; o<NUM_SUPPORT_DSP_DEV ; o++)
		devLayout->addLayout(btnLayout[o]) ;

	// arrange layout.
	layout->addWidget(descSupDev, 1, Qt::AlignTop) ;
	layout->addLayout(devLayout, 8) ;
	layout->addWidget(descHelp, 1, Qt::AlignBottom) ;

	// Connect signal and slot.
	//connect(dspDevIcons[0], SIGNAL(clicked()), this, SLOT(changeToLCDSetting())) ;
	connect(dspDevIcons[2], SIGNAL(clicked()), this, SLOT(changeToCRTSetting())) ;
	connect(dspDevIcons[5], SIGNAL(clicked()), this, SLOT(changeToTVSetting())) ;
	for (int L=0 ; L<NUM_SUPPORT_DSP_DEV ; L++)
		connect(dspDevSel[L], SIGNAL(toggled(bool)), this, SLOT(make2Selected(bool))) ;

    connect(RestoreDlg, SIGNAL(Restored()), this, SLOT(RestorePreviosBtnState()));

    // Set mode according to config file.
    //UtilSetMode(*ConfigActDev, iScrW, iScrH);
} ;

// -----------------------------------------------------------------------------
//  DispDevPage::~DispDevPage
// -----------------------------------------------------------------------------
DispDevPage::~DispDevPage()
{

} ;

// -----------------------------------------------------------------------------
// DispDevPage::changeToLCDSetting
// -----------------------------------------------------------------------------
void DispDevPage::changeToLCDSetting()
{
	// Emit only when LCD radio button is checked.
	if (dspDevSel[IDB_RLCD]->isChecked())
		emit changeToWidget(1) ; // 1 is the position of LCD page in stack window.
} ;

// -----------------------------------------------------------------------------
// DispDevPage::changeToCRTSetting
// -----------------------------------------------------------------------------
void DispDevPage::changeToCRTSetting()
{
	// Emit only when CRT radio button is checked.
	if (dspDevSel[IDB_RCRT]->isChecked())
		emit changeToWidget(2) ; // 2 is the position of LCD page in stack window.
} ;

// -----------------------------------------------------------------------------
// DispDevPage::changeToTVSetting
// -----------------------------------------------------------------------------
void DispDevPage::changeToTVSetting()
{
	// Emit only when TV radio button is checked.
	if (dspDevSel[IDB_RTV]->isChecked())
		emit changeToWidget(3) ; // 3 is the position of LCD page in stack window.
} ;


// -----------------------------------------------------------------------------
// Name : make2Selected slot function
// Desc : Make the amount of radio button selection are limited in NUM_OF_CONCURRENT_SEL(2).
// Return : emit devSelectUpdated signal.
// -----------------------------------------------------------------------------
void DispDevPage::make2Selected(bool state)
{
	// Get sender radio button.
	QRadioButton *curBtn = (QRadioButton *) sender() ;
	qDebug("[RDC Utility] : %s pressed", curBtn->text().toAscii().data()) ;
	qDebug("[RDC Utility] : The address of sendor : %X", (unsigned int) curBtn) ;

	// Process
	if (curBtn->isChecked()) // been checked.
	{
		if (devSelQueue.size() == dwCaps) // queue is already full
		{
			QRadioButton *deSelBtn = devSelQueue.dequeue() ;
			deSelBtn->setChecked(false) ;
		} ;

		devSelQueue.enqueue(curBtn) ;
	}
	else // been unchecked.
	{
		int index = devSelQueue.indexOf(curBtn) ;
		devSelQueue.removeAt(index) ;
	} ;

	emit devSelectUpdated() ;
} ;

void DispDevPage::SetFirstActDev(void)
{
    qDebug("[RDC Utility] : Enter DispDevPage::SetFirstActDev(void)") ;
    qDebug("[RDC Utility] : iFirstActDev = %d", iFirstActDev) ;
    
    if (iFirstActDev != -1)
    {
        dspDevSel[iFirstActDev]->setChecked(true);
        iFirstActDev = -1;
    };
};

// -----------------------------------------------------------------------------
// DispDevPage::updateActDevice
// -----------------------------------------------------------------------------
void DispDevPage::updateActDevice()
{
    qDebug("[RDC Utility] : Enter updateActDevice()") ;

    int ret;
	WORD index = 0;
	TVINFO *pTvInfo = &AppSetting.TV.info;

	PollConnectedDeviceStatus();
	
	actDevice.MERGE = 0 ; // init to 0.
	if (dspDevSel[LCD_ID]->isChecked())
		index |= B_LCD ;
	if (dspDevSel[DVI_ID]->isChecked())
		index |= B_DVI ;
	if (dspDevSel[CRT_ID]->isChecked())
        index |= B_CRT ;
	if (dspDevSel[HDMI_ID]->isChecked())
		index |= B_HDMI ;
	if (dspDevSel[HDTV_ID]->isChecked())
		index |= B_HDTV ;
	if (dspDevSel[TV_ID]->isChecked())
		index |= B_TV ;

    // If no device is selected.
    if (index == 0)
        index |= B_CRT;
	
	//
	// Get new active device
	//
	actDevice.MERGE = index;
	qDebug("[RDC Utility] : actDevice.MERGE = %X", (unsigned int) actDevice.MERGE) ;

	if (actDevice.MERGE & B_TV)
	    UT_SetTVInfo(pTvInfo);
	    
	ret = UtilSetMode(actDevice); // Utility call set mode.

	if (ret == RRSetConfigSuccess)
    {
        RestoreDlg->exec();
    }

	emit actDeviceUpdated() ;
} ;

void DispDevPage::show()
{
    qDebug("[RDC Utility] : Enter DispDevPage::show()") ;
    
    if (iFirstActDev != -1)
        SetFirstActDev();   
        
    QWidget::show();
};

void DispDevPage::showEvent(QShowEvent * event)
{
    PollConnectedDeviceStatus();

    qDebug("[RDC Utility] : Enter DispDevPage::showEvent()") ;
    
    if (iFirstActDev != -1)
        SetFirstActDev();
        
    QWidget::showEvent(event);
};

void DispDevPage::RestorePreviosBtnState(void)
{
    qDebug("[RDC Utility] : Enter DispDevPage::RestorePreviosBtnState()") ;
    
    UTDEVICELIST curDev;
    curDev = AppSetting.QueryCurActDev();

    qDebug("[RDC Utility] : curDev.MERGE = %d", curDev.MERGE) ;
    
    switch (curDev.MERGE)
    {
        case B_LCD:
            dspDevSel[LCD_ID]->setChecked(true);
            break;
        case B_DVI:
            dspDevSel[DVI_ID]->setChecked(true);
            break;        
        case B_CRT:
            dspDevSel[CRT_ID]->setChecked(true);
            break;
        case B_HDMI:
            dspDevSel[HDMI_ID]->setChecked(true);
            break;
        case B_HDTV:
            dspDevSel[HDTV_ID]->setChecked(true);
            break;
        case B_TV:
            dspDevSel[TV_ID]->setChecked(true);
            break;
        default:
            break;
    };
};

void DispDevPage::PollConnectedDeviceStatus(void)
{
    qDebug("[RDC Utility] : Enter DispDevPage::PollConnectedDeviceStatus()") ;
    
    AppSetting.chkConnectedDspDevice();
    
    for (int i=0 ; i<NUM_SUPPORT_DSP_DEV ; i++)
    {
        if (!AppSetting.isDeviceConnected(i)) 
			dspDevSel[i]->setDisabled(true) ;
	    else
	        dspDevSel[i]->setDisabled(false) ;
    };

    qDebug("[RDC Utility] : Leave DispDevPage::PollConnectedDeviceStatus()") ;
};
