#ifndef MODERESTOREDIALOG_H
#define MODERESTOREDIALOG_H
#include <QtGui>
#include <QDialog>
#include "setting.h"

class QLabel ;
class QPushButton ;
class QVBoxLayout ;
class QHBoxLayout ;
class QTimer;

class ModeRestoreDialog : public QDialog
{
	Q_OBJECT

	signals :
	    void Kept();
	    void Restored();

	public slots :
	    void Keep();
	    void Restore();
	    void CountDown();
	    int exec();

	public :
		ModeRestoreDialog(QWidget *parent=0) ;
		~ModeRestoreDialog() ;

	private :
		// ui components.
		QLabel		*Message ;
		QPushButton	*restoreBtn ;
		QPushButton	*okBtn ;
		QTimer      *timer;

		char        MsgBuf[256];
		int         iPeriod;

		// layout managers.
		QVBoxLayout	*layout ;
		QHBoxLayout	*BtnLayout ;
} ;

#endif

