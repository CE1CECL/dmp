#include "LcdSetting.h"
#include "Escape.h"
#include "setting.h"

// -----------------------------------------------------------------------------
// Global variable.
// -----------------------------------------------------------------------------
extern setting AppSetting ; // Declare in qtMain.cpp

LcdSetting::LcdSetting(QWidget *parent) : QWidget(parent)
{
    // Assign pointer
    piPwm = &AppSetting.LCD.iPwm;

	// init. data member.
	pwmDesc		= new QLabel(tr("LCD PWM Adjustment :")) ;
	brightDesc  = new QLabel(tr("Bright"));
	darkDesc    = new QLabel(tr("Dark"));
	pwmSlider	= new QSlider(Qt::Horizontal, this) ;
	defaultBtn	= new QPushButton(tr("Restore"), this) ;
	okBtn		= new QPushButton(tr("Ok"), this) ;

	pwmSlider->setTickPosition(QSlider::TicksBothSides) ;
	pwmSlider->setMinimum(LCDSLIDER_MIN) ;
	pwmSlider->setMaximum(LCDSLIDER_MAX) ;
	pwmSlider->setValue(*piPwm) ;
	pwmSlider->setTickInterval(LCDSLIDER_TICK_INTERVAL) ;
	pwmSlider->setSingleStep(LCDSLIDER_SINGLE_INTERVAL) ;
	pwmSlider->setPageStep(LCDSLIDER_PAGE_INTERVAL) ;

	// init. layout.
	layout		= new QVBoxLayout(this) ;
	btnLayout	= new QHBoxLayout() ;
	descLayout  = new QHBoxLayout();

    descLayout->addWidget(darkDesc, 1, Qt::AlignLeft | Qt::AlignTop);
	descLayout->addWidget(brightDesc, 1, Qt::AlignRight | Qt::AlignTop);

	midLayout = new QVBoxLayout();
	midLayout->addWidget(pwmSlider);
	midLayout->addLayout(descLayout);

	btnLayout->addWidget(defaultBtn) ;
	btnLayout->addWidget(okBtn) ;

	// arrange layout.
	layout->addWidget(pwmDesc, 1, Qt::AlignTop) ;
	layout->addLayout(midLayout, 1);
	layout->addLayout(btnLayout, 1) ;
	
	// connect signal and slot.
	connect(okBtn, SIGNAL(clicked()), this, SLOT(processWidgetChange())) ;
	connect(pwmSlider, SIGNAL(valueChanged(int)), this, SLOT(makeAlignTick(int))) ;
	connect(defaultBtn, SIGNAL(clicked()), this, SLOT(setToDefault())) ;
} ;

LcdSetting::~LcdSetting()
{

} ;

void LcdSetting::processWidgetChange()
{
	emit changeToWidget(0) ;
} ;

void LcdSetting::makeAlignTick(int value)
{
	int newpos = 0 ;
	int length = (LCDSLIDER_MAX-LCDSLIDER_MIN)/9 - 2 ;

	if (value >= 0 )
		newpos = length-(((int)value%(int)length)) ;
	else
		newpos = abs((int)value%(int)length) ;

	newpos < (length/2) ? newpos = value+newpos : newpos = value-(length-newpos) ;

	pwmSlider->setValue(newpos) ; // set position of pwmslider according to newpos.

	setPWMLevel(newpos) ; // apply new PWM level according to the new slider position.

	qDebug("[RDC Utility] : New LCD slider position is %d\n", newpos) ;
	emit alignedTick(newpos) ;
} ;

void LcdSetting::setToDefault()
{
	pwmSlider->setValue(LCDSLIDER_DEFAULT_VALUE) ;

	emit defaultSet() ;
} ;

void LcdSetting::setPWMLevel(int level)
{
    *piPwm = level;
	level = (int)(((double)(level - LCDSLIDER_MIN)/(double)(LCDSLIDER_MAX - LCDSLIDER_MIN))*(double)255) ;
	UT_SetLcdPWM((unsigned char *)&level) ;

	qDebug("[RDC Utility] : LCD PWM set to level %d\n", level) ;
	emit pwmLevelSet(*piPwm) ;
} ;
