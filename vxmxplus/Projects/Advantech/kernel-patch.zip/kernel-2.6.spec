Summary: The Linux kernel (the core of the Linux operating system)

# What parts do we want to build?  We must build at least one kernel.
# These are the kernels that are built IF the architecture allows it.

%define buildup 1
%define buildsmp 1
# Whether to apply the Xen patches, leave this enabled.
%define includexen 1
# Whether to build the Xen kernels, disable if you want.
%define buildxen 1
%define buildxenPAE 0
%define builddoc 0
%define buildkdump 1

# Versions of various parts

#
# Polite request for people who spin their own kernel rpms:
# please modify the "release" field in a way that identifies
# that the kernel isn't the stock distribution kernel, for example by
# adding some text to the end of the version number.
#
%define sublevel 15
%define kversion 2.6.%{sublevel}
%define rpmversion 2.6.%{sublevel}
%define rhbsys  %([ -r /etc/beehive-root -o -n "%{?__beehive_build}" ] && echo || echo .`whoami`)
%define release %(R="$Revision: 1.2054 $"; RR="${R##: }"; echo ${RR%%?})_FC5%{rhbsys}
%define signmodules 0
%define make_target bzImage
%define kernel_image x86

%define KVERREL %{PACKAGE_VERSION}-%{PACKAGE_RELEASE}

# groups of related archs
%define all_x86 i586 i686

# Override generic defaults with per-arch defaults 

%ifarch noarch
%define builddoc 1
%define buildup 0
%define buildsmp 0
%define all_arch_configs $RPM_SOURCE_DIR/kernel-%{kversion}-*.config
%endif

# Xen and kdump only build on i686 and x86_64 ...
%ifnarch i686 x86_64
%define buildxen 0
%define buildkdump 0
%endif

# ... and XenPAE only on i686
%ifnarch i686
%define buildxenPAE 0
%endif

# Second, per-architecture exclusions (ifarch)

%ifarch i586
%define buildsmp 0
%endif

%ifarch %{all_x86}
%define all_arch_configs $RPM_SOURCE_DIR/kernel-%{kversion}-i?86*.config
%define image_install_path boot
%define signmodules 1
%endif

%ifarch x86_64
%define buildsmp 0
%define all_arch_configs $RPM_SOURCE_DIR/kernel-%{kversion}-x86_64*.config
%define image_install_path boot
%define signmodules 1
%endif

%ifarch ppc64
%define buildsmp 0
%define all_arch_configs $RPM_SOURCE_DIR/kernel-%{kversion}-ppc64*.config
%define image_install_path boot
%define signmodules 1
%define make_target vmlinux
%define kernel_image vmlinux
%endif

%ifarch ppc64iseries
%define buildsmp 0
%define all_arch_configs $RPM_SOURCE_DIR/kernel-%{kversion}-ppc64*.config
%define image_install_path boot
%define signmodules 1
%define make_target vmlinux
%define kernel_image vmlinux
%endif

%ifarch s390
%define buildsmp 0
%define all_arch_configs $RPM_SOURCE_DIR/kernel-%{kversion}-s390*.config
%define image_install_path boot
%endif

%ifarch s390x
%define buildsmp 0
%define all_arch_configs $RPM_SOURCE_DIR/kernel-%{kversion}-s390x.config
%define image_install_path boot
%endif

%ifarch sparc
%define all_arch_configs $RPM_SOURCE_DIR/kernel-%{kversion}-sparc.config
%define buildsmp 0
%endif

%ifarch sparc64
%define all_arch_configs $RPM_SOURCE_DIR/kernel-%{kversion}-sparc64*.config
%endif

%ifarch ppc
%define all_arch_configs $RPM_SOURCE_DIR/kernel-%{kversion}-ppc*.config
%define image_install_path boot
%define make_target vmlinux
%define kernel_image vmlinux
%endif

%ifarch ia64
%define all_arch_configs $RPM_SOURCE_DIR/kernel-%{kversion}-ia64.config
%define buildsmp 0
%define image_install_path boot/efi/EFI/redhat
%define signmodules 1
%endif

#
# Three sets of minimum package version requirements in the form of Conflicts:
# to versions below the minimum
#

#
# First the general kernel 2.6 required versions as per
# Documentation/Changes
#
%define kernel_dot_org_conflicts  ppp < 2.4.3-3, isdn4k-utils < 3.2-32, nfs-utils < 1.0.7-12, e2fsprogs < 1.37-4, util-linux < 2.12, jfsutils < 1.1.7-2, reiserfs-utils < 3.6.19-2, xfsprogs < 2.6.13-4, procps < 3.2.5-6.3, oprofile < 0.9.1-2

# 
# Then a series of requirements that are distribution specific, either 
# because we add patches for something, or the older versions have 
# problems with the newer kernel or lack certain things that make 
# integration in the distro harder than needed.
#
%define package_conflicts kudzu < 1.2.5, initscripts < 7.23, udev < 063-6, iptables < 1.3.2-1, ipw2200-firmware < 2.4, selinux-policy-targeted < 1.25.3-14

#
# The ld.so.conf.d file we install uses syntax older ldconfig's don't grok.
#
%define xen_conflicts glibc < 2.3.5-1, xen < 3.0.1

#
# Packages that need to be installed before the kernel is, because the %post
# scripts use them.
#
%define kernel_prereq  fileutils, module-init-tools, initscripts >= 8.11.1-1, mkinitrd >= 4.2.21-1

Name: kernel
Group: System Environment/Kernel
License: GPLv2
Version: %{rpmversion}
Release: %{release}
ExclusiveArch: noarch %{all_x86} x86_64 ppc ppc64 ia64 sparc sparc64 ppc64iseries s390 s390x
ExclusiveOS: Linux
Provides: kernel = %{version}
Provides: kernel-drm = 4.3.0
Provides: kernel-%{_target_cpu} = %{rpmversion}-%{release}
Prereq: %{kernel_prereq}
Conflicts: %{kernel_dot_org_conflicts}
Conflicts: %{package_conflicts}
# We can't let RPM do the dependencies automatic because it'll then pick up
# a correct but undesirable perl dependency from the module headers which
# isn't required for the kernel proper to function
AutoReqProv: no

#
# List the packages used during the kernel build
#
BuildPreReq: module-init-tools, patch >= 2.5.4, bash >= 2.03, sh-utils, tar
BuildPreReq: bzip2, findutils, gzip, m4, perl, make >= 3.78, gnupg, diffutils
BuildRequires: gcc >= 3.4.2, binutils >= 2.12, redhat-rpm-config
BuildConflicts: rhbuildsys(DiskFree) < 500Mb


Source0: ftp://ftp.kernel.org/pub/linux/kernel/v2.6/linux-%{kversion}.tar.bz2
Source1: xen-20060301.tar.bz2
Source2: Config.mk

Source10: COPYING.modules
Source11: genkey

Source20: kernel-%{kversion}-i586.config
Source21: kernel-%{kversion}-i686.config
Source22: kernel-%{kversion}-i686-smp.config
Source23: kernel-%{kversion}-x86_64.config
Source24: kernel-%{kversion}-ppc64.config
Source25: kernel-%{kversion}-ppc64iseries.config
Source26: kernel-%{kversion}-s390.config
Source27: kernel-%{kversion}-s390x.config
Source28: kernel-%{kversion}-ppc.config
Source29: kernel-%{kversion}-ppc-smp.config
Source30: kernel-%{kversion}-ia64.config
Source31: kernel-%{kversion}-i686-xen0.config
Source32: kernel-%{kversion}-i686-xenU.config
Source33: kernel-%{kversion}-i686-kdump.config
Source33: kernel-%{kversion}-x86_64-kdump.config
#Source34: kernel-%{kversion}-sparc.config
#Source35: kernel-%{kversion}-sparc64.config
#Source36: kernel-%{kversion}-sparc64-smp.config
Source37: kernel-%{kversion}-i686-xen0-PAE.config
Source38: kernel-%{kversion}-i686-xenU-PAE.config
Source39: kernel-%{kversion}-x86_64-xen0.config
Source40: kernel-%{kversion}-x86_64-xenU.config

#
# Patches 0 through 100 are meant for core subsystem upgrades
#
Patch1: patch-2.6.16-rc6.bz2
Patch2: patch-2.6.16-rc6-git3.bz2

# Patches 100 through 500 are meant for architecture patches
Patch100: linux-2.6-bzimage.patch

# 200 - 299   x86(-64)

Patch200: linux-2.6-x86-tune-p4.patch
Patch201: linux-2.6-x86-apic-off-by-default.patch
Patch202: linux-2.6-x86-vga-vidfail.patch
Patch203: linux-2.6-intel-cache-build.patch
Patch204: linux-2.6-x86_64-silence-up-apic-errors.patch
Patch205: linux-2.6-edid-check.patch
Patch206: linux-2.6-x86_64-smp-on-uphw-cpucount.patch
Patch207: linux-2.6-x86-hp-reboot.patch
Patch208: linux-2.6-x86-cpu_index-false.patch

# 300 - 399   ppc(64)
Patch301: linux-2.6-cell-numa-init.patch
Patch302: linux-2.6-cell-is-cbea.patch
Patch305: linux-2.6-cell-mambo-drivers.patch
Patch306: linux-2.6-hvc-console.patch
Patch310: linux-2.6-cell-spiderpic-no-devtree.patch
Patch313: linux-2.6-hvc-rtas-console.patch
Patch314: linux-2.6-ppc-rtas-check.patch
Patch317: linux-2.6-ppc-iseries-input-layer.patch

# 400 - 499   ia64
# 500 - 599   s390(x)
# 600 - 699   sparc(64)

# 690 - 699 xen patches already split in their system
Patch690: linux-2.6-xen-i386-mach-io-check-nmi.patch
Patch691: linux-2.6-xen-net-csum.patch
Patch692: linux-2.6-xen-pmd-shared.patch
Patch693: linux-2.6-xen-smp-alts.patch
# 700 - 799 Xen
Patch700: linux-2.6-xen.patch
Patch701: linux-2.6-xen-compile-fixes.patch
Patch702: linux-2.6-xen-no-tls-warn.patch
Patch703: linux-2.6-xen-move-vdso-fixmap.patch
Patch704: linux-2.6-xen-vsyscall_base.patch
Patch706: linux-2.6-xen_remap_vma_flags.patch
Patch709: linux-2.6-percpu-NR_CPUS-hotplug-fix.patch
Patch710: linux-2.6-xen-kva-mmap.patch
Patch711: linux-2.6-xen-disable_ati_timer_quirk.patch
Patch712: linux-2.6-xen-time-went-backwards.patch

#
# Patches 800 through 899 are reserved for bugfixes to the core system
# and patches related to how RPMs are build
#
Patch800: linux-2.6-build-nonintconfig.patch
Patch801: linux-2.6-build-userspace-headers-warning.patch

# Exec-shield.
Patch810: linux-2.6-execshield.patch
Patch811: linux-2.6-execshield-xen.patch
Patch812: linux-2.6-execshield-vdso.patch
Patch813: linux-2.6-xen-vdso-note.patch
Patch814: linux-2.6-execshield-fixes.patch
Patch815: linux-2.6-vdso-xen.patch

# Module signing infrastructure.
Patch900: linux-2.6-modsign-core.patch
Patch901: linux-2.6-modsign-crypto.patch
Patch902: linux-2.6-modsign-ksign.patch
Patch903: linux-2.6-modsign-mpilib.patch
Patch904: linux-2.6-modsign-script.patch
Patch905: linux-2.6-modsign-include.patch

# Tux http accelerator.
Patch910: linux-2.6-tux.patch

#
# Patches 1000 to 5000 are reserved for bugfixes to drivers and filesystems
#

Patch1011: linux-2.6-debug-slab-backtrace.patch
Patch1012: linux-2.6-debug-list_head.patch
Patch1013: linux-2.6-debug-taint-vm.patch
PAtch1014: linux-2.6-debug-slab-leaks.patch
Patch1015: linux-2.6-debug-singlebiterror.patch
Patch1016: linux-2.6-debug-spinlock-taint.patch
Patch1017: linux-2.6-debug-spinlock-panic.patch
Patch1018: linux-2.6-debug-Wundef.patch
Patch1019: linux-2.6-debug-disable-builtins.patch
Patch1020: linux-2.6-debug-sleep-in-irq-warning.patch
Patch1021: linux-2.6-debug-reference-discarded-return-result.patch
Patch1022: linux-2.6-debug-panic-stackdump.patch
Patch1024: linux-2.6-debug-dual-line-backtrace.patch
Patch1025: linux-2.6-debug-sysfs-crash-debugging.patch
Patch1026: linux-2.6-debug-no-quiet.patch
Patch1027: linux-2.6-debug-slab-leak-detector.patch
Patch1028: linux-2.6-debug-oops-pause.patch
Patch1029: linux-2.6-debug-account-kmalloc.patch
Patch1030: linux-2.6-debug-latency-tracing.patch
Patch1031: linux-2.6-debug-periodic-slab-check.patch
Patch1032: linux-2.6-debug-boot-delay.patch
Patch1033: linux-2.6-debug-must_check.patch
Patch1034: linux-2.6-debug-pm-pci.patch

# Restrict /dev/mem usage.
Patch1050: linux-2.6-devmem.patch
Patch1051: linux-2.6-devmem-xen.patch

# Provide read only /dev/crash driver.
Patch1060: linux-2.6-crash-driver.patch
Patch1061: linux-2.6-crash-xen.patch

Patch1070: linux-2.6-sleepon.patch

# SCSI bits.
Patch1101: linux-2.6-scsi-advansys-enabler.patch
Patch1102: linux-2.6-scsi-advansys-pcitable.patch

# NFS bits.
Patch1200: linux-2.6-NFSD-non-null-getxattr.patch
Patch1201: linux-2.6-NFSD-ctlbits.patch
Patch1203: linux-2.6-NFSD-badness.patch
Patch1204: linux-2.6-NFSD-writes-shouldnt-clobber-utimes.patch

# NIC driver updates
Patch1301: linux-2.6-net-sundance-ip100A.patch
Patch1302: linux-2.6-net-wireless-features.patch
Patch1303: linux-2.6-net-ipw2200-hwcrypto.patch
Patch1304: linux-2.6-net-ipw2200-monitor.patch

# Squashfs
Patch1400: linux-2.6-squashfs.patch

# Netdump and Diskdump bits.
Patch1500: linux-2.6-crashdump-common.patch
Patch1501: linux-2.6-netdump.patch
Patch1502: linux-2.6-netconsole.patch
Patch1503: linux-2.6-diskdump.patch
Patch1504: linux-2.6-crashdump-reboot-exports.patch
Patch1505: linux-2.6-dump_smp_call_function.patch

# Misc bits.
Patch1600: linux-2.6-module_version.patch
Patch1610: linux-2.6-input-kill-stupid-messages.patch
Patch1620: linux-2.6-serial-tickle-nmi.patch
Patch1630: linux-2.6-radeon-backlight.patch
Patch1640: linux-2.6-ide-tune-locking.patch
Patch1641: linux-2.6-ide-cd-shutup.patch
Patch1650: linux-2.6-autofs-pathlookup.patch
Patch1660: linux-2.6-valid-ether-addr.patch
Patch1670: linux-2.6-softcursor-persistent-alloc.patch
Patch1680: linux-2.6-pwc-powerup-by-default.patch
Patch1690: linux-2.6-smsc-ircc2-pnp.patch
Patch1700: linux-2.6-w1-hush-debug.patch
Patch1710: linux-2.6-sched-up-migration-cost.patch
Patch1730: linux-2.6-signal-trampolines-unwind-info.patch
Patch1740: linux-2.6-softlockup-disable.patch
Patch1750: linux-2.6-drm-cripple-r300.patch
Patch1760: linux-2.6-suspend-slab-warnings.patch

# SELinux/audit patches.
Patch1800: linux-2.6-selinux-hush.patch
Patch1801: linux-2.6-selinux-mprotect-checks.patch
Patch1802: linux-2.6-selinux-disable-attributes-no-policy.patch
Patch1803: linux-2.6-selinux-selinuxfs-hard-link-count.patch
Patch1804: linux-2.6-audit-new-msg-types.patch

# Warn about usage of various obsolete functionality that may go away.
Patch1900: linux-2.6-obsolete-idescsi-warning.patch
Patch1901: linux-2.6-obsolete-oss-warning.patch

# no external module should use these symbols.
Patch1910: linux-2.6-unexport-symbols.patch

# VM bits.
Patch2001: linux-2.6-vm-silence-atomic-alloc-failures.patch
Patch2002: linux-2.6-vm-clear-unreclaimable.patch

# Tweak some defaults.
Patch2100: linux-2.6-defaults-max-symlinks.patch
Patch2101: linux-2.6-defaults-fat-utf8.patch
Patch2102: linux-2.6-defaults-enable-sata-atapi.patch
Patch2103: linux-2.6-defaults-firmware-loader-timeout.patch

# SATA Bits
Patch2200: linux-2.6-sata-promise-pata-ports.patch
Patch2201: linux-2.6-sata-silence-dumb-msg.patch

# ACPI bits
Patch2300: linux-2.6-acpi_os_acquire_object-gfp_kernel-called-with-irqs.patch

# Broadcom wireless driver
Patch5000: linux-2.6-softmac-git.patch
Patch5001: linux-2.6-bcm43xx-git.patch
Patch5002: linux-2.6-bcm43xx-neuter.patch

Patch6000: linux-2.6-piix-d1011.patch

#
# 10000 to 20000 is for stuff that has to come last due to the
# amount of drivers they touch. But only these should go here.
# Not patches you're too lazy for to put in the proper place.
#

Patch10000: linux-2.6-compile-fixes.patch

# Little obvious 1-2 liners that fix silly bugs.
# Do not add anything non-trivial here.
Patch10001: linux-2.6-random-patches.patch

# Xen hypervisor patches
Patch20000: xen-sched-sedf.patch

# END OF PATCH DEFINITIONS

BuildRoot: %{_tmppath}/kernel-%{KVERREL}-root

%ifarch x86_64
Obsoletes: kernel-smp
%endif

%description 
The kernel package contains the Linux kernel (vmlinuz), the core of any
Linux operating system.  The kernel handles the basic functions
of the operating system:  memory allocation, process allocation, device
input and output, etc.

%package devel
Summary: Development package for building kernel modules to match the kernel.
Group: System Environment/Kernel
AutoReqProv: no
Provides: kernel-devel-%{_target_cpu} = %{rpmversion}-%{release}
Prereq: /usr/bin/find

%description devel
This package provides kernel headers and makefiles sufficient to build modules
against the kernel package.


%package doc
Summary: Various documentation bits found in the kernel source.
Group: Documentation

%description doc
This package contains documentation files from the kernel
source. Various bits of information about the Linux kernel and the
device drivers shipped with it are documented in these files. 

You'll want to install this package if you need a reference to the
options that can be passed to Linux kernel modules at load time.


%package smp
Summary: The Linux kernel compiled for SMP machines.

Group: System Environment/Kernel
Provides: kernel = %{version}
Provides: kernel-drm = 4.3.0
Provides: kernel-%{_target_cpu} = %{rpmversion}-%{release}smp
Prereq: %{kernel_prereq}
Conflicts: %{kernel_dot_org_conflicts}
Conflicts: %{package_conflicts}
# upto and including kernel 2.4.9 rpms, the 4Gb+ kernel was called kernel-enterprise
# now that the smp kernel offers this capability, obsolete the old kernel
Obsoletes: kernel-enterprise < 2.4.10
# We can't let RPM do the dependencies automatic because it'll then pick up
# a correct but undesirable perl dependency from the module headers which
# isn't required for the kernel proper to function
AutoReqProv: no

%description smp
This package includes a SMP version of the Linux kernel. It is
required only on machines with two or more CPUs as well as machines with
hyperthreading technology.

Install the kernel-smp package if your machine uses two or more CPUs.

%package smp-devel
Summary: Development package for building kernel modules to match the SMP kernel.
Group: System Environment/Kernel
Provides: kernel-smp-devel-%{_target_cpu} = %{rpmversion}-%{release}
Provides: kernel-devel-%{_target_cpu} = %{rpmversion}-%{release}smp
Provides: kernel-devel = %{rpmversion}-%{release}smp
AutoReqProv: no
Prereq: /usr/sbin/hardlink, /usr/bin/find

%description smp-devel
This package provides kernel headers and makefiles sufficient to build modules
against the SMP kernel package.

%package xen0
Summary: The Linux kernel compiled for Xen guest0 VM operations

Group: System Environment/Kernel
Provides: kernel = %{version}
Provides: kernel-%{_target_cpu} = %{rpmversion}-%{release}xen0
Prereq: %{kernel_prereq}
Requires: xen
Conflicts: %{kernel_dot_org_conflicts}
Conflicts: %{package_conflicts}
Conflicts: %{xen_conflicts}
# the hypervisor kernel needs a newer mkinitrd than everything else right now
Conflicts: mkinitrd <= 4.2.0 
# We can't let RPM do the dependencies automatic because it'll then pick up
# a correct but undesirable perl dependency from the module headers which
# isn't required for the kernel proper to function
AutoReqProv: no

%description xen0
This package includes a version of the Linux kernel which
runs in Xen's guest0 VM and provides device services to
the unprivileged guests.

Install this package in your Xen guest0 environment.

%package xen0-devel
Summary: Development package for building kernel modules to match the kernel.
Group: System Environment/Kernel
AutoReqProv: no
Provides: kernel-xen0-devel-%{_target_cpu} = %{rpmversion}-%{release}
Provides: kernel-devel-%{_target_cpu} = %{rpmversion}-%{release}xen0
Provides: kernel-devel = %{rpmversion}-%{release}xen0
Prereq: /usr/sbin/hardlink, /usr/bin/find

%description xen0-devel
This package provides kernel headers and makefiles sufficient to build modules
against the kernel package.


%package xen0-PAE
Summary: The Linux kernel compiled for Xen guest0 VM operations with PAE support

Group: System Environment/Kernel
Provides: kernel = %{version}
Provides: kernel-%{_target_cpu} = %{rpmversion}-%{release}xen0-PAE
Prereq: %{kernel_prereq}
Requires: xen
Conflicts: %{kernel_dot_org_conflicts}
Conflicts: %{package_conflicts}
Conflicts: %{xen_conflicts}
# the xen0-PAE kernel needs a newer mkinitrd than everything else right now
Conflicts: mkinitrd <= 4.2.0 
# We can't let RPM do the dependencies automatic because it'll then pick up
# a correct but undesirable perl dependency from the module headers which
# isn't required for the kernel proper to function
AutoReqProv: no

%description xen0-PAE
This package includes a version of the Linux kernel which runs in
Xen's guest0 VM with PAE support and provides device services to the
unprivileged guests.

Install this package in your Xen guest0 environment.


%package xen0-PAE-devel
Summary: Development package for building kernel modules to match the kernel.
Group: System Environment/Kernel
AutoReqProv: no
Provides: kernel-xen0-PAE-devel-%{_target_cpu} = %{rpmversion}-%{release}
Provides: kernel-devel-%{_target_cpu} = %{rpmversion}-%{release}xen0-PAE
Provides: kernel-devel = %{rpmversion}-%{release}xen0-PAE
Prereq: /usr/sbin/hardlink, /usr/bin/find

%description xen0-PAE-devel
This package provides kernel headers and makefiles sufficient to build modules
against the kernel package.

%package xenU
Summary: The Linux kernel compiled for unprivileged Xen guest VMs

Group: System Environment/Kernel
Provides: kernel = %{version}
Provides: kernel-%{_target_cpu} = %{rpmversion}-%{release}xenU
Prereq: %{kernel_prereq}
Conflicts: %{kernel_dot_org_conflicts}
Conflicts: %{package_conflicts}
Conflicts: %{xen_conflicts}
# We can't let RPM do the dependencies automatic because it'll then pick up
# a correct but undesirable perl dependency from the module headers which
# isn't required for the kernel proper to function
AutoReqProv: no

%description xenU
This package includes a version of the Linux kernel which
runs in Xen unprivileged guest VMs.  This should be installed
both inside the unprivileged guest (for the modules) and in
the guest0 domain.

%package xenU-devel
Summary: Development package for building kernel modules to match the kernel.
Group: System Environment/Kernel
AutoReqProv: no
Provides: kernel-xenU-devel-%{_target_cpu} = %{rpmversion}-%{release}
Provides: kernel-devel-%{_target_cpu} = %{rpmversion}-%{release}xenU
Provides: kernel-devel = %{rpmversion}-%{release}xenU
Prereq: /usr/sbin/hardlink, /usr/bin/find

%description xenU-devel
This package provides kernel headers and makefiles sufficient to build modules
against the kernel package.

%package xenU-PAE
Summary: The Linux kernel compiled for unprivileged Xen guest VMs with PAE support

Group: System Environment/Kernel
Provides: kernel = %{version}
Provides: kernel-%{_target_cpu} = %{rpmversion}-%{release}xenU-PAE
Prereq: %{kernel_prereq}
Conflicts: %{kernel_dot_org_conflicts}
Conflicts: %{package_conflicts}
Conflicts: %{xen_conflicts}
# We can't let RPM do the dependencies automatic because it'll then pick up
# a correct but undesirable perl dependency from the module headers which
# isn't required for the kernel proper to function
AutoReqProv: no

%description xenU-PAE
This package includes a version of the Linux kernel which runs in Xen
unprivileged guest VMs with PAE support.  This should be installed
both inside the unprivileged guest (for the modules) and in the guest0
domain.

%package xenU-PAE-devel
Summary: Development package for building kernel modules to match the kernel.
Group: System Environment/Kernel
AutoReqProv: no
Provides: kernel-xenU-PAE-devel-%{_target_cpu} = %{rpmversion}-%{release}
Provides: kernel-devel-%{_target_cpu} = %{rpmversion}-%{release}xenU-PAE
Provides: kernel-devel = %{rpmversion}-%{release}xenU-PAE
Prereq: /usr/sbin/hardlink, /usr/bin/find

%description xenU-PAE-devel
This package provides kernel headers and makefiles sufficient to build modules
against the kernel package.

%package kdump
Summary: A minimal Linux kernel compiled for kernel crash dumps.

Group: System Environment/Kernel
Provides: kernel = %{version}
Provides: kernel-drm = 4.3.0
Provides: kernel-%{_target_cpu} = %{rpmversion}-%{release}kdump
Prereq: %{kernel_prereq}
Conflicts: %{kernel_dot_org_conflicts}
Conflicts: %{package_conflicts}
# We can't let RPM do the dependencies automatic because it'll then pick up
# a correct but undesirable perl dependency from the module headers which
# isn't required for the kernel proper to function
AutoReqProv: no

%description kdump
This package includes a kdump version of the Linux kernel. It is
required only on machines which will use the kexec-base kernel crash dump
mechanism.

%package kdump-devel
Summary: Development package for building kernel modules to match the kdump kernel.
Group: System Environment/Kernel
Provides: kernel-kdump-devel-%{_target_cpu} = %{rpmversion}-%{release}
Provides: kernel-devel-%{_target_cpu} = %{rpmversion}-%{release}kdump
Provides: kernel-devel = %{rpmversion}-%{release}kdump
AutoReqProv: no
Prereq: /usr/sbin/hardlink, /usr/bin/find

%description kdump-devel
This package provides kernel headers and makefiles sufficient to build modules
against the kdump kernel package.


%prep
if [ ! -d kernel-%{kversion}/vanilla ]; then
  # Ok, first time we do a make prep.
  rm -f pax_global_header
%setup -q -n %{name}-%{version} -c -a1
  cp %{SOURCE2} .
  mv linux-%{kversion} vanilla
  mv xen xen-vanilla
  cp %{SOURCE2} .
else
  # We already have a vanilla dir.
  cd kernel-%{kversion}
  if [ -d linux-%{kversion}.%{_target_cpu} ]; then
     mv linux-%{kversion}.%{_target_cpu} deleteme
     rm -rf deleteme &
  fi
  if [ -d xen ]; then
     mv xen deleteme2
     rm -rf deleteme2 &
  fi
fi
cp -rl vanilla linux-%{kversion}.%{_target_cpu}
cp -rl xen-vanilla xen

%if %{buildxen}
cd xen
# Any necessary hypervisor patches go here
%patch20000 -p2
cd ..
%endif
cd linux-%{kversion}.%{_target_cpu}

# Update to latest upstream.
%patch1 -p1
%patch2 -p1

#
# Patches 10 through 100 are meant for core subsystem upgrades
#

#
# Patches to back out
#

#
# Architecture patches
#
%patch100 -p1

#
# x86(-64)
#
# Compile 686 kernels tuned for Pentium4.
%patch200 -p1
# Keep UP APIC off by default.
#%patch201 -p1
# add vidfail capability;
# without this patch specifying a framebuffer on the kernel prompt would
# make the boot stop if there's no supported framebuffer device; this is bad
# for the installer cd that wants to automatically fall back to textmode
# in that case
%patch202 -p1
# exitfunc called from initfunc.
%patch203 -p1
# Suppress APIC errors on UP x86-64.
%patch204 -p1
# Reboot thru bios on HP laptops.
%patch205 -p1
# Workaround BIOSes that don't list CPU0
%patch206 -p1
# Reboot through BIOS on HP systems,.
%patch207 -p1
# cpu_index >= NR_CPUS becomming always false.
%patch208 -p1

#
# ppc64
#
# Arnd says don't call cell_spumem_init() till he fixes it.
%patch301 -p1
# IBM will use 'IBM,CBEA' for future Cell systems
%patch302 -p1
# Support the IBM Mambo simulator; core as well as disk and network drivers.
%patch305 -p1
# Make HVC console generic; support simulator console device using it.
%patch306 -p1
# Hardcode PIC addresses for Cell spiderpic
%patch310 -p1
# RTAS console support
%patch313 -p1
# Check properly for successful RTAS instantiation
%patch314 -p1
# No input layer on iseries
%patch317 -p1

#
# Xen
#
%if %{includexen}
# Base Xen patch from linux-2.6-merge.hg
%patch690 -p1
# Conflict with non-xen kernels
#%patch691 -p1
%patch692 -p1
%patch693 -p1

#
# Apply the main xen patch...
#
%patch700 -p1 -b .p.xen
#
# ... and back out all the ia64-specific sections, as they currently prevent
# non-xen builds from working.
#
for f in `find arch/ia64/ include/asm-ia64/ include/xen/interface/arch-ia64.h* -type f -name "*.p.xen"` ; do \
    g=`dirname $f`/`basename $f .p.xen`; \
    mv "$f" "$g"; \
    if [ ! -s "$g" ] ; then rm -f "$g" ; fi; \
done
# Delete the rest of the backup files, they just confuse the build later
find -name "*.p.xen" | xargs rm -f
    
#
# Xen includes a patch which moves the vsyscall fixmap into a user-space VA,
# freeing user-space from reliance on an absolute fixmap area and so allowing
# the fixmap area to become dynamic.
#
# Execshield already does this, making the fixmap area invisible to the user
# and adding a new randomised vdso for it in user VA, so there's no point in
# having both: revert the Xen changeset so that execsheild applies cleanly.
#
%patch703 -p2 -R

%patch701 -p1
%patch702 -p1
%patch704 -p1
%patch706 -p1
%patch709 -p1
%patch710 -p2
%patch711 -p1
%patch712 -p1

%endif

#
# Patches 500 through 1000 are reserved for bugfixes to the core system
# and patches related to how RPMs are build
#


# This patch adds a "make nonint_oldconfig" which is non-interactive and
# also gives a list of missing options at the end. Useful for automated
# builds (as used in the buildsystem).
%patch800 -p1
# Warn if someone tries to build userspace using kernel headers
%patch801 -p1

# Exec shield 
%patch810 -p1

# Xen exec-shield bits
%if %{includexen}
%patch811 -p1
%patch812 -p1
%patch813 -p1
#%patch815 -p1
%endif

# Final small execshield fixes.
%patch814 -p1

#
# GPG signed kernel modules
#
%patch900 -p1
%patch901 -p1
%patch902 -p1
%patch903 -p1
%patch904 -p1
%patch905 -p1

# Tux
%patch910 -p1

# SATA Patches
# Enable PATA ports on Promise.
%patch2200 -p1
# Silence noisy printk
%patch2201 -p1

# ACPI patches
%patch2300 -p1

#
# Patches 1000 to 5000 are reserved for bugfixes to drivers and filesystems
#



# Various low-impact patches to aid debugging.
%patch1011 -p1
%patch1012 -p1
%patch1013 -p1
%patch1014 -p1
%patch1015 -p1
%patch1016 -p1
%patch1017 -p1
%patch1018 -p1
%patch1019 -p1
%patch1020 -p1
%patch1021 -p1
%patch1022 -p1
%patch1024 -p1
%patch1025 -p1
# Disable the 'quiet' boot switch for better bug reports.
#%patch1026 -p1
# Slab leak detector.
#%patch1027 -p1
%patch1028 -p1
#%patch1029 -p1
#%patch1030 -p1
%patch1031 -p1
%patch1032 -p1
%patch1033 -p1
%patch1034 -p1

#
# Make /dev/mem a need-to-know function 
#
%patch1050 -p1
%if %{includexen}
#TODO! --sct @@@
#%patch1051 -p1
%endif

#
# /dev/crash driver for the crashdump analysis tool
#
%patch1060 -p1
%if %{includexen}
%patch1061 -p1
%endif

#
# Most^WAll users of sleep_on are broken; fix a bunch
#
%patch1070 -p1

#
# SCSI Bits.
#
# Enable Advansys driver
%patch1101 -p1
# Add a pci table to advansys driver.
%patch1102 -p1

#
# Various upstream NFS/NFSD fixes.
#
#%patch1200 -p1
# kNFSD: fixed '-p port' arg to rpc.nfsd and enables the defining proto versions and transports
%patch1201 -p1
# Fix badness.
%patch1203 -p1
# NFSD: writes should not clobber utimes() calls
%patch1204 -p1

# NIC driver fixes.
# New PCI ID for sundance driver.
%patch1301 -p1
# Goodies for wireless drivers to make NetworkManager work
%patch1302 -p1
# ipw2200 hwcrypto=0 by default to avoid firmware restarts
%patch1303 -p1
# add IPW2200_MONITOR config option
%patch1304 -p1

# Squashfs
%patch1400 -p1

# netdump bits
%patch1500 -p1
%patch1501 -p1
%patch1502 -p1
%patch1503 -p1
%patch1504 -p1
%patch1505 -p1

#
# Various SELinux fixes from 2.6.10rc
#

# Misc fixes
# Add missing MODULE_VERSION tags to some modules.
%patch1600 -p1
# The input layer spews crap no-one cares about.
%patch1610 -p1
# Tickle the NMI whilst doing serial writes.
%patch1620 -p1
# Radeon on thinkpad backlight power-management goodness.
%patch1630 -p1
# Fix IDE locking bug.
%patch1640 -p1
# Silence noisy CD drive spew
%patch1641 -p1
# autofs4 looks up wrong path element when ghosting is enabled
%patch1650 -p1
# 
%patch1660 -p1
# Use persistent allocation in softcursor
%patch1670 -p1
# Power up PWC driver by default.
%patch1680 -p1
# PNP support for smsc-ircc2
%patch1690 -p1
# Silence debug messages in w1
%patch1700 -p1
# Only print migration info on SMP
%patch1710 -p1
# Mark unwind info for signal trampolines in vDSOs
%patch1730 -p1
# Add a safety net to softlockup so that it doesn't prevent installs.
%patch1740 -p1
# Disable R300 and above DRI as it's unstable.
%patch1750 -p1
# Fix up kmalloc whilst atomic warning during resume.
%patch1760 -p1

# Silence some selinux messages.
%patch1800 -p1
# Fix the SELinux mprotect checks on executable mappings
%patch1801 -p1
# Disable setting of security attributes on new inodes when no policy is loaded
%patch1802 -p1
# Fix incorrect hardlink count in selinuxfs
%patch1803 -p1
# Add some more audit message types.
%patch1804 -p1

# Warn about obsolete functionality usage.
%patch1900 -p1
%patch1901 -p1
# Remove kernel-internal functionality that nothing external should use.
%patch1910 -p1

#
# VM related fixes.
#
# Silence GFP_ATOMIC failures.
%patch2001 -p1
# VM oom killer tweaks.
%patch2002 -p1

# Changes to upstream defaults.
# Bump up the number of recursive symlinks.
%patch2100 -p1
# Use UTF-8 by default on VFAT.
%patch2101 -p1
# Enable SATA ATAPI by default.
%patch2102 -p1
# Increase timeout on firmware loader.
%patch2103 -p1

#
# Patches 5000 to 6000 are reserved for new drivers that are about to
# be merged upstream
#

# Import softmac code from wireless-2.6 tree
%patch5000 -p1
# ... and bcm43xx driver too
%patch5001 -p1
# temporarily remove bcm43xx's MODULE_DEVICE_TABLE entry
%patch5002 -p1

%patch6000 -p1

#
# final stuff
#

#
# misc small stuff to make things compile or otherwise improve performance
#
#%patch10000 -p1

# Small 1-2 liners fixing silly bugs that get pushed upstream quickly.
%patch10001 -p1


# END OF PATCH APPLICATIONS

cp %{SOURCE10} Documentation/

mkdir configs

cp -f %{all_arch_configs} .


# now run oldconfig over all the config files
for i in *.config
do 
  mv $i .config 
  Arch=`head -1 .config | cut -b 3-`
%if %{includexen}
  make ARCH=$Arch nonint_oldconfig > /dev/null
%else
  if [ "$Arch" != "xen" ]; then
    make ARCH=$Arch nonint_oldconfig > /dev/null
  fi
%endif
  echo "# $Arch" > configs/$i
  cat .config >> configs/$i 
done

# make sure the kernel has the sublevel we know it has. This looks weird
# but for -pre and -rc versions we need it since we only want to use
# the higher version when the final kernel is released.
perl -p -i -e "s/^SUBLEVEL.*/SUBLEVEL = %{sublevel}/" Makefile
perl -p -i -e "s/^EXTRAVERSION.*/EXTRAVERSION = -prep/" Makefile

# get rid of unwanted files resulting from patch fuzz
find . -name "*.orig" -o -name "*~" -exec rm -f {} \; >/dev/null &

###
### build
###
%build
#
# Create gpg keys for signing the modules
#

gpg --homedir . --batch --gen-key %{SOURCE11}  
gpg --homedir . --export --keyring ./kernel.pub Red > extract.pub 
make linux-%{kversion}.%{_target_cpu}/scripts/bin2c
linux-%{kversion}.%{_target_cpu}/scripts/bin2c ksign_def_public_key __initdata < extract.pub > linux-%{kversion}.%{_target_cpu}/crypto/signature/key.h

BuildKernel() {
    MakeTarget=$1
    KernelImage=$2
    Flavour=$3

    # Pick the right config file for the kernel we're building
    if [ -n "$Flavour" ] ; then
      Config=kernel-%{kversion}-%{_target_cpu}-$Flavour.config
      DevelDir=/usr/src/kernels/%{KVERREL}-$Flavour-%{_target_cpu}
      DevelLink=/usr/src/kernels/%{KVERREL}$Flavour-%{_target_cpu}
    else
      Config=kernel-%{kversion}-%{_target_cpu}.config
      DevelDir=/usr/src/kernels/%{KVERREL}-%{_target_cpu}
      DevelLink=
    fi

    KernelVer=%{version}-%{release}$Flavour
    echo BUILDING A KERNEL FOR $Flavour %{_target_cpu}...

    # make sure EXTRAVERSION says what we want it to say
    perl -p -i -e "s/^EXTRAVERSION.*/EXTRAVERSION = -%{release}$Flavour/" Makefile

    # and now to start the build process

    make -s mrproper
    cp configs/$Config .config

    Arch=`head -1 .config | cut -b 3-`
    echo USING ARCH=$Arch

    if [ "$KernelImage" == "x86" ]; then
       KernelImage=arch/$Arch/boot/bzImage
    fi

    make -s ARCH=$Arch nonint_oldconfig > /dev/null
    make -s ARCH=$Arch %{?_smp_mflags} $MakeTarget
    make -s ARCH=$Arch %{?_smp_mflags} modules || exit 1
    make ARCH=$Arch buildcheck

    # Start installing the results

%if "%{_enable_debug_packages}" == "1"
    mkdir -p $RPM_BUILD_ROOT/usr/lib/debug/boot
%endif
    mkdir -p $RPM_BUILD_ROOT/%{image_install_path}
    install -m 644 .config $RPM_BUILD_ROOT/boot/config-$KernelVer
    install -m 644 System.map $RPM_BUILD_ROOT/boot/System.map-$KernelVer
    cp $KernelImage $RPM_BUILD_ROOT/%{image_install_path}/vmlinuz-$KernelVer
    if [ -f arch/$Arch/boot/zImage.stub ]; then
      cp arch/$Arch/boot/zImage.stub $RPM_BUILD_ROOT/%{image_install_path}/zImage.stub-$KernelVer || :
    fi

    if [ "$Flavour" == "kdump" ]; then
        cp vmlinux $RPM_BUILD_ROOT/%{image_install_path}/vmlinux-$KernelVer
        rm -f $RPM_BUILD_ROOT/%{image_install_path}/vmlinuz-$KernelVer
    fi

    mkdir -p $RPM_BUILD_ROOT/lib/modules/$KernelVer
    make -s ARCH=$Arch INSTALL_MOD_PATH=$RPM_BUILD_ROOT modules_install KERNELRELEASE=$KernelVer
 
    # And save the headers/makefiles etc for building modules against
    #
    # This all looks scary, but the end result is supposed to be:
    # * all arch relevant include/ files
    # * all Makefile/Kconfig files
    # * all script/ files 

    rm -f $RPM_BUILD_ROOT/lib/modules/$KernelVer/build
    rm -f $RPM_BUILD_ROOT/lib/modules/$KernelVer/source
    mkdir -p $RPM_BUILD_ROOT/lib/modules/$KernelVer/build
    (cd $RPM_BUILD_ROOT/lib/modules/$KernelVer ; ln -s build source)
    # dirs for additional modules per module-init-tools, kbuild/modules.txt
    mkdir -p $RPM_BUILD_ROOT/lib/modules/$KernelVer/extra
    mkdir -p $RPM_BUILD_ROOT/lib/modules/$KernelVer/updates
    # first copy everything
    cp --parents `find  -type f -name "Makefile*" -o -name "Kconfig*"` $RPM_BUILD_ROOT/lib/modules/$KernelVer/build 
    cp Module.symvers $RPM_BUILD_ROOT/lib/modules/$KernelVer/build
    # then drop all but the needed Makefiles/Kconfig files
    rm -rf $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/Documentation
    rm -rf $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/scripts
    rm -rf $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/include
    cp arch/%{_arch}/kernel/asm-offsets.s $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/arch/%{_arch}/kernel || :
    cp .config $RPM_BUILD_ROOT/lib/modules/$KernelVer/build
    cp .kernelrelease $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/
    cp -a scripts $RPM_BUILD_ROOT/lib/modules/$KernelVer/build
    if [ -d arch/%{_arch}/scripts ]; then
      cp -a arch/%{_arch}/scripts $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/arch/%{_arch} || :
    fi
    if [ -f arch/%{_arch}/*lds ]; then
      cp -a arch/%{_arch}/*lds $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/arch/%{_arch}/ || :
    fi
    rm -f $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/scripts/*.o
    rm -f $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/scripts/*/*.o
    mkdir -p $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/include
    cd include
    cp -a acpi config linux math-emu media net pcmcia rxrpc scsi sound video asm asm-generic $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/include
    cp -a `readlink asm` $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/include
    if [ "$Arch" = "x86_64" ]; then
      cp -a asm-i386 $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/include
    fi
    # While arch/powerpc/include/asm is still a symlink to the old
    # include/asm-ppc{64,} directory, include that in kernel-devel too.
    if [ "$Arch" = "powerpc" -a -r ../arch/powerpc/include/asm ]; then
      cp -a `readlink ../arch/powerpc/include/asm` $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/include
      mkdir -p $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/arch/$Arch/include
      pushd $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/arch/$Arch/include
      ln -sf ../../../include/asm-ppc* asm
      popd
    fi
%if %{buildxen}
    cp -a xen $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/include
%endif

    # Make sure the Makefile and version.h have a matching timestamp so that
    # external modules can be built
    touch -r $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/Makefile $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/include/linux/version.h
    touch -r $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/.config $RPM_BUILD_ROOT/lib/modules/$KernelVer/build/include/linux/autoconf.h
    cd .. 

    #
    # save the vmlinux file for kernel debugging into the kernel-debuginfo rpm
    #
%if "%{_enable_debug_packages}" == "1"
    mkdir -p $RPM_BUILD_ROOT/usr/lib/debug/lib/modules/$KernelVer
    cp vmlinux $RPM_BUILD_ROOT/usr/lib/debug/lib/modules/$KernelVer
%endif

    find $RPM_BUILD_ROOT/lib/modules/$KernelVer -name "*.ko" -type f >modnames

    # gpg sign the modules
%if %{signmodules}
    gcc -o scripts/modsign/mod-extract scripts/modsign/mod-extract.c -Wall
    KEYFLAGS="--no-default-keyring --homedir .." 
    KEYFLAGS="$KEYFLAGS --secret-keyring ../kernel.sec" 
    KEYFLAGS="$KEYFLAGS --keyring ../kernel.pub" 
    export KEYFLAGS 

    for i in `cat modnames`
    do
      sh ./scripts/modsign/modsign.sh $i Red
      mv -f $i.signed $i
    done
    unset KEYFLAGS
%endif

    # mark modules executable so that strip-to-file can strip them
    cat modnames | xargs chmod u+x

    # detect missing or incorrect license tags
    for i in `cat modnames`
    do
      echo -n "$i " 
      /sbin/modinfo -l $i >> modinfo
    done
    cat modinfo |\
      grep -v "^GPL" |
      grep -v "^Dual BSD/GPL" |\
      grep -v "^Dual MPL/GPL" |\
      grep -v "^GPL and additional rights" |\
      grep -v "^GPL v2" && exit 1 
    rm -f modinfo
    rm -f modnames
    # remove files that will be auto generated by depmod at rpm -i time
    rm -f $RPM_BUILD_ROOT/lib/modules/$KernelVer/modules.*

    # Move the devel headers out of the root file system
    mkdir -p $RPM_BUILD_ROOT/usr/src/kernels
    mv $RPM_BUILD_ROOT/lib/modules/$KernelVer/build $RPM_BUILD_ROOT/$DevelDir
    ln -sf ../../..$DevelDir $RPM_BUILD_ROOT/lib/modules/$KernelVer/build
    [ -z "$DevelLink" ] || ln -sf `basename $DevelDir` $RPM_BUILD_ROOT/$DevelLink
}

###
# DO it...
###

# prepare directories
rm -rf $RPM_BUILD_ROOT
mkdir -p $RPM_BUILD_ROOT/boot

%if %{buildxen}
  cd xen
  mkdir -p $RPM_BUILD_ROOT/%{image_install_path}
%if %{buildxenPAE}
  make debug=y verbose=y crash_debug=y pae=y
  install -m 644 xen.gz $RPM_BUILD_ROOT/boot/xen.gz-%{KVERREL}-PAE
  install -m 755 xen-syms $RPM_BUILD_ROOT/boot/xen-syms-%{KVERREL}-PAE
  make clean
%endif
  make debug=y verbose=y crash_debug=y
  install -m 644 xen.gz $RPM_BUILD_ROOT/boot/xen.gz-%{KVERREL}
  install -m 755 xen-syms $RPM_BUILD_ROOT/boot/xen-syms-%{KVERREL}
  cd ..
%endif

cd linux-%{kversion}.%{_target_cpu}

%if %{buildup}
BuildKernel %make_target %kernel_image
%endif

%if %{buildsmp}
BuildKernel %make_target %kernel_image smp
%endif

%if %{buildxenPAE}
BuildKernel vmlinuz vmlinuz xen0-PAE
BuildKernel vmlinuz vmlinuz xenU-PAE
%endif

%if %{buildxen}
BuildKernel vmlinuz vmlinuz xen0
BuildKernel vmlinuz vmlinuz xenU
%endif

%if %{buildkdump}
BuildKernel %make_target %kernel_image kdump
%endif

###
### install
###

%install

cd linux-%{kversion}.%{_target_cpu}

%if %{buildxen}
mkdir -p $RPM_BUILD_ROOT/etc/ld.so.conf.d
rm -f $RPM_BUILD_ROOT/etc/ld.so.conf.d/kernelcap-%{KVERREL}.conf
cat > $RPM_BUILD_ROOT/etc/ld.so.conf.d/kernelcap-%{KVERREL}.conf <<\EOF
# This directive teaches ldconfig to search in nosegneg subdirectories
# and cache the DSOs there with extra bit 0 set in their hwcap match
# fields.  In Xen guest kernels, the vDSO tells the dynamic linker to
# search in nosegneg subdirectories and to match this extra hwcap bit
# in the ld.so.cache file.
hwcap 0 nosegneg
EOF
chmod 444 $RPM_BUILD_ROOT/etc/ld.so.conf.d/kernelcap-%{KVERREL}.conf
%endif

%if %{builddoc}
mkdir -p $RPM_BUILD_ROOT/usr/share/doc/kernel-doc-%{kversion}/Documentation

# sometimes non-world-readable files sneak into the kernel source tree
chmod -R a+r *
# copy the source over
tar cf - Documentation | tar xf - -C $RPM_BUILD_ROOT/usr/share/doc/kernel-doc-%{kversion}
%endif

###
### clean
###

%clean
rm -rf $RPM_BUILD_ROOT

###
### scripts
###

# load the loop module for upgrades...in case the old modules get removed we have
# loopback in the kernel so that mkinitrd will work.
%pre 
/sbin/modprobe loop 2> /dev/null > /dev/null  || :
exit 0

%pre smp
/sbin/modprobe loop 2> /dev/null > /dev/null  || :
exit 0

%post 
if [ `uname -i` == "x86_64" ]; then
  if [ -f /etc/sysconfig/kernel ]; then
    /bin/sed -i -e 's/^DEFAULTKERNEL=kernel-smp$/DEFAULTKERNEL=kernel/' /etc/sysconfig/kernel
  fi
fi
[ ! -x /usr/sbin/module_upgrade ] || /usr/sbin/module_upgrade %{rpmversion}-%{release}
/sbin/new-kernel-pkg --package kernel --mkinitrd --depmod --install %{KVERREL}

%post devel
[ -f /etc/sysconfig/kernel ] && . /etc/sysconfig/kernel
if [ "$HARDLINK" != "no" -a -x /usr/sbin/hardlink ] ; then
  pushd /usr/src/kernels/%{KVERREL}-%{_target_cpu} > /dev/null
  /usr/bin/find . -type f | while read f; do hardlink -c /usr/src/kernels/*FC*/$f $f ; done
  popd > /dev/null
fi

%post smp
[ ! -x /usr/sbin/module_upgrade ] || /usr/sbin/module_upgrade %{rpmversion}-%{release}smp
/sbin/new-kernel-pkg --package kernel-smp --mkinitrd --depmod --install %{KVERREL}smp

%post smp-devel
[ -f /etc/sysconfig/kernel ] && . /etc/sysconfig/kernel
if [ "$HARDLINK" != "no" -a -x /usr/sbin/hardlink ] ; then
  pushd /usr/src/kernels/%{KVERREL}-smp-%{_target_cpu} > /dev/null
  /usr/bin/find . -type f | while read f; do hardlink -c /usr/src/kernels/*FC*/$f $f ; done
  popd > /dev/null
fi

%post xen0
[ ! -x /usr/sbin/module_upgrade ] || /usr/sbin/module_upgrade %{rpmversion}-%{release}-xen0
/sbin/new-kernel-pkg --package kernel-xen0 --mkinitrd --depmod --install --multiboot=/boot/xen.gz-%{KVERREL} %{KVERREL}xen0
[ ! -x /sbin/ldconfig ] || /sbin/ldconfig -X

%post xen0-devel
[ -f /etc/sysconfig/kernel ] && . /etc/sysconfig/kernel
if [ "$HARDLINK" != "no" -a -x /usr/sbin/hardlink ] ; then
  pushd /usr/src/kernels/%{KVERREL}-xen0-%{_target_cpu} > /dev/null
  /usr/bin/find . -type f | while read f; do hardlink -c /usr/src/kernels/*FC*/$f $f ; done
  popd > /dev/null
fi

%post xenU
[ ! -x /usr/sbin/module_upgrade ] || /usr/sbin/module_upgrade %{rpmversion}-%{release}-xenU
/sbin/new-kernel-pkg --package kernel-xenU --mkinitrd --depmod --install %{KVERREL}xenU
[ ! -x /sbin/ldconfig ] || /sbin/ldconfig -X

%post xenU-devel
[ -f /etc/sysconfig/kernel ] && . /etc/sysconfig/kernel
if [ "$HARDLINK" != "no" -a -x /usr/sbin/hardlink ] ; then
  pushd /usr/src/kernels/%{KVERREL}-xenU-%{_target_cpu} > /dev/null
  /usr/bin/find . -type f | while read f; do hardlink -c /usr/src/kernels/*FC*/$f $f ; done
  popd > /dev/null
fi

%post xen0-PAE
[ ! -x /usr/sbin/module_upgrade ] || /usr/sbin/module_upgrade %{rpmversion}-%{release}-xen0-PAE
/sbin/new-kernel-pkg --package kernel-xen0-PAE --mkinitrd --depmod --install --multiboot=/boot/xen.gz-%{KVERREL}-PAE %{KVERREL}xen0-PAE
[ ! -x /sbin/ldconfig ] || /sbin/ldconfig -X

%post xen0-PAE-devel
[ -f /etc/sysconfig/kernel ] && . /etc/sysconfig/kernel
if [ "$HARDLINK" != "no" -a -x /usr/sbin/hardlink ] ; then
  pushd /usr/src/kernels/%{KVERREL}-xen0-PAE-%{_target_cpu} > /dev/null
  /usr/bin/find . -type f | while read f; do hardlink -c /usr/src/kernels/*FC*/$f $f ; done
  popd > /dev/null
fi

%post xenU-PAE
[ ! -x /usr/sbin/module_upgrade ] || /usr/sbin/module_upgrade %{rpmversion}-%{release}-xenU-PAE
/sbin/new-kernel-pkg --package kernel-xenU-PAE --mkinitrd --depmod --install %{KVERREL}xenU-PAE
[ ! -x /sbin/ldconfig ] || /sbin/ldconfig -X

%post xenU-PAE-devel
[ -f /etc/sysconfig/kernel ] && . /etc/sysconfig/kernel
if [ "$HARDLINK" != "no" -a -x /usr/sbin/hardlink ] ; then
  pushd /usr/src/kernels/%{KVERREL}-xenU-PAE-%{_target_cpu} > /dev/null
  /usr/bin/find . -type f | while read f; do hardlink -c /usr/src/kernels/*FC*/$f $f ; done
  popd > /dev/null
fi

%post kdump
[ ! -x /usr/sbin/module_upgrade ] || /usr/sbin/module_upgrade %{rpmversion}-%{release}-kdump
/sbin/new-kernel-pkg --package kernel-kdump --mkinitrd --depmod --install %{KVERREL}kdump

%post kdump-devel
[ -f /etc/sysconfig/kernel ] && . /etc/sysconfig/kernel
if [ "$HARDLINK" != "no" -a -x /usr/sbin/hardlink ] ; then
  pushd /usr/src/kernels/%{KVERREL}-kdump-%{_target_cpu} > /dev/null
  /usr/bin/find . -type f | while read f; do hardlink -c /usr/src/kernels/*FC*/$f $f ; done
  popd > /dev/null
fi

%preun 
/sbin/modprobe loop 2> /dev/null > /dev/null  || :
/sbin/new-kernel-pkg --rminitrd --rmmoddep --remove %{KVERREL}

%preun smp
/sbin/modprobe loop 2> /dev/null > /dev/null  || :
/sbin/new-kernel-pkg --rminitrd --rmmoddep --remove %{KVERREL}smp

%preun xen0
/sbin/modprobe loop 2> /dev/null > /dev/null  || :
/sbin/new-kernel-pkg --rminitrd --rmmoddep --remove %{KVERREL}xen0

%preun xenU
/sbin/modprobe loop 2> /dev/null > /dev/null  || :
/sbin/new-kernel-pkg --rmmoddep --remove %{KVERREL}xenU

%preun xen0-PAE
/sbin/modprobe loop 2> /dev/null > /dev/null  || :
/sbin/new-kernel-pkg --rminitrd --rmmoddep --remove %{KVERREL}xen0-PAE

%preun xenU-PAE
/sbin/modprobe loop 2> /dev/null > /dev/null  || :
/sbin/new-kernel-pkg --rmmoddep --remove %{KVERREL}xenU-PAE


###
### file lists
###

%if %{buildup}
%files 
%defattr(-,root,root)
/%{image_install_path}/vmlinuz-%{KVERREL}
/boot/System.map-%{KVERREL}
/boot/config-%{KVERREL}
%dir /lib/modules/%{KVERREL}
/lib/modules/%{KVERREL}/kernel
/lib/modules/%{KVERREL}/build
/lib/modules/%{KVERREL}/source
/lib/modules/%{KVERREL}/extra
/lib/modules/%{KVERREL}/updates

%files devel
%defattr(-,root,root)
%verify(not mtime) /usr/src/kernels/%{KVERREL}-%{_target_cpu}
%endif

%if %{buildsmp}
%files smp
%defattr(-,root,root)
/%{image_install_path}/vmlinuz-%{KVERREL}smp
/boot/System.map-%{KVERREL}smp
/boot/config-%{KVERREL}smp
%dir /lib/modules/%{KVERREL}smp
/lib/modules/%{KVERREL}smp/kernel
/lib/modules/%{KVERREL}smp/build
/lib/modules/%{KVERREL}smp/source
/lib/modules/%{KVERREL}smp/extra
/lib/modules/%{KVERREL}smp/updates

%files smp-devel
%defattr(-,root,root)
%verify(not mtime) /usr/src/kernels/%{KVERREL}-smp-%{_target_cpu}
/usr/src/kernels/%{KVERREL}smp-%{_target_cpu}
%endif

%if %{buildxen}
%files xen0
%defattr(-,root,root)
/%{image_install_path}/vmlinuz-%{KVERREL}xen0
/boot/System.map-%{KVERREL}xen0
/boot/config-%{KVERREL}xen0
/boot/xen.gz-%{KVERREL}
/boot/xen-syms-%{KVERREL}
%dir /lib/modules/%{KVERREL}xen0
/lib/modules/%{KVERREL}xen0/kernel
%verify(not mtime) /lib/modules/%{KVERREL}xen0/build
/lib/modules/%{KVERREL}xen0/source
/etc/ld.so.conf.d/kernelcap-%{KVERREL}.conf
/lib/modules/%{KVERREL}xen0/extra
/lib/modules/%{KVERREL}xen0/updates

%files xen0-devel
%defattr(-,root,root)
%verify(not mtime) /usr/src/kernels/%{KVERREL}-xen0-%{_target_cpu}
/usr/src/kernels/%{KVERREL}xen0-%{_target_cpu}

%files xenU
%defattr(-,root,root)
/%{image_install_path}/vmlinuz-%{KVERREL}xenU
/boot/System.map-%{KVERREL}xenU
/boot/config-%{KVERREL}xenU
%dir /lib/modules/%{KVERREL}xenU
/lib/modules/%{KVERREL}xenU/kernel
%verify(not mtime) /lib/modules/%{KVERREL}xenU/build
/lib/modules/%{KVERREL}xenU/source
/etc/ld.so.conf.d/kernelcap-%{KVERREL}.conf
/lib/modules/%{KVERREL}xenU/extra
/lib/modules/%{KVERREL}xenU/updates

%files xenU-devel
%defattr(-,root,root)
%verify(not mtime) /usr/src/kernels/%{KVERREL}-xenU-%{_target_cpu}
/usr/src/kernels/%{KVERREL}xenU-%{_target_cpu}
%endif

%if %{buildxenPAE}
%files xen0-PAE
%defattr(-,root,root)
/%{image_install_path}/vmlinuz-%{KVERREL}xen0-PAE
/boot/System.map-%{KVERREL}xen0-PAE
/boot/config-%{KVERREL}xen0-PAE
/boot/xen.gz-%{KVERREL}-PAE
/boot/xen-syms-%{KVERREL}-PAE
%dir /lib/modules/%{KVERREL}xen0-PAE
/lib/modules/%{KVERREL}xen0-PAE/kernel
%verify(not mtime) /lib/modules/%{KVERREL}xen0-PAE/build
/lib/modules/%{KVERREL}xen0-PAE/source
/etc/ld.so.conf.d/kernelcap-%{KVERREL}.conf
/lib/modules/%{KVERREL}xen0-PAE/extra
/lib/modules/%{KVERREL}xen0-PAE/updates

%files xen0-PAE-devel
%defattr(-,root,root)
%verify(not mtime) /usr/src/kernels/%{KVERREL}-xen0-PAE-%{_target_cpu}
/usr/src/kernels/%{KVERREL}xen0-PAE-%{_target_cpu}

%files xenU-PAE
%defattr(-,root,root)
/%{image_install_path}/vmlinuz-%{KVERREL}xenU-PAE
/boot/System.map-%{KVERREL}xenU-PAE
/boot/config-%{KVERREL}xenU-PAE
%dir /lib/modules/%{KVERREL}xenU-PAE
/lib/modules/%{KVERREL}xenU-PAE/kernel
%verify(not mtime) /lib/modules/%{KVERREL}xenU-PAE/build
/lib/modules/%{KVERREL}xenU-PAE/source
/etc/ld.so.conf.d/kernelcap-%{KVERREL}.conf
/lib/modules/%{KVERREL}xenU-PAE/extra
/lib/modules/%{KVERREL}xenU-PAE/updates

%files xenU-PAE-devel
%defattr(-,root,root)
%verify(not mtime) /usr/src/kernels/%{KVERREL}-xenU-PAE-%{_target_cpu}
/usr/src/kernels/%{KVERREL}xenU-PAE-%{_target_cpu}
%endif

%if %{buildkdump}

%files kdump
%defattr(-,root,root)
/%{image_install_path}/vmlinux-%{KVERREL}kdump
/boot/System.map-%{KVERREL}kdump
/boot/config-%{KVERREL}kdump
%dir /lib/modules/%{KVERREL}kdump
/lib/modules/%{KVERREL}kdump/kernel
/lib/modules/%{KVERREL}kdump/build
/lib/modules/%{KVERREL}kdump/source
/lib/modules/%{KVERREL}kdump/extra
/lib/modules/%{KVERREL}kdump/updates

%files kdump-devel
%defattr(-,root,root)
%verify(not mtime) /usr/src/kernels/%{KVERREL}-kdump-%{_target_cpu}
/usr/src/kernels/%{KVERREL}kdump-%{_target_cpu}
%endif

# only some architecture builds need kernel-doc

%if %{builddoc}
%files doc
%defattr(-,root,root)
%{_datadir}/doc/kernel-doc-%{kversion}/Documentation/*
%dir %{_datadir}/doc/kernel-doc-%{kversion}/Documentation
%dir %{_datadir}/doc/kernel-doc-%{kversion}
%endif

%changelog
* Tue Mar 14 2006 Dave Jones <davej@redhat.com>
- 2.6.16-rc6-git3

* Tue Mar 14 2006 David Woodhouse <dwmw2@redhat.com>
- Recognise 'IBM,CBEA' as Cell platform too.

* Mon Mar 13 2006 Rik van Riel <riel@redhat.com>
- fix "Time went backwards" Xen kernel bug. (#185317)

* Mon Mar 13 2006 James Morris <jmorris@redhat.com>
- Modify sched-sedf defaults for dom0 so domU does not
  get soft cpu lockup under load.

* Mon Mar 13 2006 Dave Jones <davej@redhat.com>
- 2.6.16-rc6-git1
- Disable slab debug yet again.

* Sat Mar 11 2006 Dave Jones <davej@redhat.com>
- 2.6.16-rc6
- 2.6.16-rc5-git15 & -git16
- Set x86 ACPI cut-off date to 1999 on advice from upstream acpi maintainer.

* Fri Mar 10 2006 Dave Jones <davej@redhat.com>
- 2.6.16-rc5-git14
- Don't do an explict 'make version.h', which causes obscure
  breakage 1 time in a billion builds. *sigh* (the dreaded #182731)
- Turn slab debug back off.

* Fri Mar 10 2006 Dave Jones <davej@redhat.com>
- Turn slab debug back on for one more build

* Thu Mar  9 2006 Dave Jones <davej@redhat.com>
- Add viro's slab leak detector.

* Thu Mar  9 2006 Stephen Tweedie <sct@redhat.com>
- Disable a bunch of hardware drivers in xenU that have no business
  being built in an unprivileged guest.
- Fix conflict between Xen and ati patch from latest git tree

* Thu Mar  9 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc5-git12/git13
- Make 'quiet' work again.
- Turn off some debugging stuff.
- Fix up some debug spew that could occur during resume.

* Wed Mar  8 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc5-git10/git11

* Tue Mar  7 2006 John W. Linville <linville@redhat.com>
- Temporarily disable automatic load of bcm43xx driver (causes hangs on some systems)

* Tue Mar  7 2006 Stephen Tweedie <sct@redhat.com>
- Include xen header files in -devel packages if we're building xen.
  (bug 180198)
- Disable CONFIG_B44 for Xen builds for now: it results in
  "b44.ko needs unknown symbol dma_get_cache_alignment" errors.

* Tue Mar  7 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc5-git9
- Fix NMI watchdog on i386.

* Mon Mar  6 2006 Dave Jones <davej@redhat.com>
- Disable DRI on Radeon R300 and above, due to instability. (#174646,#182196)
- Don't do voluntary preempt until after bootup

* Mon Mar  6 2006 Stephen Tweedie <sct@redhat.com>
- Merge xen rebase with 1.2016 kernel
- Rename kernel-xen-(hypervisor|guest) to kernel-xen(0|U) for consistency
  with upstream and to make kernel subtype suffixes match the subpackage
  names.  (From Jeremy Katz.)
- Export mmap-able kva interface for xen to find the xenstore page
  (xen-unstable cset 9130)
- Remove stale linux-2.6-xen-module-fault.patch file
- Add workaround for non-xen ia64 builds: temporarily back-out the ia64-
  specific portions of linux-2.6-xen.patch.

* Sun Mar  5 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc5-git8
- Add a safety net to softlockup so that it doesn't prevent installs.

* Sat Mar  4 2006 Dave Jones <davej@redhat.com>
- Silence noisy SATA printk.

* Fri Mar  3 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc5-git7
- Fix cpu_index >= NR_CPUS always false warnings.

* Thu Mar  2 2006 John W. Linville <linville@redhat.com>
- Update to current bcm43xx code

* Thu Mar  2 2006 Stephen Tweedie <sct@redhat.com>
- Rebase to rawhide 1.2009
- Disable xen PAE build again

* Thu Mar  2 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc5-git6
- Fix acpi_os_acquire_object() with IRQs disabled debug msgs.
- Mark unwind info for signal trampolines in vDSOs

* Thu Mar  2 2006 Juan Quintela <quintela@redhat.com>
- rebase with rawhide 2008.

* Thu Mar  2 2006 Stephen Tweedie <sct@redhat.com>
- Fix xen/execshield VSYSCALL_BASE conflict

* Thu Mar  2 2006 Dave Jones <davej@redhat.com>
- Fix acpi_os_acquire_object() with IRQs disabled debug msgs.
- Mark unwind info for signal trampolines in vDSOs

* Wed Mar  1 2006 Juan Quintela <quintela@redhat.com>
- disable ia64 build again.

* Wed Mar  1 2006 Stephen Tweedie <sct@redhat.com>
- Rebase to xen kernel patches and HV from xen-unstable cset 9022
- Delete xen cpu steal patches (now upstream)
- Delete xen_net_read_mac export patch (now upstream)
- Revert xen cset 8948 (vdso updates which execshield already performs)
- Delete unneeded linux-2.6-xen-gcc-4.1-compile-fix.patch

* Wed Mar  1 2006 Juan Quintela <quintela@redhat.com>
- remove xen ia64 bits, they break ia64 build.
- riel cpusteal hv fix.

* Wed Mar  1 2006 Juan Quintela <quintela@redhat.com>
- enable ia64 again

* Wed Mar  1 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc5-git4
- Fix leak in RAID1
- Further fixing of selinuxfs link count. (#182001)
- Enable PATA ports on Promise SATA. (#179369)
- NFS: writes should not clobber utimes() calls. (#183208)

* Tue Feb 28 2006 Juan Quintela <quintela@redhat.com>
- fix x86_64 xen build.

* Tue Feb 28 2006 Juan Quintela <quintela@redhat.com>
- rebase with rawhide 1.1993.
- enable ia64 again.
- rebase with rawhide 1.1991.

* Tue Feb 28 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc5-git3

* Tue Feb 28 2006 David Woodhouse <dwmw2@redhat.com>
- Fix gettimeofday() in the 64-bit PowerPC vDSO

* Mon Feb 27 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc5 & rc5-git1

* Sun Feb 26 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc4-git9 & -git10
- Temporarily disable xen due to build breakage.

* Sat Feb 25 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc4-git8

* Fri Feb 24 2006 Stephen Tweedie <sct@redhat.com>
- Disable ia64 until we work out the Xen interactions
- Fix config confusion on ia64
- Execshield/vdso fixes (quintela@redhat.com)

* Fri Feb 24 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc4-git7

* Fri Feb 24 2006 John W. Linville <linville@redhat.com>
- Add/enable IPW2200_MONITOR config option for i686 and x86_64

* Thu Feb 23 2006 David Woodhouse <dwmw2@redhat.com>
- Shut up the debugging messages from pmac platform stuff

* Thu Feb 23 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc4-git6

* Tue Feb 21 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc4-git2
- Make some more UP x86-64s able to boot an SMP kernel
  by forcing the number of CPUs to at least 1.
- default fat filesystems to use UTF-8

* Tue Feb 21 2006 Rik van Riel <riel@redhat.com>
- Make it possible to disable xen and kdump builds.
- Add Xen cpu steal accounting code.

* Mon Feb 20 2006 Stephen Tweedie <sct@redhat.com>
- Rebase kernel xen patches to xen-unstable cset 8907

* Sun Feb 20 2006 Dave Jones <davej@redhat.com>
- Fix incorrect hardlink count in selinuxfs (#182001)

* Sat Feb 18 2006 Dave Jones <davej@redhat.com>
- Reenable EMI26 driver. (#181813)
- Fix counting of hotplug cpu's in x86 microcode driver
- Fix syscall auditting doing allocations whilst atomic.
- Disable setting of security attributes on new inodes when
  no policy is loaded. (#180296)

* Fri Feb 17 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc4
- 2.6.16rc3-git8 & git9

* Thu Feb 16 2006 John W. Linville <linville@redhat.com>
- stop adding duplicate MODULE_VERSION line to tg3

* Thu Feb 16 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc3-git5, git6 & git7
- Enable exec* checking on all architectures. (#178747)

* Wed Feb 15 2006 Stephen Tweedie <sct@redhat.com>
- Fix module oopses on x86_64 SMP xen dom0

* Wed Feb 15 2006 John W. Linville <linville@redhat.com>
- Update to current softmac/bcm43xx code.
- Set ipw2200 hwcrypto option to 0 to avoid firmware restarts.

* Wed Feb 15 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc3-git4
- Hopefully fix suspend to swap-on-LVM

* Tue Feb 14 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc3-git2 & -git3
- Disable PCI message signalled interrupts.

* Mon Feb 13 2006 Rik van Riel <riel@redhat.com>
- go with the SMP workaround from Hubertus

* Mon Feb 13 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc3-git1 
- Merge kernel-xen back to kernel.

* Mon Feb 13 2006 Juan Quintela <quintela@redhat.com>
- rebase rawhide 1.1941.

* Mon Feb 13 2006 Juan Quintela <quintela@redhat.com>
- rebase with rawhide 1.1940.
- build only for x86_64 & i686.

* Sun Feb 12 2006 Juan Quintela <quintela@redhat.com>
- make real release, only with x86_64 & i686.
- rebase with rawhide 1.1936

* Sun Feb 12 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc2-git11, -git12, and 2.6.16rc3
- Fix warning in bcm43xx driver.
- Missing license tag in p8023
- Fix oops in bluetooth
- Ratelimit some networking messages
- Only print migration info on SMP
- Remove a bunch of dead CONFIG_ options from the configs.

* Sat Feb 11 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc2-git10

* Sat Feb 11 2006 Juan Quintela <quintela@redhat.com>
- i686 xen PAE xennet fix.

* Fri Feb 10 2006 Juan Quintela <quintela@redhat.com>
- rebase 1.1927.
- added xen smp fixes.
- added xen x86_64 fixes.

* Fri Feb 10 2006 Juan Quintela <quintela@redhat.com>
- rebase rawhide 1.1924.
- merge with rawhide spec file.

* Fri Feb 10 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc2-git8 & -git9
- Begin the kernel-xen & kernel merge by merging the easy bits.
- Remove x86_64 TIF_RESTORE_SIGMASK & generic sys_rt_sigsuspend
  (They seemed to cause big problems)

* Fri Feb 10 2006 Juan Quintela <quintela@redhat.com>
- rebase rawhide 1.1924.
- merge with rawhide spec file.

* Thu Feb  9 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc2-git7
- More airo encryption fixing from Dan Williams.
- Minor tweaks to the oops-pauser.
- Disable DRM for certain Radeons that don't work right now.
- Further fixing of the selinux mprotect patch

* Wed Feb  8 2006 Rik van Riel <riel@redhat.com>
- fix oops on SMP boot (#180535)

* Wed Feb  8 2006 Jeremy Katz <katzj@redhat.com>
- update to newer hypervisor snapshot, conflict with older tools
- fix pae hypervisor new-kernel-pkg call

* Wed Feb  8 2006 Juan Quintela <quintela@redhat.com>
- make_target & kernel_image passed as arguments to BuildKernel.

* Wed Feb  8 2006 Juan Quintela <quintela@redhat.com>
- removed SMP_ALTERNATIVES from smp kernel.

* Wed Feb  8 2006 Juan Quintela <quintela@redhat.com>
- merge with rawhide 1.1918.
- add up, smp & kdump kernels.
- add xen PAE kernels.

* Wed Feb  8 2006 Rik van Riel <riel@redhat.com>
- fix oops on SMP boot (#180535)

* Wed Feb  8 2006 Jeremy Katz <katzj@redhat.com> 
- update to newer hypervisor snapshot, conflict with older tools
- fix pae hypervisor new-kernel-pkg call

* Wed Feb  8 2006 Juan Quintela <quintela@redhat.com>
- make_target & kernel_image passed as arguments to BuildKernel.

* Wed Feb  8 2006 Juan Quintela <quintela@redhat.com>
- removed SMP_ALTERNATIVES from smp kernel.

* Wed Feb  8 2006 Juan Quintela <quintela@redhat.com>
- merge with rawhide 1.1918.
- add up, smp & kdump kernels.
- add xen PAE kernels.

* Wed Feb  8 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc2-git6

* Tue Feb  7 2006 Juan Quintela <quintela@redhat.com>
- fix xen to compile with gcc-4.1.
- disable PAE build.
- enable debug hypervisor options.

* Tue Feb 07 2006 Jesse Keating <jkeating@redhat.com>
- rebuilt for new gcc4.1 snapshot and glibc changes

* Tue Feb  7 2006 Dave Jones <davej@redhat.com>
- Touch NMI watchdogs in printk pauser.

* Tue Feb  7 2006 David Woodhouse <dwmw2@redhat.com>
- Fix softmac scanning

* Tue Feb  7 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc2-git3

* Mon Feb  6 2006 Juan Quintela <quintela@redhat.com>
- merge with rawhide 1.1914.

* Mon Feb  6 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc2-git2

* Mon Feb  6 2006 David Woodhouse <dwmw2@redhat.com>
- Update to current softmac/bcm43xx code.

* Sun Feb  5 2006 Dave Jones <davej@redhat.com>
- Fix sed failure if /etc/sysconfig/kernel doesn't exist. (#180025)

* Sat Feb  4 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc2-git1
- Fix deadlock in do_path_lookup()

* Fri Feb  3 2006 Stephen Tweedie <sct@redhat.com>
- Rebase to chrisw's latest merge tree (fix skbuff conflicts)
- Rebase to xen-unstable hypervisor cset 8737
- Fix merge of davej's acpi changes to xen

* Fri Feb  3 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc2
- Modify /etc/sysconfig/kernel on x86-64 to handle kernel-smp going away.
- Silence noisy edac drivers.
- Merge some patches from cpufreq git tree.
- Fix some bogus percpu data accesses.
- Suppress some network layer msgs

* Thu Feb  2 2006 Stephen Tweedie <sct@redhat.com>
- Rebase to linux-2.6-merge.hg cset 19892
- Disable PAE again

* Thu Feb  2 2006 Juan Quintela <quintela@redhat.com>
- merged with rawhide 1985.
- enable PAE for this run.

* Thu Feb  2 2006 Juan Quintela <quintela@redhat.com>
- Add PAE hypervisor & guest kernel, disabled by default.

* Thu Feb  2 2006 Dave Jones <davej@redhat.com>
- 2.6.16rc1-git6
- enable the periodic slab debugger again.

* Wed Feb  1 2006 Dave Jones <davej@redhat.com>
- Woo, 2.6.16rc1-git5 (at last)
- Enable exec* checking except for execmod for ppc32 and ia64 (#178747)
- Disable a bunch of drivers for SBC's that won't run Fedora.
- Reenable building of firmware for QLogic HBA's.
- Add a bunch of missing newlines & the like to module init's.
- Fix up broken DVB kobject use.
- Fixed an oops in the stradis driver initialisation.
- Happy Birthday to "The Yellow Dart".

* Tue Jan 31 2006 Dave Jones <<davej@redhat.com>
- Remove prereq on hardlink, making hardlinking of -devel packages optional
- Further improvements to the 'dont want to hardlink' case.
  Now checks for HARDLINK="no" in /etc/sysconfig/kernel

* Tue Jan 31 2006 Don Zickus <<dzickus@redhat.com>
- Enable x86-64 kdumping, and kdump related specfile cleanup.

* Tue Jan 31 2006 Juan Quintela <quintela@redhat.com>
- Merge with rawhide 1884.
- kdump don't work yet at xen.

* Mon Jan 30 2006 Dave Jones <davej@redhat.com>
- Dan Williams' goodies for wireless drivers to make NetworkManager
  work with WEP/WPA on ipw2200, and WEP on airo.

* Fri Jan 27 2006 Dave Jones <davej@redhat.com>
- New userspace audit message types.
- Fix software suspend on kernels without memory hotplug. (#178339)

* Fri Jan 27 2006  Stephen Tweedie <sct@redhat.com>
- Rebase to linux-2.6-merge.hg cset 19859
- Rebase to HV from xen-unstable.hg cset 8680
- Delete unused linux-2.6.12-xen.patch

* Thu Jan 26 2006 Juan Quintela <quintela@redhat.com>
- "don't edit patches by hand" release.

* Thu Jan 26 2006 Dave Jones <davej@redhat.com>
- Fix building of kdump kernels.
- Fix slab corruption in network layer.
- Make iptables work again.
- Update ACPI to latest acpi-git tree.
- Fix the SELinux mprotect checks on executable mappings. (#178747)

* Wed Jan 25 2006 Juan Quintela <quintela@redhat.com>
- merge with rawhide kernel 1.1869.

* Wed Jan 25 2006 Dave Jones <davej@redhat.com>
- Disable page allocation debugging again.

* Tue Jan 24 2006 David Woidhouse <dwmw2@redhat.com>
- Fix snd_powermac I2C handling
- Add pselect/ppoll on x86_64

* Sun Jan 22 2006 Dave Jones <davej@redhat.com>
- Add missing .kernelrelease to kernel-devel (#178491)
- Make serial /dev nodes get created for pci modems again.
- Re-add Intel AGP for 586 kernels.

* Sat Jan 21 2006 Dave Jones <davej@redhat.com>
- 2.6.16-rc1-git4

* Fri Jan 20 2006 Dave Jones <davej@redhat.com>
- 2.6.16-rc1-git3

-* Thu Jan 19 2006 Dave Jones <davej@redhat.com>
- 2.6.16-rc1-git2
- Fix IA64 unresolved symbols.

* Wed Jan 18 2006 Dave Jones <davej@redhat.com>
- 2.6.16-rc1-git1

* Tue Jan 17 2006 Dave Jones <davej@redhat.com>
- 2.6.16-rc1
- Revert changes that broke named, ifconfig, radvd etc

* Mon Jan 16 2006 Dave Jones <davej@redhat.com>
- 2.6.15-git12

* Sun Jan 15 2006 Dave Jones <davej@redhat.com>
- 2.6.15-git11
- Revert some DRM changes as an experiment.

* Sat Jan 14 2006 David Woodhouse <dwmw2@redhat.com>
- 2.6.15-git10
- Re-enable Wacom driver on PPC

* Sat Jan 14 2006 David Woodhouse <dwmw2@redhat.com>
- Make CHRP build again

* Fri Jan 13 2006 David Woodhouse <dwmw2@redhat.com>
- Update softmac and add WPA support to bcm43xx driver
- 2.6.15-git9 

* Fri Jan 13 2006 David Woodhouse <dwmw2@redhat.com>
- Add TIF_RESTORE_SIGMASK patches. 
- Fix I/O queue stalls

* Fri Jan 13 2006 Dave Jones <davej@redhat.com>
- Disable more cruft from iseries config.

* Fri Jan 13 2006 David Woodhouse <dwmw2@redhat.com>
- Fix oops on Cell Broadband Engine with NUMA enabled.

* Thu Jan 12 2006 Dave Jones <davej@redhat.com>
- 2.6.15-git8

* Thu Jan 12 2006 David Woodhouse <dwmw2@redhat.com>
- 2.6.15-git7a -- another interim snapshot because stuff we care about
  got fixed today
- Fix TCPv6 oops when sending RST or ACK packets

* Wed Jan 11 2006 Dave Jones <davej@redhat.com>
- Make ATI chipset based x86-64 machines boot again.

* Wed Jan 11 2006 David Woodhouse <dwmw2@redhat.com>
- 2.6.15-git7
- Turn off CONFIG_DEBUG_MUTEXES since it makes the G5 not boot
- Update bcm43xx and softmac

* Wed Jan 11 2006 David Woodhouse <dwmw2@redhat.com>
- 2.6.15-git6a (49cd619c69d643b30a24029e40eb5364c7a26b2e)
- Disable S390

* Wed Jan 11 2006  <sct@redhat.com>
- Fix up kevent usage for xen net backend
- Fix %post to create mkinitrd for domU

* Tue Jan 10 2006 David Woodhouse <dwmw2@redhat.com>
- 2.6.15-git5a (1fd5a46dd6bbca3a1275465120caf4748872c2a7)

* Mon Jan  9 2006 Stephen Tweedie <sct@redhat.com>
- Rebase xen to hypervisor from 20060106
- Rebase xen kernel code to linux-2.6-merge.hg cset 16985
- Disable power management bits that don't work in Xen
- Remove include/asm-xen from rpm

* Mon Jan  9 2006 Dave Jones <davej@redhat.com>
- 2.6.15-git5

* Sat Jan 07 2006 Dave Jones <davej@redhat.com>
- 2.6.15-git3

* Fri Jan  6 2006 Dave Jones <davej@redhat.com>
- Enable nvram driver for x86-64
- Fix posix-cpu-timers sched_time accumulation

* Fri Jan  6 2006 David Woodhouse <dwmw2@redhat.com>
- Fix mv643xx_eth and spider_net compilation
- Update Broadcom driver, switch to git tree for softmac
- Fix IA64 build (asm-generic/signal.h needs linux/compiler.h)

* Fri Jan  6 2006 Dave Jones <davej@redhat.com>
- 2.6.15-git2
- Add timer quirk for ATI chipsets.
- Reboot through BIOS on HP laptops.
- Additional check in x86 edid parser.
- power up pwc webcam by default
- don't confuse wireless security lock as a mouse.
- Hush some debug messages in w1 driver.
- Disable input layer on iseries.
- VM OOM killer tweaks.

* Thu Jan  5 2006 Dave Jones <davej@redhat.com>
- Try to debug some negative pagecount errors.

* Tue Jan  3 2006 Dave Jones <davej@redhat.com>
- Silence some gcc4.1 warnings.

* Tue Jan  3 2006 David Woodhouse <dwmw2@redhat.com>
- Make bcm43xx quieter when dropping packets, and make it reassociate on 
  resume

* Tue Jan  3 2006 Dave Jones <davej@redhat.com>
- Update to 2.6.15 final.
- Altix: Fix sn_flush_device_kernel & spinlock initialization. (#176827)

* Mon Jan 02 2006 David Woodhouse <dwmw2@redhat.com>
- Merge experimental Broadcom wireless driver

* Sun Jan 01 2006 Dave Jones <davej@redhat.com>
- 2.6.15-rc7-git6

* Sat Dec 31 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc7-git5

* Fri Dec 30 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc7-git4

* Thu Dec 29 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc7-git3
- Further cfq/ub spinlock fixing.

* Wed Dec 28 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc7-git2
- Reduce stack usage in block layer.
- Limit number of serial ports registered at boot time.
- Fix spinlock corruption in cfq with ub.

* Tue Dec 27 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc7-git1

* Sun Dec 25 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc7
- bah humbug.

* Sat Dec 24 2005 Dave Jones <davej@redhat.com>
- Disable dumb yealink driver, which bound to any hid device.

* Fri Dec 23 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc6-git4

* Thu Dec 22 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc6-git3

* Wed Dec 21 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc6-git2

* Wed Dec 21 2005 Juan Quintela <quintela@trasno.org>
- rebase to rawhide 1.7779.

* Tue Dec 20 2005 Juan Quintela <quintela@redhat.com>
- switch BSD license to Dual BSD/GPL as agreed with upstream.

* Tue Dec 20 2005 Juan Quintela <quintela@redhat.com>
- add EXPORT_SYMBOL for xen_net_read_mac.

* Tue Dec 20 2005 Juan Quintela <quintela@redhat.com>
- xennet is a module again.
- merge with rawhide 1.7776 kernel.
- HIGHMEM4G is default now.

* Tue Dec 20 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc6-git1
- Make APM work again.

* Tue Dec 20 2005 Dave Jones <davej@redhat.com>
- Try to disable SMBFS again.
  smbfs got hardly any fixing in the last 12 months, whilst
  cifs is under constant improvement.  Hopefully things are
  in better shape than they were last time we tried this
  back in FC3.

* Mon Dec 19 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc6
- Various ub stability improvements from Pete Zaitcev.
- Update ACPICA.

* Mon Dec 19 2005 David Woodhouse <dwmw2@redhat.com>
- Fix thermal overload on liquid-cooled G5s
- Fix USB suspend
- Disable floppy driver on ppc32

* Sat Dec 17 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc5-git7

* Fri Dec 16 2005 David Woodhouse <dwmw2@redhat.com>
- Update to fixed Cell pause_zero code

* Fri Dec 16 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc5-git6

* Fri Dec 16 2005 Dave Jones <davej@redhat.com>
- If we oops, pause a while before doing anything
  so that people get a chance to grab the debug info.

* Thu Dec 15 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc5-git5

* Wed Dec 14 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc5-git4
- Try 'optimise for size' again.
- Silence noisy CD drives that spew msgs when probed whilst empty.

* Tue Dec 13 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc5-git3
- Use MMIO instead of PIO for 8139too

* Tue Dec 13 2005 David Woodhouse <dwmw2@redhat.com>
- Remove workaround for fixed GCC PR25248

* Mon Dec 12 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc5-git2

* Mon Dec 12 2005 David Woodhouse <dwmw2@redhat.com>
- Make mambo_disk not run on real hardware; only on sim
- Also make it a module
- Handle iommu on DD3 boards
- Fix parport patch

* Sun Dec 11 2005 Dave Jones <davej@redhat.com>
- Re-add ISA soundblaster drivers. (#175492)

* Sat Dec 10 2005 Dave Jones <davej@redhat.com>
- Disable guessing of how many x86-64 hotplug cpus to add.

* Sat Dec 10 2005 David Woodhouse <dwmw2@redhat.com>
- Work around GCC PR25248 
- Fix parport_pc driver to check before poking at legacy I/O ports

* Thu Dec  8 2005 David Woodhouse <dwmw2@redhat.com>
- Clean up Cell patches, make it boot on real hardware

* Wed Dec  7 2005 Dave Jones <davej@redhat.com>
- Merge slab leak detector.
- Suppress APIC errors on UP x86-64. (#175193)

* Tue Dec  6 2005 Dave Jones <davej@redhat.com>
- Test build with gcc4.1

* Mon Dec 05 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc5-git1

* Sun Dec  4 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc5

* Sat Dec 03 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc4-git2

* Fri Dec  2 2005 Stephen Tweedie <sct@redhat.com>
- Initial merge of current linux-2.6-merge.hg tree into rawhide

* Fri Dec 02 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc4-git1
- sysfs debug on x86-64 too.

* Fri Dec  2 2005 Dave Jones <davej@redhat.com>
- Better fix for the NFSD cache_change_attribute fix. (#174010)

* Thu Dec  1 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc4
- Flip default ioscheduler back to cfq.
- Increase firmware loader timeout. (#174589)
- Add sysfs debug info to oops output.

* Wed Nov 30 2005 Dave Jones <davej@redhat.com>
- Revert a broken NFS change from upstream. (#174010)
- Re-add a rediffed Tux http accelerator.
- 2.6.15-rc3-git1

* Tue Nov 29 2005 David Woodhouse <dwmw2@redhat.com>
- Fix EHCI panic on initialisation
- Fix is_valid_ether_addr() not to claim broadcast is valid

* Tue Nov 29 2005 Dave Jones <davej@redhat.com>
- 2.6.15rc3

* Mon Nov 28 2005 Dave Jones <davej@redhat.com>
- Additional ID for Conexant AccessRunner USB driver (#174339)

* Mon Nov 28 2005 David Woodhouse <dwmw2@redhat.com>
- Fix RX packet alignment and multicast on MV643xx Ethernet

* Sun Nov 27 2005 Dave Jones <davej@redhat.com>
- Port change_page_attr fixes from x86-64.
  (Fixes rodata-readonly causes instant reboot)

* Sat Nov 26 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc2-git6

* Fri Nov 25 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc2-git5

* Fri Nov 25 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc2-git4

* Thu Nov 24 2005 David Woodhouse <dwmw2@redhat.com>
- Fix non-volatile register saving in ppc32 signal delivery
- Compile mambonet (IBM Cell sim network) as a module

* Wed Nov 23 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc2-git3

* Tue Nov 22 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc2-git2
- Add a 'nowprodata' to disable rodata protection during debug.
- Fix NFSD badness warning.
- Enable SATA ATAPI by default.
- Fix some silly thinko's in the signed modules code.

* Mon Nov 21 2005 David Woodhouse <dwmw2@redhat.com>
- No pcskpr on ppc64
- Fix IBM Cell sim console output

* Mon Nov 21 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc2-git1
- Shrink the 586 kernel by removing some unnecessary modules.

* Sun Nov 20 2005 Dave Jones <davej@redhat.com>
- Fix bad locking in NFS (#173364)

* Sat Nov 19 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc2

* Sat Nov 19 2005 David Woodhouse <dwmw2@redhat.com>
- Make kernel-devel packages work again for ppc/ppc64
- Fix oops with MGA on root PCI bus

* Fri Nov 18 2005 David Woodhouse <dwmw2@redhat.com>
- Fix ppc64 sparsemem with memory holes.

* Fri Nov 18 2005 Dave Jones <davej@redhat.com>
- Write protect kernel space rodata on x86-32 too.
- Fix up the placement of Obsolete: on x86-64

* Thu Nov 17 2005 Dave Jones <davej@redhat.com>
- Disable 3c501 driver. Sorry, Alan.

* Thu Nov 17 2005 David Woodhouse <dwmw2@redhat.com>
- Disable HFC USB again since it's not fixed in -git3

* Thu Nov 17 2005 Stephen Tweedie <sct@redhat.com>
- 2.6.15-rc1-git3

* Thu Nov 17 2005 David Woodhouse <dwmw2@redhat.com>
- Disable CONFIG_RTC on ppc64. It's CONFIG_GEN_RTC now
- Use anticipatory I/O scheduler by default. CFQ appears broken.

* Wed Nov 16 2005 David Woodhouse <dwmw2@redhat.com>
- 2.6.15-rc1-git4
- Re-enable hfc_usb since it appears to be fixed
- Re-enable iSeries too on the same basis
- Fix EEH use of uninitialised spinlock again

* Wed Nov 16 2005 David Woodhouse <dwmw2@redhat.com>
- Support PPC64 kernel running in IBM Cell Broadband Engine simulator
  (http://www.alphaworks.ibm.com/tech/cellsystemsim)
- Update serial-of patch

* Wed Nov 16 2005 Dave Jones <davej@redhat.com>
- Unbreak config generation. HIGHMEM64G works again.

* Tue Nov 15 2005 Dave Jones <davej@redhat.com>
- More UB fixing.

* Tue Nov 15 2005 David Woodhouse <dwmw2@redhat.com>
- Revamp ppc32 and ppc64 system call entry/exit paths
- Fix up PCI initialisation on ppc64 to prevent parport_pc killing G5s

* Tue Nov 15 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc1-git3
- Make lrmi using apps (ddcprobe et al) work again.

* Tue Nov 15 2005 David Woodhouse <dwmw2@redhat.com>
- More PPC vDSO fixes

* Mon Nov 14 2005 Dave Jones <davej@redhat.com>
- Enable USB storage,UB & libusual magick.
- Disable busted HFC-S USB based HiSAX ISDN driver.

* Mon Nov 14 2005 David Woodhouse <dwmw2@redhat.com>
- Clean up ppc64 config a little; enable thermal support

* Mon Nov 14 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc1-git2
- Ignore result from acpi_bus_find_driver(device);
  Should fix boot hangs on several HP systems (and maybe others).
- Terminate the device id list in hfc driver.

* Mon Nov 14 2005 David Woodhouse <dwmw2@redhat.com>
- PPC vDSO fixes from BenH

* Sun Nov 13 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc1-git1

* Fri Nov 11 2005 Dave Jones <davej@redhat.com>
- 2.6.15-rc1
  - iseries broken, so disabled for now.
- 2.6.14-git14

* Fri Nov 11 2005 Bill Nottingham <notting@redhat.com>
- ipw2200 requires a new firmware version, tweak conflict

* Thu Nov 10 2005 Dave Jones <davej@redhat.com>
- 2.6.14-git13

* Wed Nov 09 2005 Dave Jones <davej@redhat.com>
- 2.6.14-git12

* Tue Nov 08 2005 Dave Jones <davej@redhat.com>
- Update patch to write protect read-only kernel data.

* Tue Nov 08 2005 David Woodhouse <dwmw2@redhat.com>
- 2.6.14-git11

* Mon Nov 07 2005 Dave Jones <davej@redhat.com>
- 2.6.14-git10

* Mon Nov 07 2005 Dave Jones <davej@redhat.com>
- silence some selinux messages.

* Sun Nov 06 2005 Dave Jones <davej@redhat.com>
- 2.6.14-git9

* Sat Nov 05 2005 David Woodhouse <dwmw2@redhat.com>
- Attempt ppc smp build again

* Sat Nov 05 2005 Dave Jones <davej@redhat.com>
- Add another IBM Thinkpad to the Radeon whitelist.

* Sat Nov 05 2005 David Woodhouse <dwmw2@redhat.com>
- 2.6.14-git8
- Fix i8259 cascade initialisation in arch/powerpc
- disable ppc smp build for now

* Fri Nov 04 2005 Dave Jones <davej@redhat.com>
- Own /lib/modules/<version>/{extra,updates} (#172075)
- 2.6.14-git7

* Thu Nov 03 2005 Dave Jones <davej@redhat.com>
- prereq new kudzu. (Should fix upgrades for mptfusion users)
- 2.6.14-git6
- Copy all Makefiles to -devel packages.

* Wed Nov 02 2005 David Woodhouse <dwmw2@redhat.com>
- Switch ppc64 and ppc kernels to arch/powerpc
- Add nvram driver back again
- Fix ppc32 initrd with arch/powerpc

* Wed Nov 02 2005 David Woodhouse <dwmw2@redhat.com>
- 2.6.14-git5
- Fix up PPC configs in preparation for using arch/powerpc
- Prevent kauditd from aborting suspend

* Sun Oct 30 2005 Dave Jones <davej@redhat.com>
- 2.6.14-git2

* Thu Oct 27 2005 Dave Jones <davej@redhat.com>
- 2.6.14

* Thu Oct 27 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc5-git7 

* Wed Oct 26 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc5-git6
- Disable CONFIG_OPTIMIZE_FOR_SIZE again
  It seems to break booting randomly on x86-64 among other things.

* Tue Oct 25 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc5-git5

* Mon Oct 24 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc5-git4
- Fix up maestro driver hang at init. (#134507)

* Mon Oct 24 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc5-git3

* Sat Oct 22 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc5-git2

* Sat Oct 22 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc5-git1

* Thu Oct 20 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc5
- Aparently the ipw2200 drivers need 2.2 of the firmware right now.
- Fix autofs4 looking up wrong path element when ghosting is enabled.

* Thu Oct 20 2005 David Woodhouse <dwmw2@redhat.com>
- Bring forward 8250 OpenFirmware probe patch from FC4.

* Tue Oct 18 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc4-git6

* Mon Oct 17 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc4-git5

* Sun Oct 16 2005 Dave Jones <davej@redhat.com>
- Enable ACPI EC Burst.
- Change printk level of an ACPI message.
- Stop IDE claiming legacy ports before libata in combined mode.

* Sat Oct 15 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc4-git4

* Fri Oct 14 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc4-git3

* Thu Oct 13 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc4-git2

* Wed Oct 12 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc4-git1

* Tue Oct 11 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc4

* Fri Oct 07 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc3-git7

* Thu Oct 06 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc3-git6

* Thu Oct 06 2005 Dave Jones <davej@redhat.com>
- fix suspend to sbp devices. (#166452)

* Wed Oct 05 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc3-git5

* Tue Oct 04 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc3-git4
- canonicalise getxattr results.

* Mon Oct 03 2005 Dave Jones <davej@redhat.com>
- silence silly debug message in cx88. (#168931)
- bring back ac97 sliders on emu10k1
- 2.6.14-rc3-git3

* Sun Oct 02 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc3-git1

* Fri Sep 30 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc3
- fix eject on ide-floppy. (#158548)
- 2.6.14-rc2-git8

* Thu Sep 29 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc2-git7
- Fix up module aliases for firedire. (#134047)
- rebuild.

* Wed Sep 28 2005 Dave Jones <davej@redhat.com>
- Package ppc32 includes in ppc64 headers too. (#147724)
- Add another Thinkpad to the radeon backlight dmi list. (#168156)

* Tue Sep 27 2005 Dave Jones <davej@redhat.com>
- Fix typo in previous knfsd patch.

* Mon Sep 26 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc2-git6

* Mon Sep 26 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc2-git5

* Sat Sep 24 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc2-git4
- kNFSD: fixed '-p port' arg to rpc.nfsd and enables the
  defining proto versions and transports

* Fri Sep 23 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc2-git3
- Add another Radeon to the power saving backlight patch. (#165297)
- Enable UP APIC support, but disable by default.

* Thu Sep 22 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc2-git2

* Thu Sep 22 2005 Dave Jones <davej@redhat.com>
- Reset some conflicts: to earlier revisions.

* Thu Sep 22 2005 David Woodhouse <dwmw2@redhat.com>
- Fix G5 boot by avoiding EEH checks

* Wed Sep 21 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc2-git1

* Wed Sep 21 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc2

* Wed Sep 21 2005 David Woodhouse <dwmw2@redhat.com>
- Fix zImage.stub build, but then disable it anyway since we don't need 
  it any more -- the stub is built as part of ppc64-utils instead.

* Mon Sep 19 2005 David Woodhouse <dwmw2@redhat.com>
- Add asm-powerpc directory, DVB include files from drivers/media/dvb/

* Sun Sep 18 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc1-git4

* Fri Sep 16 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc1-git3

* Fri Sep 16 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc1-git2

* Wed Sep 14 2005 Dave Jones <davej@redhat.com>
- Fix bug in mm/slab.c (#168258)

* Tue Sep 13 2005 Dave Jones <davej@redhat.com>
- 2.6.14-rc1
- Reenable fixed version of the execshield vdso patch.

* Mon Sep 12 2005 Dave Jones <davej@redhat.com>
- 2.6.13-git12

* Sat Sep 10 2005 Dave Jones <davej@redhat.com>
- 2.6.13-git10

* Fri Sep 09 2005 Dave Jones <davej@redhat.com>
- 2.6.13-git9

* Thu Sep 08 2005 Dave Jones <davej@redhat.com>
- 2.6.13-git8

* Wed Sep 07 2005 Dave Jones <davej@redhat.com>
- 2.6.13-git7

* Tue Sep 06 2005 Dave Jones <davej@redhat.com>
- 2.6.13-git6

* Mon Sep 05 2005 Dave Jones <davej@redhat.com>
- 2.6.13-git5

* Sun Sep 04 2005 Dave Jones <davej@redhat.com>
- 2.6.13-git4

* Fri Sep 02 2005 Dave Jones <davej@redhat.com>
- 2.6.13-git3.
  (For real this time, the last two builds didn't really rebase).
  - Tux & Xen currently disabled.
  - ipw2100/ipw2200 drivers are now upstream.
- "The yellow dart" strikes again. Kexec based kdump support.

* Wed Aug 31 2005 Dave Jones <davej@redhat.com>
- 2.6.13-git2

* Tue Aug 30 2005 Dave Jones <davej@redhat.com>
- 2.6.13-git1

* Sun Aug 28 2005 Dave Jones <davej@redhat.com>
- 2.6.13 final.

* Sat Aug 27 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc7-git2

* Sat Aug 27 2005 Dave Jones <davej@redhat.com>
- Enabled voluntary preemption.

* Fri Aug 26 2005 Dave Jones <davej@redhat.com>
- Add another bios rev to the "thinkpad that cant do c2/c3" list. (#165590)
- Add another thinkpad to the radeon-pm list. (#166123)
- Better identify local builds. (#159696)
- Fix up some missing exported symbols.
- Build network drivers for Xen0 kernel.

* Thu Aug 25 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc7-git1
- FUTEX_WAKE_OP support.

* Tue Aug 23 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc7
- Net/Diskdump/netconsole update from Jeff "The Yellow Dart" Moyer.

* Tue Aug 23 2005 Rik van Riel <riel@redhat.com>
- upgrade to latest upstream Xen snapshot

* Mon Aug 22 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6-git13

* Sat Aug 20 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6-git12

* Sat Aug 20 2005 Dave Jones <davej@redhat.com>
- Disable -Os again, to see if some odd bugs 'go away'.
- Add errata 122 workaround for AMD x86-64 CPUs.

* Fri Aug 19 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6-git11

* Thu Aug 18 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6-git10
- Drop a bunch of bogus patches.

* Thu Aug 18 2005 David Woodhouse <dwmw2@redhat.com>
- Don't probe 8250 ports on ppc32 unless they're in the device tree
- Prevent snd-powermac from oopsing on non-Mac hardware
- Audit updates from git tree

* Thu Aug 18 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6-git9
- Fix up the 'last item on the boot cmdline gets eaten' bug.
- Better workaround for the usbmon DMA deficiency.

* Tue Aug 16 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6-git8

* Mon Aug 15 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6-git7
- Fix module_verify_elf check that rejected valid .ko files. (#165528)

* Sun Aug 14 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6-git6

* Sat Aug 13 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6-git5

* Fri Aug 12 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6-git4
- Bump mkinitrd dependancy.

* Thu Aug 11 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6-git3

* Thu Aug 11 2005 David Woodhouse <dwmw2@redhat.com>
- Enable ISDN and CONFIG_SERIAL_8250_CONSOLE for PPC32

* Wed Aug 10 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6-git2
- Enable CONFIG_I2C_I801 for x86-64.

* Tue Aug 09 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6-git1
- PCMCIA/PCCARD are now built non-modular for improved resource management.
- Fix incorrect n_link count in procfs.
- Fix missing declaration in the ppc64 kernel.

* Tue Aug 09 2005 Dave Jones <davej@redhat.com>
- Improve the spinlock debugging panic code.
  (Worse case, users can now boot with 'dontpanic')
- Add new patch to deal with the 'white space at eol of modprobe.conf' bug.
  (This one doesn't ignore obsolete parameters).

* Mon Aug 08 2005 Dave Jones <davej@redhat.com>
- Various specfile cleanup.
  - dropped dead patches, renamed some patches, updated package conflicts:
- Improve megaraid compatiblity hack.
  (Now the legacy driver doesn't claim support for the drivers
   that the newer driver supports).
- Disable building of sk98lin driver. (Use sk98 instead).

* Sun Aug 07 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc6

* Sat Aug 06 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc5-git4

* Fri Aug 05 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc5-git3
- Add support for netcell revolution IDE controller. (#164330)

* Thu Aug 04 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc5-git2

* Wed Aug 03 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc5-git1

* Tue Aug 02 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc5

* Mon Aug 01 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc4-git4

* Mon Aug 01 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc4-git3

* Fri Jul 29 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc4-git1

* Thu Jul 28 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc4

* Thu Jul 28 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc3-git9

* Thu Jul 28 2005 David Woodhouse <dwmw2@redhat.com>
- Enable i8042 and Amiga partitions on PPC (for Pegasos II, CHRP)

* Wed Jul 27 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc3-git8

* Mon Jul 25 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc3-git7

* Sat Jul 23 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc3-git5

* Mon Jul 18 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc3-git4

* Sun Jul 17 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc3-git4

* Fri Jul 15 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc3-git2

* Thu Jul 14 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc3-git1

* Wed Jul 13 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc3

* Tue Jul 12 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc2-git5
- Fix IDE locking bug de jour.
- Workaround a usbmon deficiency.
- Re-add Tux again.

* Sun Jul 10 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc2-git3

* Fri Jul 08 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc2-git2

* Thu Jul 07 2005 Dave Jones <davej@redhat.com>
- Fix exec-shield to not randomize to between end-of-binary and start-of-brk

* Wed Jul 06 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc2

* Tue Jul 05 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc1-git7
- Radeon power saving for another T41 (#159791)
- Drop x86-64 SMP kernels, and make generic kernel use SMP.
- Add pci table to advansys scsi driver. (#162431)

* Mon Jul 04 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc1-git6

* Fri Jul 01 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc1-git3
  - Xen broke again, so is temporarily disabled. Sorry :(
- Add a vdso marker to /proc/*/maps even if the vDSO is randomized

* Thu Jun 30 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc1-git2

* Wed Jun 29 2005 Dave Jones <davej@redhat.com>
- 2.6.13-rc1

* Tue Jun 28 2005 Dave Jones <davej@redhat.com>
- 2.6.12-git10

* Mon Jun 27 2005 Dave Jones <davej@redhat.com>
- 2.6.12-git9

* Mon Jun 27 2005 Dave Jones <davej@redhat.com>
- 2.6.12-git8

* Thu Jun 23 2005 Dave Jones <davej@redhat.com>
- 2.6.12-git5
- Revert ipw drivers back to those shipped with FC4 for the time being..
- Make Orinoco driver suck less.
  (Scanning/Roaming/Ethtool support).

* Wed Jun 22 2005 Dave Jones <davej@redhat.com>
- 2.6.12-git4
- Bring back the IDE fixes from -ac

* Tue Jun 21 2005 Dave Jones <davej@redhat.com>
- 2.6.12-git3
  - Welcome back Tux.
- Don't disable sysenter if booted with exec_shield=0
- Fix up and reenable Xen.

* Mon Jun 20 2005 Dave Jones <davej@redhat.com>
- 2.6.12-git2
  - temporarily disable Tux as the rebase broke it.

* Mon Jun 13 2005 Peter Jones <pjones@redhat.com>
- Reenable fixed ipw drivers.

* Mon Jun 13 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc6-git5

* Thu Jun 09 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc6-git3
- Temporarily disable the ipw drivers until I sort them out.

* Tue Jun  7 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc6-git1
- Disable hercules fb.
  If you have one of these, please put it back in the trash. Thanks.

* Mon Jun  6 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc6
- Copy asm-i386 into x86-64's kernel-devel too. (#150266)

* Sat Jun  4 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc5-git9

* Fri Jun  3 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc5-git8

* Thu Jun  2 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc5-git7

* Wed Jun  1 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc5-git6

* Tue May 31 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc5-git5

* Sun May 29 2005 Dave Jones <davej@redhat.com>
- Fix slab corruption in firewire (#158424)
- 2.6.12-rc5-git4

* Sat May 28 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc5-git3

* Fri May 27 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc5-git2

* Thu May 26 2005 Dave Jones <davej@redhat.com>
- Specfile adjustments for FC5
- 2.6.12-rc5-git1
- Fix unintialised value in single bit error detector. (#158825)

* Wed May 25 2005 David Woodhouse <dwmw2@redhat.com>
- Turn off CONFIG_ISA on PPC again. It makes some Macs unhappy (#149200)
- Make Speedtouch DSL modem resync automatically

* Tue May 24 2005 Dave Jones <davej@redhat.com>
- Update various cpufreq drivers.
- 2.6.12-rc4-git8
  kobject ordering, tg3 fixes, ppc32 ipic fix,
  ppc64 powermac smp fix. token-ring fixes,
  TCP fix. ipv6 fix.

* Mon May 23 2005 Dave Jones <davej@redhat.com>
- Add extra id to SATA Sil driver. (#155748)
- Fix oops on rmmod of lanai & ms558 drivers when no hardware present.

* Mon May 23 2005 Dave Jones <davej@redhat.com>
- Fix double unlock of spinlock on tulip. (#158522)

* Mon May 23 2005 David Woodhouse <dwmw2@redhat.com>
- audit updates: log serial # in user messages, escape comm= in syscalls

* Mon May 23 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc4-git6
  MMC update, reiserfs fixes, AIO fix.
- Fix absolute symlink in -devel (#158582)
- 2.6.12-rc4-git7
  PPC64 & i2c fixes
- Fix another divide by zero in ipw2100 (#158406)
- Fix dir ownership in kernel-doc rpm (#158478)

* Sun May 22 2005 Dave Jones <davej@redhat.com>
- Fix divide by zero in ipw2100 driver. (#158406)
- 2.6.12-rc4-git5
  More x86-64 updates, Further pktcdvd frobbing,
  yet more dvb updates, x86(64) ioremap fixes,
  ppc updates, IPMI sysfs support (reverted for now due to breakage),
  various SCSI fixes (aix7xxx, spi transport), vmalloc improvements

* Sat May 21 2005 David Woodhouse <dwmw2@redhat.com>
- Fix oops in avc_audit() (#158377)
- Include serial numbers in non-syscall audit messages

* Sat May 21 2005 Bill Nottingham <notting@redhat.com>
- bump ipw2200 conflict

* Sat May 21 2005 Dave Jones <davej@redhat.com> [2.6.11-1.1334_FC4]
- driver core: restore event order for device_add()

* Sat May 21 2005 David Woodhouse <dwmw2@redhat.com>
- More audit updates. Including a fix for AVC_USER messages.

* Fri May 20 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc4-git4
  networking fixes (netlink, pkt_sched, ipsec, netfilter,
  ip_vs, af_unix, ipv4/6, xfrm). TG3 driver improvements.

* Thu May 19 2005 Dave Jones <davej@redhat.com> [2.6.11-1.1327_FC4]
- 2.6.12-rc4-git3
  Further fixing to raw driver. More DVB updates,
  driver model updates, power management improvements,
  ext3 fixes.  
- Radeon on thinkpad backlight power-management goodness.
  (Peter Jones owes me two tacos).
- Fix ieee1394 smp init.

* Thu May 19 2005 Rik van Riel <riel@redhat.com>
- Xen: disable TLS warning (#156414)

* Thu May 19 2005 David Woodhouse <dwmw2@redhat.com>
- Update audit patches

* Thu May 19 2005 Dave Jones <davej@redhat.com> [2.6.11-1.1325_FC4]
- Fix up missing symbols in ipw2200 driver.
- Reenable debugfs / usbmon. SELinux seems to cope ok now.
  (Needs selinux-targeted-policy >= 1.23.16-1)

* Wed May 18 2005 Dave Jones <davej@redhat.com>
- Fix up some warnings in the IDE patches.
- 2.6.12-rc4-git2
  Further pktcdvd fixing, DVB update, Lots of x86-64 updates,
  ptrace fixes, ieee1394 changes, input layer tweaks,
  md layer fixes, PCI hotplug improvements, PCMCIA fixes,
  libata fixes, serial layer, usb core, usbnet, VM fixes,
  SELinux tweaks.
- Update ipw2100 driver to 1.1.0
- Update ipw2200 driver to 1.0.4 (#158073)

* Tue May 17 2005 Dave Jones <davej@redhat.com>
- 2.6.12-rc4-git1
  ARM, ioctl security fixes, mmc driver update,
  ibm_emac & tulip netdriver fixes, serial updates
  ELF loader security fix.

* Mon May 16 2005 Rik van Riel <riel@redhat.com>
- enable Xen again (not tested yet)
- fix a typo in the EXPORT_SYMBOL patch

* Sat May 14 2005 Dave Jones <davej@redhat.com>
- Update E1000 driver from netdev-2.6 tree. 
- Add some missing EXPORT_SYMBOLs.

* Fri May 13 2005 Dave Jones <davej@redhat.com>
- Bump maximum supported CPUs on x86-64 to 32.
- Tickle the NMI watchdog when we're doing serial writes.
- SCSI CAM geometry fix.
- Slab debug single-bit error improvement.

* Thu May 12 2005 David Woodhouse <dwmw2@redhat.com>
- Enable CONFIG_ISA on ppc32 to make the RS/6000 user happy.
- Update audit patches

* Wed May 11 2005 Dave Jones <davej@redhat.com>
- Add Ingo's patch to detect soft lockups.
- Thread exits silently via __RESTORE_ALL exception for iret. (#154369)

* Wed May 11 2005 David Woodhouse <dwmw2@redhat.com>
- Import post-rc4 audit fixes from git, including ppc syscall auditing

* Wed May 11 2005 Dave Jones <davej@redhat.com>
- Revert NMI watchdog changes.

* Tue May 10 2005 Dave Jones <davej@redhat.com>
- Enable PNP on x86-64

* Tue May 10 2005 Jeremy Katz <katzj@redhat.com>
- make other -devel packages provide kernel-devel so they get 
  installed instead of upgraded (#155988)

* Mon May  9 2005 Dave Jones <davej@redhat.com>
- Rebase to 2.6.12-rc4
  | Xen builds are temporarily disabled again.
- Conflict if old version of ipw firmware is present.

* Fri May  6 2005 Dave Jones <davej@redhat.com>
- Add PCI ID for new sundance driver. (#156859)

* Thu May  5 2005 David Woodhouse <dwmw2@redhat.com>
- Import audit fixes from upstream

* Wed May  4 2005 Jeremy Katz <katzj@redhat.com>
- enable radeonfb and agp on ppc64 to fix X on the G5

* Tue May  3 2005 Dave Jones <davej@redhat.com>
- Disable usbmon/debugfs again for now until SELinux policy is fixed.

* Mon May  2 2005 David Woodhouse <dwmw2@redhat.com>
- Make kallsyms include platform-specific symbols
- Fix might_sleep warning in pbook clock-spreading fix

* Sun May  1 2005 Dave Jones <davej@redhat.com>
- Fix yesterdays IDE fixes.
- Blacklist another brainless SCSI scanner. (#155457)

* Sun May  1 2005 David Woodhouse <dwmw2@redhat.com>
- Fix EHCI port power switching

* Sun May  1 2005 Dave Jones <davej@redhat.com>
- Enable usbmon & debugfs. (#156489)

* Sat Apr 30 2005 Dave Jones <davej@redhat.com>
- Numerous IDE layer fixes from Alan Cox.
- Kill off some stupid messages from the input layer.

* Fri Apr 29 2005 Roland McGrath <roland@redhat.com>
- Fix the 32bit emulation on x86-64 segfaults.

* Wed Apr 27 2005 Dave Jones <davej@redhat.com>
- Hopefully fix the random reboots some folks saw on x86-64.

* Wed Apr 27 2005 Jeremy Katz <katzj@redhat.com>
- fix prereqs for -devel packages

* Wed Apr 27 2005 Rik van Riel <riel@redhat.com>
- Fix up the vdso stuff so kernel-xen* compile again
- Import upstream bugfix so xenU domains can be started again

* Tue Apr 26 2005 Dave Jones <davej@redhat.com>
- Fix up the vdso again, which broke on the last rebase to -rc3
- Fix the put_user() fix. (#155999)

* Mon Apr 25 2005 Dave Jones <davej@redhat.com>
- Fix x86-64 put_user()
- Fix serio oops.
- Fix ipv6_skip_exthdr() invocation causing OOPS.
- Fix up some permissions on some /proc files.
- Support PATA drives on Promise SATA. (#147303)

* Mon Apr 25 2005 Rik van Riel <riel@redhat.com>
- upgrade to the latest version of xenolinux patches
- reenable xen (it boots, ship it!)

* Sat Apr 23 2005 David Woodhouse <dwmw2@redhat.com>
- Enable adt746x and windtunnel thermal modules
- Disable clock spreading on certain pbooks before sleep
- Sound support for Mac Mini

* Fri Apr 22 2005 Dave Jones <davej@redhat.com>
- Reenable i2c-viapro on x86-64.

* Fri Apr 22 2005 Dave Jones <davej@redhat.com>
- Don't build powernow-k6 on anything other than 586 kernels.
- Temporarily disable Xen again.

* Wed Apr 20 2005 Dave Jones <davej@redhat.com>
- 2.6.12rc3

* Wed Apr 20 2005 Dave Jones <davej@redhat.com>
- Adjust struct dentry 'padding' based on 64bit'ness.

* Tue Apr 19 2005 Dave Jones <davej@redhat.com>
- Print stack trace when we panic.
  Might give more clues for some of the wierd panics being seen right now.
- Blacklist another 'No C2/C3 states' Thinkpad R40e BIOS. (#155236)

* Mon Apr 18 2005 Dave Jones <davej@redhat.com>
- Make ISDN ICN driver not oops when probed with no hardware present.
- Add missing MODULE_LICENSE to mac_modes.ko

* Sat Apr 16 2005 Dave Jones <davej@redhat.com>
- Make some i2c drivers arch dependant.
- Make multimedia buttons on Dell inspiron 8200 work. (#126148)
- Add diffutils buildreq (#155121)

* Thu Apr 14 2005 Dave Jones <davej@redhat.com>
- Build DRM modular. (#154769)

* Wed Apr 13 2005 Rik van Riel <riel@redhat.com>
- fix up Xen for 2.6.12-rc2
- drop arch/xen/i386/signal.c, thanks to Roland's vdso patch (yay!)
- reenable xen compile - this kernel test boots on my system

* Tue Apr 12 2005 Dave Jones <davej@redhat.com>
- Further vdso work from Roland.

* Mon Apr 11 2005 David Woodhouse <dwmw2@redhat.com>
- Disable PPC cpufreq/sleep patches which make sleep less reliable
- Add TIMEOUT to hotplug environment when requesting firmware (#153993)

* Sun Apr 10 2005 Dave Jones <davej@redhat.com>
- Integrate Roland McGrath's changes to make exec-shield
  and vdso play nicely together.

* Fri Apr  8 2005 Dave Jones <davej@redhat.com>
- Disable Longhaul driver (again).

* Wed Apr  6 2005 Dave Jones <davej@redhat.com>
- 2.6.12rc2
  - netdump/netconsole currently broken.
  - Xen temporarily disabled.

* Fri Apr  1 2005 Dave Jones <davej@redhat.com>
- Make the CFQ elevator the default again.

* Thu Mar 31 2005 Rik van Riel <riel@redhat.com>
- upgrade to new upstream Xen code, twice 
- for performance reasons, disable CONFIG_DEBUG_PAGEALLOC for FC4t2

* Wed Mar 30 2005 Rik van Riel <riel@redhat.com>
- fix Xen kernel compilation (pci, page table, put_user, execshield, ...)
- reenable Xen kernel compilation

* Tue Mar 29 2005 Rik van Riel <riel@redhat.com>
- apply Xen patches again (they don't compile yet, though)
- Use uname in kernel-devel directories (#145914)
- add uname-based kernel-devel provisions (#152357)
- make sure /usr/share/doc/kernel-doc-%%{kversion} is owned by a
  package, so it will get removed again on uninstall/upgrade (#130667)

* Mon Mar 28 2005 Dave Jones <davej@redhat.com>
- Don't generate debuginfo files if %%_enable_debug_packages isnt set. (#152268)

* Sun Mar 27 2005 Dave Jones <davej@redhat.com>
- 2.6.12rc1-bk2
- Disable NVidia FB driver for time being, it isn't stable.

* Thu Mar 24 2005 Dave Jones <davej@redhat.com>
- rebuild

* Tue Mar 22 2005 Dave Jones <davej@redhat.com>
- Fix several instances of swapped arguments to memset()
- 2.6.12rc1-bk1

* Fri Mar 18 2005 Dave Jones <davej@redhat.com>
- kjournald release race. (#146344)
- 2.6.12rc1

* Thu Mar 17 2005 Rik van Riel <riel@redhat.com>
- upgrade to latest upstream Xen code

* Tue Mar 15 2005 Rik van Riel <riel@redhat.com>
- add Provides: headers for external kernel modules (#149249)
- move build & source symlinks from kernel-*-devel to kernel-* (#149210)
- fix xen0 and xenU devel %%post scripts to use /usr/src/kernels (#149210)

* Thu Mar 10 2005 Dave Jones <davej@redhat.com>
- Reenable advansys driver for x86

* Tue Mar  8 2005 Dave Jones <davej@redhat.com>
- Change SELinux execute-related permission checking. (#149819)

* Sun Mar  6 2005 Dave Jones <davej@redhat.com>
- Forward port some FC3 patches that got lost.

* Fri Mar  4 2005 Dave Jones <davej@redhat.com>
- Fix up ACPI vs keyboard controller problem.
- Fix up Altivec usage on PPC/PPC64.

* Fri Mar  4 2005 Dave Jones <davej@redhat.com>
- Finger the programs that try to read from /dev/mem.
- Improve spinlock debugging a little.

* Thu Mar  3 2005 Dave Jones <davej@redhat.com>
- Fix up the unresolved symbols problem.

* Thu Mar  3 2005 Rik van Riel <riel@redhat.com>
- upgrade to new Xen snapshot (requires new xen RPM, too)

* Wed Mar  2 2005 Dave Jones <davej@redhat.com>
- 2.6.11

* Tue Mar 1 2005 David Woodhouse <dwmw2@redhat.com>
- Building is nice. Booting would be better. Work around GCC -Os bug which
  which makes the PPC kernel die when extracting its initramfs. (#150020)
- Update include/linux/compiler-gcc+.h

* Tue Mar 1 2005 Dave Jones <davej@redhat.com>
- 802.11b/ipw2100/ipw2200 update.
- 2.6.11-rc5-bk4

* Tue Mar 1 2005 David Woodhouse <dwmw2@redhat.com>
- Fix ppc/ppc64/ppc64iseries builds for gcc 4.0
- Fix Xen build too

* Mon Feb 28 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc5-bk3
- Various compile fixes for building with gcc-4.0

* Sat Feb 26 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc5-bk1

* Fri Feb 25 2005 Dave Jones <davej@redhat.com>
- Hopefully fix the zillion unresolved symbols. (#149758)

* Thu Feb 24 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc5

* Wed Feb 23 2005 Rik van Riel <riel@redhat.com>
- get rid of unknown symbols in kernel-xen0 (#149495)

* Wed Feb 23 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc4-bk11

* Mon Feb 21 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc4-bk9

* Sat Feb 19 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc4-bk7

* Sat Feb 19 2005 Rik van Riel <riel@redhat.com>
- upgrade to newer Xen code, needs xen-20050218 to run

* Sat Feb 19 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc4-bk6

* Fri Feb 18 2005 David Woodhouse <dwmw2@redhat.com>
- Add SMP kernel for PPC32

* Fri Feb 18 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc4-bk5

* Tue Feb 15 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc4-bk3

* Mon Feb 14 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc4-bk2

* Sun Feb 13 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc4-bk1

* Sat Feb 12 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc4

* Fri Feb 11 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc3-bk8

* Thu Feb 10 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc3-bk7

* Wed Feb  9 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc3-bk6

* Tue Feb  8 2005 Dave Jones <davej@redhat.com>
- Enable old style and new style USB initialisation.
- More PPC jiggery pokery hackery.
- 2.6.11-rc3-bk5

* Mon Feb  7 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc3-bk4
- Various patches to unbork PPC.
- Display taint bits on VM error.

* Mon Feb  7 2005 Rik van Riel <riel@redhat.com>
- upgrade to latest upstream Xen bits, upgrade those to 2.6.11-rc3-bk2

* Sat Feb  5 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc3-bk2

* Fri Feb  4 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc3-bk1

* Wed Feb  2 2005 Dave Jones <davej@redhat.com>
- Stop the input layer spamming the console. (#146906)
- 2.6.11-rc3

* Tue Feb  1 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc2-bk10
- Reenable periodic slab checker.

* Tue Feb  1 2005 Rik van Riel <riel@redhat.com>
- update to latest xen-unstable source snapshot
- add agpgart patch from upstream xen tree
- port Ingo's latest execshield updates to Xen

* Mon Jan 31 2005 Rik van Riel <riel@redhat.com>
- enable SMP support in xenU kernel, use the xen0 kernel for the
  unprivileged domains if the SMP xenU breaks on your system

* Thu Jan 27 2005 Dave Jones <davej@redhat.com>
- Drop VM hack that broke in yesterdays rebase.

* Wed Jan 26 2005 Dave Jones <davej@redhat.com>
- Drop 586-SMP kernels.  These are a good candidate for
  fedora-extras when it appears. The number of people
  actually using this variant is likely to be very very small.
- 2.6.11-rc2-bk4

* Tue Jan 25 2005 Dave Jones <davej@redhat.com>
- 2.6.11-rc2-bk3

* Sun Jan 23 2005 Dave Jones <davej@redhat.com>
- Updated periodic slab debug check from Manfred.
- Enable PAGE_ALLOC debugging again, it should now be fixed.
- 2.6.11-rc2-bk1

* Fri Jan 21 2005 Dave Jones <davej@redhat.com>
- Rebase to 2.6.11-rc2

* Fri Jan 21 2005 Rik van Riel <riel@redhat.com>
- make exec-shield segment limits work inside the xen kernels

* Thu Jan 20 2005 Dave Jones <davej@redhat.com>
- Rebase to -bk8

* Wed Jan 19 2005 Dave Jones <davej@redhat.com>
- Re-add diskdump/netdump based on Jeff Moyers patches.
- Rebase to -bk7

* Tue Jan 18 2005 Jeremy Katz <katzj@redhat.com>
- fixup xen0 %%post to use new grubby features for multiboot kernels
- conflict with older mkinitrd for kernel-xen0

* Tue Jan 18 2005 Dave Jones <davej@redhat.com>
- -bk6

* Mon Jan 17 2005 Dave Jones <davej@redhat.com>
- First stab at kernel-devel packages. (David Woodhouse).

* Mon Jan 17 2005 Rik van Riel <riel@redhat.com>
- apply dmi fix, now xenU boots again

* Fri Jan 14 2005 Dave Jones <davej@redhat.com>
- Rebase to 2.6.11-bk2

* Thu Jan 13 2005 Dave Jones <davej@redhat.com>
- Rebase to 2.6.11-bk1

* Wed Jan 12 2005 Dave Jones <davej@redhat.com>
- Rebase to 2.6.11rc1

* Tue Jan 11 2005 Rik van Riel <riel@redhat.com>
- fix Xen compile with -bk14

* Tue Jan 11 2005 Dave Jones <davej@redhat.com>
- Update to -bk14
- Print tainted information in slab corruption messages.

* Tue Jan 11 2005 Rik van Riel <riel@redhat.com>
- merge fix for the Xen TLS segment fixup issue

* Tue Jan 11 2005 Dave Jones <davej@redhat.com>
- Depend on hardlink, not kernel-utils.

* Mon Jan 10 2005 Dave Jones <davej@redhat.com>
- Update to -bk13, reinstate GFP_ZERO patch which hopefully
  is now fixed.
- Add another Lexar card reader to the whitelist. (#143600)
- Package asm-m68k for asm-ppc includes. (don't ask). (#144604)

* Sat Jan  8 2005 Dave Jones <davej@redhat.com>
- Periodic slab debug is incompatable with pagealloc debug.
  Disable the latter.

* Fri Jan  7 2005 Dave Jones <davej@redhat.com>
- Santa came to Notting's house too. (another new card reader)
- Rebase to 2.6.10-bk10

* Thu Jan  6 2005 Rik van Riel <riel@redhat.com>
- update to latest xen-unstable tree
- fix up Xen compile with -bk9, mostly pudding

* Thu Jan  6 2005 Dave Jones <davej@redhat.com>
- Rebase to 2.6.10-bk9

* Tue Jan  4 2005 Dave Jones <davej@redhat.com>
- Rebase to 2.6.10-bk7
- Add periodic slab debug checker.

* Sun Jan  2 2005 Dave Jones <davej@redhat.com>
- Rebase to 2.6.10-bk5

* Sat Jan  1 2005 Dave Jones <davej@redhat.com>
- Fix probing of vesafb. (#125890)
- Reenable EDD.
- Don't assume existance of ~/.gnupg (#142201)

* Fri Dec 31 2004 Dave Jones <davej@redhat.com>
- Rebase to 2.6.10-bk4

* Thu Dec 30 2004 Dave Jones <davej@redhat.com>
- Rebase to 2.6.10-bk3

* Tue Dec 28 2004 Dave Jones <davej@redhat.com>
- Drop bogus ethernet slab cache.

* Sun Dec 26 2004 Dave Jones <davej@redhat.com>
- Santa brought a new card reader that needs whitelisting.

* Fri Dec 24 2004 Dave Jones <davej@redhat.com>
- Rebase to 2.6.10

* Wed Dec 22 2004 Dave Jones <davej@redhat.com>
- Re-add missing part of the exit() race fix. (#142505, #141896)

* Tue Dec 21 2004 Dave Jones <davej@redhat.com>
- Fix two silly bugs in the AGP posting fixes.

* Fri Dec 17 2004 Dave Jones <davej@redhat.com>
- Fix bio error propagation.
- Clear ebp on sysenter return.
- Extra debugging info on OOM kill.
- exit() race fix.
- Fix refcounting order in sd/sr, fixing cable pulls on USB storage.
- IGMP source filter fixes.
- Fix ext2/3 leak on umount.
- fix missing wakeup in ipc/sem
- Fix another tux corner case bug.
- NULL out ptrs in airo driver after kfree'ing them.

* Thu Dec 16 2004 Dave Jones <davej@redhat.com>
- Better version of the PCI Posting fixes for AGPGART.
- Add missing cache flush to the AGP code.
- Drop netdump and common crashdump code.

* Mon Dec 13 2004 Dave Jones <davej@redhat.com>
- Drop diskdump. Aiming for a better kexec based solution for FC4.

* Sun Dec 12 2004 Dave Jones <davej@redhat.com>
- fix false ECHILD result from wait* with zombie group leader.

* Sat Dec 11 2004 Dave Jones <davej@redhat.com>
- Workaround broken pci posting in AGPGART.
- Compile 686 kernel tuned for pentium4.
  | Needs benchmarking across various CPUs under
  | various workloads to find out if its worth keeping.
- Make sure VC resizing fits in s16.

* Fri Dec 10 2004 Dave Jones <davej@redhat.com>
- Prevent block device queues from being shared in viocd. (#139018)
- Libata updates. (#132848, #138405)
- aacraid: remove aac_handle_aif (#135527)
- fix uninitialized variable in waitid(2). (#142505)
- Fix CMSG validation checks wrt. signedness.
- Fix memory leak in ip_conntrack_ftp
- [IPV4]: Do not leak IP options.
- ppc64: Align PACA buffer for hypervisor's use. (#141817)
- ppc64: Indicate that the veth link is always up. (#135402)
- ppc64: Quiesce OpenFirmware stdin device at boot. (#142009)
- SELinux: Fix avc_node_update oops. (#142353)
- Fix CCISS ioctl return code.
- Make ppc64's pci_alloc_consistent() conform to documentation. (#140047)
- Enable EDD
- Enable ETH1394. (#138497)
- Workaround E1000 post-maturely writing back to TX descriptors. (#133261)
- Fix the previous E1000 errata workaround.
- Several IDE fixes from 2.6.9-ac
- vm pageout throttling. (#133858)
- Fix Tux from oopsing. (#140918)
- Fix Tux/SELinux incompatability (#140916)
- Fix Tux/IPV6 problem. (#140916)
- ide: Fix possible oops on boot.
- Make spinlock debugging panic instead of printk.
- Update Emulex lpfc driver to 8.0.16
- Selected patches from 2.6.9-ac12
- ppc64: Fix inability to find space for TCE table (#138844)
- Fix compat fcntl F_GETLK{,64} (#141680)
- blkdev_get_blocks(): handle eof
- Another card reader for the whitelist. (#134094)
- Disable tiglusb module. (#142102)
- E1000 64k-alignment fix. (#140047)
- Disable tiglusb module. (#142102)
- ID updates for cciss driver.
- Fix overflows in USB Edgeport-IO driver. (#142258)
- Fix wrong TASK_SIZE for 32bit processes on x86-64. (#141737)
- Fix ext2/ext3 xattr/mbcache race. (#138951)
- Fix bug where __getblk_slow can loop forever when pages are partially mapped. (#140424)
- Add missing cache flushes in agpgart code.

* Thu Dec  9 2004 Dave Jones <davej@redhat.com>
- Drop the 4g/4g hugemem kernel completely.

* Wed Dec  8 2004 Rik van Riel <riel@redhat.com>
- make Xen inherit config options from x86

* Mon Dec  6 2004 Rik van Riel <riel@redhat.com>
- apparently Xen works better without serial drivers in domain0 (#141497)

* Sun Dec  5 2004 Rik van Riel <riel@redhat.com>
- Fix up and reenable Xen compile.
- Fix bug in install part of BuildKernel. 

* Sat Dec  4 2004 Dave Jones <davej@redhat.com>
- Enable both old and new megaraid drivers.
- Add yet another card reader to usb scsi whitelist. (#141367)

* Fri Dec  3 2004 Dave Jones <davej@redhat.com>
- Sync all patches with latest updates in FC3.
- Fix up xen0/xenU uninstall.
- Temporarily disable xen builds.

* Wed Dec  1 2004 Rik van Riel <riel@redhat.com>
- replace VM hack with the upstream version
- more Xen bugfixes

* Tue Nov 30 2004 Rik van Riel <riel@redhat.com>
- upgrade to later Xen sources, with upstream bugfixes
- export direct_remap_area_pages for Xen

* Mon Nov 29 2004 Dave Jones <davej@redhat.com>
- Add another card reader to whitelist. (#141022)

* Fri Nov 26 2004 Rik van Riel <riel@redhat.com>
- add Xen kernels for i686, plus various bits and pieces to make them work

* Mon Nov 15 2004 Dave Jones <davej@redhat.com>
- Rebase to 2.6.9-ac9

* Sat Nov 13 2004 Dave Jones <davej@redhat.com>
- Drop some bogus patches.

* Thu Nov 11 2004 Dave Jones <davej@redhat.com>
- NFS: Fix dentry refcount accounting error
- Fix single-stepping on PPC64
- Integrate kernel-devel changes
- SELinux: netif fixes.
- SELinux: add DAC check to setxattr() hook.
- SELinux: sidtab locking fix.
- SELinux: mediate send_sigurg().
- SELinux: fix setscheduler hook deadlock.
- ide-floppy: Supresses error messages resulting from Medium not present
- Various IA64 updates from 2.6.10rc1
- nfsd: make sure getxattr inode op is non-NULL before calling it.
- Handle NULL dev->dev_addr in SIOCGIFHWADDR correctly. (#137648)
- Fix NFSD domainname size limit.
- nfsd4: nfsd oopsed when encountering a conflict with a local lock
- nfsd4: fix putrootfh return
- nfsd: Insecure port warning shows decimal IPv4 address
- Disable sw irqbalance/irqaffinity for e7520/e7320/e7525 (#136419)
- Fix exec-shield non-PIE/non-prelinked bug
- ext3 reservations: fix goal hit accounting.
- Fix problems with non-power-of-two sector size discs. (#135094)
- Fix possible oops in netpoll (#132153)
- Add missing MODULE_VERSION tags to various modules. (#136399)
- Add USB card reader de jour. (#124048)
- Remove SG_IO deprecation warning (#136179)
- Make sure that modules get signed with the right key.
- Remove SG_IO deprecation warning (#136179)
- s390: Fix fake_ll for qeth device. (#136175)
- s390: zfcp: Kernel stack frame for zfcp_cfdc_dev_ioctl() is too big
- s390: Use slab allocator for DASD I/O pages.
- PPC64: HVSI udbg support
- PPC64: Make HVSI console survive FSP reset
- PPC64: Make PCI hostbridge hotplugging work
- PPC64: Fix IBM VSCSI problems (#138124)
- Rebase -ac patch to 2.6.9-ac8.

* Wed Nov  3 2004 Dave Jones <davej@redhat.com>
- Reenable token-ring drivers (#122602)

* Tue Nov  2 2004 Dave Jones <davej@redhat.com>
- Reenable SLIP. (#124223)
- Add USB card reader de jour. (#124048)

* Mon Nov  1 2004 Dave Jones <davej@redhat.com>
- Fix memory leak on x86-64 in mixed 32/64 mode. (#132947)
- Yet another USB card reader for the whitelist. (#137722)

* Fri Oct 29 2004 Dave Jones <davej@redhat.com>
- Fix raid5 oops (#127862)
- Stop E820 BIOS entries being corrupted by EDID info. (#137510)

* Thu Oct 28 2004 Dave Jones <davej@redhat.com>
- Remove the possibility of some false OOM kills. (#131251)
- Add more USB card readers to SCSI whitelist (#131546)
- Disable CONFIG_SCHED_SMT for iseries.

* Wed Oct 27 2004 Dave Jones <davej@redhat.com>
- Reenable ISA NIC support (#136569)

* Tue Oct 26 2004 Dave Jones <davej@redhat.com>
- Reenable Initio 9100U(W) SCSI driver. (#137153)

* Mon Oct 25 2004 Dave Jones <davej@redhat.com>
- Add another USB card reader to SCSI whitelist (#132923)

* Fri Oct 22 2004 Dave Jones <davej@redhat.com>
- Fix PPC NUMA (#130716).
- Fix autoraid for S390 (#123842/#130339)
- Selected bits from 2.6.9-ac3
  - Fix syncppp/async ppp problems with new hangup
  - Fix broken parport_pc unload
  - Stop i8xx_tco making some boxes reboot on load
  - Fix cpia/module tools deadlock
  - Security fix for smbfs leak/overrun

* Thu Oct 21 2004 Dave Jones <davej@redhat.com>
- Misc security fixes from 2.6.9-ac2

* Wed Oct 20 2004 Dave Jones <davej@redhat.com>
- Fix ia64 module loading. (#136365)
- Enable discontigmem for PPC64
- Disable a bunch of useless PPC config options
- Enable PACK_STACK on s390.

* Tue Oct 19 2004 Dave Jones <davej@redhat.com>
- Fix NFS badness (#132726)
- Drop bogus USB workaround. (#131127)

* Mon Oct 18 2004 Dave Jones <davej@redhat.com>
- Rebase to 2.6.9
- Speedtouch USB DSL modem driver update.
- Cleanup some iseries config options.

* Fri Oct 15 2004 Dave Jones <davej@redhat.com>
- 2.6.9-rc4-bk3
- Fix up a bunch of unresolved symbols that crept in recently.
- Remove bogus O_NONBLOCK patch which broke lots of userspace.
- Fix booting on PPC64 by reserving initrd pages.

* Thu Oct 14 2004 Dave Jones <davej@redhat.com>
- Rebase to 2.6.9-rc4-bk2
- librtas needs to work around the /dev/mem restrictions.
- EXT3 reservations use-before-initialised bugfix.
- support O_NONBLOCK for read,pread,readv of regular files.
- EDD blows up some x86-64's. Disable again.

* Wed Oct 13 2004 Dave Jones <davej@redhat.com>
- Make EDD driver modular on x86-64 too.
- Various mkinitrd spec changes (Jeremy Katz)
- Enable a bunch more PPC64 config options. (Dave Howells)
- Enable ACPI cpufreq driver for x86-64 too.

* Tue Oct 12 2004 Dave Jones <davej@redhat.com>
- Rebase to 2.6.9-rc4-bk1
- Tux update.
- Update netdump/diskdump patches
- PowerPC 64 netboot changes.
- Various CONFIG_ option diddling.
- Fix up the find_isa_irq_pin() oops on reboot for x86-64 too. 

* Mon Oct 11 2004 Dave Jones <davej@redhat.com>
- Rebase to 2.6.9-rc4
- Enable CONFIG_MICROCODE for x86-64

* Fri Oct  8 2004 Dave Jones <davej@redhat.com>
- Rebase to 2.6.9-rc3-bk8

* Thu Oct  7 2004 Dave Jones <davej@redhat.com>
- Rebase to 2.6.9-rc3-bk7
- Fix up PPC/PPC64 compilation failures due to new binutils. (David Woodhouse)

* Wed Oct  6 2004 Dave Jones <davej@redhat.com>
- Rebase to 2.6.9-rc3-bk6
- Add xattr support for tmpfs.

* Mon Oct  4 2004 Stephen C. Tweedie <sct@redhat.com>
- Update ext3 online resize to 2.6.9-rc3-mm2 upstream
- Reenable ext3 online resize in .spec

* Tue Sep 28 2004 Jeremy Katz <katzj@redhat.com>
- add patch from Roland McGrath/James Morris to fix mprotect hook bug (#133505)

* Mon Sep 20 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.9-rc2-bk5

* Thu Sep 16 2004 Arjan van de Ven <arjanv@redhat.com>
- fix tux for x86-64 and ppc64

* Tue Sep 14 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.9-rc2
- add diskdump

* Fri Sep 10 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.9-rc1-bk17 ; make ppc32 build

* Tue Sep 07 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.9-rc1-bk13

* Mon Sep 06 2004 Arjan van de Ven <arjanv@redhat.com>
- disable online resize again
- hopefully fix Quake3 interaction with execshield
- add Alan's borken-bios-IRQ workaround patch

* Sat Sep 04 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.9-rc1-bk11

* Tue Aug 31 2004 Arjan van de Ven <arjanv@redhat.com>
- fix execshield buglet with legacy binaries
- 2.6.9-rc1-bk7

* Mon Aug 30 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.9-rc1-bk6

* Sat Aug 28 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.9-rc1-bk4, now with i915 DRM driver

* Fri Aug 27 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.9-rc1-bk2 

* Mon Aug 23 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.8.1-bk2

* Sat Aug 21 2004 Arjan van de Ven <arjanv@redhat.com>
- attempt to fix early-udev bug

* Fri Aug 13 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.8-rc4-bk3
- split execshield up some more

* Fri Aug 13 2004 Dave Jones <davej@redhat.com>
- Update SCSI whitelist again with some more card readers.

* Mon Aug 9 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.8-rc3-bk3

* Wed Aug 4 2004 Arjan van de Ven <arjanv@redhat.com>
- Add the flex-mmap bits for s390/s390x (Pete Zaitcev)
- Add flex-mmap for x86-64 32 bit emulation
- 2.6.8-rc3

* Mon Aug 2 2004 Arjan van de Ven <arjanv@redhat.com>
- Add Rik's token trashing control patch

* Sun Aug 1 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.8-rc2-bk11

* Fri Jul 30 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.8-rc2-bk8

* Wed Jul 28 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.8-rc2-bk6
- make a start at splitting up the execshield patchkit

* Fri Jul 16 2004 Arjan van de Ven <arjanv@redhat.com>
- ppc32 embedded updates

* Thu Jul 15 2004 Arjan van de Ven <arjanv@redhat.com>
- make USB modules again and add Alan's real fix for the SMM-meets-USB bug
- 2.6.8-rc1-bk4

* Wed Jul 14 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.8-rc1-bk3

* Tue Jul 13 2004 Arjan van de Ven <arjanv@redhat.com>
- add "enforcemodulesig" boot option to make the kernel load signed modules only

* Mon Jul 12 2004 Arjan van de Ven <arjanv@redhat.com>
- updated voluntary preempt
- 2.6.8-rc1

* Wed Jul 7 2004 Arjan van de Ven <arjanv@redhat.com>
- fix boot breakage that was hitting lots of people (Dave Jones)

* Tue Jul 6 2004 Arjan van de Ven <arjanv@redhat.com>
- add voluntary preemption patch from Ingo
- 2.6.7-bk19

* Tue Jun 29 2004 Arjan van de Ven <arjanv@redhat.com>
- make a start at gpg signed modules support

* Sat Jun 27 2004 Arjan van de Ven <arjanv@redhat.com>
- experiment with making the hardlink call in post more efficient
- 2.6.7-bk9

* Thu Jun 24 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.7-bk7
- Add wli's patch to allocate memory bottom up not top down
- change some config options in the kernel-sourcecode package that are
  good for rpm kernel builds but not for custom user builds to more appropriate 
  default values.
- reenable kernel-sourcecode again for a few builds 

* Wed Jun 23 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.7-bk5
- fix tux unresolved symbols (#126532)

* Mon Jun 21 2004 Arjan van de Ven <arjanv@redhat.com>
- make kernel-doc and kernel-sourcecode builds independent of eachother
- disable kernel-sourcecode builds entirely, we'll be replacing it with documentation
  on how to use the src.rpm instead for building your own kernel.

* Sat Jun 19 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.7-bk2

* Sun Jun 13 2004 Arjan van de Ven <arjanv@redhat.com>
- add patch from DaveM to fix the ppp-keeps-iface-busy bug

* Sat Jun 12 2004 Arjan van de Ven <arjanv@redhat.com>
- add fix from Andi Kleen/Linus for the fpu-DoS

* Thu Jun 10 2004 Arjan van de Ven <arjanv@redhat.com>
- disable mlock-uses-rlimit patch, it has a security hole and needs more thought
- revert airo driver to the FC2 one since the new one breaks

* Tue Jun 8 2004 Dave Jones <davej@redhat.com>
- Update to 2.6.7rc3

* Fri Jun 4 2004 Arjan van de Ven <arjanv@redhat.com>
- fix the mlock-uses-rlimit patch

* Wed Jun 2 2004 David Woodhouse <dwmw2@redhat.com>
- Add ppc64 (Mac G5)

* Wed Jun 2 2004 Arjan van de Ven <arjanv@redhat.com>
- add a forward port of the mlock-uses-rlimit patch
- add NX support for x86 (Intel, Ingo)

* Tue Jun 1 2004 Arjan van de Ven <arjanv@redhat.com>
- refresh ext3 reservation patch

* Sun May 30 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.7-rc2
- set the ACPI OS name to "Microsoft Windows XP" for better compatibility

* Thu May 27 2004 Pete Zaitcev <zaitcev@redhat.com>
- Fix qeth and zfcp (s390 drivers): align qib by 256, embedded into qdio_irq.

* Thu May 27 2004 Dave Jones <davej@redhat.com>
- Fix the crashes on boot on Asus P4P800 boards. (#121819)

* Wed May 26 2004 Dave Jones <davej@redhat.com>
- Lots more updates to the SCSI whitelist for various
  USB card readers. (#112778, among others..)

* Wed May 26 2004 Arjan van de Ven <arjanv@redhat.com>
- back out ehci suspend/resume patch, it breaks
- add fix for 3c59x-meets-kudzu bug from Alan

* Tue May 25 2004 Arjan van de Ven <arjanv@redhat.com>
- try improving suspend/resume by restoring more PCI state
- 2.6.7-rc1-bk1

* Mon May 24 2004 Dave Jones <davej@redhat.com>
- Add yet another multi-card reader to the whitelist (#85851)

* Sun May 23 2004 Dave Jones <davej@redhat.com>
- Add another multi-card reader to the whitelist (#124048)

* Wed May 19 2004 Arjan van de Ven <arjanv@redhat.com>
- put firewire race fix in (datacorruptor)

* Tue May 18 2004 Dave Jones <davej@redhat.com>
- Fix typo in ibmtr driver preventing compile (#123391)

* Mon May 17 2004 Arjan van de Ven <arjanv@redhat.com>
- update to 2.6.6-bk3
- made kernel-source and kernel-doc noarch.rpm's since they are not
  architecture specific.

* Sat May 08 2004 Arjan van de Ven <arjanv@redhat.com>
- fix non-booting on Transmeta cpus (Peter Anvin)
- fix count leak in message queues

* Fri May 07 2004 Arjan van de Ven <arjanv@redhat.com>
- more ide cache flush work
- patch from scsi-bk to fix sd refcounting

* Thu May 06 2004 Arjan van de Ven <arjanv@redhat.com>
- some more ide cache flush fixes 

* Wed May 05 2004 Arjan van de Ven <arjanv@redhat.com>
- fix bug 122504
- convert b44 to ethtool ops (jgarzik)
- make IDE do a cache-flush on shutdown (me/Alan)

* Tue May 04 2004 Arjan van de Ven <arjanv@redhat.com>
- work around i810/i830 DRM issue

* Fri Apr 30 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.6-rc3-bk1
- make amd64 boot again
- fix vm86-vs-4g4g interaction (Ingo)

* Thu Apr 22 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.6-rc2
 
* Tue Apr 20 2004 Arjan van de Ven <arjanv@redhat.com>
- add the ext3 online resize patch

* Mon Apr 19 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.6-rc1-bk3
- add the objrmap vm from the -mm tree; it needs testing

* Thu Apr 15 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.5-bk2
- disable DISCONTIGMEM on ia64 for performance
- fix sleep_on use in reiserfs (Chris Mason)

* Tue Apr 13 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.5-mc4
- reenable sg driver for scsi tape changers and such
- the sk98lin driver oopses on module unload, preven that

* Mon Apr 12 2004 Arjan van de Ven <arjanv@redhat.com>
- fix "bad pmd" bug with patch from Ingo

* Fri Apr 09 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.5-mc3
- finish up the -mc2 merge
- latest 4g/4g patch from Ingo
- latest execshield patch from Ingo
- fix a few framebuffer bugs

* Thu Apr 08 2004 Arjan van de Ven <arjanv@redhat.com>
- first attempt at a 2.6.5-mc2 merge

* Thu Apr 08 2004 Dave Jones <davej@redhat.com>
- Add in missing SiS AGP fix.

* Tue Apr 06 2004 Dave Jones <davej@redhat.com>
- More agpgart fixes.

* Fri Apr 02 2004 Arjan van de Ven <arjanv@redhat.com>
- fix another 4g/4g-vs-resume bug

* Tue Mar 30 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.5-rc3
- fix PCI posting bug in i830 DRM

* Mon Mar 29 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.5-rc2-bk8

* Mon Mar 29 2004 Dave Jones <davej@redhat.com>
- Include latest agpgart fixes.

* Thu Mar 25 2004 Arjan van de Ven <arjanv@redhat.com>
- more DRM fixes
- add the fsync patches from akpm

* Tue Mar 23 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.5-rc2-bk3
- fix direct userspace memory access in i830 drm driver

* Mon Mar 22 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.5-rc2-bk2
- some stackbloat reductions from Dave and me

* Sat Mar 20 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.5-rc2

* Tue Mar 16 2004 Dave Jones <davej@redhat.com>
- 2.6.5-rc1

* Mon Mar 15 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.4-bk3
- fix oops in toshiba_acpi (Barry K. Nathan)

* Sat Mar 13 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.4-bk2 merge 

* Thu Mar 11 2004 Arjan van de Ven <arjanv@redhat.com>
- renable sonypi driver that was off accidentally
- 2.6.4-final 
- fix the oops on alsa module unloads

* Wed Mar 10 2004 Arjan van de Ven <arjanv@redhat.com>
- add ppc64/iseries, ppc32 (powermac/ibook) and ia64 architectures
- 2.6.4-rc3 

* Tue Mar 09 2004 Arjan van de Ven <arjanv@redhat.com>
- 2.6.4-rc2-bk5
- fix nfs-vs-selinux issue
- fix typo in URL as per #117849

* Mon Mar 08 2004 Arjan van de Ven <arjanv@redhat.com>
- fix race in lp.c (#117710)
- 2.6.4-rc2-bk3
- attempt to fix S3 suspend-to-ram with 4g/4g split

* Sat Mar 06 2004 Arjan van de Ven <arjanv@redhat.com>
- fix reiserfs
- set HZ to 1000 again for some tests

* Wed Feb 25 2004 Arjan van de Ven <arjanv@redhat.com>
- merge back a bunch of fedora fixes
- disable audit

* Tue Feb 24 2004 Arjan van de Ven <arjanv@redhat.com>
- audit bugfixes
- update tux to a working version
- 2.6.3-bk5 merge

* Fri Feb 20 2004 Arjan van de Ven <arjanv@redhat.com>
- re-add and enable the Auditing patch
- switch several cpufreq modules to built in since detecting in userspace
  which to use is unpleasant

* Thu Jul 03 2003 Arjan van de Ven <arjanv@redhat.com>
- 2.6 start

