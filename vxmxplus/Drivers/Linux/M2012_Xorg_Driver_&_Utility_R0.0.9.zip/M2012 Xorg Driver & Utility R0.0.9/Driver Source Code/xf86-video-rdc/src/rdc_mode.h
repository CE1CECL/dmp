/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 


typedef struct {
    UCHAR   MISC;
    UCHAR   SEQ[4];
    UCHAR   CRTC[25];
    UCHAR   AReg[20];
    UCHAR   GReg[9];
    
} VBIOS_STDTABLE_STRUCT, *PVBIOS_STDTABLE_STRUCT;

typedef struct {
    UCHAR   ucNS;
    UCHAR   ucMS;
    UCHAR   ucRS;
} VBIOS_DCLK_INFO, *PVBIOS_DCLK_INFO;

typedef struct _RRateInfo{
    float fRefreshRate;
    Bool  BInterlaced;
    UCHAR ucRRateIndex;
}RRateInfo;

typedef struct _MODE_PRIVATE
{
    USHORT  Mode_ID_8bpp;
    USHORT  Mode_ID_16bpp;
    USHORT  Mode_ID_32bpp;
    UCHAR   ucRRate_ID;
} MODE_PRIVATE;


