! GAPFile Version 3.0
GAPFile Version 3.0
Units: Mills
*CAP_LIBRARY 
*END_CAP_LIBRARY

*APERTURES2 259
10  Rectangle Sq w:102.00 h:75.00 a:0.0
11  Rectangle Sq w:75.00 h:102.00 a:0.0
12  Rectangle Sq w:108.00 h:81.00 a:0.0
13  Rectangle Sq w:81.00 h:108.00 a:0.0
14  Rectangle Sq w:210.00 h:80.00 a:0.0
15  Rectangle Sq w:80.00 h:210.00 a:0.0
16  Rectangle Sq w:216.00 h:86.00 a:0.0
17  Rectangle Sq w:86.00 h:216.00 a:0.0
18  Round d:28.00
19  Thermal Simple od:10.00 id:7.50 sa:45 a:0.0
20  Round d:22.00
21  Round d:20.00
22  Round d:30.00
23  Round d:24.00
24  Round d:46.00
25  Round d:50.00
26  Round d:200.00
27  Thermal Simple od:200.00 id:150.00 sa:45 a:0.0
28  Round d:157.00
29  Round d:167.00
30  Rectangle Sq w:100.00 h:60.00 a:0.0
31  Rectangle Sq w:60.00 h:100.00 a:0.0
32  Rectangle Sq w:106.00 h:66.00 a:0.0
33  Rectangle Sq w:66.00 h:106.00 a:0.0
34  Rectangle Sq w:20.00 h:50.00 a:0.0
35  Rectangle Sq w:50.00 h:20.00 a:0.0
36  Rectangle Sq w:26.00 h:56.00 a:0.0
37  Rectangle Sq w:56.00 h:26.00 a:0.0
38  Rectangle Sq w:20.00 h:90.00 a:0.0
39  Rectangle Sq w:90.00 h:20.00 a:0.0
40  Rectangle Sq w:26.00 h:96.00 a:0.0
41  Rectangle Sq w:96.00 h:26.00 a:0.0
42  Round d:113.00
43  Thermal Simple od:113.00 id:84.75 sa:45 a:0.0
44  Round d:73.00
45  Round d:79.00
46  Round d:197.00
47  Round d:121.00
48  Thermal Simple od:121.00 id:90.75 sa:45 a:0.0
49  Round d:203.00
50  Round d:118.00
51  Round d:40.00
52  Round d:80.00
53  Round d:48.00
54  Thermal Simple od:48.00 id:36.00 sa:45 a:0.0
55  Round d:34.00
56  Rectangle Sq w:55.00 h:90.00 a:0.0
57  Rectangle Sq w:90.00 h:55.00 a:0.0
58  Rectangle Sq w:61.00 h:96.00 a:0.0
59  Rectangle Sq w:96.00 h:61.00 a:0.0
60  Rectangle Sq w:70.00 h:80.00 a:0.0
61  Rectangle Sq w:80.00 h:70.00 a:0.0
62  Rectangle Sq w:76.00 h:86.00 a:0.0
63  Rectangle Sq w:86.00 h:76.00 a:0.0
64  Rectangle Sq w:50.00 h:70.00 a:0.0
65  Rectangle Sq w:70.00 h:50.00 a:0.0
66  Rectangle Sq w:56.00 h:76.00 a:0.0
67  Rectangle Sq w:76.00 h:56.00 a:0.0
68  Round d:120.00
69  Thermal Simple od:120.00 id:90.00 sa:45 a:0.0
70  Round d:100.00
71  Round d:110.00
72  Square s:100.00 a:0.0
73  Round d:85.00
74  Thermal Simple od:85.00 id:63.75 sa:45 a:0.0
75  Round d:65.00
76  Round d:75.00
77  Square s:65.00 a:0.0
78  Square s:71.00 a:0.0
79  Rectangle Sq w:177.00 h:60.00 a:0.0
80  Rectangle Sq w:60.00 h:177.00 a:0.0
81  Rectangle Sq w:183.00 h:66.00 a:0.0
82  Rectangle Sq w:66.00 h:183.00 a:0.0
83  Rectangle Sq w:71.00 h:80.00 a:0.0
84  Rectangle Sq w:80.00 h:71.00 a:0.0
85  Rectangle Sq w:77.00 h:86.00 a:0.0
86  Rectangle Sq w:86.00 h:77.00 a:0.0
87  Rectangle Sq w:36.00 h:36.00 a:0.0
88  Rectangle Sq w:42.00 h:42.00 a:0.0
89  Rectangle Sq w:118.00 h:47.00 a:0.0
90  Rectangle Sq w:47.00 h:118.00 a:0.0
91  Rectangle Sq w:124.00 h:53.00 a:0.0
92  Rectangle Sq w:53.00 h:124.00 a:0.0
93  Rectangle Sq w:50.00 h:50.00 a:0.0
94  Rectangle Sq w:56.00 h:56.00 a:0.0
95  Thermal Simple od:75.00 id:56.25 sa:45 a:0.0
96  Round d:55.00
97  Round d:61.00
98  Rectangle Sq w:55.00 h:70.00 a:0.0
99  Rectangle Sq w:70.00 h:55.00 a:0.0
100  Rectangle Sq w:61.00 h:76.00 a:0.0
101  Rectangle Sq w:76.00 h:61.00 a:0.0
102  Rectangle Sq w:43.00 h:71.00 a:0.0
103  Rectangle Sq w:71.00 h:43.00 a:0.0
104  Rectangle Sq w:49.00 h:77.00 a:0.0
105  Rectangle Sq w:77.00 h:49.00 a:0.0
106  Rectangle Sq w:292.00 h:260.00 a:0.0
107  Square s:52.00 a:0.0
108  Square s:58.00 a:0.0
109  Rectangle Sq w:40.00 h:50.00 a:0.0
110  Rectangle Sq w:50.00 h:40.00 a:0.0
111  Rectangle Sq w:46.00 h:56.00 a:0.0
112  Rectangle Sq w:56.00 h:46.00 a:0.0
113  Rectangle Sq w:63.00 h:51.00 a:0.0
114  Rectangle Sq w:51.00 h:63.00 a:0.0
115  Rectangle Sq w:69.00 h:57.00 a:0.0
116  Rectangle Sq w:57.00 h:69.00 a:0.0
117  Rectangle Sq w:14.00 h:44.00 a:0.0
118  Rectangle Sq w:44.00 h:14.00 a:0.0
119  Round d:90.00
120  Thermal Simple od:90.00 id:67.50 sa:45 a:0.0
121  Square s:70.00 a:0.0
122  Round d:70.00
123  Square s:90.00 a:0.0
124  Square s:80.00 a:0.0
125  Rectangle Sq w:180.00 h:120.00 a:0.0
126  Rectangle Sq w:120.00 h:180.00 a:0.0
127  Thermal Simple od:130.00 id:97.50 sa:45 a:0.0
128  Rectangle Sq w:160.00 h:100.00 a:0.0
129  Rectangle Sq w:100.00 h:160.00 a:0.0
130  Rectangle Sq w:166.00 h:106.00 a:0.0
131  Rectangle Sq w:106.00 h:166.00 a:0.0
132  Round d:180.00
133  Thermal Simple od:180.00 id:135.00 sa:45 a:0.0
134  Rectangle Sq w:160.00 h:65.00 a:0.0
135  Rectangle Sq w:65.00 h:160.00 a:0.0
136  Rectangle Sq w:166.00 h:71.00 a:0.0
137  Rectangle Sq w:71.00 h:166.00 a:0.0
138  Rectangle Sq w:27.00 h:40.00 a:0.0
139  Rectangle Sq w:40.00 h:27.00 a:0.0
140  Rectangle Sq w:33.00 h:46.00 a:0.0
141  Rectangle Sq w:46.00 h:33.00 a:0.0
142  Round d:140.00
143  Thermal Simple od:140.00 id:105.00 sa:45 a:0.0
144  Round d:125.00
145  Round d:131.00
146  Rectangle Sq w:83.00 h:118.00 a:0.0
147  Rectangle Sq w:118.00 h:83.00 a:0.0
148  Rectangle Sq w:89.00 h:124.00 a:0.0
149  Rectangle Sq w:124.00 h:89.00 a:0.0
150  Rectangle Sq w:32.00 h:80.00 a:0.0
151  Rectangle Sq w:80.00 h:32.00 a:0.0
152  Rectangle Sq w:38.00 h:86.00 a:0.0
153  Rectangle Sq w:86.00 h:38.00 a:0.0
154  Rectangle Sq w:20.00 h:45.00 a:0.0
155  Rectangle Sq w:45.00 h:20.00 a:0.0
156  Rectangle Sq w:26.00 h:51.00 a:0.0
157  Rectangle Sq w:51.00 h:26.00 a:0.0
158  Thermal Simple od:55.00 id:41.25 sa:45 a:0.0
159  Round d:35.00
160  Round d:45.00
161  Rectangle Sq w:40.00 h:32.00 a:0.0
162  Rectangle Sq w:32.00 h:40.00 a:0.0
163  Rectangle Sq w:46.00 h:38.00 a:0.0
164  Rectangle Sq w:38.00 h:46.00 a:0.0
165  Rectangle Sq w:27.00 h:60.00 a:0.0
166  Rectangle Sq w:60.00 h:27.00 a:0.0
167  Rectangle Sq w:33.00 h:66.00 a:0.0
168  Rectangle Sq w:66.00 h:33.00 a:0.0
169  Rectangle Sq w:24.00 h:75.00 a:0.0
170  Rectangle Sq w:75.00 h:24.00 a:0.0
171  Rectangle Sq w:30.00 h:81.00 a:0.0
172  Rectangle Sq w:81.00 h:30.00 a:0.0
173  Thermal Simple od:197.00 id:147.75 sa:45 a:0.0
174  Round d:177.00
175  Round d:183.00
176  Round d:78.00
177  Thermal Simple od:78.00 id:58.50 sa:45 a:0.0
178  Round d:58.00
179  Round d:126.00
180  Thermal Simple od:80.00 id:60.00 sa:45 a:0.0
181  Square s:60.00 a:0.0
182  Round d:60.00
183  Round d:66.00
184  Round d:145.00
185  Thermal Simple od:145.00 id:108.75 sa:45 a:0.0
186  Thermal Simple od:131.00 id:98.25 sa:45 a:0.0
187  Round d:91.00
188  Round d:97.00
189  Thermal Simple od:110.00 id:82.50 sa:45 a:0.0
190  Rectangle Sq w:14.00 h:80.00 a:0.0
191  Rectangle Sq w:80.00 h:14.00 a:0.0
192  Rectangle Sq w:20.00 h:86.00 a:0.0
193  Rectangle Sq w:86.00 h:20.00 a:0.0
194  Round d:160.00
195  Thermal Simple od:160.00 id:120.00 sa:45 a:0.0
196  Round d:146.00
197  Round d:64.00
198  Square s:55.00 a:0.0
199  Rectangle Sq w:12.00 h:50.00 a:0.0
200  Rectangle Sq w:50.00 h:12.00 a:0.0
201  Rectangle Sq w:18.00 h:56.00 a:0.0
202  Rectangle Sq w:56.00 h:18.00 a:0.0
203  Rectangle Sq w:71.00 h:60.00 a:0.0
204  Rectangle Sq w:60.00 h:71.00 a:0.0
205  Rectangle Sq w:77.00 h:66.00 a:0.0
206  Rectangle Sq w:66.00 h:77.00 a:0.0
207  Round d:148.00
208  Thermal Simple od:148.00 id:111.00 sa:45 a:0.0
209  Round d:128.00
210  Thermal Simple od:70.00 id:52.50 sa:45 a:0.0
211  Square s:50.00 a:0.0
212  Round d:56.00
213  Rectangle Sq w:72.00 h:20.00 a:0.0
214  Rectangle Sq w:20.00 h:72.00 a:0.0
215  Rectangle Sq w:78.00 h:26.00 a:0.0
216  Rectangle Sq w:26.00 h:78.00 a:0.0
217  Rectangle Sq w:72.00 h:12.00 a:0.0
218  Rectangle Sq w:12.00 h:72.00 a:0.0
219  Rectangle Sq w:78.00 h:18.00 a:0.0
220  Rectangle Sq w:18.00 h:78.00 a:0.0
221  Round d:16.00
222  Rectangle Sq w:10.00 h:70.00 a:0.0
223  Rectangle Sq w:70.00 h:10.00 a:0.0
224  Rectangle Sq w:16.00 h:76.00 a:0.0
225  Rectangle Sq w:76.00 h:16.00 a:0.0
226  Square s:51.00 a:0.0
227  Round d:51.00
228  Square s:57.00 a:0.0
229  Round d:57.00
230  Rectangle Sq w:20.00 h:80.00 a:0.0
231  Rectangle Sq w:80.00 h:20.00 a:0.0
232  Rectangle Sq w:26.00 h:86.00 a:0.0
233  Rectangle Sq w:86.00 h:26.00 a:0.0
234  Rectangle Sq w:110.00 h:200.00 a:0.0
235  Rectangle Sq w:200.00 h:110.00 a:0.0
236  Rectangle Sq w:116.00 h:206.00 a:0.0
237  Rectangle Sq w:206.00 h:116.00 a:0.0
238  Round d:103.00
239  Thermal Simple od:103.00 id:77.25 sa:45 a:0.0
240  Round d:63.00
241  Round d:69.00
242  Round d:74.00
243  Thermal Simple od:74.00 id:55.50 sa:45 a:0.0
244  Round d:43.00
245  Round d:49.00
246  Round d:18.00
247  Round d:6.00
248  Round d:8.00
249  Round d:10.00
250  Round d:16.00
251  Round d:18.00
252  Round d:5.00
253  Round d:4.00
254  Round d:25.00
255  Round d:20.00
256  Round d:30.00
257  Round d:12.00
258  Round d:4.02
259  Round d:12.01
260  Round d:5.98
261  Round d:11.81
262  Round d:7.87
263  Round d:15.00
264  Round d:24.00
265  Round d:5.50
266  Round d:14.00
267  Round d:2.75
268  Round d:2.00
*END_APERTURES


