-:  include/linux/autoconf.h \
 /root/linux-2.6.32/arch/x86/include/asm/types.h \
 /root/linux-2.6.32/include/asm-generic/types.h \
 /root/linux-2.6.32/include/asm-generic/int-ll64.h \
 /root/linux-2.6.32/arch/x86/include/asm/bitsperlong.h \
 /root/linux-2.6.32/include/asm-generic/bitsperlong.h \
 /root/linux-2.6.32/arch/x86/include/asm/unistd.h \
 /root/linux-2.6.32/arch/x86/include/asm/unistd_32.h
