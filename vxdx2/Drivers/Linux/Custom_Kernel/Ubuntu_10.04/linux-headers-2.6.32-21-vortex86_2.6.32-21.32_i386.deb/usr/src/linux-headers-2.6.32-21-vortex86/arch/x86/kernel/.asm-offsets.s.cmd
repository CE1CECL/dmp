cmd_arch/x86/kernel/asm-offsets.s := gcc -Wp,-MD,arch/x86/kernel/.asm-offsets.s.d  -nostdinc -isystem /usr/lib/gcc/i486-linux-gnu/4.4.3/include -I/usr/src/linux-headers-lbm- -Iinclude -Iinclude2 -I/root/linux-2.6.32/include -I/root/linux-2.6.32/arch/x86/include -include include/linux/autoconf.h -Iubuntu/include -I/root/linux-2.6.32/ubuntu/include  -I/root/linux-2.6.32/. -I. -D__KERNEL__ -Wall -Wundef -Wstrict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -Werror-implicit-function-declaration -Wno-format-security -fno-delete-null-pointer-checks -O2 -m32 -msoft-float -mregparm=3 -freg-struct-return -mpreferred-stack-boundary=2 -march=i486 -maccumulate-outgoing-args -Wa,-mtune=generic32 -ffreestanding -fstack-protector -DCONFIG_AS_CFI=1 -DCONFIG_AS_CFI_SIGNAL_FRAME=1 -pipe -Wno-sign-compare -fno-asynchronous-unwind-tables -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -Wframe-larger-than=1024 -fno-omit-frame-pointer -fno-optimize-sibling-calls -pg -fno-inline-functions-called-once -Wdeclaration-after-statement -Wno-pointer-sign -fno-strict-overflow -fno-dwarf2-cfi-asm -fconserve-stack   -D"KBUILD_STR(s)=\#s" -D"KBUILD_BASENAME=KBUILD_STR(asm_offsets)"  -D"KBUILD_MODNAME=KBUILD_STR(asm_offsets)"  -fverbose-asm -S -o arch/x86/kernel/asm-offsets.s /root/linux-2.6.32/arch/x86/kernel/asm-offsets.c

deps_arch/x86/kernel/asm-offsets.s := \
  /root/linux-2.6.32/arch/x86/kernel/asm-offsets.c \
    $(wildcard include/config/x86/32.h) \
  /root/linux-2.6.32/arch/x86/kernel/asm-offsets_32.c \
    $(wildcard include/config/paravirt.h) \
    $(wildcard include/config/xen.h) \
    $(wildcard include/config/lguest.h) \
    $(wildcard include/config/lguest/guest.h) \
  /root/linux-2.6.32/include/linux/crypto.h \
  /root/linux-2.6.32/arch/x86/include/asm/atomic.h \
  /root/linux-2.6.32/arch/x86/include/asm/atomic_32.h \
    $(wildcard include/config/m386.h) \
  /root/linux-2.6.32/include/linux/compiler.h \
    $(wildcard include/config/trace/branch/profiling.h) \
    $(wildcard include/config/profile/all/branches.h) \
    $(wildcard include/config/enable/must/check.h) \
    $(wildcard include/config/enable/warn/deprecated.h) \
  /root/linux-2.6.32/include/linux/compiler-gcc.h \
    $(wildcard include/config/arch/supports/optimized/inlining.h) \
    $(wildcard include/config/optimize/inlining.h) \
  /root/linux-2.6.32/include/linux/compiler-gcc4.h \
  /root/linux-2.6.32/include/linux/types.h \
    $(wildcard include/config/uid16.h) \
    $(wildcard include/config/lbdaf.h) \
    $(wildcard include/config/phys/addr/t/64bit.h) \
    $(wildcard include/config/64bit.h) \
  /root/linux-2.6.32/arch/x86/include/asm/types.h \
    $(wildcard include/config/x86/64.h) \
    $(wildcard include/config/highmem64g.h) \
  /root/linux-2.6.32/include/asm-generic/types.h \
  /root/linux-2.6.32/include/asm-generic/int-ll64.h \
  /root/linux-2.6.32/arch/x86/include/asm/bitsperlong.h \
  /root/linux-2.6.32/include/asm-generic/bitsperlong.h \
  /root/linux-2.6.32/include/linux/posix_types.h \
  /root/linux-2.6.32/include/linux/stddef.h \
  /root/linux-2.6.32/arch/x86/include/asm/posix_types.h \
  /root/linux-2.6.32/arch/x86/include/asm/posix_types_32.h \
  /root/linux-2.6.32/arch/x86/include/asm/processor.h \
    $(wildcard include/config/x86/vsmp.h) \
    $(wildcard include/config/smp.h) \
    $(wildcard include/config/cc/stackprotector.h) \
    $(wildcard include/config/m486.h) \
    $(wildcard include/config/x86/debugctlmsr.h) \
  /root/linux-2.6.32/arch/x86/include/asm/processor-flags.h \
    $(wildcard include/config/vm86.h) \
  /root/linux-2.6.32/arch/x86/include/asm/vm86.h \
  /root/linux-2.6.32/arch/x86/include/asm/ptrace.h \
    $(wildcard include/config/x86/ptrace/bts.h) \
  /root/linux-2.6.32/arch/x86/include/asm/ptrace-abi.h \
  /root/linux-2.6.32/arch/x86/include/asm/segment.h \
  /root/linux-2.6.32/include/linux/init.h \
    $(wildcard include/config/modules.h) \
    $(wildcard include/config/hotplug.h) \
  /root/linux-2.6.32/arch/x86/include/asm/math_emu.h \
  /root/linux-2.6.32/arch/x86/include/asm/sigcontext.h \
  /root/linux-2.6.32/arch/x86/include/asm/current.h \
  /root/linux-2.6.32/arch/x86/include/asm/percpu.h \
    $(wildcard include/config/x86/64/smp.h) \
  /root/linux-2.6.32/include/linux/kernel.h \
    $(wildcard include/config/preempt/voluntary.h) \
    $(wildcard include/config/debug/spinlock/sleep.h) \
    $(wildcard include/config/prove/locking.h) \
    $(wildcard include/config/printk.h) \
    $(wildcard include/config/dynamic/debug.h) \
    $(wildcard include/config/ring/buffer.h) \
    $(wildcard include/config/tracing.h) \
    $(wildcard include/config/numa.h) \
    $(wildcard include/config/ftrace/mcount/record.h) \
  /usr/lib/gcc/i486-linux-gnu/4.4.3/include/stdarg.h \
  /root/linux-2.6.32/include/linux/linkage.h \
  /root/linux-2.6.32/arch/x86/include/asm/linkage.h \
    $(wildcard include/config/x86/alignment/16.h) \
  /root/linux-2.6.32/include/linux/stringify.h \
  /root/linux-2.6.32/include/linux/bitops.h \
    $(wildcard include/config/generic/find/first/bit.h) \
    $(wildcard include/config/generic/find/last/bit.h) \
    $(wildcard include/config/generic/find/next/bit.h) \
  /root/linux-2.6.32/arch/x86/include/asm/bitops.h \
    $(wildcard include/config/x86/cmov.h) \
  /root/linux-2.6.32/arch/x86/include/asm/alternative.h \
  /root/linux-2.6.32/arch/x86/include/asm/asm.h \
  /root/linux-2.6.32/arch/x86/include/asm/cpufeature.h \
    $(wildcard include/config/x86/invlpg.h) \
  /root/linux-2.6.32/arch/x86/include/asm/required-features.h \
    $(wildcard include/config/x86/minimum/cpu/family.h) \
    $(wildcard include/config/math/emulation.h) \
    $(wildcard include/config/x86/pae.h) \
    $(wildcard include/config/x86/cmpxchg64.h) \
    $(wildcard include/config/x86/use/3dnow.h) \
    $(wildcard include/config/x86/p6/nop.h) \
  /root/linux-2.6.32/include/asm-generic/bitops/sched.h \
  /root/linux-2.6.32/include/asm-generic/bitops/hweight.h \
  /root/linux-2.6.32/include/asm-generic/bitops/fls64.h \
  /root/linux-2.6.32/include/asm-generic/bitops/ext2-non-atomic.h \
  /root/linux-2.6.32/include/asm-generic/bitops/le.h \
  /root/linux-2.6.32/arch/x86/include/asm/byteorder.h \
  /root/linux-2.6.32/include/linux/byteorder/little_endian.h \
  /root/linux-2.6.32/include/linux/swab.h \
  /root/linux-2.6.32/arch/x86/include/asm/swab.h \
    $(wildcard include/config/x86/bswap.h) \
  /root/linux-2.6.32/include/linux/byteorder/generic.h \
  /root/linux-2.6.32/include/asm-generic/bitops/minix.h \
  /root/linux-2.6.32/include/linux/log2.h \
    $(wildcard include/config/arch/has/ilog2/u32.h) \
    $(wildcard include/config/arch/has/ilog2/u64.h) \
  /root/linux-2.6.32/include/linux/typecheck.h \
  /root/linux-2.6.32/include/linux/ratelimit.h \
  /root/linux-2.6.32/include/linux/param.h \
  /root/linux-2.6.32/arch/x86/include/asm/param.h \
  /root/linux-2.6.32/include/asm-generic/param.h \
    $(wildcard include/config/hz.h) \
  /root/linux-2.6.32/include/linux/dynamic_debug.h \
  /root/linux-2.6.32/arch/x86/include/asm/bug.h \
    $(wildcard include/config/bug.h) \
    $(wildcard include/config/debug/bugverbose.h) \
  /root/linux-2.6.32/include/asm-generic/bug.h \
    $(wildcard include/config/generic/bug.h) \
    $(wildcard include/config/generic/bug/relative/pointers.h) \
  /root/linux-2.6.32/arch/x86/include/asm/div64.h \
  /root/linux-2.6.32/include/asm-generic/percpu.h \
    $(wildcard include/config/debug/preempt.h) \
    $(wildcard include/config/have/setup/per/cpu/area.h) \
  /root/linux-2.6.32/include/linux/threads.h \
    $(wildcard include/config/nr/cpus.h) \
    $(wildcard include/config/base/small.h) \
  /root/linux-2.6.32/include/linux/percpu-defs.h \
    $(wildcard include/config/debug/force/weak/per/cpu.h) \
  /root/linux-2.6.32/arch/x86/include/asm/system.h \
    $(wildcard include/config/ia32/emulation.h) \
    $(wildcard include/config/x86/32/lazy/gs.h) \
    $(wildcard include/config/x86/ppro/fence.h) \
    $(wildcard include/config/x86/oostore.h) \
  /root/linux-2.6.32/arch/x86/include/asm/cmpxchg.h \
  /root/linux-2.6.32/arch/x86/include/asm/cmpxchg_32.h \
    $(wildcard include/config/x86/cmpxchg.h) \
  /root/linux-2.6.32/arch/x86/include/asm/nops.h \
    $(wildcard include/config/mk7.h) \
  /root/linux-2.6.32/include/linux/irqflags.h \
    $(wildcard include/config/trace/irqflags.h) \
    $(wildcard include/config/irqsoff/tracer.h) \
    $(wildcard include/config/preempt/tracer.h) \
    $(wildcard include/config/trace/irqflags/support.h) \
    $(wildcard include/config/x86.h) \
  /root/linux-2.6.32/arch/x86/include/asm/irqflags.h \
    $(wildcard include/config/debug/lock/alloc.h) \
  /root/linux-2.6.32/arch/x86/include/asm/paravirt.h \
    $(wildcard include/config/highpte.h) \
    $(wildcard include/config/paravirt/spinlocks.h) \
  /root/linux-2.6.32/arch/x86/include/asm/pgtable_types.h \
    $(wildcard include/config/kmemcheck.h) \
    $(wildcard include/config/compat/vdso.h) \
    $(wildcard include/config/proc/fs.h) \
  /root/linux-2.6.32/include/linux/const.h \
  /root/linux-2.6.32/arch/x86/include/asm/page_types.h \
  /root/linux-2.6.32/arch/x86/include/asm/page_32_types.h \
    $(wildcard include/config/highmem4g.h) \
    $(wildcard include/config/page/offset.h) \
    $(wildcard include/config/4kstacks.h) \
  /root/linux-2.6.32/arch/x86/include/asm/pgtable_32_types.h \
    $(wildcard include/config/highmem.h) \
  /root/linux-2.6.32/arch/x86/include/asm/pgtable-2level_types.h \
  /root/linux-2.6.32/include/asm-generic/pgtable-nopud.h \
  /root/linux-2.6.32/include/asm-generic/pgtable-nopmd.h \
  /root/linux-2.6.32/arch/x86/include/asm/paravirt_types.h \
    $(wildcard include/config/x86/local/apic.h) \
    $(wildcard include/config/paravirt/debug.h) \
  /root/linux-2.6.32/arch/x86/include/asm/desc_defs.h \
  /root/linux-2.6.32/arch/x86/include/asm/kmap_types.h \
    $(wildcard include/config/debug/highmem.h) \
  /root/linux-2.6.32/include/asm-generic/kmap_types.h \
  /root/linux-2.6.32/include/linux/cpumask.h \
    $(wildcard include/config/cpumask/offstack.h) \
    $(wildcard include/config/hotplug/cpu.h) \
    $(wildcard include/config/debug/per/cpu/maps.h) \
    $(wildcard include/config/disable/obsolete/cpumask/functions.h) \
  /root/linux-2.6.32/include/linux/bitmap.h \
  /root/linux-2.6.32/include/linux/string.h \
    $(wildcard include/config/binary/printf.h) \
  /root/linux-2.6.32/arch/x86/include/asm/string.h \
  /root/linux-2.6.32/arch/x86/include/asm/string_32.h \
  /root/linux-2.6.32/arch/x86/include/asm/page.h \
  /root/linux-2.6.32/arch/x86/include/asm/page_32.h \
    $(wildcard include/config/hugetlb/page.h) \
    $(wildcard include/config/debug/virtual.h) \
    $(wildcard include/config/flatmem.h) \
    $(wildcard include/config/x86/3dnow.h) \
  /root/linux-2.6.32/include/asm-generic/memory_model.h \
    $(wildcard include/config/discontigmem.h) \
    $(wildcard include/config/sparsemem/vmemmap.h) \
    $(wildcard include/config/sparsemem.h) \
  /root/linux-2.6.32/include/asm-generic/getorder.h \
  /root/linux-2.6.32/arch/x86/include/asm/msr.h \
  /root/linux-2.6.32/arch/x86/include/asm/msr-index.h \
  /root/linux-2.6.32/include/linux/ioctl.h \
  /root/linux-2.6.32/arch/x86/include/asm/ioctl.h \
  /root/linux-2.6.32/include/asm-generic/ioctl.h \
  /root/linux-2.6.32/arch/x86/include/asm/errno.h \
  /root/linux-2.6.32/include/asm-generic/errno.h \
  /root/linux-2.6.32/include/asm-generic/errno-base.h \
  /root/linux-2.6.32/arch/x86/include/asm/cpumask.h \
  /root/linux-2.6.32/arch/x86/include/asm/ds.h \
    $(wildcard include/config/x86/ds.h) \
  /root/linux-2.6.32/include/linux/err.h \
  /root/linux-2.6.32/include/linux/personality.h \
  /root/linux-2.6.32/include/linux/cache.h \
    $(wildcard include/config/arch/has/cache/line/size.h) \
  /root/linux-2.6.32/arch/x86/include/asm/cache.h \
    $(wildcard include/config/x86/l1/cache/shift.h) \
  /root/linux-2.6.32/include/linux/math64.h \
  /root/linux-2.6.32/include/asm-generic/atomic-long.h \
  /root/linux-2.6.32/include/linux/module.h \
    $(wildcard include/config/modversions.h) \
    $(wildcard include/config/unused/symbols.h) \
    $(wildcard include/config/kallsyms.h) \
    $(wildcard include/config/tracepoints.h) \
    $(wildcard include/config/event/tracing.h) \
    $(wildcard include/config/module/unload.h) \
    $(wildcard include/config/constructors.h) \
    $(wildcard include/config/sysfs.h) \
  /root/linux-2.6.32/include/linux/list.h \
    $(wildcard include/config/debug/list.h) \
  /root/linux-2.6.32/include/linux/poison.h \
  /root/linux-2.6.32/include/linux/prefetch.h \
  /root/linux-2.6.32/include/linux/stat.h \
  /root/linux-2.6.32/arch/x86/include/asm/stat.h \
  /root/linux-2.6.32/include/linux/time.h \
    $(wildcard include/config/arch/uses/gettimeoffset.h) \
  /root/linux-2.6.32/include/linux/seqlock.h \
  /root/linux-2.6.32/include/linux/spinlock.h \
    $(wildcard include/config/debug/spinlock.h) \
    $(wildcard include/config/generic/lockbreak.h) \
    $(wildcard include/config/preempt.h) \
  /root/linux-2.6.32/include/linux/preempt.h \
    $(wildcard include/config/preempt/notifiers.h) \
  /root/linux-2.6.32/include/linux/thread_info.h \
    $(wildcard include/config/compat.h) \
  /root/linux-2.6.32/arch/x86/include/asm/thread_info.h \
    $(wildcard include/config/debug/stack/usage.h) \
  /root/linux-2.6.32/arch/x86/include/asm/ftrace.h \
    $(wildcard include/config/function/tracer.h) \
    $(wildcard include/config/dynamic/ftrace.h) \
  /root/linux-2.6.32/include/linux/bottom_half.h \
  /root/linux-2.6.32/include/linux/spinlock_types.h \
  /root/linux-2.6.32/arch/x86/include/asm/spinlock_types.h \
  /root/linux-2.6.32/include/linux/lockdep.h \
    $(wildcard include/config/lockdep.h) \
    $(wildcard include/config/lock/stat.h) \
    $(wildcard include/config/generic/hardirqs.h) \
  /root/linux-2.6.32/arch/x86/include/asm/spinlock.h \
  /root/linux-2.6.32/arch/x86/include/asm/rwlock.h \
  /root/linux-2.6.32/include/linux/spinlock_api_smp.h \
  /root/linux-2.6.32/include/linux/kmod.h \
  /root/linux-2.6.32/include/linux/gfp.h \
    $(wildcard include/config/zone/dma.h) \
    $(wildcard include/config/zone/dma32.h) \
    $(wildcard include/config/debug/vm.h) \
  /root/linux-2.6.32/include/linux/mmzone.h \
    $(wildcard include/config/force/max/zoneorder.h) \
    $(wildcard include/config/memory/hotplug.h) \
    $(wildcard include/config/arch/populates/node/map.h) \
    $(wildcard include/config/flat/node/mem/map.h) \
    $(wildcard include/config/cgroup/mem/res/ctlr.h) \
    $(wildcard include/config/have/memory/present.h) \
    $(wildcard include/config/need/node/memmap/size.h) \
    $(wildcard include/config/need/multiple/nodes.h) \
    $(wildcard include/config/have/arch/early/pfn/to/nid.h) \
    $(wildcard include/config/sparsemem/extreme.h) \
    $(wildcard include/config/nodes/span/other/nodes.h) \
    $(wildcard include/config/holes/in/zone.h) \
    $(wildcard include/config/arch/has/holes/memorymodel.h) \
  /root/linux-2.6.32/include/linux/wait.h \
  /root/linux-2.6.32/include/linux/numa.h \
    $(wildcard include/config/nodes/shift.h) \
  /root/linux-2.6.32/include/linux/nodemask.h \
  /root/linux-2.6.32/include/linux/pageblock-flags.h \
    $(wildcard include/config/hugetlb/page/size/variable.h) \
  include/linux/bounds.h \
  /root/linux-2.6.32/include/linux/memory_hotplug.h \
    $(wildcard include/config/have/arch/nodedata/extension.h) \
    $(wildcard include/config/memory/hotremove.h) \
  /root/linux-2.6.32/include/linux/notifier.h \
  /root/linux-2.6.32/include/linux/errno.h \
  /root/linux-2.6.32/include/linux/mutex.h \
    $(wildcard include/config/debug/mutexes.h) \
  /root/linux-2.6.32/include/linux/rwsem.h \
    $(wildcard include/config/rwsem/generic/spinlock.h) \
  /root/linux-2.6.32/arch/x86/include/asm/rwsem.h \
  /root/linux-2.6.32/include/linux/srcu.h \
  /root/linux-2.6.32/include/linux/topology.h \
    $(wildcard include/config/sched/smt.h) \
    $(wildcard include/config/sched/mc.h) \
  /root/linux-2.6.32/include/linux/smp.h \
    $(wildcard include/config/use/generic/smp/helpers.h) \
  /root/linux-2.6.32/arch/x86/include/asm/smp.h \
    $(wildcard include/config/x86/io/apic.h) \
    $(wildcard include/config/x86/32/smp.h) \
  /root/linux-2.6.32/arch/x86/include/asm/mpspec.h \
    $(wildcard include/config/x86/numaq.h) \
    $(wildcard include/config/mca.h) \
    $(wildcard include/config/eisa.h) \
    $(wildcard include/config/x86/mpparse.h) \
    $(wildcard include/config/acpi.h) \
  /root/linux-2.6.32/arch/x86/include/asm/mpspec_def.h \
  /root/linux-2.6.32/arch/x86/include/asm/x86_init.h \
  /root/linux-2.6.32/arch/x86/include/asm/bootparam.h \
  /root/linux-2.6.32/include/linux/screen_info.h \
  /root/linux-2.6.32/include/linux/apm_bios.h \
  /root/linux-2.6.32/include/linux/edd.h \
  /root/linux-2.6.32/arch/x86/include/asm/e820.h \
    $(wildcard include/config/efi.h) \
    $(wildcard include/config/hibernation.h) \
    $(wildcard include/config/memtest.h) \
  /root/linux-2.6.32/include/linux/ioport.h \
  /root/linux-2.6.32/arch/x86/include/asm/ist.h \
  /root/linux-2.6.32/include/video/edid.h \
  /root/linux-2.6.32/arch/x86/include/asm/apic.h \
    $(wildcard include/config/x86/x2apic.h) \
  /root/linux-2.6.32/include/linux/delay.h \
  /root/linux-2.6.32/arch/x86/include/asm/delay.h \
  /root/linux-2.6.32/include/linux/pm.h \
    $(wildcard include/config/pm/sleep.h) \
    $(wildcard include/config/pm/runtime.h) \
  /root/linux-2.6.32/include/linux/workqueue.h \
  /root/linux-2.6.32/include/linux/timer.h \
    $(wildcard include/config/timer/stats.h) \
    $(wildcard include/config/debug/objects/timers.h) \
  /root/linux-2.6.32/include/linux/ktime.h \
    $(wildcard include/config/ktime/scalar.h) \
  /root/linux-2.6.32/include/linux/jiffies.h \
  /root/linux-2.6.32/include/linux/timex.h \
    $(wildcard include/config/no/hz.h) \
  /root/linux-2.6.32/arch/x86/include/asm/timex.h \
  /root/linux-2.6.32/arch/x86/include/asm/tsc.h \
    $(wildcard include/config/x86/tsc.h) \
  /root/linux-2.6.32/include/linux/debugobjects.h \
    $(wildcard include/config/debug/objects.h) \
    $(wildcard include/config/debug/objects/free.h) \
  /root/linux-2.6.32/arch/x86/include/asm/apicdef.h \
  /root/linux-2.6.32/arch/x86/include/asm/fixmap.h \
    $(wildcard include/config/provide/ohci1394/dma/init.h) \
    $(wildcard include/config/x86/visws/apic.h) \
    $(wildcard include/config/x86/f00f/bug.h) \
    $(wildcard include/config/x86/cyclone/timer.h) \
    $(wildcard include/config/pci/mmconfig.h) \
    $(wildcard include/config/intel/txt.h) \
  /root/linux-2.6.32/arch/x86/include/asm/acpi.h \
    $(wildcard include/config/acpi/numa.h) \
  /root/linux-2.6.32/include/acpi/pdc_intel.h \
  /root/linux-2.6.32/arch/x86/include/asm/numa.h \
  /root/linux-2.6.32/arch/x86/include/asm/numa_32.h \
  /root/linux-2.6.32/arch/x86/include/asm/mmu.h \
  /root/linux-2.6.32/arch/x86/include/asm/io_apic.h \
  /root/linux-2.6.32/arch/x86/include/asm/irq_vectors.h \
    $(wildcard include/config/sparse/irq.h) \
  /root/linux-2.6.32/arch/x86/include/asm/topology.h \
    $(wildcard include/config/x86/ht.h) \
    $(wildcard include/config/x86/64/acpi/numa.h) \
  /root/linux-2.6.32/include/asm-generic/topology.h \
  /root/linux-2.6.32/include/linux/mmdebug.h \
  /root/linux-2.6.32/include/linux/elf.h \
  /root/linux-2.6.32/include/linux/elf-em.h \
  /root/linux-2.6.32/arch/x86/include/asm/elf.h \
  /root/linux-2.6.32/arch/x86/include/asm/user.h \
  /root/linux-2.6.32/arch/x86/include/asm/user_32.h \
  /root/linux-2.6.32/arch/x86/include/asm/auxvec.h \
  /root/linux-2.6.32/arch/x86/include/asm/vdso.h \
  /root/linux-2.6.32/arch/x86/include/asm/desc.h \
  /root/linux-2.6.32/arch/x86/include/asm/ldt.h \
  /root/linux-2.6.32/include/linux/mm_types.h \
    $(wildcard include/config/split/ptlock/cpus.h) \
    $(wildcard include/config/want/page/debug/flags.h) \
    $(wildcard include/config/mmu.h) \
    $(wildcard include/config/aio.h) \
    $(wildcard include/config/mm/owner.h) \
    $(wildcard include/config/mmu/notifier.h) \
  /root/linux-2.6.32/include/linux/auxvec.h \
  /root/linux-2.6.32/include/linux/prio_tree.h \
  /root/linux-2.6.32/include/linux/rbtree.h \
  /root/linux-2.6.32/include/linux/completion.h \
  /root/linux-2.6.32/include/linux/page-debug-flags.h \
    $(wildcard include/config/page/poisoning.h) \
    $(wildcard include/config/page/debug/something/else.h) \
  /root/linux-2.6.32/include/linux/kobject.h \
  /root/linux-2.6.32/include/linux/sysfs.h \
  /root/linux-2.6.32/include/linux/kref.h \
  /root/linux-2.6.32/include/linux/moduleparam.h \
    $(wildcard include/config/alpha.h) \
    $(wildcard include/config/ia64.h) \
    $(wildcard include/config/ppc64.h) \
  /root/linux-2.6.32/include/linux/tracepoint.h \
  /root/linux-2.6.32/include/linux/rcupdate.h \
    $(wildcard include/config/tree/preempt/rcu.h) \
    $(wildcard include/config/tree/rcu.h) \
  /root/linux-2.6.32/include/linux/rcutree.h \
  /root/linux-2.6.32/arch/x86/include/asm/local.h \
  /root/linux-2.6.32/include/linux/percpu.h \
    $(wildcard include/config/have/legacy/per/cpu/area.h) \
    $(wildcard include/config/need/per/cpu/embed/first/chunk.h) \
    $(wildcard include/config/need/per/cpu/page/first/chunk.h) \
    $(wildcard include/config/debug/kmemleak.h) \
  /root/linux-2.6.32/include/linux/slab.h \
    $(wildcard include/config/slab/debug.h) \
    $(wildcard include/config/slub.h) \
    $(wildcard include/config/slob.h) \
    $(wildcard include/config/debug/slab.h) \
  /root/linux-2.6.32/include/linux/slub_def.h \
    $(wildcard include/config/slub/stats.h) \
    $(wildcard include/config/slub/debug.h) \
    $(wildcard include/config/kmemtrace.h) \
  /root/linux-2.6.32/include/linux/kmemtrace.h \
  /root/linux-2.6.32/include/trace/events/kmem.h \
  /root/linux-2.6.32/include/trace/define_trace.h \
  /root/linux-2.6.32/include/linux/kmemleak.h \
  /root/linux-2.6.32/include/linux/pfn.h \
  /root/linux-2.6.32/arch/x86/include/asm/module.h \
    $(wildcard include/config/m586.h) \
    $(wildcard include/config/m586tsc.h) \
    $(wildcard include/config/m586mmx.h) \
    $(wildcard include/config/mcore2.h) \
    $(wildcard include/config/matom.h) \
    $(wildcard include/config/m686.h) \
    $(wildcard include/config/mpentiumii.h) \
    $(wildcard include/config/mpentiumiii.h) \
    $(wildcard include/config/mpentiumm.h) \
    $(wildcard include/config/mpentium4.h) \
    $(wildcard include/config/mk6.h) \
    $(wildcard include/config/mk8.h) \
    $(wildcard include/config/x86/elan.h) \
    $(wildcard include/config/mcrusoe.h) \
    $(wildcard include/config/mefficeon.h) \
    $(wildcard include/config/mwinchipc6.h) \
    $(wildcard include/config/mwinchip3d.h) \
    $(wildcard include/config/mcyrixiii.h) \
    $(wildcard include/config/mviac3/2.h) \
    $(wildcard include/config/mviac7.h) \
    $(wildcard include/config/mgeodegx1.h) \
    $(wildcard include/config/mgeode/lx.h) \
  /root/linux-2.6.32/include/asm-generic/module.h \
  /root/linux-2.6.32/include/trace/events/module.h \
  /root/linux-2.6.32/include/linux/uaccess.h \
  /root/linux-2.6.32/arch/x86/include/asm/uaccess.h \
    $(wildcard include/config/x86/wp/works/ok.h) \
    $(wildcard include/config/x86/intel/usercopy.h) \
  /root/linux-2.6.32/arch/x86/include/asm/uaccess_32.h \
  /root/linux-2.6.32/include/linux/sched.h \
    $(wildcard include/config/sched/debug.h) \
    $(wildcard include/config/detect/softlockup.h) \
    $(wildcard include/config/detect/hung/task.h) \
    $(wildcard include/config/core/dump/default/elf/headers.h) \
    $(wildcard include/config/bsd/process/acct.h) \
    $(wildcard include/config/taskstats.h) \
    $(wildcard include/config/audit.h) \
    $(wildcard include/config/inotify/user.h) \
    $(wildcard include/config/epoll.h) \
    $(wildcard include/config/posix/mqueue.h) \
    $(wildcard include/config/keys.h) \
    $(wildcard include/config/user/sched.h) \
    $(wildcard include/config/perf/events.h) \
    $(wildcard include/config/schedstats.h) \
    $(wildcard include/config/task/delay/acct.h) \
    $(wildcard include/config/fair/group/sched.h) \
    $(wildcard include/config/rt/group/sched.h) \
    $(wildcard include/config/blk/dev/io/trace.h) \
    $(wildcard include/config/sysvipc.h) \
    $(wildcard include/config/auditsyscall.h) \
    $(wildcard include/config/rt/mutexes.h) \
    $(wildcard include/config/task/xacct.h) \
    $(wildcard include/config/cpusets.h) \
    $(wildcard include/config/cgroups.h) \
    $(wildcard include/config/futex.h) \
    $(wildcard include/config/fault/injection.h) \
    $(wildcard include/config/latencytop.h) \
    $(wildcard include/config/function/graph/tracer.h) \
    $(wildcard include/config/have/unstable/sched/clock.h) \
    $(wildcard include/config/stack/growsup.h) \
    $(wildcard include/config/group/sched.h) \
  /root/linux-2.6.32/include/linux/capability.h \
    $(wildcard include/config/security/file/capabilities.h) \
  /root/linux-2.6.32/arch/x86/include/asm/cputime.h \
  /root/linux-2.6.32/include/asm-generic/cputime.h \
  /root/linux-2.6.32/include/linux/sem.h \
  /root/linux-2.6.32/include/linux/ipc.h \
  /root/linux-2.6.32/arch/x86/include/asm/ipcbuf.h \
  /root/linux-2.6.32/include/asm-generic/ipcbuf.h \
  /root/linux-2.6.32/arch/x86/include/asm/sembuf.h \
  /root/linux-2.6.32/include/linux/signal.h \
  /root/linux-2.6.32/arch/x86/include/asm/signal.h \
  /root/linux-2.6.32/include/asm-generic/signal-defs.h \
  /root/linux-2.6.32/arch/x86/include/asm/siginfo.h \
  /root/linux-2.6.32/include/asm-generic/siginfo.h \
  /root/linux-2.6.32/include/linux/path.h \
  /root/linux-2.6.32/include/linux/pid.h \
  /root/linux-2.6.32/include/linux/proportions.h \
  /root/linux-2.6.32/include/linux/percpu_counter.h \
  /root/linux-2.6.32/include/linux/seccomp.h \
    $(wildcard include/config/seccomp.h) \
  /root/linux-2.6.32/arch/x86/include/asm/seccomp.h \
  /root/linux-2.6.32/arch/x86/include/asm/seccomp_32.h \
  /root/linux-2.6.32/include/linux/unistd.h \
  /root/linux-2.6.32/arch/x86/include/asm/unistd.h \
  /root/linux-2.6.32/arch/x86/include/asm/unistd_32.h \
  /root/linux-2.6.32/include/linux/rculist.h \
  /root/linux-2.6.32/include/linux/rtmutex.h \
    $(wildcard include/config/debug/rt/mutexes.h) \
  /root/linux-2.6.32/include/linux/plist.h \
    $(wildcard include/config/debug/pi/list.h) \
  /root/linux-2.6.32/include/linux/resource.h \
  /root/linux-2.6.32/arch/x86/include/asm/resource.h \
  /root/linux-2.6.32/include/asm-generic/resource.h \
  /root/linux-2.6.32/include/linux/hrtimer.h \
    $(wildcard include/config/high/res/timers.h) \
  /root/linux-2.6.32/include/linux/task_io_accounting.h \
    $(wildcard include/config/task/io/accounting.h) \
  /root/linux-2.6.32/include/linux/latencytop.h \
  /root/linux-2.6.32/include/linux/cred.h \
    $(wildcard include/config/debug/credentials.h) \
    $(wildcard include/config/security.h) \
  /root/linux-2.6.32/include/linux/key.h \
    $(wildcard include/config/sysctl.h) \
  /root/linux-2.6.32/include/linux/sysctl.h \
  /root/linux-2.6.32/include/linux/selinux.h \
    $(wildcard include/config/security/selinux.h) \
  /root/linux-2.6.32/include/linux/aio.h \
  /root/linux-2.6.32/include/linux/aio_abi.h \
  /root/linux-2.6.32/include/linux/uio.h \
  /root/linux-2.6.32/include/linux/suspend.h \
    $(wildcard include/config/vt.h) \
    $(wildcard include/config/vt/console.h) \
    $(wildcard include/config/suspend.h) \
    $(wildcard include/config/hibernation/nvs.h) \
  /root/linux-2.6.32/include/linux/swap.h \
    $(wildcard include/config/migration.h) \
    $(wildcard include/config/memory/failure.h) \
    $(wildcard include/config/swap.h) \
    $(wildcard include/config/cgroup/mem/res/ctlr/swap.h) \
  /root/linux-2.6.32/include/linux/memcontrol.h \
    $(wildcard include/config/cgroup/mem/cont.h) \
  /root/linux-2.6.32/include/linux/cgroup.h \
  /root/linux-2.6.32/include/linux/cgroupstats.h \
  /root/linux-2.6.32/include/linux/taskstats.h \
  /root/linux-2.6.32/include/linux/prio_heap.h \
  /root/linux-2.6.32/include/linux/idr.h \
  /root/linux-2.6.32/include/linux/cgroup_subsys.h \
    $(wildcard include/config/cgroup/debug.h) \
    $(wildcard include/config/cgroup/ns.h) \
    $(wildcard include/config/cgroup/sched.h) \
    $(wildcard include/config/cgroup/cpuacct.h) \
    $(wildcard include/config/cgroup/device.h) \
    $(wildcard include/config/cgroup/freezer.h) \
    $(wildcard include/config/net/cls/cgroup.h) \
  /root/linux-2.6.32/include/linux/node.h \
  /root/linux-2.6.32/include/linux/sysdev.h \
  /root/linux-2.6.32/include/linux/mm.h \
    $(wildcard include/config/debug/pagealloc.h) \
  /root/linux-2.6.32/include/linux/debug_locks.h \
    $(wildcard include/config/debug/locking/api/selftests.h) \
  /root/linux-2.6.32/arch/x86/include/asm/pgtable.h \
  /root/linux-2.6.32/arch/x86/include/asm/pgtable_32.h \
  /root/linux-2.6.32/arch/x86/include/asm/pgtable_32_types.h \
  /root/linux-2.6.32/arch/x86/include/asm/pgtable-2level.h \
  /root/linux-2.6.32/include/asm-generic/pgtable.h \
  /root/linux-2.6.32/include/linux/page-flags.h \
    $(wildcard include/config/pageflags/extended.h) \
    $(wildcard include/config/have/mlocked/page/bit.h) \
    $(wildcard include/config/arch/uses/pg/uncached.h) \
    $(wildcard include/config/s390.h) \
  /root/linux-2.6.32/include/linux/vmstat.h \
    $(wildcard include/config/vm/event/counters.h) \
  /root/linux-2.6.32/include/linux/kbuild.h \
  /root/linux-2.6.32/arch/x86/include/asm/ucontext.h \
  /root/linux-2.6.32/include/asm-generic/ucontext.h \
  /root/linux-2.6.32/arch/x86/include/asm/sigframe.h \
  /root/linux-2.6.32/arch/x86/include/asm/suspend.h \
  /root/linux-2.6.32/arch/x86/include/asm/suspend_32.h \
  /root/linux-2.6.32/arch/x86/include/asm/i387.h \
  /root/linux-2.6.32/include/linux/kernel_stat.h \
  /root/linux-2.6.32/include/linux/interrupt.h \
    $(wildcard include/config/generic/irq/probe.h) \
    $(wildcard include/config/debug/shirq.h) \
  /root/linux-2.6.32/include/linux/irqreturn.h \
  /root/linux-2.6.32/include/linux/irqnr.h \
  /root/linux-2.6.32/include/linux/hardirq.h \
    $(wildcard include/config/virt/cpu/accounting.h) \
  /root/linux-2.6.32/include/linux/ftrace_irq.h \
    $(wildcard include/config/ftrace/nmi/enter.h) \
  /root/linux-2.6.32/arch/x86/include/asm/hardirq.h \
    $(wildcard include/config/x86/mce.h) \
    $(wildcard include/config/x86/mce/threshold.h) \
  /root/linux-2.6.32/include/linux/irq.h \
    $(wildcard include/config/irq/per/cpu.h) \
    $(wildcard include/config/irq/release/method.h) \
    $(wildcard include/config/intr/remap.h) \
    $(wildcard include/config/generic/pending/irq.h) \
    $(wildcard include/config/numa/irq/desc.h) \
    $(wildcard include/config/generic/hardirqs/no//do/irq.h) \
    $(wildcard include/config/cpumasks/offstack.h) \
  /root/linux-2.6.32/arch/x86/include/asm/irq.h \
  /root/linux-2.6.32/arch/x86/include/asm/irq_regs.h \
  /root/linux-2.6.32/arch/x86/include/asm/hw_irq.h \
  /root/linux-2.6.32/include/linux/profile.h \
    $(wildcard include/config/profiling.h) \
  /root/linux-2.6.32/arch/x86/include/asm/sections.h \
  /root/linux-2.6.32/include/asm-generic/sections.h \
  /root/linux-2.6.32/include/linux/regset.h \
  /root/linux-2.6.32/arch/x86/include/asm/xsave.h \
  /root/linux-2.6.32/include/xen/interface/xen.h \
  /root/linux-2.6.32/arch/x86/include/asm/xen/interface.h \
  /root/linux-2.6.32/arch/x86/include/asm/xen/interface_32.h \
  /root/linux-2.6.32/arch/x86/include/asm/pvclock-abi.h \
  /root/linux-2.6.32/include/linux/lguest.h \
  /root/linux-2.6.32/arch/x86/include/asm/lguest_hcall.h \
  /root/linux-2.6.32/arch/x86/include/asm/kvm_para.h \
  /root/linux-2.6.32/arch/x86/kernel/../../../drivers/lguest/lg.h \
  /root/linux-2.6.32/include/linux/lguest_launcher.h \
  /root/linux-2.6.32/arch/x86/include/asm/lguest.h \

arch/x86/kernel/asm-offsets.s: $(deps_arch/x86/kernel/asm-offsets.s)

$(deps_arch/x86/kernel/asm-offsets.s):
