/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 

PORT_CONFIG *pPortConfig;
MODE_INFO   *pLCDTable;
MODE_INFO   *pVESATable;
MODE_INFO   *pHDMITable = NULL;
void *PCIDataStruct;
void *BiosInfoData;
HDMITxDetect *pTMDSTxTable = NULL;

bool bCRTSUPPORT = false;
bool bLCDSUPPORT = false;
bool bDVISUPPORT = false;
bool bTVSUPPORT = false;
bool bHDMISUPPORT = false;

bool bDS_SUPPORT = false;


void *Display1VESAModeInitRegs;


void *POSTInItRegs;
void *DDRII400Tbl;
void *DDRII533Tbl;
void *ExtendRegs2;


void *EP932M_INIT_TBL;


void *EP932M_AVI_TBL;
void *IT6610_AVI_TBL;
void *PLLFS473TVEnc;



REG_OP HTotal1[] = {
            {CR, 0xFF, 0x00,3},                 
            {CR, BIT0, 0xAC,11},                  
            {NR,0x0,0x0,0x0}
};


REG_OP HDispEnd1[] = {
            {SR, BIT6+BIT5+BIT4, 0x33,0},
            {CR, 0xFF, 0x01,3},
            {CR, BIT2, 0xAC,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HBnkSt1[] = {
            {SR, BIT2+BIT1+BIT0, 0x34,0},
            {CR, 0xFF, 0x02,3},
            {CR, BIT4, 0xAC,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HBnkEnd1[] = {
            {SR, BIT6+BIT5+BIT4, 0x34,0},
            {CR, 0x1F, 0x03,3},
            {CR, BIT7, 0x05,8},
            {CR, BIT0, 0xAD,9},
            {NR,0x0,0x0,0x0}
};


REG_OP HSyncSt1[] = {
            {SR, BIT2+BIT1+BIT0, 0x35,0},
            {CR, 0xFF, 0x04,3},
            {CR, BIT6, 0xAC,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HSyncEnd1[] = {
            {SR, BIT6+BIT5+BIT4, 0x35,0},
            {CR, 0x1F, 0x05,3},
            {CR, BIT2, 0xAD,8},
            {NR,0x0,0x0,0x0}
};


REG_OP VTotal1[] = {
            {CR, 0xFF, 0x06,0},
            {CR, BIT0, 0x07,8},
            {CR, BIT5, 0x07,9},
            {CR, BIT0, 0xAE,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VDispEnd1[] = {
            {CR, 0xFF, 0x12,0},
            {CR, BIT1, 0x07,8},
            {CR, BIT6, 0x07,9},
            {CR, BIT1, 0xAE,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VBnkSt1[] = {
            {CR, 0xFF, 0x15,0},
            {CR, BIT3, 0x07,8},
            {CR, BIT5, 0x09,9},
            {CR, BIT2, 0xAE,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VBnkEnd1[] = {
            {CR, 0xFF, 0x16,0},
            {CR, BIT4, 0xAE,8},
            {NR,0x0,0x0,0x0}
};


REG_OP VSyncSt1[] = {
             {CR, 0xFF, 0x10,0},
             {CR, BIT2, 0x07,8},
             {CR, BIT7, 0x07,9},
             {CR, BIT3, 0xAE,10},
             {NR,0x0,0x0,0x0}
};


REG_OP VSyncEnd1[] = {
             {CR, BIT3+BIT2+BIT1+BIT0, 0x11,0},
             {CR, BIT6+BIT5, 0xAE,4},
             {NR,0x0,0x0,0x0}
};


REG_OP Pitch1[] = {
             {CR, 0xFF, 0x13,0},
             {CR, 0x3F, 0xB0,8},
             {NR,0x0,0x0,0x0}
};




REG_OP HTotal2[] = {
            {CR, 0xFF, 0x23,3},                 
            {CR, BIT0, 0x29,11},                  
            {NR,0x0,0x0,0x0}
};


REG_OP HDispEnd2[] = {
            {SR, BIT6+BIT5+BIT4, 0x36,0},
            {CR, 0xFF, 0x24,3},
            {CR, BIT2, 0x29,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HBnkSt2[] = {
            {SR, BIT2+BIT1+BIT0, 0x37,0},
            {CR, 0xFF, 0x25,3},
            {CR, BIT4, 0x29,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HBnkEnd2[] = {
            {SR, BIT6+BIT5+BIT4, 0x37,0},
            {CR, 0x1F, 0x26,3},
            {CR, BIT7, 0x28,8},
            {CR, BIT0, 0x2A,9},
            {NR,0x0,0x0,0x0}
};


REG_OP HSyncSt2[] = {
            {SR, BIT2+BIT1+BIT0, 0x38,0},
            {CR, 0xFF, 0x27,3},
            {CR, BIT6, 0x29,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HSyncEnd2[] = {
            {SR, BIT6+BIT5+BIT4, 0x38,0},
            {CR, 0x1F, 0x28,3},
            {CR, BIT2, 0x2A,8},
            {NR,0x0,0x0,0x0}
};


REG_OP VTotal2[] = {
            {CR, 0xFF, 0x2B,0},
            {CR, BIT0, 0x31,8},
            {CR, BIT5, 0x31,9},
            {CR, BIT0, 0x32,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VDispEnd2[] = {
            {CR, 0xFF, 0x2C,0},
            {CR, BIT1, 0x31,8},
            {CR, BIT6, 0x31,9},
            {CR, BIT1, 0x32,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VBnkSt2[] = {
            {CR, 0xFF, 0x2D,0},
            {CR, BIT3, 0x31,8},
            {CR, BIT5, 0x29,9},
            {CR, BIT2, 0x32,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VBnkEnd2[] = {
            {CR, 0xFF, 0x2E,0},
            {CR, BIT4, 0x32,8},
            {NR,0x0,0x0,0x0}
};


REG_OP VSyncSt2[] = {
             {CR, 0xFF, 0x2F,0},
             {CR, BIT2, 0x31,8},
             {CR, BIT7, 0x31,9},
             {CR, BIT3, 0x32,10},
             {NR,0x0,0x0,0x0}
};


REG_OP VSyncEnd2[] = {
             {CR, BIT3+BIT2+BIT1+BIT0, 0x30,0},
             {CR, BIT6+BIT5, 0x32,4},
             {NR,0x0,0x0,0x0}
};


REG_OP Pitch2[] = {
             {CR, 0xFF, 0x3A,0},
             {CR, 0x3F, 0x3B,8},
             {NR,0x0,0x0,0x0}
};


REG_OP HSource1[] = {
            {SR, 0xFF,                0x4B, 0},
            {SR, BIT3+BIT2+BIT1+BIT0, 0x4C, 8},
            {NR,0x0,0x0,0x0}
};

REG_OP HSource2[] = {
            {SR, 0xFF,                0x4D, 0},
            {SR, BIT3+BIT2+BIT1+BIT0, 0x4E, 8},
            {NR,0x0,0x0,0x0}
};

REG_OP HScalingFactor1[] = {
            {SR, 0xFF,                0x59, 0},
            {SR, BIT3+BIT2+BIT1+BIT0, 0x5B, 8},
            {NR,0x0,0x0,0x0}
};
        
REG_OP VScalingFactor1[] = {
            {SR, 0xFF,                0x5A, 0},
            {SR, BIT6+BIT5+BIT4,      0x5B, 8},
            {NR,0x0,0x0,0x0}
};
        
REG_OP HScalingFactor2[] = {
            {SR, 0xFF,                0x51, 0},
            {SR, BIT3+BIT2+BIT1+BIT0, 0x53, 8},
            {NR,0x0,0x0,0x0}
};

REG_OP VScalingFactor2[] = {
            {SR, 0xFF,                0x52, 0},
            {SR, BIT6+BIT5+BIT4,      0x53, 8},
            {NR,0x0,0x0,0x0}
};

REG_OP HorDownScaleFactor1[] = {
        {SR, 0xFF,                    0x75, 0},
        {SR, BIT1+BIT0,               0x74, 8},
        {NR,0x0,0x0,0x0}
};
        
REG_OP VerDownScaleFactor1[] = {
        {SR, 0xFF,                    0x71, 0},
        {SR, BIT1+BIT0,               0x70, 8},
        {NR,0x0,0x0,0x0}
};

REG_OP HorDownScaleSrcSize1[] = {
            {SR, 0xFF,                0x77, 0},
            {SR, BIT2+BIT1+BIT0,      0x76, 8},
            {NR,0x0,0x0,0x0}
};

REG_OP VerDownScaleSrcSize1[] = {
            {SR, 0xFF,                0x73, 0},
            {SR, BIT2+BIT1+BIT0,      0x72, 8},
            {NR,0x0,0x0,0x0}
};

VESA_TABLE CInt10VESATable[] = {
        {
            {1280, 720, MODE_1280x720x8, MODE_1280x720x16, MODE_1280x720x32, 1},
            {74250, RR60, PHS+PVS, 370, 1390, 40,  30,  725,  5}
        },
        {
            {1280, 768, MODE_1280x768x8, MODE_1280x768x16, MODE_1280x768x32, 1},
            { 79500, RR60, NHS+PVS, 384, 1344, 128,  30,  771,  7}
        },
        {
            {1280, 960, MODE_1280x960x8, MODE_1280x960x16, MODE_1280x960x32, 1},
            {108000, RR60, PHS+PVS, 520, 1376, 112, 40,  961,  3}
        },
        {
            {1280, 1024, MODE_1280x1024x8, MODE_1280x1024x16, MODE_1280x1024x32, 1},
            {108000, RR60, PHS+PVS, 408, 1328, 112, 42, 1025, 3}
        },
        {
            {1360, 768, MODE_1360x768x8, MODE_1360x768x16, MODE_1360x768x32, 1},
            {85500, RR60, NHS+PVS, 432, 1424, 112, 27, 771, 6}            
        },
        {
            {1366, 768, MODE_1366x768x8, MODE_1366x768x16, MODE_1366x768x32, 1},
            { 85860, RR60, NHS+PVS, 434, 1440, 144,  27,  769,  3}
        },
        {
            {1400, 960, MODE_1400x960x8, MODE_1400x960x16, MODE_1400x960x32, 1},
            {111169, RR60, NHS+PVS, 464, 1480, 152, 34, 961, 3}
        },
        {
            {1400,1050, MODE_1400x1050x8, MODE_1400x960x16, MODE_1400x960x32, 1},
            {121750, RR60, NHS+PVS, 464, 1488, 144, 39, 1053, 4}
        },
        {
            {1440, 900, MODE_1440x900x8, MODE_1440x900x16, MODE_1440x900x32, 1},
            {106472, RR60, NHS+PVS, 464, 1520, 152, 32, 901, 3}
        },
        {
            {1440, 960, MODE_1440x960x8, MODE_1440x960x16, MODE_1440x960x32, 1},
            {121750, RR60, NHS+PVS, 480, 1528, 152, 34, 961, 3}
        },
        {
            {1600, 1200, MODE_1600x1200x8, MODE_1600x1200x16, MODE_1600x1200x32, 1},
            {162000, RR60, PHS+PVS, 560, 1664, 192, 50, 1201, 3}
        },
        {
            {1680, 1050, MODE_1680x1050x8, MODE_1680x1050x16, MODE_1680x1050x32, 1},
            {119000, RR60, NHS+PVS, 160, 1728, 32, 30, 1053, 6}
        },
        {
            {1920, 1080, MODE_1920x1080x8, MODE_1920x1080x16, MODE_1920x1080x32, 1},
            {172798, RR60, NHS+PVS, 656, 2040, 208, 38, 1081, 3}
        },
        {
            {1920, 1200, MODE_1920x1200x8, MODE_1920x1200x16, MODE_1920x1200x32, 1},
            {193250, RR60, NHS+PVS, 676, 2056, 200, 45, 1203, 6}
        },
        {
            {1920, 1440, MODE_1920x1440x8, MODE_1920x1440x16, MODE_1920x1440x32, 1},
            {234000, RR60, NHS+PVS, 680, 2048, 208, 60, 1441, 3}
        },

        {
            {0xffff,1050, 0x138, 0x139, 0x13A, 1},
            {121750, RR60, NHS+PVS, 464, 1488, 144, 39, 1053, 4}
        }
};


