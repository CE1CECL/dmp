/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include "CInt10.h"
#include "vbiosdata.h"
#include "debug.h"


CI_STATUS Get_MODE_INFO_From_LCD_Table(UCHAR bDeviceIndex, MODE_INFO **ppModeInfo)
{
    int i;
    UCHAR bLCDTableIndex;
     
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter Get_MODE_INFO_From_LCD_Table()==\n");
    
    if (bLCDSUPPORT)
    {
        *ppModeInfo = pLCDTable;
        
        if (bDeviceIndex == LCD_ID)
        {
            bLCDTableIndex = Get_LCD_TABLE_INDEX();
        }
        else if (bDeviceIndex == LCD2_ID)
        {
            bLCDTableIndex = Get_LCD2_TABLE_INDEX();
        }
        else
        {
            CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit1 Get_MODE_INFO_From_LCD_Table()== return fail!!\n");
            return false;
        }


        if (bLCDTableIndex == 0)
        {
            CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "LCD Index = 0\n");
            CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit2 Get_MODE_INFO_From_LCD_Table()== return fail!!\n");
            return false;
        }

        while ((*ppModeInfo)->H_Size != 0xFFFF)
        {
            CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "(*ppModeInfo)->H_Size = %d\n", (*ppModeInfo)->H_Size);

            if (bLCDTableIndex == 1)
            {
                CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit3 Get_MODE_INFO_From_LCD_Table()== return success\n");
                return true;
            }
            (*ppModeInfo) = (MODE_INFO*)((int)*ppModeInfo + sizeof(MODE_INFO) + sizeof(PANEL_TABLE));
            bLCDTableIndex--;
        }
    }
    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit4 Get_MODE_INFO_From_LCD_Table()== return fail!!\n");

    return false;
    
}


CI_STATUS GetModePointerFromLCDTable(UCHAR bDeviceIndex, MODE_INFO **ppModeInfo, PANEL_TABLE **ppPanelTable)
{
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter GetModePointerFromLCDTable()==\n");
    if (Get_MODE_INFO_From_LCD_Table(bDeviceIndex, ppModeInfo))
    {
        *ppPanelTable = (PANEL_TABLE*)((int)(*ppModeInfo) + sizeof(MODE_INFO));
        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "*ppPanelTable = 0x%x\n", *ppPanelTable);
        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit1 GetModePointerFromLCDTable()== return success\n");
        return true;
    }
    else
    {
        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit1 GetModePointerFromLCDTable()== return fail\n");
        return false;
    }
}


void LoadLCDTiming(UCHAR bDisplayPath, USHORT wModeNum)
{
    UCHAR bDeviceIndex = Get_DEV_ID(bDisplayPath);
    MODE_INFO *pPanelModeInfo, *pUserModeInfo;
    PANEL_TABLE *pPanelTable;

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter LoadLCDTiming()==\n");

    if(GetModePointerFromLCDTable(bDeviceIndex,  &pPanelModeInfo, &pPanelTable))
    {
        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "&pPanelTable->Timing = 0x%x\n", &pPanelTable->Timing);
        SetTimingRegs(bDisplayPath, pPanelModeInfo, &pPanelTable->Timing);
        Get_MODE_INFO(wModeNum, &pUserModeInfo);
        SetScalingFactor(bDisplayPath, pUserModeInfo, pPanelModeInfo);
    }
    else
    {
        
    }

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit LoadLCDTiming()==\n");
}


CI_STATUS isLCDFitMode(UCHAR bDeviceIndex, USHORT wModeNum)
{
    MODE_INFO *pModeInfo;
    
    if (Get_MODE_INFO_From_LCD_Table(bDeviceIndex, &pModeInfo))
    {
        if ((wModeNum == pModeInfo->Mode_ID_8bpp) ||
            (wModeNum == pModeInfo->Mode_ID_16bpp) ||
            (wModeNum == pModeInfo->Mode_ID_32bpp))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}

