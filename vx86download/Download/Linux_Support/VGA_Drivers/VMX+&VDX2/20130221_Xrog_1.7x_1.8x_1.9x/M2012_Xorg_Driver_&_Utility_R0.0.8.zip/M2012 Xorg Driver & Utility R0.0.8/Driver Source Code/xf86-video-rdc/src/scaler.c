/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include "typedef.h"
#include "regop.h"
#include "reggroupindex.h"
#include "vbiosdata.h"
#include "debug.h"


REG_OP HSource1[] = {
            {SR, 0xFF,                0x4B, 0},
            {SR, BIT3+BIT2+BIT1+BIT0, 0x4C, 8},
            {NR,0x0,0x0,0x0}
};

REG_OP HSource2[] = {
            {SR, 0xFF,                0x4D, 0},
            {SR, BIT3+BIT2+BIT1+BIT0, 0x4E, 8},
            {NR,0x0,0x0,0x0}
};

REG_OP HScalingFactor1[] = {
            {SR, 0xFF,                0x59, 0},
            {SR, BIT3+BIT2+BIT1+BIT0, 0x5B, 8},
            {NR,0x0,0x0,0x0}
};
        
REG_OP VScalingFactor1[] = {
            {SR, 0xFF,                0x5A, 0},
            {SR, BIT6+BIT5+BIT4,      0x5B, 8},
            {NR,0x0,0x0,0x0}
};
        
REG_OP HScalingFactor2[] = {
            {SR, 0xFF,                0x51, 0},
            {SR, BIT3+BIT2+BIT1+BIT0, 0x53, 8},
            {NR,0x0,0x0,0x0}
};

REG_OP VScalingFactor2[] = {
            {SR, 0xFF,                0x52, 0},
            {SR, BIT6+BIT5+BIT4,      0x53, 8},
            {NR,0x0,0x0,0x0}
};

REG_OP HorDownScaleFactor1[] = {
        {SR, 0xFF,                    0x75, 0},
        {SR, BIT1+BIT0,               0x74, 8},
        {NR,0x0,0x0,0x0}
};
        
REG_OP VerDownScaleFactor1[] = {
        {SR, 0xFF,                    0x71, 0},
        {SR, BIT1+BIT0,               0x70, 8},
        {NR,0x0,0x0,0x0}
};

REG_OP HorDownScaleSrcSize1[] = {
            {SR, 0xFF,                0x77, 0},
            {SR, BIT2+BIT1+BIT0,      0x76, 8},
            {NR,0x0,0x0,0x0}
};

REG_OP VerDownScaleSrcSize1[] = {
            {SR, 0xFF,                0x73, 0},
            {SR, BIT2+BIT1+BIT0,      0x72, 8},
            {NR,0x0,0x0,0x0}
};


void TurnOnScaler(UCHAR bDisplayPath)
{
    if (bDisplayPath == DISP1)
        SetSRReg(0x58, BIT0, BIT0);
    else
        SetSRReg(0x50, BIT0, BIT0);
}

void TurnOffScaler(UCHAR bDisplayPath)
{
    if (bDisplayPath == DISP1)
        SetSRReg(0x58, 0, BIT0);
    else
        SetSRReg(0x50, 0, BIT0);
}

void TurnOnHorScaler(UCHAR bDisplayPath)
{
    if (bDisplayPath == DISP1)
        SetSRReg(0x58, BIT2, BIT2);
    else
        SetSRReg(0x50, BIT2, BIT2);
}

void TurnOffHorScaler(UCHAR bDisplayPath)
{
    if (bDisplayPath == DISP1)
        SetSRReg(0x58, 0, BIT2);
    else
        SetSRReg(0x50, 0, BIT2);
}

void TurnOnVerScaler(UCHAR bDisplayPath)
{
    if (bDisplayPath == DISP1)
        SetSRReg(0x58, BIT1, BIT1);
    else
        SetSRReg(0x50, BIT1, BIT1);
}

void TurnOffVerScaler(UCHAR bDisplayPath)
{
    if (bDisplayPath == DISP1)
        SetSRReg(0x58, 0, BIT1);
    else
        SetSRReg(0x50, 0, BIT1);
}


void TurnOnHorDownScaler(UCHAR bDisplayPath)
{
    if (bDisplayPath == DISP1)
        SetSRReg(0x74, BIT7, BIT7);
}

void TurnOffHorDownScaler(UCHAR bDisplayPath)
{
    if (bDisplayPath == DISP1)
        SetSRReg(0x74, 0, BIT7);
}

void TurnOnVerDownScaler(UCHAR bDisplayPath)
{
    if (bDisplayPath == DISP1)
        SetSRReg(0x70, BIT7, BIT7);
}

void TurnOffVerDownScaler(UCHAR bDisplayPath)
{
    if (bDisplayPath == DISP1)
        SetSRReg(0x70, 0, BIT7);
}


void SetHSource(UCHAR bDisplayPath, USHORT wValue)
{
    wValue -= 1;
    
    if(bDisplayPath == DISP1)
    {
        WriteRegToHW(HSource1, wValue);
    }
    else
    {
        WriteRegToHW(HSource2, wValue);
    }
}


void SetHorDownScaleSrcSize(USHORT wValue)
{
    if (bLCDSUPPORT)
    {
        WriteRegToHW(HorDownScaleSrcSize1, wValue);
    }
}


void SetVerDownScaleSrcSize(USHORT wValue)
{
    if (bLCDSUPPORT)
    {
        WriteRegToHW(VerDownScaleSrcSize1, wValue);
    }
}


void SetHorScalingFactor(UCHAR bDisplayPath, USHORT wValue)
{
    if(bDisplayPath == DISP1)
    {
        WriteRegToHW(HScalingFactor1, wValue);
    }
    else
    {
        WriteRegToHW(HScalingFactor2, wValue);
    }
}

void SetVerScalingFactor(UCHAR bDisplayPath, USHORT wValue)
{
    if(bDisplayPath == DISP1)
    {
        WriteRegToHW(VScalingFactor1, wValue);
    }
    else
    {
        WriteRegToHW(VScalingFactor2, wValue);
    }
}


void SetHorDownScalingFactor(UCHAR bDisplayPath, USHORT wValue)
{
    if (bLCDSUPPORT)
    {
        if (bDisplayPath == DISP1)
        {
            WriteRegToHW(HorDownScaleFactor1, wValue);
        }
    }
}


void SetVerDownScalingFactor(UCHAR bDisplayPath, USHORT wValue)
{
    if (bLCDSUPPORT)
    {
        if (bDisplayPath == DISP1)
        {
            WriteRegToHW(VerDownScaleFactor1, wValue);
        }
    }
}


void SetScalingFactor(UCHAR bDisplayPath, MODE_INFO *pUserModeInfo, MODE_INFO *pPanelModeInfo)
{
    ULONG dwScalingFactor;

    USHORT usUserModeHSize, usUserModeVSize;
    USHORT usPanelModeHSize, usPanelModeVSize;

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter SetScalingFactor()==\n");
    usUserModeHSize = pUserModeInfo->H_Size;

    usUserModeVSize = pUserModeInfo->V_Size;

    usPanelModeHSize = pPanelModeInfo->H_Size;

    usPanelModeVSize = pPanelModeInfo->V_Size;


    TurnOffHorScaler(bDisplayPath);

    TurnOffVerScaler(bDisplayPath);

    SetHSource(bDisplayPath, usUserModeHSize);

    if (bDS_SUPPORT)
    {
        SetHorDownScaleSrcSize(usUserModeHSize);
        if ((usUserModeHSize <= 1024) && (usUserModeVSize <= 768))
        {
            if ((usPanelModeHSize < usUserModeHSize) && (IsDownScaleEnable()))
            {
                dwScalingFactor = ((ULONG)usUserModeHSize << 8) / usPanelModeHSize;
                dwScalingFactor++;
                SetHorDownScalingFactor(DISP1, (USHORT)dwScalingFactor);
                TurnOnHorDownScaler(DISP1);
            }
        }
    }

    if (usPanelModeHSize > usUserModeHSize)
    {
        CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "Enable H scaler\n");
        dwScalingFactor = ((ULONG)usUserModeHSize << 12) / usPanelModeHSize;
        SetHorScalingFactor(bDisplayPath, dwScalingFactor);
        TurnOnHorScaler(bDisplayPath);
        TurnOnScaler(bDisplayPath);
    }

    if (bDS_SUPPORT)
    {
        SetVerDownScaleSrcSize(usUserModeVSize);
        if ((usUserModeHSize <= 1024) && (usUserModeVSize <= 768))
        {
            if ((usPanelModeVSize < usUserModeVSize) && (IsDownScaleEnable()))
            {
                dwScalingFactor = ((ULONG)usUserModeVSize << 8) / usPanelModeVSize;
                dwScalingFactor++;
                SetVerDownScalingFactor(DISP1, (USHORT)dwScalingFactor);
                TurnOnVerDownScaler(DISP1);
            }
        }
    }

    if (usPanelModeVSize > usUserModeVSize)
    {
        CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "Enable V scaler\n");
        dwScalingFactor = ((ULONG)usUserModeVSize << 11) / usPanelModeVSize;
        SetVerScalingFactor(bDisplayPath, dwScalingFactor);
        TurnOnVerScaler(bDisplayPath);
        TurnOnScaler(bDisplayPath);
    }
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit SetScalingFactor()==\n");
}

