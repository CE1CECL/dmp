/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include "vbiosdata.h"
#include "CInt10.h"
#include "io.h"
#include "edid.h"
#include "debug.h"



void Fire_Starting_Address();
void Display1TurnOnTX();
void Display1TurnOffTX();
void Display2TurnOnTX();
void Display2TurnOffTX();
UCHAR GetPortConnectPath(UCHAR PortType);
USHORT TransDevIDtoBit(UCHAR DeviceIndex);
void LongWait();
void Delay(ULONG ulDelayCount);
void ClearFrameBuffer(UCHAR DisplayPath,ULONG *pFrameBufferBase, MODE_INFO *pModeInfo, UCHAR ucColorDepth);
ULONG Difference(ULONG Value1, ULONG Value2);
void SetDPMS(UCHAR DPMSState, UCHAR DisplayPath);
CI_STATUS DetectMonitor();
void WaitDisplayPeriod();
USHORT GetVESAMEMSize();
CI_STATUS SenseCRT();
void OpenCRTDACSenseReg();
void CloseCRTDACSenseReg();



void Fire_Starting_Address()
{
    UCHAR *pucPCIDataStruct = (UCHAR*)PCIDataStruct;

    if(*(USHORT*)(pucPCIDataStruct + OFF_DID) == PCI_CHIP_M2012)
    {
        SetSRReg(0x22, 0x04, BIT2);
    }
}

void Display1TurnOnTX()
{

}

void Display1TurnOffTX()
{

}

void Display2TurnOnTX()
{

}

void Display2TurnOffTX()
{

}



UCHAR GetPortConnectPath(UCHAR PortType)
{
    UCHAR SR1F, PortMask;

    SR1F = GetSRReg(0x1F);
    SR1F ^= 0x03;
    
    switch(PortType)
    {
        case CRT_PORT:
            PortMask = BIT2;
            break;
            
        case DVP1:
        case DVP12:
            PortMask = BIT0;
            break;
            
        case DVP2:
            PortMask = BIT1;
            break;
    }
    
    return ((SR1F & PortMask) ? 1 : 0);

}


USHORT TransDevIDtoBit(UCHAR DeviceIndex)
{
    return (1 << (DeviceIndex - 1));
}



void LongWait()
{
     while (GetIS1Reg() & BIT3);
     
     while (!(GetIS1Reg() & BIT3));
}


void Delay(ULONG ulDelayCount)
{
    while (ulDelayCount != 0)
    {
        GetSRReg(0x00);
        ulDelayCount--;
    }
}


void ClearFrameBuffer(UCHAR DisplayPath,ULONG *pFrameBufferBase, MODE_INFO *pModeInfo, UCHAR ucColorDepth)
{
    ULONG dwWidth = (ULONG)pModeInfo->H_Size, dwHeight = (ULONG)pModeInfo->V_Size, dwFactor  = 0;
    ULONG i = 0;

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter ClearFrameBuffer()==\n");
    
    
    
    switch(ucColorDepth)
    {
        case 8:
        case 16:
        case 32:    
          dwFactor = 32 / ucColorDepth;
          break;
          
        default:
            return;
    }

    
    for(i = 0;i<((dwWidth*dwHeight)/dwFactor);i++)
    {
        *(pFrameBufferBase+i) = 0x00000000;
    }
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit ClearFrameBuffer()==\n");
    
}

ULONG Difference(ULONG Value1, ULONG Value2)
{
    if (Value1 > Value2)
        return (Value1 - Value2);
    else
        return (Value2 - Value1);
}




#define DPMS__ON                     0
#define DPMS__STANDBY                1
#define DPMS__SUSPEND                2
#define DPMS__OFF                    3

void SetDPMS(UCHAR DPMSState, UCHAR DisplayPath)
{

    UCHAR RegValue;

    if (DPMSState > DPMS__OFF)
        RegValue = 3;
    else if (DPMSState <= DPMS__SUSPEND)
        RegValue = DPMSState;
        
    if (DisplayPath == DISP1)
        SetCRReg(0xB6, RegValue, BIT1+BIT0);
    else if (DisplayPath == DISP2)
        SetCRReg(0x3E, RegValue, BIT1+BIT0);

}

CI_STATUS DetectMonitor()
{
    CI_STATUS ConnectStatus;

    
    SetCRReg(0xA9, 0x80, 0xFF);

    
    SetCRReg(0xA8, BIT6, BIT6);

    
    WaitDisplayPeriod();

    
    ConnectStatus = ((InPort(INPUT_STATUS_0_READ) & BIT4) ? true : false);

    SetCRReg(0xA8, 0x00, BIT6);

    return ConnectStatus;
}

void WaitDisplayPeriod()
{
     while ((InPort(COLOR_INPUT_STATUS1_READ)&BIT0) == 1);
     
     while ((InPort(COLOR_INPUT_STATUS1_READ)&BIT0) == 0);
}


USHORT GetVESAMEMSize()
{
    UCHAR bHWStrapping;
    bHWStrapping = (GetCRReg(0xAA) & (BIT2+BIT1+BIT0));
    
    return (2 << (bHWStrapping+3));
}


CI_STATUS SenseCRT()
{
    UCHAR ucSR3c;
    PORT_CONFIG *pDevicePortConfig = pPortConfig;
    UCHAR ucI2CPort;
    
    if(bCRTSUPPORT)
    {
        OpenCRTDACSenseReg();
        
        LongWait();

        ucSR3c = GetSRReg(0x3c);

        CloseCRTDACSenseReg();

        if(ucSR3c & BIT0)
            return true;

        
        
        GetDevicePortConfig(CRT_ID, &pDevicePortConfig);
        ucI2CPort = pDevicePortConfig->TX_I2C_Port;
        
        if (CheckMinitorEDID(ucI2CPort) == DDCEDIDWORD)
            return true;
    }

    return false;
}

void OpenCRTDACSenseReg()
{
    SetSRReg(0x4f, 0x80, 0xff);    
}

void CloseCRTDACSenseReg()
{
    SetSRReg(0x4f, 0x00, 0xff);    
}
