/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#ifndef __TIMINGTBL_H__
#define __TIMINGTBL_H__


#include "modenum.h"
#include "typedef.h"

struct _MODE_INFO{
    USHORT  H_Size;
    USHORT  V_Size;
    USHORT  Mode_ID_8bpp;
    USHORT  Mode_ID_16bpp;
    USHORT  Mode_ID_32bpp;
    UCHAR   RRTableCount;
}__attribute__((packed));;
typedef struct _MODE_INFO MODE_INFO;

struct _RRATE_TABLE {
    ULONG   Clock;          
    UCHAR   RRate_ID;
    USHORT  Attribute;
    USHORT  H_Blank_Time;
    USHORT  H_Sync_Start;
    USHORT  H_Sync_Time;
    USHORT  V_Blank_Time;
    USHORT  V_Sync_Start;
    USHORT  V_Sync_Time;
}__attribute__((packed));;
typedef struct _RRATE_TABLE RRATE_TABLE;

struct _VESA_TABLE {
    MODE_INFO   ModeInfo;
    RRATE_TABLE RRateTable;
}__attribute__((packed));;
typedef struct _VESA_TABLE VESA_TABLE;

struct _PANEL_TABLE {
    USHORT    TD0;
    USHORT    TD1;
    USHORT    TD2;
    USHORT    TD3;
    USHORT    TD5;
    USHORT    TD6;
    USHORT    TD7;
    UCHAR   PWM_Clock;
    USHORT  Reserved1;
    USHORT  Reserved2;
    RRATE_TABLE Timing;
}__attribute__((packed));;
typedef struct _PANEL_TABLE PANEL_TABLE;


#define SEQ         BIT1                
#define TTL         BIT6                


#define RR60        0
#define RR50I       1
#define RR59_94I    2
#define RR50        3
#define RR56        4
#define RR59_94     5
#define RR24        6
#define RR70        7
#define RR75        8
#define RR80        9
#define RR85        10
#define RR90        11
#define RR100       12
#define RR120       13
#define RR72        14
#define RR65        15


#define DISABLE              0x0001             
#define NHS                  0x0002             
#define PHS                  0
#define NVS                  0x0004             
#define PVS                  0
#define HB                   0x0008             
#define VB                   0x0010             
#define RBK                  0x0020             
#define ROT                  0x0040             
#define EN_DIT               0x0080             
#define MSB                  0x0100             
#define _2_CH                0x0200             
#define SW_PS                0x0400             
#define MHB                  0x1000             
#define MVB                  0x2000             


static const VESA_TABLE CInt10VESATable[] = {
        {
            {1280, 720, MODE_1280x720x8, MODE_1280x720x16, MODE_1280x720x32, 1},
            {74250, RR60,  PHS+PVS, 368, 1390, 40, 30, 725, 5}
        },
        {
            {1280, 768, MODE_1280x768x8, MODE_1280x768x16, MODE_1280x768x32, 1},
            {79500, RR60,  NHS+PVS, 384, 1344, 128, 30, 771, 7}
        },
        {
            {1280, 960, MODE_1280x960x8, MODE_1280x960x16, MODE_1280x960x32, 1},
            {108000, RR60,  PHS+PVS, 520, 1376, 112, 40, 961, 3}
        },
        {
            {1280, 1024, MODE_1280x1024x8, MODE_1280x1024x16, MODE_1280x1024x32, 1},
            {108000, RR60,  PHS+PVS, 408, 1328, 112, 42, 1025, 3}
        },
        {
            {1360, 768, MODE_1360x768x8, MODE_1360x768x16, MODE_1360x768x32, 1},
            {85500, RR60,  PHS+PVS, 432, 1424, 112, 27, 771, 6}           
        },
        {
            {1366, 768, MODE_1366x768x8, MODE_1366x768x16, MODE_1366x768x32, 1},
            {85860, RR60,  NHS+PVS, 434, 1440, 144, 27, 769, 3}
        },
        {
            {1400, 960, MODE_1400x960x8, MODE_1400x960x16, MODE_1400x960x32, 1},
            {111169, RR60,  NHS+PVS, 464, 1480, 152, 34, 961, 3}
        },
        {
            {1400,1050, MODE_1400x1050x8, MODE_1400x1050x16, MODE_1400x1050x32, 1},
            {121750, RR60,  NHS+PVS, 464, 1488, 144, 39, 1053, 4}
        },
        {
            {1440, 900, MODE_1440x900x8, MODE_1440x900x16, MODE_1440x900x32, 1},
            {106472, RR60,  NHS+PVS, 464, 1520, 152, 32, 901, 3}
        },
        {
            {1440, 960, MODE_1440x960x8, MODE_1440x960x16, MODE_1440x960x32, 1},
            {121750, RR60,  NHS+PVS, 480, 1528, 152, 34, 961, 3}
        },
        {
            {1600, 900, MODE_1600x900x8, MODE_1600x900x16, MODE_1600x900x32, 1},
            {118997, RR60, PHS+PVS, 528, 1696, 168, 32, 901, 3}
        },
        
        {
            {1680, 1050, MODE_1680x1050x8, MODE_1680x1050x16, MODE_1680x1050x32, 1},
            {119000, RR60,  NHS+PVS, 160, 1728, 32, 30, 1053, 6}
        },
        {
            {1920, 1080, MODE_1920x1080x8, MODE_1920x1080x16, MODE_1920x1080x32, 1},
            {148500, RR60,  PHS+PVS, 280, 2008, 44, 45, 1084, 5}
        },

        
        
        {
            {0xffff,0xffff, 0x1FD, 0x1FE, 0x1FF, 1},
            {0, RR60, 0, 0, 0, 0, 0, 0, 0}
        }     
};

static const VESA_TABLE HDMITable[] =
{

    { 
        {640, 480, MODE_640x480x8, MODE_640x480x16, MODE_640x480x32, 1},
        { 25175, 0, 0,            0, 0, 0, 0, 0, 0}
    },        
    { 
        {1280, 720, MODE_1280x720x8, MODE_1280x720x16, MODE_1280x720x32, 1},
        { 74250, RR60, PHS+PVS,            370, 1391, 40, 30, 725, 5}
    },        
    { 
        {1920, 540, 0, 0, 0, 1},
        { 74250, 0, 0,            0, 0, 0, 0, 0, 0}
    },        
    { 
        {720, 480, MODE_720x480x8, MODE_720x480x16, MODE_720x480x32, 1},
        { 27000, RR60, NHS+NVS,            138, 736, 62, 45, 485, 6}
    },        
    { 
        {1920, 1080, MODE_1920x1080x8, MODE_1920x1080x16, MODE_1920x1080x32, 1},
        { 148500, RR60, PHS+PVS,            280, 2008, 44, 45, 1084, 5}
    }
};

#endif 

