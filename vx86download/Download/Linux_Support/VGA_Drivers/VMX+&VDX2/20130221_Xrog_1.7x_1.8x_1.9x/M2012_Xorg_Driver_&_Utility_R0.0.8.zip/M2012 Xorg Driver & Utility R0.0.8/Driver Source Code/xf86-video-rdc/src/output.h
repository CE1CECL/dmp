/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#ifndef __OUTPUT_H__
#define __OUTPUT_H__

#include "typedef.h"


#define Dev_SUPPORT BIT0        
#define TX_DIT      BIT1
#define TX_PS       BIT2
#define DSTN_COLOR  BIT3        
#define DSTN_MONO   0           
#define DSTN_6X4    BIT4        
#define DSTN_3X2    0           
#define TX_MSB      BIT5

struct _PORT_CONFIG
{
    UCHAR        DevID;
    UCHAR        PortID;
    UCHAR        TX_Enc_ID;
    UCHAR        TX_I2C_Port;
    UCHAR        TX_I2C_Addr;
    UCHAR        Attribute;
}__attribute__((packed));;
typedef struct _PORT_CONFIG PORT_CONFIG;

#endif 
