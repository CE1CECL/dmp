/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include "typedef.h"
#include "reggroupindex.h"



void SerialLoadRegBits(UCHAR **ppucTablePointer, UCHAR ucRegGroup, UCHAR ucI2Cport, UCHAR ucI2CAddr)
{
    UCHAR ucRegIndex, ucRegValue, ucMask;
    ucRegGroup &= 0x7F;

    while (**ppucTablePointer != 0xFF)
    {
        ucRegIndex = **ppucTablePointer;
        (*ppucTablePointer)++;

        ucRegValue = **ppucTablePointer;
        (*ppucTablePointer)++;

        ucMask = **ppucTablePointer;
        (*ppucTablePointer)++;

        switch(ucRegGroup)
        {
            case SR:
                SetSRReg(ucRegIndex, ucRegValue, ucMask);
                break;

            case CR:
                SetCRReg(ucRegIndex, ucRegValue, ucMask);
                break;
                
            case I2C:
                WriteI2CBits(ucI2Cport, ucI2CAddr, ucRegIndex, ucRegValue, ucMask);
                break;
        }
    }
    (*ppucTablePointer)++;
}


void SerialLoadReg(UCHAR **ppucTablePointer, UCHAR ucRegGroup, UCHAR ucI2Cport, UCHAR ucI2CAddr)
{
    UCHAR ucRegIndex, ucRegValue;

    while (**ppucTablePointer != 0xFF)
    {
        ucRegIndex = **ppucTablePointer;
        (*ppucTablePointer)++;

        ucRegValue = **ppucTablePointer;
        (*ppucTablePointer)++;

        switch(ucRegGroup)
        {
            case SR:
                SetSRReg(ucRegIndex, ucRegValue, 0xFF);
                break;

            case CR:
                SetCRReg(ucRegIndex, ucRegValue, 0xFF);
                break;
                
            case GR:
                SetGRReg(ucRegIndex, ucRegValue, 0xFF);
                break;

            case I2C:
                WriteI2C(ucI2Cport, ucI2CAddr, ucRegIndex, ucRegValue);
                break;
        }
    }
    (*ppucTablePointer)++;
}


void SerialLoadTable(UCHAR **ppucTablePointer, UCHAR ucI2Cport, UCHAR ucI2CAddr)
{
    UCHAR ucRegGroup;

    while (**ppucTablePointer != 0xFF)
    {
        ucRegGroup = **ppucTablePointer;
        (*ppucTablePointer)++;
        if (ucRegGroup & BITS)
        {
            SerialLoadRegBits(ppucTablePointer, ucRegGroup, ucI2Cport, ucI2CAddr);
        }
        else
        {
            SerialLoadReg(ppucTablePointer, ucRegGroup, ucI2Cport, ucI2CAddr);
        }
    }
    (*ppucTablePointer)++;
}


