/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
     

#include "typedef.h"
#include "CInt10.h"
#include "tv.h"
#include "vbiosdata.h"
#include "output.h"


void SetFS473EncRegLoop(UCHAR *pIndexCount, UCHAR **pData, UCHAR ucI2CPort, UCHAR ucI2CAddr)
{
    UCHAR ucStartIndex, ucLoopCount;
    int i;
    ucStartIndex = *(pIndexCount+1);
    ucLoopCount = *pIndexCount;

    for(i = 0; i < ucLoopCount; i++,(*pData)++)
    {
        WriteI2C(ucI2CPort, ucI2CAddr, ucStartIndex+i, **pData);
    }
}


CI_STATUS GetFSModeTable(void **ppFS_TV_Table)
{
    UCHAR ucTvType = Get_TV_TYPE();
    UCHAR ucTv1ModeIndex = Get_TV1_Mode_Index();
    TVTBLDATA *pFSTable = FS_Table_Start;
    
    if (PAL < ucTvType)        
        return false;
        
    Clear_TV_Polarity(ucTv1ModeIndex);

    while(pFSTable->TVModeIndex != 0xFF)
    {
        if (pFSTable->TVModeIndex != ucTv1ModeIndex)
        {
            pFSTable++;
            continue;
        }

        if (ucTvType == NTSC)
            *ppFS_TV_Table = (void*)(((ULONG)(pFSTable->TVNTSCTP)) + (ULONG)BiosInfoData);
        else if (ucTvType == PAL)
            *ppFS_TV_Table = (void*)(((ULONG)(pFSTable->TVPALTP)) + (ULONG)BiosInfoData);

        if (*ppFS_TV_Table != NULL)
            return true;

        break;
    }
    
    return false;
}


void SetFSModeRegs(void *pFS_TV_Table)
{
    int         i;
    UCHAR       ucI2CPort, ucI2CAddr;
    PORT_CONFIG *pDevicePortConfig;
    void*       pFSRegTvTypeGruop;
    void*       pFSRegGruop;
   
    GetDevicePortConfig(TV_ID, &pDevicePortConfig);
    pFSRegGruop = FS_REG_GROUP;
    ucI2CPort = pDevicePortConfig->TX_I2C_Port;
    ucI2CAddr = pDevicePortConfig->TX_I2C_Addr;

    for (i = 0; i < 4; i++)
    {
        WriteI2C(ucI2CPort, ucI2CAddr, (*(UCHAR*)FS_REG_RESET_GROUP)+i, *(UCHAR*)(FS_REG_RESET_GROUP+1+i));
    }

    if (Get_TV_TYPE() == NTSC)
    {
        pFSRegTvTypeGruop = FS_REG_NTSC_GROUP;
    }
    else
    {
        pFSRegTvTypeGruop = FS_REG_PAL_GROUP;
    }
    
    for (i = 0; i < 7; i++, pFSRegGruop+=2)
    {
        SetFS473EncRegLoop(pFSRegGruop, &pFSRegTvTypeGruop, ucI2CPort, ucI2CAddr);
    }

    for (i = 0; i < 4; i++, pFSRegGruop+=2)
    {
        SetFS473EncRegLoop(pFSRegGruop, &pFS_TV_Table, ucI2CPort, ucI2CAddr);
    }
    
    SetHTotal(DISP1, *(USHORT*)pFS_TV_Table);
    SetHDisplayEnd(DISP1, *(USHORT*)(pFS_TV_Table+2));
    SetHBlankingStart(DISP1, *(USHORT*)(pFS_TV_Table+4));
    SetHBlankingEnd(DISP1, (*(USHORT*)(pFS_TV_Table+4)) + (*(USHORT*)(pFS_TV_Table+6)));
    SetHSyncStart(DISP1, *(USHORT*)(pFS_TV_Table+8));
    SetHSyncEnd(DISP1, (*(USHORT*)(pFS_TV_Table+8)) + (*(USHORT*)(pFS_TV_Table+10)));

    SetVTotal(DISP1, *(USHORT*)(pFS_TV_Table+12));
    SetVDisplayEnd(DISP1, *(USHORT*)(pFS_TV_Table+14));
    SetVBlankingStart(DISP1, *(USHORT*)(pFS_TV_Table+16));
    SetVBlankingEnd(DISP1, (*(USHORT*)(pFS_TV_Table+16)) + (*(USHORT*)(pFS_TV_Table+18)));
    SetVSyncStart(DISP1, *(USHORT*)(pFS_TV_Table+20));
    SetVSyncEnd(DISP1, (*(USHORT*)(pFS_TV_Table+20)) + (*(USHORT*)(pFS_TV_Table+22)));

    SetDPAReg(4);
}


UCHAR SenseFS473TV(UCHAR ucI2CPort, UCHAR ucI2CAddr)
{
    UCHAR ucRegd4Data;
    UCHAR ucRegd9Data;
    int i;

    ReadI2C(ucI2CPort, ucI2CAddr, 0xd4, &ucRegd4Data);
    WriteI2C(ucI2CPort, ucI2CAddr, 0xd4, 0);
    
    WriteI2C(ucI2CPort, ucI2CAddr, 0xd5, 0);
    WriteI2C(ucI2CPort, ucI2CAddr, 0x9e, 0xe0);
    WriteI2C(ucI2CPort, ucI2CAddr, 0x9f, 0x01);
    WriteI2C(ucI2CPort, ucI2CAddr, 0x9c, 0x28);
    WriteI2C(ucI2CPort, ucI2CAddr, 0x9d, 0x49);

    for (i=0; i<10; i++)
    {
        ReadI2C(ucI2CPort, ucI2CAddr, 0x9d, &ucRegd9Data);
        if (ucRegd9Data & BIT6)
            break;
    }

    WriteI2C(ucI2CPort, ucI2CAddr, 0xd4, ucRegd4Data);
    WriteI2C(ucI2CPort, ucI2CAddr, 0xd5, 0);

    return ucRegd9Data;
}

void vSetFS473CCRSLevel(UCHAR bCCRSLevel)
{
    xf86DrvMsgVerb(0, X_INFO, 4, "Enter vSetFS473CCRSLevel()\n");

    UCHAR       ucI2CPort, ucI2CAddr;
    PORT_CONFIG *pDevicePortConfig;
    
    GetDevicePortConfig(TV_ID, &pDevicePortConfig);
    ucI2CPort = pDevicePortConfig->TX_I2C_Port;
    ucI2CAddr = pDevicePortConfig->TX_I2C_Addr;

    xf86DrvMsgVerb(0, X_INFO, 4, "bCCRSLevel : %X\n", bCCRSLevel);
    xf86DrvMsgVerb(0, X_INFO, 4, "pDevicePortConfig->TX_I2C_Port : %X\n", pDevicePortConfig->TX_I2C_Port);
    xf86DrvMsgVerb(0, X_INFO, 4, "pDevicePortConfig->TX_I2C_Addr : %X\n", pDevicePortConfig->TX_I2C_Addr);

    UCHAR bTmpdata[4],i;
    
    bTmpdata[1]= 0;
    bTmpdata[3]= 0;
    switch(bCCRSLevel)
    {
        case 2:
            bTmpdata[0]= 0x8;
            bTmpdata[2]= 0xC;
        break;
        case 1:
            bTmpdata[0]= 0x8;
            bTmpdata[2]= 0x6;    
        break;
        case 0:
        default:
            bTmpdata[0]= 0x0;
            bTmpdata[2]= 0x0;
        break;
    }

    for(i=0; i<4; i++)
        WriteI2C(ucI2CPort, ucI2CAddr,i+0x20,bTmpdata[i]);

    xf86DrvMsgVerb(0, X_INFO, 4, "Exit vSetFS473CCRSLevel()\n");
}


void SetFS473HPosition(UCHAR bHPosition)
{
    xf86DrvMsgVerb(0, X_INFO, 4, "Enter SetFS473HPosition()\n");

    UCHAR       ucI2CPort, ucI2CAddr;
    PORT_CONFIG *pDevicePortConfig;
   
    GetDevicePortConfig(TV_ID, &pDevicePortConfig);
    ucI2CPort = pDevicePortConfig->TX_I2C_Port;
    ucI2CAddr = pDevicePortConfig->TX_I2C_Addr;

    xf86DrvMsgVerb(0, X_INFO, 4, "bHPosition : %X\n", bHPosition);
    xf86DrvMsgVerb(0, X_INFO, 4, "pDevicePortConfig->TX_I2C_Port : %X\n", pDevicePortConfig->TX_I2C_Port);
    xf86DrvMsgVerb(0, X_INFO, 4, "pDevicePortConfig->TX_I2C_Addr : %X\n", pDevicePortConfig->TX_I2C_Addr);
    
    WriteI2C(ucI2CPort, ucI2CAddr, Reg_FS473HPos, bHPosition);
    WriteI2C(ucI2CPort, ucI2CAddr, (Reg_FS473HPos+1), 0);

    xf86DrvMsgVerb(0, X_INFO, 4, "Exit SetFS473HPosition()\n");
}

void SetFS473VPosition(UCHAR bVPosition)
{
    xf86DrvMsgVerb(0, X_INFO, 4, "Enter SetFS473VPosition()\n");

    UCHAR       ucI2CPort, ucI2CAddr;
    PORT_CONFIG *pDevicePortConfig;

    GetDevicePortConfig(TV_ID, &pDevicePortConfig);
    ucI2CPort = pDevicePortConfig->TX_I2C_Port;
    ucI2CAddr = pDevicePortConfig->TX_I2C_Addr;

    xf86DrvMsgVerb(0, X_INFO, 4, "bVPosition : %X\n", bVPosition);
    xf86DrvMsgVerb(0, X_INFO, 4, "pDevicePortConfig->TX_I2C_Port : %X\n", pDevicePortConfig->TX_I2C_Port);
    xf86DrvMsgVerb(0, X_INFO, 4, "pDevicePortConfig->TX_I2C_Addr : %X\n", pDevicePortConfig->TX_I2C_Addr);

    WriteI2C(ucI2CPort, ucI2CAddr, Reg_FS473VPos, bVPosition);
    WriteI2C(ucI2CPort, ucI2CAddr, (Reg_FS473VPos+1), 0);

    xf86DrvMsgVerb(0, X_INFO, 4, "Exit SetFS473HPosition()\n");
}

void SetFS473HSCaler(RDCRecPtr pRDC, int iHScaler)
{
    xf86DrvMsgVerb(0, X_INFO, 4, "Enter SetFS473HSCaler()\n");

    USHORT wHres,wHScalerVector, wHScalerDiff; 
    int MAX_HScalerVector,MIN_HScalerVector;

    UCHAR       ucI2CPort, ucI2CAddr;
    PORT_CONFIG *pDevicePortConfig;
    UCHAR ucTvType = Get_TV_TYPE();
    VIDEOMODE *pVidMode = &(pRDC->VideoModeInfo);

    GetDevicePortConfig(TV_ID, &pDevicePortConfig);
    ucI2CPort = pDevicePortConfig->TX_I2C_Port;
    ucI2CAddr = pDevicePortConfig->TX_I2C_Addr;
    
    if(pRDC->bEnableTVPanning)
        wHres = pRDC->TVEncoderInfo[0].TVOut_HSize;
    else
        wHres = pVidMode->ScreenWidth;

    xf86DrvMsgVerb(0, X_INFO, 4, "wHres : %d\n", wHres);
        
    MAX_HScalerVector= 10; 
    MIN_HScalerVector= -10;
    switch(wHres)
    {
        case 640:
            wHScalerDiff     = 0x100;
            if(ucTvType) 
                wHScalerVector   = 0xA00;
            else 
                wHScalerVector   = 0xC00; 
        break;
        case 720:
            wHScalerDiff     = 0x1 ;
            if(ucTvType) 
                wHScalerVector   = 0xF5;
            else 
                wHScalerVector   = 0xF9; 
        break;
        case 800:
            wHScalerDiff     = 0x1 ;
            if(ucTvType) 
                 wHScalerVector   = 0xE9;
            else 
                 wHScalerVector   = 0xEB;
         break;
        case 1024:
            wHScalerDiff     = 0x100; 
            if(ucTvType) 
                wHScalerVector   = 0x2B00;
            else 
                wHScalerVector   = 0x2700; 
        break;
        default:
            xf86DrvMsgVerb(0, X_INFO, 4, 0, "FS473 Set H Scaler Fail!!\n");
        break;
    }
    
    if(iHScaler>0) 
    {
        if(iHScaler > MAX_HScalerVector)
        {
            wHScalerVector   += (USHORT)(wHScalerDiff*MAX_HScalerVector);
            
        }else
        {
            wHScalerVector   += (USHORT)(wHScalerDiff*iHScaler);
        }
    }else 
    {
        if(iHScaler < MIN_HScalerVector)
        {
            iHScaler = -MIN_HScalerVector;
            wHScalerVector   -= (USHORT)(wHScalerDiff*iHScaler);
            
        }else
        {
            iHScaler = -iHScaler;
            wHScalerVector   -= (USHORT)(wHScalerDiff*iHScaler);
        }
    }

    WriteI2C(ucI2CPort, ucI2CAddr,Reg_FS473HScaler,(UCHAR)wHScalerVector);
    WriteI2C(ucI2CPort, ucI2CAddr,(Reg_FS473HScaler+1),(UCHAR)(wHScalerVector>>8));

    xf86DrvMsgVerb(0, X_INFO, 4, "Exit SetFS473HSCaler()\n");
}

void vSetFS473VScalingLevel(RDCRecPtr pRDC, UCHAR bVScalingLevel)
{
    UCHAR i;
    USHORT wHres;

    UCHAR ucTvType = Get_TV_TYPE();
    VIDEOMODE *pVidMode = &(pRDC->VideoModeInfo);

    if(pRDC->bEnableTVPanning)
        wHres = pRDC->TVEncoderInfo[0].TVOut_HSize;
    else
        wHres = pVidMode->ScreenWidth;
        
    CBIOSSetFS473VScalingLevel(pRDC, bVScalingLevel, ucTvType, wHres);
}

void CBIOSSetFS473VScalingLevel(RDCRecPtr pRDC, UCHAR bVScalingLevel, UCHAR TVType, USHORT wHres)
{
    FSVSRegdata *FSScalingTAble;
    UCHAR i,ucI2CPort, ucAddr;

    PORT_CONFIG *pDevicePortConfig;
    UCHAR ucTvType = Get_TV_TYPE();
    VIDEOMODE *pVidMode = &(pRDC->VideoModeInfo);
    
    GetDevicePortConfig(TV_ID, &pDevicePortConfig);
    ucI2CPort = pDevicePortConfig->TX_I2C_Port;
    ucAddr = pDevicePortConfig->TX_I2C_Addr;

    
    for(i=0; i<TVVESAModeCnt; i++)
    {
        if((FocusVScaleringTable[i].ucTVType == TVType) &&
           (FocusVScaleringTable[i].wHRes    == wHres))
        {
            FSScalingTAble = &(FocusVScaleringTable[i].ScalerTable[bVScalingLevel]);
            break;
        }
    }
    if(i!=TVVESAModeCnt)
    {
        UCHAR ucAddress;
        UCHAR ucColor[6]={0xA0,0,0xDB,0,0x7E,0};
        
        
        
        
        for(i=0; i<6; i++)
            WriteI2C(ucI2CPort, ucAddr, 0xA8+i, 0);
        
        UnLockDisplay1Timing();
        SetVTotal(1, FSScalingTAble->VTotal);        
        SetVBlankingEnd(1, FSScalingTAble->VTotal);  
        LockDisplay1Timing();
        
        
        for(i=0; i<10; i++)
        {
            WriteI2C(ucI2CPort, ucAddr, i+0xC6, FSScalingTAble->ucData[i]);
        }
        
        for(i=10; i<18; i++)
        {
            WriteI2C(ucI2CPort, ucAddr, i+8, FSScalingTAble->ucData[i]);
        }
        
        WriteI2C(ucI2CPort, ucAddr, 0x6, FSScalingTAble->ucData[18]);
        WriteI2C(ucI2CPort, ucAddr, 0x7, FSScalingTAble->ucData[19]);
        
        
        
        for(i=0; i<6; i++)
            WriteI2C(ucI2CPort, ucAddr, 0xA8+i, ucColor[i]);
    }
}

void GetFS473PositionFromVBIOS(RDCRecPtr pRDC)
{
    
    USHORT   wHres;
    VIDEOMODE *pVidMode = &(pRDC->VideoModeInfo);
    
    if(pRDC->bEnableTVPanning)
        wHres = pRDC->TVEncoderInfo[0].TVOut_HSize;
    else
        wHres = pVidMode->ScreenWidth;
        
    switch(wHres)    
    {
        case 640:
            if(pRDC->TVEncoderInfo[0].TVType) 
            {
                pRDC->TVEncoderInfo[0].ucHPosition = 0x1a;
                pRDC->TVEncoderInfo[0].ucVPosition = 0x2c;
            }else 
            {
                pRDC->TVEncoderInfo[0].ucHPosition = 0x5b;
                pRDC->TVEncoderInfo[0].ucVPosition = 0x18;
            }
        break;
        case 720:
            if(pRDC->TVEncoderInfo[0].TVType) 
            {
                pRDC->TVEncoderInfo[0].ucHPosition = 0x30;
                pRDC->TVEncoderInfo[0].ucVPosition = 0x20;
            }else 
            {
                pRDC->TVEncoderInfo[0].ucHPosition = 0x20;
                pRDC->TVEncoderInfo[0].ucVPosition = 0x16;
            }
        break;
        case 800:        
            if(pRDC->TVEncoderInfo[0].TVType) 
            {
                pRDC->TVEncoderInfo[0].ucHPosition = 0x41;
                pRDC->TVEncoderInfo[0].ucVPosition = 0x43;
            }else 
            {
                pRDC->TVEncoderInfo[0].ucHPosition = 0x8b;
                pRDC->TVEncoderInfo[0].ucVPosition = 0x1b;
            }
        break;
        case 1024:        
            if(pRDC->TVEncoderInfo[0].TVType) 
            {
                pRDC->TVEncoderInfo[0].ucHPosition = 0x42;
                pRDC->TVEncoderInfo[0].ucVPosition = 0x57;
            }else 
            {
                pRDC->TVEncoderInfo[0].ucHPosition = 0x32;
                pRDC->TVEncoderInfo[0].ucVPosition = 0x26;
            }
        break;
        default:
            pRDC->TVEncoderInfo[0].ucHPosition = 0xa0;
            pRDC->TVEncoderInfo[0].ucVPosition = 0x2a;
        break;
    }
    pRDC->TVEncoderInfo[0].iHScaler = 0;
}

