/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include "typedef.h"
#include "timingtbl.h"
#include "CInt10.h"
#include "output.h"
#include "vbiosdata.h"
#include "io.h"
#include "debug.h"



void LoadTiming(UCHAR bDisplayPath, USHORT wModeNum)
{
    UCHAR bDeviceIndex = Get_DEV_ID(bDisplayPath);

    UnLockDisplay1Timing();
     

    switch(bDeviceIndex)
    {
        case CRT_ID:
        case CRT2_ID:
        case DVI_ID:
        case DVI2_ID:
            LoadVESATiming(bDisplayPath, wModeNum);
            break;

        case LCD_ID:
        case LCD2_ID:
            LoadLCDTiming(bDisplayPath, wModeNum);
            LockDisplay1Timing();
        case TV_ID:
        case TV2_ID:
            LoadTVTiming(bDisplayPath, wModeNum, bDeviceIndex);
            LockDisplay1Timing();
            break;
            
        case HDMI_ID:
        case HDMI2_ID:
            LoadHDMITiming(bDisplayPath, wModeNum);
            LockDisplay1Timing();
            break;
            
        default:
            break;
    }

}


CI_STATUS Get_MODE_INFO(USHORT wModeNum, MODE_INFO **ppModeInfo)
{
    if (Get_MODE_INFO_From_VESA_Table(wModeNum, ppModeInfo))
    {
        return true;
    }
    else if(isLCDFitMode(LCD_ID, wModeNum))
    {
        Get_MODE_INFO_From_LCD_Table(LCD_ID, ppModeInfo);
        return true;
    }
    else if(isLCDFitMode(LCD2_ID, wModeNum))
    {
        Get_MODE_INFO_From_LCD_Table(LCD2_ID, ppModeInfo);
        return true;
    }
    else
    {
        return false;
    }
}


CI_STATUS GetModeColorDepth(USHORT wModeNum, MODE_INFO *pModeInfo, UCHAR *pucColorDepth)
{
    if(pModeInfo->Mode_ID_8bpp == wModeNum)
    {
        *pucColorDepth = 8;
        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit1 GetModeColorDepth()== *pucColorDepth = %d\n", *pucColorDepth);
        return true;
    }
    else if(pModeInfo->Mode_ID_16bpp == wModeNum)
    {
        *pucColorDepth = 16;
        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit2 GetModeColorDepth()== *pucColorDepth = %d\n", *pucColorDepth);
        return true;
    }
    else if(pModeInfo->Mode_ID_32bpp == wModeNum)
    {
        *pucColorDepth = 32;
        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit3 GetModeColorDepth()== *pucColorDepth = %d\n", *pucColorDepth);
        return true;
    }
    else
    {
        *pucColorDepth = 0;
        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit4 GetModeColorDepth()== *pucColorDepth = %d\n", *pucColorDepth);
        return false;
    }    
}

CI_STATUS GetModePitch(USHORT ModeNum, USHORT *pPitch)
{
    MODE_INFO *pModeInfo = NULL;
    UCHAR ucColorDepth = 0;
    
    
    if(!Get_MODE_INFO(ModeNum, &pModeInfo))
    {
        return false;
    }
    else
    {
        if(!GetModeColorDepth(ModeNum, pModeInfo, &ucColorDepth))
        {
            return false;
        }
        else
        {
            ucColorDepth = ucColorDepth >> 4;
            *pPitch = ((pModeInfo->H_Size << ucColorDepth)+0x7)&0xFFF8;
        }
    }

    return true;
}


CI_STATUS CheckForModeAvailable(USHORT ModeNum)
{
    MODE_INFO *pModeInfo = NULL;
    return Get_MODE_INFO_From_VESA_Table(ModeNum, &pModeInfo);
}

CI_STATUS CheckForNewDeviceAvailable(UCHAR bDeviceIndex)
{
    PORT_CONFIG *pDevicePortConfig;
    
    return GetDevicePortConfig(bDeviceIndex, &pDevicePortConfig);
}

void LoadDisplay1VESAModeInitRegs()
{
    UCHAR *pucDisplay1VESAModeInitRegs = (UCHAR*)Display1VESAModeInitRegs;
    
    OutPort(MISC_WRITE, 0x2F);

    UnLockCR0ToCR7();
    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "&pucDisplay1VESAModeInitRegs = 0x%x\n", &pucDisplay1VESAModeInitRegs);
    SerialLoadTable(&pucDisplay1VESAModeInitRegs, 0, 0);

    ResetATTR();
    
    SetARReg(0x10, *pucDisplay1VESAModeInitRegs);
    pucDisplay1VESAModeInitRegs++;
    SetARReg(0x11, *pucDisplay1VESAModeInitRegs);
    pucDisplay1VESAModeInitRegs++;
    SetARReg(0x12, *pucDisplay1VESAModeInitRegs);
    pucDisplay1VESAModeInitRegs++;
    SetARReg(0x13, *pucDisplay1VESAModeInitRegs);
    pucDisplay1VESAModeInitRegs++;
    SetARReg(0x14, *pucDisplay1VESAModeInitRegs);
    
    EnableATTR();
}

void VESASetBIOSData(USHORT ModeNum)
{
    
}


void DisableDisplayPathAndDevice(UCHAR bDisplayPath)
{
    UCHAR bDeviceIndex = Get_DEV_ID(bDisplayPath);

    
    ControlPwrSeqOff(bDeviceIndex);

    

    
    TurnOffDigitalPort(bDeviceIndex);
    
    
    SequencerOff(bDisplayPath);
}



