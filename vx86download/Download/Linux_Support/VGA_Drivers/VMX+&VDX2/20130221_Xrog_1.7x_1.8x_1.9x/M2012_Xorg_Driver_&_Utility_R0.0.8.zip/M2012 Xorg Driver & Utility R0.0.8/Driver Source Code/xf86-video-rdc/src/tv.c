/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 #include "vbiosdata.h"
#include "CInt10.h"
#include "io.h"
#include "scratchpad.h"
#include "debug.h"



#define TVMode3              0
#define TVMode6x4            3
#define TVMode7x4            4
#define TVMode7x5            5
#define TVMode8x6            6
#define TVMode1024           7




void Clear_TV_Polarity(UCHAR ucTvModeIndex)
{
    if (bTVSUPPORT)
    {
        if (ucTvModeIndex > TVMode6x4)
            return;

        OutPort(MISC_WRITE, (InPort(MISC_READ) & 0x3F));
    }
}

void EnableTVClock()
{
    SetCRReg(0xD0, BIT6, BIT6);
}

void DisableTVClock()
{
    SetCRReg(0xD0, 0, BIT6);
    SetTVConnectionRegs(0);
}


void SetTVConnectionRegs(UCHAR ucTvConnectionType)
{
    PORT_CONFIG *pDevicePortConfig;
    UCHAR ucI2CPort, ucI2CAddr;

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "==Enter %s(ucTvConnectionType = %d)==\n", __func__, ucTvConnectionType);
    
    if (!GetDevicePortConfig(TV_ID, &pDevicePortConfig))
        return;

    
    if (pDevicePortConfig->TX_Enc_ID == ENC_SAA7105)
    {
        if (ENC_SAA7105 == Get_TV_Encoder_Index())
        {
            ucI2CPort = pDevicePortConfig->TX_I2C_Port;
            ucI2CAddr = pDevicePortConfig->TX_I2C_Addr;
        
            if (ucTvConnectionType == 0)
            {
                WriteI2C(ucI2CPort, ucI2CAddr, 0x61, 0x40);
                WriteI2C(ucI2CPort, ucI2CAddr, 0x2D, 0x08);
            }
            else if (ucTvConnectionType == CVBS)
            {
                WriteI2C(ucI2CPort, ucI2CAddr, 0x2D, 0x24);
            }
            else if (ucTvConnectionType == SVideo)
            {
                WriteI2C(ucI2CPort, ucI2CAddr, 0x2D, 0x94);
            }
            else if (ucTvConnectionType == CVBS+SVideo)
            {
                WriteI2C(ucI2CPort, ucI2CAddr, 0x2D, 0xB4);
            }
        }
    }

    if (pDevicePortConfig->TX_Enc_ID == ENC_FS473)
    {
        if (Get_TV_Encoder_Index() == ENC_FS473)
        {
            ucI2CPort = pDevicePortConfig->TX_I2C_Port;
            ucI2CAddr = pDevicePortConfig->TX_I2C_Addr;

            if (ucTvConnectionType == 0)
            {
                WriteI2C(ucI2CPort, ucI2CAddr, 0xd4, 0x03);
            }
            else
            {
                WriteI2C(ucI2CPort, ucI2CAddr, 0xd4, 0x00);

            }
            WriteI2C(ucI2CPort, ucI2CAddr, 0xd5, 0x00);;
        }
    }
}


void LoadTVTiming(UCHAR ucDisplayPath, USHORT usModeNum)
{
    PORT_CONFIG *pDevicePortConfig;    
    UCHAR ucTvConnectType;
    void *pSAA_TV_Table;
    void *pFS_TV_Table;

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "==Enter %s(usModeNum = 0x%x)==\n", __func__, usModeNum);
    
    if(!GetDevicePortConfig(TV_ID, &pDevicePortConfig))
        return;
        
    if(pDevicePortConfig->TX_Enc_ID == ENC_SAA7105)
    {
        GetSAA7105ModeTable(&pSAA_TV_Table);  
        SetSAA7105ModeRegs(pSAA_TV_Table);
    }
    if(pDevicePortConfig->TX_Enc_ID == ENC_FS473)
    {
        GetFSModeTable(&pFS_TV_Table);          
        SetFSModeRegs(pFS_TV_Table);
        if (TVMode3 == Get_TV1_Mode_Index())
            Set8DotCharacter();
    }

    
    EnableTVClock();
    ucTvConnectType = Get_TV_CONNECTION_TYPE(DISP1);
    SetTVConnectionRegs(ucTvConnectType);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "==Exit %s()==\n", __func__);
}

void PatchPLLbyTVEncoder(ULONG ulPixelClock)
{
    UCHAR ucNewDeviceId = Get_NEW_DEV_ID(DISP1);
    PORT_CONFIG *pDevicePortConfig;
    UCHAR ucI2CPort;
    UCHAR ucI2CAddr;
    void *pPLLSAA7105TVEnc = PLLSAA7105TVEnc;
    void *pPLLFS473TVEnc = PLLFS473TVEnc;
    int i;
    
    if (ucNewDeviceId == CRT_ID)
        return;
    else if (ucNewDeviceId == 0)
        return;
    else if (!GetDevicePortConfig(TV_ID, &pDevicePortConfig))
        return;

    ucI2CPort = pDevicePortConfig->TX_I2C_Port;
    ucI2CAddr = pDevicePortConfig->TX_I2C_Addr;

    if (pDevicePortConfig->TX_Enc_ID == ENC_SAA7105)
    {
        while (*(ULONG*)pPLLSAA7105TVEnc != ulPixelClock)
        {
            if (*(UCHAR*)pPLLSAA7105TVEnc == 0xff)
                return;

            pPLLSAA7105TVEnc += 7;
        }
        pPLLSAA7105TVEnc += 4;

        for (i=0; i<3; i++)
            WriteI2C(ucI2CPort, ucI2CAddr, 0x81+i, *(UCHAR*)(pPLLSAA7105TVEnc+i));

        WriteI2C(ucI2CPort, ucI2CAddr, 0x84, 0xa5);
    }
    else if (pDevicePortConfig->TX_Enc_ID == ENC_FS473)
    {
        while (*(ULONG*)pPLLFS473TVEnc != ulPixelClock)
        {
            if (*(UCHAR*)pPLLFS473TVEnc == 0xff)
                return;

            pPLLFS473TVEnc += 14;
        }
        pPLLFS473TVEnc += 4;

        for (i=0; i<10; i++)
            WriteI2C(ucI2CPort, ucI2CAddr, 0xc6+i, *(UCHAR*)(pPLLFS473TVEnc+i));
    }

    EnableTVClock();
}


CI_STATUS SetTVVESAModeIndex(USHORT usModeNum)
{
    int iTvVesaModeCnt = (int)(*(UCHAR*)TVVESAModeConfig);
    int i;
    TVVESAMODETBL *pTvVesaModeTbl = TVVESAModeConfig+1;

    if (bTVSUPPORT)
    {
        for (i = 0; i < iTvVesaModeCnt; i++, pTvVesaModeTbl++)
        {
            if ((pTvVesaModeTbl->TVMode_ID_8bpp == usModeNum) || (pTvVesaModeTbl->TVMode_ID_16bpp == usModeNum) || (pTvVesaModeTbl->TVMode_ID_32bpp == usModeNum))
            {
                Set_TV1_Mode_Index (pTvVesaModeTbl->TVVESAModeIndex);
                CBIOS_PRINTLOG(0, X_INFO, InternalLevel, " Set_TV1_Mode_Index = %d\n", pTvVesaModeTbl->TVVESAModeIndex);
                return true;
            }
        }
    }

    return false;
}


CI_STATUS SenseTV()
{
    PORT_CONFIG *pDevicePortConfig;
    UCHAR ucI2CPort, ucI2CAddr, ucTxEncID;
    
    if (bTVSUPPORT)
    {
        GetDevicePortConfig(TV_ID, &pDevicePortConfig);
        ucI2CPort = pDevicePortConfig->TX_I2C_Port;
        ucI2CAddr = pDevicePortConfig->TX_I2C_Addr;
        ucTxEncID = pDevicePortConfig->TX_Enc_ID;
        
        if (ucTxEncID == ENC_SAA7105)
        {
            if (SenseSAA7105TV(ucI2CPort, ucI2CAddr) & (CVBS+SVideo))
                return true;
        }
        else if (ucTxEncID == ENC_FS473)
        {
            if (SenseFS473TV(ucI2CPort, ucI2CAddr) & BIT3)
                return true;

        }
        else
            return true;
    }
        return false;
}


USHORT GetTVPanningModeIndex(RDCRecPtr pRDC, MODE_INFO *pModeInfo, UCHAR bColorDepth)
{
    xf86DrvMsgVerb(0, X_INFO, 4, "Enter GetTVPanningModeIndex()\n");

    USHORT wVESAModeNum;

    
    if (pModeInfo->H_Size > pRDC->TVEncoderInfo[0].TVOut_HSize)
        pRDC->TVEncoderInfo[0].bEnableHPanning = true;
    else
        pRDC->TVEncoderInfo[0].bEnableHPanning = false;

    
    if (pModeInfo->V_Size > pRDC->TVEncoderInfo[0].TVOut_VSize)
        pRDC->TVEncoderInfo[0].bEnableVPanning = true;
    else
        pRDC->TVEncoderInfo[0].bEnableVPanning = false;
    
    if (pRDC->bEnableTVPanning)
    {
        switch (bColorDepth)
        {
            case 8:
                if (pRDC->TVEncoderInfo[0].TVOut_HSize == 640)
                    wVESAModeNum = 0x101;
                else if (pRDC->TVEncoderInfo[0].TVOut_HSize == 800)
                    wVESAModeNum = 0x103;
                else
                    wVESAModeNum = 0x105;
                break;
            case 16:
                if (pRDC->TVEncoderInfo[0].TVOut_HSize == 640)
                    wVESAModeNum = 0x111;
                else if (pRDC->TVEncoderInfo[0].TVOut_HSize == 800)
                    wVESAModeNum = 0x114;
                else
                    wVESAModeNum = 0x117;
                break;
            case 32:
                if (pRDC->TVEncoderInfo[0].TVOut_HSize == 640)
                    wVESAModeNum = 0x112;
                else if (pRDC->TVEncoderInfo[0].TVOut_HSize == 800)
                    wVESAModeNum = 0x115;
                else
                    wVESAModeNum = 0x118;
                break;
        };
    };

    xf86DrvMsgVerb(0, X_INFO, 4, "wVESAModeNum : %X\n", wVESAModeNum);

    xf86DrvMsgVerb(0, X_INFO, 4, "Exit GetTVPanningModeIndex()\n");

    return wVESAModeNum;
};
