/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
     

#include "CInt10.h"
#include "scratchpad.h"
#include "tv.h"
#include "output.h"
#include "vbiosdata.h"
#include "debug.h"


CI_STATUS GetSAA7105ModeTable(void **ppSAA_TV_Table)
{
    UCHAR ucTvType = Get_TV_TYPE();
    UCHAR ucTv1ModeIndex = Get_TV1_Mode_Index();
    TVTBLDATA *pSAATable = SAA_Table_Start;
    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "==Enter %s()==\n", __func__);
    CBIOS_PRINTLOG(0, X_INFO, InternalLevel, " ucTv1ModeIndex = %d\n", ucTv1ModeIndex);
    
    if (PAL < ucTvType)        
    {
        CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "==Exit1 %s(), return false==\n", __func__);
        return false;
    }
    
    Clear_TV_Polarity(ucTv1ModeIndex);

    while(pSAATable->TVModeIndex != 0xFF)
    {
        if (pSAATable->TVModeIndex != ucTv1ModeIndex)
        {
            CBIOS_PRINTLOG(0, X_INFO, InternalLevel, " pSAATable = 0x%x\n", pSAATable);
            CBIOS_PRINTLOG(0, X_INFO, InternalLevel, " pSAATable->TVModeIndex = %d\n", pSAATable->TVModeIndex);
            pSAATable++;
            continue;
        }

        if (ucTvType == NTSC)
        {
            CBIOS_PRINTLOG(0, X_INFO, InternalLevel, " pSAATable->TVNTSCTP = 0x%x\n", pSAATable->TVNTSCTP);
            CBIOS_PRINTLOG(0, X_INFO, InternalLevel, " pSAATable->TVPALTP = 0x%x\n", pSAATable->TVPALTP);
            *ppSAA_TV_Table = (void*)(((ULONG)(pSAATable->TVNTSCTP)) + (ULONG)BiosInfoData);
            CBIOS_PRINTLOG(0, X_INFO, InternalLevel, " *ppSAA_TV_Table = 0x%x\n", *ppSAA_TV_Table);
        }
        else if (ucTvType == PAL)
            *ppSAA_TV_Table = (void*)(((ULONG)(pSAATable->TVPALTP)) + (ULONG)BiosInfoData);

        if (*ppSAA_TV_Table != NULL)
        {
            CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "==Exit2 %s(), return true==\n", __func__);
            return true;
        }

        break;
    }
    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "==Exit3 %s(), return false==\n", __func__);
    return false;
}


void SetSAA7105ModeRegs(void *pSAA_TV_Table)
{
    int         i;
    UCHAR       ucI2CPort, ucI2CAddr;
    PORT_CONFIG *pDevicePortConfig;

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "==Enter %s(pSAA_TV_Table = 0x%x)==\n", __func__, pSAA_TV_Table);
    
    GetDevicePortConfig(TV_ID, &pDevicePortConfig);

    ucI2CPort = pDevicePortConfig->TX_I2C_Port;
    ucI2CAddr = pDevicePortConfig->TX_I2C_Addr;

        
    for (i = 0; i < 13; i++, pSAA_TV_Table++)
    {
        WriteI2C(ucI2CPort, ucI2CAddr, 0x5A+i, *(UCHAR *)(pSAA_TV_Table));
    }
    
        
    for (i = 0; i < 17; i++, pSAA_TV_Table++) 
    {
        WriteI2C(ucI2CPort, ucI2CAddr, 0x6c+i, *(UCHAR *)(pSAA_TV_Table));
    }

        
    for (i = 0; i < 5; i++, pSAA_TV_Table++) 
    {
        WriteI2C(ucI2CPort, ucI2CAddr, 0x81+i, *(UCHAR *)(pSAA_TV_Table));
    }

        
    for (i = 0; i < 16; i++, pSAA_TV_Table++) 
    {
        WriteI2C(ucI2CPort, ucI2CAddr, 0x90+i, *(UCHAR *)(pSAA_TV_Table));
    }

    SetHTotal(DISP1, *(USHORT *)(pSAA_TV_Table));
    SetHDisplayEnd(DISP1, *(USHORT *)(pSAA_TV_Table+2));
    SetHBlankingStart(DISP1, *(USHORT *)(pSAA_TV_Table+4));
    SetHBlankingEnd(DISP1, (*(USHORT *)(pSAA_TV_Table+4)) + (*(USHORT *)(pSAA_TV_Table+6)));
    SetHSyncStart(DISP1, *(USHORT *)(pSAA_TV_Table+8));
    SetHSyncEnd(DISP1, (*(USHORT *)(pSAA_TV_Table+8)) + (*(USHORT *)(pSAA_TV_Table+10)));

    SetVTotal(DISP1, *(USHORT *)(pSAA_TV_Table+12));
    SetVDisplayEnd(DISP1, *(USHORT *)(pSAA_TV_Table+14));
    SetVBlankingStart(DISP1, *(USHORT *)(pSAA_TV_Table+16));
    SetVBlankingEnd(DISP1, (*(USHORT *)(pSAA_TV_Table+16))+(*(USHORT *)(pSAA_TV_Table+18)));
    SetVSyncStart(DISP1, *(USHORT *)(pSAA_TV_Table+20));
    SetVSyncEnd(DISP1, (*(USHORT *)(pSAA_TV_Table+20))+(*(USHORT *)(pSAA_TV_Table+22)));

    SetDPAReg(*(UCHAR *)(pSAA_TV_Table+24));

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "==Exit %s()==\n", __func__);
}


UCHAR SenseSAA7105TV(UCHAR ucI2CPort, UCHAR ucI2CAddr)
{
    UCHAR ucReg2dData;
    UCHAR ucReg61Data;
    UCHAR ucReg1bData;

    ReadI2C(ucI2CPort, ucI2CAddr, 0x2d, &ucReg2dData);
    WriteI2C(ucI2CPort, ucI2CAddr, 0x2d, 0xb4);

    ReadI2C(ucI2CPort, ucI2CAddr, 0x61, &ucReg61Data);
    WriteI2C(ucI2CPort, ucI2CAddr, 0x61, ucReg61Data & 0x3f);

    WriteI2C(ucI2CPort, ucI2CAddr, 0x1a, 0x46);

    WriteI2C(ucI2CPort, ucI2CAddr, 0x1b, 0x80);
    WriteI2C(ucI2CPort, ucI2CAddr, 0x1b, 0);
    ReadI2C(ucI2CPort, ucI2CAddr, 0x1b, &ucReg1bData);

    ucReg1bData &= (BIT0+BIT1+BIT2);

    WriteI2C(ucI2CPort, ucI2CAddr, 0x61, ucReg61Data);

    WriteI2C(ucI2CPort, ucI2CAddr, 0x2d, ucReg2dData);

    if (ucReg1bData == (BIT1+BIT2))
        return CVBS;
    else if (ucReg1bData == BIT1)
        return SVideo;
    else if (ucReg1bData == (BIT0+BIT1+BIT2))
        return 0;
    else
        return (BIT0+BIT1+BIT2);

}


