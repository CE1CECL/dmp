/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 

#ifndef __VBIOSDATA_H__
#define __VBIOSDATA_H__

#include "typedef.h"
#include "output.h"
#include "timingtbl.h"
#include "tv.h"


extern bool bCRTSUPPORT;
extern bool bLCDSUPPORT;
extern bool bDVISUPPORT;
extern bool bTVSUPPORT;
extern bool bHDMISUPPORT;

extern bool bDS_SUPPORT;


extern PORT_CONFIG *pPortConfig;
extern MODE_INFO   *pLCDTable;
extern MODE_INFO   *pVESATable;
extern void *PCIDataStruct;
extern void *BiosInfoData;
extern HDMITxDetect *pTMDSTxTable;



extern void *Display1VESAModeInitRegs;


extern void *POSTInItRegs;
extern void *DDRII400Tbl;
extern void *DDRII533Tbl;
extern void *ExtendRegs2;


extern void *EP932M_INIT_TBL;


extern void *EP932M_AVI_TBL;
extern void *IT6610_AVI_TBL;
extern void *PLLFS473TVEnc;


extern TVTBLDATA *SAA_Table_Start;
extern TVTBLDATA *FS_Table_Start;
extern void *FS_REG_RESET_GROUP;
extern void *FS_REG_GROUP;
extern void *FS_REG_NTSC_GROUP;
extern void *FS_REG_PAL_GROUP;
extern void *TVVESAModeConfig;
extern void *PLLSAA7105TVEnc;


extern USHORT Relocate_IOAddress;


#define OFF_VID             0
#define OFF_DID             2
#define OFF_PTR_VPD         4
#define OFF_PCI_DS_LEN      6
#define OFF_PCI_DS_REV      8
#define OFF_CLASS_CODE1     9
#define OFF_CLASS_CODE2     10
#define OFF_CLASS_CODE3     11
#define OFF_SIZE_VBIOS      12
#define OFF_ROM_CODE_REV    14
#define OFF_PC_AT_COMP      16
#define OFF_LII             17
#define OFF_RESERVED        18

#endif 

