/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 

#ifndef __IO_H__
#define __IO_H__

#define ATTR_ADDR                   0X0040
#define ATTR_DATA_WRITE             0X0040
#define ATTR_DATA_READ              0X0041
#define MISC_WRITE                  0X0042
#define INPUT_STATUS_0_READ         0X0042
#define RIO_VGA_ENABLE              0X0043
#define SEQ_INDEX                   0X0044
#define SEQ_DATA                    0X0045
#define PEL_MASK                    0X0046
#define DAC_INDEX_READ              0X0047
#define FEAT_CTRL_READ              0X004A
#define MISC_READ                   0X004C
#define GRAPH_INDEX                 0X004E
#define GRAPH_DATA                  0X004F

#define MONO_CRTC_INDEX             0X0034
#define MONO_CRTC_DATA              0X0035
#define MONO_INPUT_STATUS1_READ     0X003A

#define COLOR_CRTC_INDEX            0X0054
#define COLOR_CRTC_DATA             0X0055
#define COLOR_INPUT_STATUS1_READ    0X005A

#endif 

