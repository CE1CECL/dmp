/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 typedef struct _HDMI_I2C_REG{
    UCHAR    ucIndex;
    UCHAR    ucData;
} HDMI_I2C_REG;

typedef struct _DVPDPA_TABLE
{
    ULONG   Clock;          
    BYTE    VGAValue;
    BYTE    TX_Index;
    BYTE    TX_Data;
} DVPDPA_TABLE;

HDMI_I2C_REG EP932M_INIT_Reg[]=
{
    {0x08, 0x0B},
    {0x0D, 0x08},
    {0x0E, 0x01},
    {0x63, 0x00},
    {0x64, 0x18},
    {0x65, 0x00},
    {0x3F, 0xF0},
    {0xFF, 0xFF}
};

DVPDPA_TABLE TMDS_EP932M[] = {
        {     0, 0x0, 0x0A, 0x8F},   
        { 70000, 0x4, 0x0A, 0x8F},   
        { 90000, 0x0, 0x0A, 0x8F},   
        {120000, 0x0, 0x0A, 0x1F},   
        {150000, 0x0, 0x0A, 0x1F}    
};

PORT_CONFIG PortConfig[]={
        {0,0,0,0,0,0}, 
        {0,0,0,0,0,0}, 
        {0,0,0,0,0,0}, 
        {0,0,0,0,0,0}  
};


typedef struct _HVRES_TYPE {
   unsigned char  HVPol;
   unsigned short Hres;
   unsigned short Vres;
   unsigned short Vprd;
} HVRES_TYPE, *PHVRES_TYPE;



typedef enum {
    PIX_FREQ_25175KHz = 0,
    PIX_FREQ_25200KHz,

    PIX_FREQ_27000KHz,
    PIX_FREQ_27027KHz,

    PIX_FREQ_54000KHz,
    PIX_FREQ_54054KHz,

    PIX_FREQ_72000KHz,

    PIX_FREQ_74176KHz,
    PIX_FREQ_74250KHz,

    PIX_FREQ_108000KHz,
    PIX_FREQ_108108KHz,

    PIX_FREQ_148352KHz,
    PIX_FREQ_148500KHz,

    PIX_FREQ_PC

} PIX_FREQ_TYPE;


#define  VPosHPos               0x00
#define  VPosHNeg               0x04
#define  VNegHPos               0x08
#define  VNegHNeg               0x0C


typedef struct _DE_GEN_SETTINGS { 
    unsigned short DE_DLY;
    unsigned short DE_CNT;
    unsigned char  DE_TOP;
    unsigned short DE_LIN;
} DE_GEN_SETTINGS, *PDE_GEN_SETTINGS;


typedef struct _E_SYNC_SETTINGS { 
    unsigned char  CTL;
    unsigned short H_DLY;
    unsigned short H_WIDTH;
    unsigned char  V_DLY;
    unsigned char  V_WIDTH;
    unsigned short V_OFST;
} E_SYNC_SETTINGS, *PE_SYNC_SETTINGS;


typedef struct _VDO_SETTINGS { 
    unsigned char   VideoCode;
    HVRES_TYPE      HVRes_Type;
    DE_GEN_SETTINGS DE_Gen;
    E_SYNC_SETTINGS E_Sync; 
    unsigned char   AR_PR;
    PIX_FREQ_TYPE   Pix_Freq_Type;
} VDO_SETTINGS, *PVDO_SETTINGS;


VDO_SETTINGS EP932_VDO_Settings[] = {
    
    {  0,{       0,   0,   0,    0},{  0,   0,  0,   0},{0x00,  0,  0,  0,  0,   0},  0x00,                  1}, 
    
    {  1,{VNegHNeg, 800, 525,16666},{ 48, 640, 34, 480},{0x00, 12, 96, 10,  2,   0},  0x10,  PIX_FREQ_25175KHz}, 
    {  2,{VNegHNeg, 858, 525,16666},{ 60, 720, 31, 480},{0x00, 12, 62,  9,  6,   0},  0x10,  PIX_FREQ_27000KHz}, 
    {  3,{VNegHNeg, 858, 525,16666},{ 60, 720, 31, 480},{0x00, 12, 62,  9,  6,   0},  0x20,  PIX_FREQ_27000KHz}, 
    {  4,{VPosHPos,1650, 750,16666},{220,1280, 21, 720},{0x00,106, 40,  5,  5,   0},  0x20,  PIX_FREQ_74176KHz}, 
    {  5,{VPosHPos,2200, 563,16666},{148,1920, 16, 540},{0x09, 84, 44,  2,  5,1100},  0x20,  PIX_FREQ_74176KHz}, 
    {  6,{VNegHNeg, 858, 262,16666},{ 57, 720, 16, 240},{0x09, 15, 62,  4,  3, 429},  0x15,  PIX_FREQ_27000KHz}, 
    {  7,{VNegHNeg, 858, 262,16666},{ 57, 720, 16, 240},{0x09, 15, 62,  4,  3, 429},  0x25,  PIX_FREQ_27000KHz}, 
    {  8,{VNegHNeg, 858, 262,16666},{ 57, 720, 16, 240},{0x00, 15, 62,  4,  3,   0},  0x15,  PIX_FREQ_27000KHz}, 
    {  9,{VNegHNeg, 858, 262,16666},{ 57, 720, 16, 240},{0x00, 15, 62,  4,  3,   0},  0x25,  PIX_FREQ_27000KHz}, 
    { 10,{VNegHNeg,3432, 262,16666},{228,2880, 16, 240},{0x09, 72,248,  4,  3,1716},  0x10,  PIX_FREQ_54000KHz}, 
    { 11,{VNegHNeg,3432, 262,16666},{228,2880, 16, 240},{0x09, 72,248,  4,  3,1716},  0x20,  PIX_FREQ_54000KHz}, 
    { 12,{VNegHNeg,3432, 262,16666},{228,2880, 16, 240},{0x00, 72,248,  4,  3,   0},  0x10,  PIX_FREQ_54000KHz}, 
    { 13,{VNegHNeg,3432, 262,16666},{228,2880, 16, 240},{0x00, 72,248,  4,  3,   0},  0x20,  PIX_FREQ_54000KHz}, 
    { 14,{VNegHNeg,1716, 525,16666},{120,1440, 31, 480},{0x00, 28,124,  9,  6,   0},  0x10,  PIX_FREQ_54000KHz}, 
    { 15,{VNegHNeg,1716, 525,16666},{120,1440, 31, 480},{0x00, 28,124,  9,  6,   0},  0x20,  PIX_FREQ_54000KHz}, 
    { 16,{VPosHPos,2200,1125,16666},{148,1920, 37,1080},{0x00, 84, 44,  4,  5,   0},  0x20, PIX_FREQ_148500KHz}, 
    { 17,{VNegHNeg, 864, 625,20000},{ 68, 720, 40, 576},{0x00,  8, 64,  5,  5,   0},  0x10,  PIX_FREQ_27000KHz}, 
    { 18,{VNegHNeg, 864, 625,20000},{ 68, 720, 40, 576},{0x00,  8, 64,  5,  5,   0},  0x20,  PIX_FREQ_27000KHz}, 
    { 19,{VPosHPos,1980, 750,20000},{220,1280, 21, 720},{0x00,436, 40,  5,  5,   0},  0x20,  PIX_FREQ_74250KHz}, 
    { 20,{VPosHPos,2640, 563,20000},{148,1920, 16, 540},{0x09,524, 44,  2,  5,1320},  0x20,  PIX_FREQ_74250KHz}, 
    { 21,{VNegHNeg, 864, 313,20000},{ 69, 720, 20, 288},{0x09,  8, 63,  2,  3, 432},  0x15,  PIX_FREQ_27000KHz}, 
    { 22,{VNegHNeg, 864, 313,20000},{ 69, 720, 20, 288},{0x09,  8, 63,  2,  3, 432},  0x25,  PIX_FREQ_27000KHz}, 
    { 23,{VNegHNeg, 864, 313,20000},{ 69, 720, 20, 288},{0x00,  8, 63,  3,  3,   0},  0x15,  PIX_FREQ_27000KHz}, 
    { 24,{VNegHNeg, 864, 313,20000},{ 69, 720, 20, 288},{0x00,  8, 63,  3,  3,   0},  0x25,  PIX_FREQ_27000KHz}, 
    { 25,{VNegHNeg,3456, 313,20000},{276,2880, 20, 288},{0x09, 44,252,  2,  3,1728},  0x10,  PIX_FREQ_54000KHz}, 
    { 26,{VNegHNeg,3456, 313,20000},{276,2880, 20, 288},{0x09, 44,252,  2,  3,1728},  0x20,  PIX_FREQ_54000KHz}, 
    { 27,{VNegHNeg,3456, 313,20000},{276,2880, 20, 288},{0x00, 44,252,  3,  3,   0},  0x10,  PIX_FREQ_54000KHz}, 
    { 28,{VNegHNeg,3456, 313,20000},{276,2880, 20, 288},{0x00, 44,252,  3,  3,   0},  0x20,  PIX_FREQ_54000KHz}, 
    { 29,{VPosHNeg,1728, 625,20000},{136,1440, 40, 576},{0x00, 20,128,  5,  5,   0},  0x10,  PIX_FREQ_54000KHz}, 
    { 30,{VPosHNeg,1728, 625,20000},{136,1440, 40, 576},{0x00, 20,128,  5,  5,   0},  0x20,  PIX_FREQ_54000KHz}, 
    { 31,{VPosHPos,2640,1125,20000},{148,1920, 37,1080},{0x00,524, 44,  4,  5,   0},  0x20, PIX_FREQ_148500KHz}, 
    { 32,{VPosHPos,2750,1125,41666},{148,1920, 37,1080},{0x00,634, 44,  4,  5,   0},  0x20,  PIX_FREQ_74176KHz}, 
    { 33,{VPosHPos,2640,1125,40000},{148,1920, 37,1080},{0x00,524, 44,  4,  5,   0},  0x20,  PIX_FREQ_74250KHz}, 
    { 34,{VPosHPos,2200,1125,33333},{148,1920, 37,1080},{0x00, 84, 44,  4,  5,   0},  0x20,  PIX_FREQ_74176KHz}, 

    { 35,{VNegHNeg,3432, 525,16666},{240,2880, 31, 480},{0x00, 92,248,  9,  6,   0},  0x10, PIX_FREQ_108000KHz}, 
    { 36,{VNegHNeg,3432, 525,16666},{240,2880, 31, 480},{0x00, 92,248,  9,  6,   0},  0x20, PIX_FREQ_108000KHz}, 
    { 37,{VNegHNeg,3456, 625,20000},{272,2880, 40, 576},{0x00, 44,256,  5,  5,   0},  0x10, PIX_FREQ_108000KHz}, 
    { 38,{VNegHNeg,3456, 625,20000},{272,2880, 40, 576},{0x00, 44,256,  5,  5,   0},  0x20, PIX_FREQ_108000KHz}, 
    { 39,{VPosHNeg,2304, 625,20000},{184,1920, 58, 540},{0x09, 28,168,  2,  5,1152},  0x20,  PIX_FREQ_72000KHz}, 
    { 40,{VPosHPos,2640, 563,10000},{148,1920, 16, 540},{0x09,524, 44,  2,  5,1320},  0x20, PIX_FREQ_148500KHz}, 
    { 41,{VPosHPos,1980, 750,10000},{220,1280, 21, 720},{0x00,436, 40,  5,  5,   0},  0x20, PIX_FREQ_148500KHz}, 
    { 42,{VNegHNeg, 864, 625,10000},{ 68, 720, 40, 576},{0x00,  8, 64,  5,  5,   0},  0x10,  PIX_FREQ_54000KHz}, 
    { 43,{VNegHNeg, 864, 625,10000},{ 68, 720, 40, 576},{0x00,  8, 64,  5,  5,   0},  0x20,  PIX_FREQ_54000KHz}, 
    { 44,{VNegHNeg, 864, 313,10000},{ 69, 720, 20, 288},{0x09,  8, 63,  2,  3, 432},  0x15,  PIX_FREQ_54000KHz}, 
    { 45,{VNegHNeg, 864, 313,10000},{ 69, 720, 20, 288},{0x09,  8, 63,  2,  3, 432},  0x25,  PIX_FREQ_54000KHz}, 
    { 46,{VPosHPos,2200, 563, 8333},{148,1920, 16, 540},{0x09, 84, 44,  2,  5,2200},  0x20, PIX_FREQ_148352KHz}, 
    { 47,{VPosHPos,1650, 750, 8333},{220,1280, 21, 720},{0x00,106, 40,  5,  5,   0},  0x20, PIX_FREQ_148352KHz}, 
    { 48,{VNegHNeg, 858, 525, 8333},{ 60, 720, 31, 480},{0x00, 12, 62,  9,  6,   0},  0x10,  PIX_FREQ_54000KHz}, 
    { 49,{VNegHNeg, 858, 525, 8333},{ 60, 720, 31, 480},{0x00, 12, 62,  9,  6,   0},  0x20,  PIX_FREQ_54000KHz}, 
    { 50,{VNegHNeg, 858, 262, 8333},{ 57, 720, 16, 240},{0x09, 15, 62,  4,  3, 429},  0x15,  PIX_FREQ_54000KHz}, 
    { 51,{VNegHNeg, 858, 262, 8333},{ 57, 720, 16, 240},{0x09, 15, 62,  4,  3, 429},  0x25,  PIX_FREQ_54000KHz}, 
    { 52,{VNegHNeg, 864, 625, 5000},{ 68, 720, 40, 576},{0x00,  8, 64,  5,  5,   0},  0x10, PIX_FREQ_108000KHz}, 
    { 53,{VNegHNeg, 864, 625, 5000},{ 68, 720, 40, 576},{0x00,  8, 64,  5,  5,   0},  0x20, PIX_FREQ_108000KHz}, 
    { 54,{VNegHNeg, 864, 313, 5000},{ 69, 720, 20, 288},{0x09,  8, 63,  2,  3, 432},  0x15, PIX_FREQ_108000KHz}, 
    { 55,{VNegHNeg, 864, 313, 5000},{ 69, 720, 20, 288},{0x09,  8, 63,  2,  3, 432},  0x25, PIX_FREQ_108000KHz}, 
    { 56,{VNegHNeg, 858, 525, 4166},{ 60, 720, 31, 480},{0x00, 12, 62,  9,  6,   0},  0x10, PIX_FREQ_108000KHz}, 
    { 57,{VNegHNeg, 858, 525, 4166},{ 60, 720, 31, 480},{0x00, 12, 62,  9,  6,   0},  0x20, PIX_FREQ_108000KHz}, 
    { 58,{VNegHNeg, 858, 263, 4166},{ 57, 720, 16, 240},{0x09, 15, 62,  4,  3, 429},  0x15, PIX_FREQ_108000KHz}, 
    { 59,{VNegHNeg, 858, 263, 4166},{ 57, 720, 16, 240},{0x09, 15, 62,  4,  3, 429},  0x25, PIX_FREQ_108000KHz}, 

    
    {  6,{VNegHNeg,1716, 262,16666},{114,1440, 16, 240},{0x09, 30,124,  4,  3, 858},  0x14,  PIX_FREQ_27000KHz}, 
    {  7,{VNegHNeg,1716, 262,16666},{114,1440, 16, 240},{0x09, 30,124,  4,  3, 858},  0x24,  PIX_FREQ_27000KHz}, 
    {  8,{VNegHNeg,1716, 262,16666},{114,1440, 16, 240},{0x00, 30,124,  4,  3,   0},  0x14,  PIX_FREQ_27000KHz}, 
    {  9,{VNegHNeg,1716, 262,16666},{114,1440, 16, 240},{0x00, 30,124,  4,  3,   0},  0x24,  PIX_FREQ_27000KHz}, 

    { 21,{VNegHNeg,1728, 313,20000},{192,1440, 20, 288},{0x09, 20,128,  2,  3, 864},  0x14,  PIX_FREQ_27000KHz}, 
    { 22,{VNegHNeg,1728, 313,20000},{192,1440, 20, 288},{0x09, 20,128,  2,  3, 864},  0x24,  PIX_FREQ_27000KHz}, 
    { 23,{VNegHNeg,1728, 313,20000},{192,1440, 20, 288},{0x00, 20,128,  3,  3,   0},  0x14,  PIX_FREQ_27000KHz}, 
    { 24,{VNegHNeg,1728, 313,20000},{192,1440, 20, 288},{0x00, 20,128,  3,  3,   0},  0x24,  PIX_FREQ_27000KHz}, 

    { 44,{VNegHNeg,1728, 313,10000},{192,1440, 20, 288},{0x09, 20,128,  2,  3, 864},  0x14,  PIX_FREQ_54000KHz}, 
    { 45,{VNegHNeg,1728, 313,10000},{192,1440, 20, 288},{0x09, 20,128,  2,  3, 864},  0x24,  PIX_FREQ_54000KHz}, 

    { 50,{VNegHNeg,1716, 262, 8333},{114,1440, 16, 240},{0x09, 30,124,  4,  3, 858},  0x14,  PIX_FREQ_54000KHz}, 
    { 51,{VNegHNeg,1716, 262, 8333},{114,1440, 16, 240},{0x09, 30,124,  4,  3, 858},  0x24,  PIX_FREQ_54000KHz}, 

    { 54,{VNegHNeg,1728, 313, 5000},{192,1440, 20, 288},{0x09, 20,128,  2,  3, 864},  0x14, PIX_FREQ_108000KHz}, 
    { 55,{VNegHNeg,1728, 313, 5000},{192,1440, 20, 288},{0x09, 20,128,  2,  3, 864},  0x24, PIX_FREQ_108000KHz}, 

    { 58,{VNegHNeg,1716, 262, 4166},{114,1440, 16, 240},{0x09, 30,124,  4,  3, 858},  0x14, PIX_FREQ_108000KHz}, 
    { 59,{VNegHNeg,1716, 262, 4166},{114,1440, 16, 240},{0x09, 30,124,  4,  3, 858},  0x24, PIX_FREQ_108000KHz}, 

    
    {128,{VNegHPos, 832, 445,16683},{ 96, 640, 61, 350},{0x00, 28, 64, 32,  3,   0},  0x00,        PIX_FREQ_PC}, 
    {129,{VNegHPos, 832, 445,14285},{ 96, 640, 61, 350},{0x00, 28, 64, 32,  3,   0},  0x00,        PIX_FREQ_PC}, 
    {130,{VNegHPos, 832, 445,13333},{ 96, 640, 61, 350},{0x00, 28, 64, 32,  3,   0},  0x00,        PIX_FREQ_PC}, 
    {131,{VNegHPos, 832, 445,11753},{ 96, 640, 61, 350},{0x00, 28, 64, 32,  3,   0},  0x00,        PIX_FREQ_PC}, 
    
    {132,{VPosHNeg, 832, 445,16683},{ 96, 640, 42, 400},{0x00, 28, 64,  1,  3,   0},  0x00,        PIX_FREQ_PC}, 
    {133,{VPosHNeg, 832, 445,14285},{ 96, 640, 42, 400},{0x00, 28, 64,  1,  3,   0},  0x00,        PIX_FREQ_PC}, 
    {134,{VPosHNeg, 832, 445,13333},{ 96, 640, 42, 400},{0x00, 28, 64,  1,  3,   0},  0x00,        PIX_FREQ_PC}, 
    {135,{VPosHNeg, 832, 445,11753},{ 96, 640, 42, 400},{0x00, 28, 64,  1,  3,   0},  0x00,        PIX_FREQ_PC}, 

    {136,{VPosHNeg, 900, 449,16683},{108, 720, 43, 400},{0x00, 14,108, 13,  2,   0},  0x00,        PIX_FREQ_PC}, 
    {137,{VPosHNeg, 900, 449,14285},{108, 720, 43, 400},{0x00, 14,108, 13,  2,   0},  0x00,        PIX_FREQ_PC}, 
    {138,{VPosHNeg, 900, 449,13333},{108, 720, 43, 400},{0x00, 14,108, 13,  2,   0},  0x00,        PIX_FREQ_PC}, 
    {139,{VPosHNeg, 936, 446,11759},{108, 720, 43, 400},{0x00, 32, 72,  1,  3,   0},  0x00,        PIX_FREQ_PC}, 

    
    {140,{VNegHNeg, 800, 525,16683},{ 48, 640, 34, 480},{0x00,  8,100,  8,  4,   0},  0x10,  PIX_FREQ_25175KHz}, 
    {141,{VNegHNeg, 832, 520,13734},{128, 640, 29, 480},{0x00, 20, 40,  9,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {142,{VNegHNeg, 840, 500,13333},{120, 640, 17, 480},{0x00, 12, 64,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {143,{VNegHNeg, 832, 509,11763},{ 80, 640, 26, 480},{0x00, 52, 56,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    
    
    {144,{VPosHPos,1056, 628,16579},{ 88, 800, 24, 600},{0x00, 36,128,  1,  4,   0},  0x10,        PIX_FREQ_PC}, 
    {145,{VPosHPos,1040, 666,13852},{ 64, 800, 24, 600},{0x00, 52,120, 37,  6,   0},  0x10,        PIX_FREQ_PC}, 
    {146,{VPosHPos,1056, 625,13333},{160, 800, 22, 600},{0x00, 12, 80,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {147,{VPosHPos,1048, 631,11756},{152, 800, 28, 600},{0x00, 28, 64,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 

    {148,{VPosHPos,1088, 517,16666},{112, 848, 24, 480},{0x00, 12,112,  6,  8,   0},  0x20,        PIX_FREQ_PC}, 
    {149,{VPosHPos,1088, 517,14285},{112, 848, 24, 480},{0x00, 12,112,  6,  8,   0},  0x20,        PIX_FREQ_PC}, 
    {150,{VPosHPos,1088, 517,13333},{112, 848, 24, 480},{0x00, 12,112,  6,  8,   0},  0x20,        PIX_FREQ_PC}, 
    {151,{VPosHPos,1088, 517,11764},{112, 848, 24, 480},{0x00, 12,112,  6,  8,   0},  0x20,        PIX_FREQ_PC}, 

    
    {152,{VNegHNeg,1344, 806,16665},{160,1024, 30, 768},{0x00, 20,136,  3,  6,   0},  0x10,        PIX_FREQ_PC}, 
    {153,{VNegHNeg,1328, 806,14271},{144,1024, 30, 768},{0x00, 20,136,  3,  6,   0},  0x10,        PIX_FREQ_PC}, 
    {154,{VPosHPos,1312, 800,13328},{176,1024, 29, 768},{0x00, 12, 96,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {155,{VPosHPos,1376, 808,11765},{208,1024, 37, 768},{0x00, 44, 96,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 

    {156,{VPosHPos,1600, 900,16666},{256,1152, 33, 864},{0x00, 60,128,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {157,{VPosHPos,1600, 900,14285},{256,1152, 33, 864},{0x00, 60,128,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {158,{VPosHPos,1600, 900,13333},{256,1152, 33, 864},{0x00, 60,128,  1,  3,   0},  0x10, PIX_FREQ_108000KHz}, 
    {159,{VPosHPos,1600, 900,11764},{256,1152, 33, 864},{0x00, 60,128,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 

    {160,{VPosHNeg,1664, 798,16702},{192,1280, 21, 768},{0x00, 60,128,  3,  7,   0},  0x20,        PIX_FREQ_PC}, 
    {161,{VPosHNeg,1696, 805,14285},{208,1280, 28, 768},{0x00, 76,128,  3,  7,   0},  0x20,        PIX_FREQ_PC}, 
    {162,{VPosHNeg,1696, 805,13352},{208,1280, 28, 768},{0x00, 76,128,  3,  7,   0},  0x20,        PIX_FREQ_PC}, 
    {163,{VPosHNeg,1712, 809,11787},{216,1280, 32, 768},{0x00, 76,136,  3,  7,   0},  0x20,        PIX_FREQ_PC}, 

    {164,{VPosHPos,1800,1000,16666},{312,1280, 37, 960},{0x00, 92,112,  1,  3,   0},  0x10, PIX_FREQ_108000KHz}, 
    {165,{VPosHPos,1728,1011,14285},{224,1280, 48, 960},{0x00, 60,160,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {166,{VPosHPos,1728,1011,13333},{224,1280, 48, 960},{0x00, 60,160,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {167,{VPosHPos,1728,1011,11764},{224,1280, 48, 960},{0x00, 60,160,  1,  3,   0},  0x10, PIX_FREQ_148500KHz}, 

    
    {168,{VPosHPos,1688,1066,16661},{248,1280, 39,1024},{0x00, 44,112,  1,  3,   0},  0x10, PIX_FREQ_108000KHz}, 
    {169,{VPosHPos,1688,1066,14285},{248,1280, 39,1024},{0x00, 12,144,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {170,{VPosHPos,1688,1066,13328},{248,1280, 39,1024},{0x00, 12,144,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {171,{VPosHPos,1728,1072,11761},{224,1280, 45,1024},{0x00, 60,160,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 

    {172,{VPosHPos,1792, 795,16662},{256,1360, 19, 768},{0x00, 60,112,  3,  6,   0},  0x20,        PIX_FREQ_PC}, 
    {173,{VPosHPos,1792, 795,14285},{256,1360, 19, 768},{0x00, 60,112,  3,  6,   0},  0x20,        PIX_FREQ_PC}, 
    {174,{VPosHPos,1792, 795,13333},{256,1360, 19, 768},{0x00, 60,112,  3,  6,   0},  0x20,        PIX_FREQ_PC}, 
    {175,{VPosHPos,1792, 795,11764},{256,1360, 19, 768},{0x00, 60,112,  3,  6,   0},  0x20,        PIX_FREQ_PC}, 

    {176,{VPosHNeg,1864,1089,16672},{232,1400, 33,1050},{0x00, 84,144,  3,  4,   0},  0x10,        PIX_FREQ_PC}, 
    {177,{VPosHNeg,1896,1099,14285},{248,1400, 43,1050},{0x00,100,144,  3,  4,   0},  0x10,        PIX_FREQ_PC}, 
    {178,{VPosHNeg,1896,1099,13357},{248,1400, 43,1050},{0x00,100,144,  3,  4,   0},  0x10,        PIX_FREQ_PC}, 
    {179,{VPosHNeg,1912,1105,11770},{256,1400, 49,1050},{0x00,100,152,  3,  4,   0},  0x10,        PIX_FREQ_PC}, 

    {180,{VPosHNeg,1904, 934,16698},{232,1440, 26, 900},{0x00, 76,152,  3,  6,   0},  0x00,        PIX_FREQ_PC}, 
    {181,{VPosHNeg,1936, 942,14285},{248,1440, 34, 900},{0x00, 92,152,  3,  6,   0},  0x00,        PIX_FREQ_PC}, 
    {182,{VPosHNeg,1936, 942,13336},{248,1440, 34, 900},{0x00, 92,152,  3,  6,   0},  0x00,        PIX_FREQ_PC}, 
    {183,{VPosHNeg,1952, 948,11786},{256,1440, 40, 900},{0x00,100,152,  3,  6,   0},  0x00,        PIX_FREQ_PC}, 

    
    {184,{VPosHPos,2160,1250,16666},{304,1600, 47,1200},{0x00, 60,192,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {185,{VPosHPos,2160,1250,14285},{304,1600, 47,1200},{0x00, 60,192,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {186,{VPosHPos,2160,1250,13333},{304,1600, 47,1200},{0x00, 60,192,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {187,{VPosHPos,2160,1250,11764},{304,1600, 47,1200},{0x00, 60,192,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    
    {188,{VPosHNeg,2240,1089,16679},{280,1680, 31,1050},{0x00,100,176,  3,  6,   0},  0x10,        PIX_FREQ_PC}, 
    {189,{VPosHNeg,2272,1099,14285},{296,1680, 41,1050},{0x00,116,176,  3,  6,   0},  0x10,        PIX_FREQ_PC}, 
    {190,{VPosHNeg,2272,1099,13352},{296,1680, 41,1050},{0x00,116,176,  3,  6,   0},  0x10,        PIX_FREQ_PC}, 
    {191,{VPosHNeg,2288,1105,11772},{304,1680, 47,1050},{0x00,124,176,  3,  6,   0},  0x10,        PIX_FREQ_PC}, 

    {192,{VPosHNeg,2448,1394,16666},{328,1792, 47,1344},{0x00,124,200,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {193,{VPosHNeg,2456,1417,14285},{352,1792, 70,1344},{0x00, 92,216,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {194,{VPosHNeg,2456,1417,13333},{352,1792, 70,1344},{0x00, 92,216,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {195,{VPosHNeg,2456,1417,11764},{352,1792, 70,1344},{0x00, 92,216,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 

    {196,{VPosHNeg,2528,1439,16668},{352,1856, 44,1392},{0x00, 92,224,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {197,{VPosHNeg,2560,1500,14285},{352,1856,105,1392},{0x00,124,224,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {198,{VPosHNeg,2560,1500,13333},{352,1856,105,1392},{0x00,124,224,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {199,{VPosHNeg,2560,1500,11764},{352,1856,105,1392},{0x00,124,224,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 

    {200,{VPosHNeg,2592,1245,16698},{336,1920, 37,1200},{0x00,132,200,  3,  6,   0},  0x10,        PIX_FREQ_PC}, 
    {201,{VPosHNeg,2608,1255,14285},{344,1920, 47,1200},{0x00,132,208,  3,  6,   0},  0x10,        PIX_FREQ_PC}, 
    {202,{VPosHNeg,2608,1255,13345},{344,1920, 47,1200},{0x00,132,208,  3,  6,   0},  0x10,        PIX_FREQ_PC}, 
    {203,{VPosHNeg,2624,1262,11774},{352,1920, 54,1200},{0x00,140,208,  3,  6,   0},  0x10,        PIX_FREQ_PC}, 

    {204,{VPosHNeg,2600,1500,16666},{344,1920, 57,1440},{0x00,124,208,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {205,{VPosHNeg,2640,1500,14285},{352,1920, 57,1440},{0x00,140,224,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {206,{VPosHNeg,2640,1500,13333},{352,1920, 57,1440},{0x00,140,224,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {207,{VPosHNeg,2640,1500,11774},{352,1920, 57,1440},{0x00,140,224,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 

    
    {144,{VPosHPos,1024, 625,17777},{128, 800, 23, 600},{0x00, 20, 72,  1,  2,   0},  0x10,        PIX_FREQ_PC}, 
    {160,{VNegHPos,1440, 790,16668},{ 80,1280, 13, 768},{0x00, 44, 32,  3,  7,   0},  0x10,        PIX_FREQ_PC}, 
    {176,{VNegHPos,1560,1080,16681},{ 80,1400, 24,1050},{0x00, 44, 32,  3,  4,   0},  0x10,        PIX_FREQ_PC}, 
    {180,{VNegHPos,1600, 926,16694},{ 80,1440, 18, 900},{0x00, 44, 32,  3,  6,   0},  0x10,        PIX_FREQ_PC}, 
    {184,{VPosHPos,2160,1250,15484},{304,1600, 47,1200},{0x00, 60,192,  1,  3,   0},  0x10,        PIX_FREQ_PC}, 
    {188,{VNegHPos,1840,1080,16699},{ 80,1680, 22,1050},{0x00, 44, 32,  3,  6,   0},  0x10,        PIX_FREQ_PC}, 
    {200,{VNegHPos,2080,1235,16680},{ 80,1920, 27,1200},{0x00, 44, 32,  3,  6,   0},  0x10,        PIX_FREQ_PC}, 
};


unsigned char EP932_VDO_Settings_Max = (sizeof(EP932_VDO_Settings)/sizeof(EP932_VDO_Settings[0]));
#define EP932_VDO_Settings_IT_Start 76
#define Addr_EP932M_AVI_Start       0x66
#define Addr_EP932M_ADO_Start       0x74
#define Addr_EP932M_Fire_All        0x3F



void SetEP932MInitReg(UCHAR ucDeviceID,UCHAR I2CPort,UCHAR Addr);
void SetHDMIInfoframe(UCHAR ucHDMIType,UCHAR I2CPort,UCHAR Addr);


