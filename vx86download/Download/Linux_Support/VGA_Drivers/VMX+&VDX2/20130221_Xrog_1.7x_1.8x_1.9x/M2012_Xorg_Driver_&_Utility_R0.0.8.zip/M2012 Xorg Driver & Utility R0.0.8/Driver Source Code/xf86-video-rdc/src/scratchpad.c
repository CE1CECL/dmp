/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include    "typedef.h"
#include    "scratchpad.h"
#include    "CInt10.h"




UCHAR Get_DEV_ID(UCHAR DisplayPath);
void Set_DEV_ID(UCHAR DeviceID, UCHAR DisplayPath);
UCHAR Get_NEW_DEV_ID(UCHAR DisplayPath);
void Set_NEW_DEV_ID(UCHAR DeviceID, UCHAR DisplayPath);
USHORT Get_LCD_H_SIZE();
USHORT Get_LCD_V_SIZE();
ULONG Get_LCD_SIZE();
USHORT Get_LCD2_H_SIZE();
USHORT Get_LCD2_V_SIZE();
ULONG Get_LCD2_SIZE();
UCHAR Get_RRATE_ID(UCHAR DisplayPath);
void Set_RRATE_ID(UCHAR RRateID, UCHAR DisplayPath);
UCHAR Get_LCD_TABLE_INDEX(void);
UCHAR Get_LCD2_TABLE_INDEX(void);
void Set_LCD_TABLE_INDEX(UCHAR bLCDIndex);
UCHAR Get_TV_ConnectorType(void);
UCHAR Get_TV_TYPE();
void Set_TV_Confiuration(UCHAR TVConfig);
void Set_LVDS1_TX_ID(UCHAR ucLvds1Index);
void Set_TMDS1_TX_ID(UCHAR ucTmds1Index);
USHORT Get_VESA_MODE(UCHAR DisplayPath);
void Set_VESA_MODE(USHORT ModeNum, UCHAR DisplayPath);
UCHAR Get_TMDS1_TX_ID();
UCHAR Get_LVDS_TX_ID(UCHAR ucDisplayPath);
UCHAR Get_TV_CONNECTION_TYPE(UCHAR bDisplayPath);
UCHAR Get_HDMI_TYPE();
UCHAR Get_TV1_Mode_Index();
UCHAR Get_TV_Encoder_Index();
void Set_TV_Encoder_Index(UCHAR ucTvEncIndex);
CI_STATUS IsDownScaleEnable(void);
UCHAR AlignDataToLSB(UCHAR bData, UCHAR bMask);
UCHAR AlignDataToMask(UCHAR bData, UCHAR bMask);
UCHAR ReadScratch(USHORT IndexMask);
void WriteScratch(USHORT IndexMask, UCHAR Data);


UCHAR Get_DEV_ID(UCHAR DisplayPath)
{
    return ((DisplayPath == DISP1) ? ReadScratch(IDX_IGA1_DEV_ID) : ReadScratch(IDX_IGA2_DEV_ID));
}


void Set_DEV_ID(UCHAR DeviceID, UCHAR DisplayPath)
{
    if (DisplayPath == DISP1)
        WriteScratch(IDX_IGA1_DEV_ID, DeviceID);
    else
        WriteScratch(IDX_IGA2_DEV_ID, DeviceID);
}


UCHAR Get_NEW_DEV_ID(UCHAR DisplayPath)
{
    return ((DisplayPath == DISP1) ? ReadScratch(IDX_NEW_IGA1_DEV_ID) : ReadScratch(IDX_NEW_IGA2_DEV_ID));
}

void Set_NEW_DEV_ID(UCHAR DeviceID, UCHAR DisplayPath)
{
    if (DisplayPath == DISP1)
        WriteScratch(IDX_NEW_IGA1_DEV_ID, DeviceID);
    else
        WriteScratch(IDX_NEW_IGA2_DEV_ID, DeviceID);
}

USHORT Get_LCD_H_SIZE()
{
    USHORT wValue;

    wValue = (USHORT)ReadScratch(IDX_LCD_H_SIZE_OVERFLOW);
    wValue <<= 8;
    wValue |= (USHORT)ReadScratch(IDX_LCD_H_SIZE);
    
    return wValue;
}

USHORT Get_LCD_V_SIZE()
{
    USHORT wValue;

    wValue = (USHORT)ReadScratch(IDX_LCD_V_SIZE_OVERFLOW);
    wValue <<= 8;
    wValue |= (USHORT)ReadScratch(IDX_LCD_V_SIZE);
    
    return wValue;
}

ULONG Get_LCD_SIZE()
{
    ULONG dwValue;

    dwValue = (ULONG)Get_LCD_V_SIZE();
    dwValue <<= 16;
    dwValue |= (ULONG)Get_LCD_H_SIZE();
    
    return dwValue;
}

USHORT Get_LCD2_H_SIZE()
{
    USHORT wValue;

    wValue = (USHORT)ReadScratch(IDX_LCD2_H_SIZE_OVERFLOW);
    wValue <<= 8;
    wValue |= (USHORT)ReadScratch(IDX_LCD2_H_SIZE);
    
    return wValue;
}

USHORT Get_LCD2_V_SIZE()
{
    USHORT wValue;

    wValue = (USHORT)ReadScratch(IDX_LCD2_V_SIZE_OVERFLOW);
    wValue <<= 8;
    wValue |= (USHORT)ReadScratch(IDX_LCD2_V_SIZE);
    
    return wValue;
}

ULONG Get_LCD2_SIZE()
{
    ULONG dwValue;

    dwValue = (ULONG)Get_LCD2_V_SIZE();
    dwValue <<= 16;
    dwValue |= (ULONG)Get_LCD2_H_SIZE();
    
    return dwValue;
}

UCHAR Get_RRATE_ID(UCHAR DisplayPath)
{
    return ((DisplayPath == DISP1) ? ReadScratch(IDX_IGA1_RRATE_ID) : ReadScratch(IDX_IGA2_RRATE_ID));
}

void Set_RRATE_ID(UCHAR RRateID, UCHAR DisplayPath)
{
    if (DisplayPath == DISP1)
        WriteScratch(IDX_IGA1_RRATE_ID, RRateID);
    else
        WriteScratch(IDX_IGA2_RRATE_ID, RRateID);
}

UCHAR Get_LCD_TABLE_INDEX(void)
{
    return ReadScratch(IDX_LCD1_TABLE_INDEX);
}

UCHAR Get_LCD2_TABLE_INDEX(void)
{
    return ReadScratch(IDX_LCD2_TABLE_INDEX);
}

void Set_LCD_TABLE_INDEX(UCHAR bLCDIndex)
{
    WriteScratch(IDX_LCD1_TABLE_INDEX, bLCDIndex);
}

UCHAR Get_TV_ConnectorType(void)
{
    return ReadScratch(IDX_TV1_CONNECTION_TYPE);
}

UCHAR Get_TV_TYPE()
{
    return ReadScratch(IDX_TV1_TYPE);
}

void Set_TV_Confiuration(UCHAR TVConfig)
{
    WriteScratch(IDX_TV1_TYPE, (TVConfig&0xF));
    WriteScratch(IDX_TV1_CONNECTION_TYPE, ((TVConfig>>4)&0x3));
}

void Set_LVDS1_TX_ID(UCHAR ucLvds1Index)
{
    WriteScratch(IDX_LVDS1_TX_ID, ucLvds1Index);
}

void Set_TMDS1_TX_ID(UCHAR ucTmds1Index)
{
    WriteScratch(IDX_TMDS1_TX_ID, ucTmds1Index);
}

USHORT Get_VESA_MODE(UCHAR DisplayPath)
{
    UCHAR VESAMode, VESAModeOver;

    if (DisplayPath == DISP1)
    {
        VESAMode = ReadScratch(IDX_IGA1_VESA_MODE);
        VESAModeOver = ReadScratch(IDX_IGA1_VESA_MODE_OVERFLOW);
    }
    else
    {
        VESAMode = ReadScratch(IDX_IGA2_VESA_MODE);
        VESAModeOver = ReadScratch(IDX_IGA2_VESA_MODE_OVERFLOW);
    }
    
    return  ((USHORT)VESAModeOver) << 8 | (USHORT)VESAMode;
}

void Set_VESA_MODE(USHORT ModeNum, UCHAR DisplayPath)
{
    if (DisplayPath == DISP1)
    {
        WriteScratch(IDX_IGA1_VESA_MODE, (UCHAR)ModeNum);
        WriteScratch(IDX_IGA1_VESA_MODE_OVERFLOW, (UCHAR)(ModeNum >> 8));
    }
    else
    {
        WriteScratch(IDX_IGA2_VESA_MODE, (UCHAR)ModeNum);
        WriteScratch(IDX_IGA2_VESA_MODE_OVERFLOW, (UCHAR)(ModeNum >> 8));
    }
}

UCHAR Get_TMDS1_TX_ID()
{
    return ReadScratch(IDX_TMDS1_TX_ID);
}

UCHAR Get_LVDS_TX_ID(UCHAR ucDisplayPath)
{
    return ((ucDisplayPath == DISP1) ? ReadScratch(IDX_LVDS1_TX_ID) : ReadScratch(IDX_LVDS2_TX_ID));
}

UCHAR Get_TV_CONNECTION_TYPE(UCHAR bDisplayPath)
{
    return ((bDisplayPath == DISP1) ? ReadScratch(IDX_TV1_CONNECTION_TYPE) : ReadScratch(IDX_TV2_CONNECTION_TYPE));
}

UCHAR Get_HDMI_TYPE()
{
    return ReadScratch(IDX_HDMI1_TYPE);
}

UCHAR Get_TV1_Mode_Index()
{
    return ReadScratch(IDX_TV1_Mode_TABLE_INDEX);
}

UCHAR Get_TV_Encoder_Index()
{
    return ReadScratch(IDX_TV1_ENCODER_ID);
}

void Set_TV_Encoder_Index(UCHAR ucTvEncIndex)
{
    WriteScratch(IDX_TV1_ENCODER_ID, ucTvEncIndex);
}

void Set_TV1_Mode_Index(UCHAR ucTvModeIndex)
{
    WriteScratch(IDX_TV1_Mode_TABLE_INDEX, ucTvModeIndex);
}


CI_STATUS IsDownScaleEnable(void)
{
    return ((ReadScratch(IDX_DS_ENABLE) == 1) ? true : false);
}



UCHAR AlignDataToLSB(UCHAR bData, UCHAR bMask)
{
    bData &= bMask;
    
    while ((bMask & BIT0) == 0)
    {
        bData >>= 1;
        bMask >>= 1;
    }
    
    return bData;
}


UCHAR AlignDataToMask(UCHAR bData, UCHAR bMask)
{
    while ((bMask & BIT0) == 0)
    {
        bData <<= 1;
        bMask >>= 1;
    }
    
    return bData;
}


UCHAR ReadScratch(USHORT IndexMask)
{
    UCHAR Index = (UCHAR)(IndexMask >> 8);
    UCHAR Mask = (UCHAR)IndexMask;
    UCHAR RetValue;

    RetValue = GetCRReg(Index);
    RetValue &= Mask;
    
    RetValue = AlignDataToLSB(RetValue, Mask);

    return RetValue;
}


void WriteScratch(USHORT IndexMask, UCHAR Data)
{
    UCHAR Index = (UCHAR)(IndexMask >> 8);
    UCHAR Mask = (UCHAR)IndexMask;

    Data = AlignDataToMask(Data, Mask);
    Data &= Mask;
    SetCRReg(Index, Data, Mask);
}

