/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include <string.h>
#include "output.h"
#include "vbiosdata.h"
#include "debug.h"

#define BIOS_ROM_SIZE           32*1024

void SetDeviceSupport()
{
    PORT_CONFIG *pDevicePortConfig;
    
    CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "Entry %s()\n", __func__);
    
    if (GetDevicePortConfig(CRT_ID, &pDevicePortConfig))
    {
        if (pDevicePortConfig->Attribute & Dev_SUPPORT)
        {
            bCRTSUPPORT = TRUE;
            CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "CRT supported\n");
        }
    }
    
    if (GetDevicePortConfig(LCD_ID, &pDevicePortConfig))
    {
        if (pDevicePortConfig->Attribute & Dev_SUPPORT)
        {
            bLCDSUPPORT = TRUE;
            CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "LCD supported\n");
        }
    }

    if (GetDevicePortConfig(DVI_ID, &pDevicePortConfig))
    {
        if (pDevicePortConfig->Attribute & Dev_SUPPORT)
        {
            bDVISUPPORT = TRUE;
            CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "DVI supported\n");
        }
    }
    
    if (GetDevicePortConfig(TV_ID, &pDevicePortConfig))
    {
        if (pDevicePortConfig->Attribute & Dev_SUPPORT)
        {
            bTVSUPPORT = TRUE;
            CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "TV supported\n");
        }
    }    

    if (GetDevicePortConfig(HDMI_ID, &pDevicePortConfig))
    {
        if (pDevicePortConfig->Attribute & Dev_SUPPORT)
        {
            
            bHDMISUPPORT = TRUE;
            bDVISUPPORT = TRUE;
            CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "HDMI and DVI supported\n");
        }
    }
    
    CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "Exit %s()\n", __func__);
}

void* SearchString(char *pcKeyWord, UCHAR *from)
{
    int i, lenKeyWord;

    lenKeyWord = strlen(pcKeyWord);
    for(i = 0; i < BIOS_ROM_SIZE; i++)
    {
        if ((*pcKeyWord == *(from+i)) && !memcmp(pcKeyWord, from+i, lenKeyWord))
        {
            return from+i;
        }
    }

    return NULL;
}

void ParseTable(char* pcKeyWord, UCHAR *from, UCHAR **pointer)
{
    *pointer = (UCHAR*)SearchString(pcKeyWord, from);
    *pointer += strlen(pcKeyWord);
}

