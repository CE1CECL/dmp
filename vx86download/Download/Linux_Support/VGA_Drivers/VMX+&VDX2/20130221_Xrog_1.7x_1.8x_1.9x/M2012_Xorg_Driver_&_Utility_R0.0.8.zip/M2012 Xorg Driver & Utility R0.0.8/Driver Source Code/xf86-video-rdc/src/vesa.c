/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include "CInt10.h"
#include "timingtbl.h"
#include "vbiosdata.h"
#include "debug.h"


CI_STATUS Get_MODE_INFO_From_VESA_Table(USHORT wModeNum, MODE_INFO **ppModeInfo)
{
    UCHAR ucColorDepth;

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter Get_MODE_INFO_From_VESA_Table()==\n");

    *ppModeInfo = pVESATable;

    while((*ppModeInfo)->H_Size != 0xFFFF)
    {
        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "*ppModeInfo = 0x%x\n", *ppModeInfo);
        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "(*ppModeInfo)->H_Size = %d\n", (*ppModeInfo)->H_Size);

        if (GetModeColorDepth(wModeNum, *ppModeInfo, &ucColorDepth))
        {
            CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "*ppModeInfo = 0x%x\n", *ppModeInfo);
            CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "  Exit1 Get_MODE_INFO_From_VESA_Table()== return success\n");
            return true;
        }

        *ppModeInfo = (MODE_INFO*)((*ppModeInfo)->RRTableCount * sizeof(RRATE_TABLE) + sizeof(MODE_INFO) + (void*)(*ppModeInfo));
    }

    *ppModeInfo = (MODE_INFO*)(&CInt10VESATable);

    while((*ppModeInfo)->H_Size != 0xFFFF)
    {
        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "*ppModeInfo = 0x%x\n", *ppModeInfo);
        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "(*ppModeInfo)->H_Size = %d\n", (*ppModeInfo)->H_Size);

        if (GetModeColorDepth(wModeNum, *ppModeInfo, &ucColorDepth))
        {
            CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "*ppModeInfo = 0x%x\n", *ppModeInfo);
            CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "  Exit1 Get_MODE_INFO_From_VESA_Table()== return success\n");
            return true;
        }

        *ppModeInfo = (MODE_INFO*)((*ppModeInfo)->RRTableCount * sizeof(RRATE_TABLE) + sizeof(MODE_INFO) + (void*)(*ppModeInfo));
    }

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "  Exit2 Get_MODE_INFO_From_VESA_Table()== return fail!!\n");
    return false;
}


CI_STATUS GetModePointerFromVESATable(USHORT wModeNum, UCHAR ucRRIndex, MODE_INFO **ppModeInfo, RRATE_TABLE **ppRRateTable)
{
    int iRRateTableIndex;

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter GetModePointerFromVESATable()==\n");
 
    
    if(Get_MODE_INFO_From_VESA_Table(wModeNum, ppModeInfo))
    {
        
        *ppRRateTable = (RRATE_TABLE*)((int)(*ppModeInfo) + sizeof(MODE_INFO));

        for(iRRateTableIndex = 0; iRRateTableIndex < (*ppModeInfo)->RRTableCount; iRRateTableIndex++, (*ppRRateTable)++)
        {
            CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "*ppRRateTable = 0x%x\n", *ppRRateTable);

            if(((*ppRRateTable)->RRate_ID == ucRRIndex) && (!((*ppRRateTable)->Attribute & DISABLE)))
            {
                CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "*ppRRateTable = 0x%x\n", *ppRRateTable);
                CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "  Exit1 GetModePointerFromVESATable()== return success\n");
                return true;
            }
        }
    }

    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "  Exit2 GetModePointerFromVESATable()== return fail!!\n");
    return false;
}



void LoadVESATiming(UCHAR bDisplayPath, USHORT wModeNum)
{
    UCHAR bR_Rate_value = 0x0;
    MODE_INFO *pModeInfo = NULL;
    RRATE_TABLE *pRRateTable = NULL;
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter LoadVESATiming()==\n");
    bR_Rate_value = Get_RRATE_ID(bDisplayPath);
    
    if(GetModePointerFromVESATable(wModeNum, bR_Rate_value, &pModeInfo, &pRRateTable))
    {
        SetTimingRegs(bDisplayPath, pModeInfo, pRRateTable);
    }
    else
    {
        CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "Mode not found!!\n");
        
    }
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit LoadVESATiming()==\n");
}

