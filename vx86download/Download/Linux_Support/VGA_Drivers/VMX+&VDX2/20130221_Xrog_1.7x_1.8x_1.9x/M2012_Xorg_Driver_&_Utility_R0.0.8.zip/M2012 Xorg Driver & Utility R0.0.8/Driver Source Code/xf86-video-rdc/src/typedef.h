/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#ifndef __TYPEDEF_H__
#define __TYPEDEF_H__

#include "rdc.h"

#define X_INFO 0
#define X_WARNING 1
#define X_ERROR 2

#ifndef NULL
#define NULL    0
#endif





#define bool    BOOL
#define FALSE   false
#define TRUE    true


#define BIT0                        0x00000001
#define BIT1                        0x00000002
#define BIT2                        0x00000004
#define BIT3                        0x00000008
#define BIT4                        0x00000010
#define BIT5                        0x00000020
#define BIT6                        0x00000040
#define BIT7                        0x00000080
#define BIT8                        0x00000100
#define BIT9                        0x00000200
#define BIT10                       0x00000400
#define BIT11                       0x00000800
#define BIT12                       0x00001000
#define BIT13                       0x00002000
#define BIT14                       0x00004000
#define BIT15                       0x00008000
#define BIT16                       0x00010000
#define BIT17                       0x00020000
#define BIT18                       0x00040000
#define BIT19                       0x00080000
#define BIT20                       0x00100000
#define BIT21                       0x00200000
#define BIT22                       0x00400000
#define BIT23                       0x00800000
#define BIT24                       0x01000000
#define BIT25                       0x02000000
#define BIT26                       0x04000000
#define BIT27                       0x08000000
#define BIT28                       0x10000000
#define BIT29                       0x20000000
#define BIT30                       0x40000000
#define BIT31                       0x80000000


#define DISP1       1
#define DISP2       2


#define LCD_ID      1
#define DVI_ID      2
#define CRT_ID      3
#define HDMI_ID     4
#define HDTV_ID     5
#define TV_ID       6
#define LCD2_ID     8
#define DVI2_ID     9
#define CRT2_ID     10
#define HDMI2_ID    11
#define HDTV2_ID    12
#define TV2_ID      13
#define DSTN        14


#define B_LCD       BIT0
#define B_DVI       BIT1
#define B_CRT       BIT2
#define B_HDMI      BIT3
#define B_HDTV      BIT4
#define B_TV        BIT5
#define B_LCD2      BIT7
#define B_DVI2      BIT8
#define B_CRT2      BIT9
#define B_HDMI2     BIT10
#define B_HDTV2     BIT11
#define B_TV2       BIT12


#define CRT_PORT    0
#define DVP1        1
#define DVP2        2
#define DVP12       3

struct _HDMITxDetect
{
    UCHAR        TMDSTxIndex;
    UCHAR        TMDSTxAddr;
    UCHAR        D_IDIndex;
    UCHAR        D_IDData;
}__attribute__((packed));;
typedef struct _HDMITxDetect HDMITxDetect;


#endif 

