/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include "regop.h"
#include "reggroupindex.h"
#include "timingtbl.h"
#include "timing.h"
#include "output.h"
#include "io.h"
#include "debug.h"
#include "vbiosdata.h"

extern void *PCIDataStruct;

void SetHTotal(UCHAR DisplayPath, USHORT Value);
void SetHDisplayEnd(UCHAR DisplayPath, USHORT Value);
void SetHBlankingStart(UCHAR DisplayPath, USHORT Value);
void SetHBlankingEnd(UCHAR DisplayPath, USHORT Value);
void SetHSyncStart(UCHAR DisplayPath, USHORT Value);
void SetHSyncEnd(UCHAR DisplayPath, USHORT Value);
void SetVTotal(UCHAR DisplayPath, USHORT Value);
void SetVDisplayEnd(UCHAR DisplayPath, USHORT Value);
void SetVBlankingStart(UCHAR DisplayPath, USHORT Value);
void SetVBlankingEnd(UCHAR DisplayPath, USHORT Value);
void SetVSyncStart(UCHAR DisplayPath, USHORT Value);
void SetVSyncEnd(UCHAR DisplayPath, USHORT Value);
void SetHTotalLow3bit(RRATE_TABLE *pRRateTable);
void ClearHTotalLow3bit();
void LockDisplay1Timing();
void UnLockDisplay1Timing();
void UnLockCR0ToCR7();
void LockCR0ToCR7();
void SetPixelClock(UCHAR bDisplayPath, ULONG dwClock);
PLL_Info ClockToPLLF9003A(ULONG Clock);
PLL_Info ClockToPLLF4002A(ULONG Clock);
void SetF4002APLLReg(UCHAR DisplayPath, PLL_Info PLLInfo, UCHAR bPLLDiv);
void SetF9003APLLReg(UCHAR DisplayPath, PLL_Info PLLInfo, UCHAR bPLLDiv);
USHORT GetVDisplayEnd(UCHAR DisplayPath);
void SetPolarity(UCHAR ucDisplayPath, USHORT usValue);
void Set8DotCharacter();
void SetTimingRegs(UCHAR ucDisplayPath, MODE_INFO *pModeInfo, RRATE_TABLE *pRRateTable);
void SetTimingCentering(UCHAR ucDisplayPath, MODE_INFO *pModeInfo, RRATE_TABLE *pRRateTable);


#define PLLReferenceClock           14318
#define MaxFCKVCO9003A              810000
#define MinFCKVCO9003A              350000
#define MaxFCKVCO9001A              1600000
#define MinFCKVCO9001A              833000
#define MaxFCKVCO4002A              805000
#define MinFCKVCO4002A              350000




REG_OP HTotal1[] = {
            {CR, 0xFF, 0x00,3},                 
            {CR, BIT0, 0xAC,11},                  
            {NR,0x0,0x0,0x0}
};


REG_OP HDispEnd1[] = {
            {SR, BIT6+BIT5+BIT4, 0x33,0},
            {CR, 0xFF, 0x01,3},
            {CR, BIT2, 0xAC,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HBnkSt1[] = {
            {SR, BIT2+BIT1+BIT0, 0x34,0},
            {CR, 0xFF, 0x02,3},
            {CR, BIT4, 0xAC,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HBnkEnd1[] = {
            {SR, BIT6+BIT5+BIT4, 0x34,0},
            {CR, 0x1F, 0x03,3},
            {CR, BIT7, 0x05,8},
            {CR, BIT0, 0xAD,9},
            {NR,0x0,0x0,0x0}
};


REG_OP HSyncSt1[] = {
            {SR, BIT2+BIT1+BIT0, 0x35,0},
            {CR, 0xFF, 0x04,3},
            {CR, BIT6, 0xAC,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HSyncEnd1[] = {
            {SR, BIT6+BIT5+BIT4, 0x35,0},
            {CR, 0x1F, 0x05,3},
            {CR, BIT2, 0xAD,8},
            {NR,0x0,0x0,0x0}
};


REG_OP VTotal1[] = {
            {CR, 0xFF, 0x06,0},
            {CR, BIT0, 0x07,8},
            {CR, BIT5, 0x07,9},
            {CR, BIT0, 0xAE,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VDispEnd1[] = {
            {CR, 0xFF, 0x12,0},
            {CR, BIT1, 0x07,8},
            {CR, BIT6, 0x07,9},
            {CR, BIT1, 0xAE,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VBnkSt1[] = {
            {CR, 0xFF, 0x15,0},
            {CR, BIT3, 0x07,8},
            {CR, BIT5, 0x09,9},
            {CR, BIT2, 0xAE,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VBnkEnd1[] = {
            {CR, 0xFF, 0x16,0},
            {CR, BIT4, 0xAE,8},
            {NR,0x0,0x0,0x0}
};


REG_OP VSyncSt1[] = {
             {CR, 0xFF, 0x10,0},
             {CR, BIT2, 0x07,8},
             {CR, BIT7, 0x07,9},
             {CR, BIT3, 0xAE,10},
             {NR,0x0,0x0,0x0}
};


REG_OP VSyncEnd1[] = {
             {CR, BIT3+BIT2+BIT1+BIT0, 0x11,0},
             {CR, BIT6+BIT5, 0xAE,4},
             {NR,0x0,0x0,0x0}
};




REG_OP HTotal2[] = {
            {CR, 0xFF, 0x23,3},                 
            {CR, BIT0, 0x29,11},                  
            {NR,0x0,0x0,0x0}
};


REG_OP HDispEnd2[] = {
            {SR, BIT6+BIT5+BIT4, 0x36,0},
            {CR, 0xFF, 0x24,3},
            {CR, BIT2, 0x29,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HBnkSt2[] = {
            {SR, BIT2+BIT1+BIT0, 0x37,0},
            {CR, 0xFF, 0x25,3},
            {CR, BIT4, 0x29,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HBnkEnd2[] = {
            {SR, BIT6+BIT5+BIT4, 0x37,0},
            {CR, 0x1F, 0x26,3},
            {CR, BIT7, 0x28,8},
            {CR, BIT0, 0x2A,9},
            {NR,0x0,0x0,0x0}
};


REG_OP HSyncSt2[] = {
            {SR, BIT2+BIT1+BIT0, 0x38,0},
            {CR, 0xFF, 0x27,3},
            {CR, BIT6, 0x29,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HSyncEnd2[] = {
            {SR, BIT6+BIT5+BIT4, 0x38,0},
            {CR, 0x1F, 0x28,3},
            {CR, BIT2, 0x2A,8},
            {NR,0x0,0x0,0x0}
};


REG_OP VTotal2[] = {
            {CR, 0xFF, 0x2B,0},
            {CR, BIT0, 0x31,8},
            {CR, BIT5, 0x31,9},
            {CR, BIT0, 0x32,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VDispEnd2[] = {
            {CR, 0xFF, 0x2C,0},
            {CR, BIT1, 0x31,8},
            {CR, BIT6, 0x31,9},
            {CR, BIT1, 0x32,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VBnkSt2[] = {
            {CR, 0xFF, 0x2D,0},
            {CR, BIT3, 0x31,8},
            {CR, BIT5, 0x29,9},
            {CR, BIT2, 0x32,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VBnkEnd2[] = {
            {CR, 0xFF, 0x2E,0},
            {CR, BIT4, 0x32,8},
            {NR,0x0,0x0,0x0}
};


REG_OP VSyncSt2[] = {
             {CR, 0xFF, 0x2F,0},
             {CR, BIT2, 0x31,8},
             {CR, BIT7, 0x31,9},
             {CR, BIT3, 0x32,10},
             {NR,0x0,0x0,0x0}
};


REG_OP VSyncEnd2[] = {
             {CR, BIT3+BIT2+BIT1+BIT0, 0x30,0},
             {CR, BIT6+BIT5, 0x32,4},
             {NR,0x0,0x0,0x0}
};




void SetHTotal(UCHAR DisplayPath, USHORT Value)
{
    
    Value -= 40;
    
    

    if(DisplayPath == DISP1)
    {
        WriteRegToHW(HTotal1, Value);
    }
    else
    {
        WriteRegToHW(HTotal2, Value);
    }

    return;
}


void SetHDisplayEnd(UCHAR DisplayPath, USHORT Value)
{
    
    Value -= 8;

    if(DisplayPath == DISP1)
    {
        WriteRegToHW(HDispEnd1, Value);
    }
    else
    {
        WriteRegToHW(HDispEnd2, Value);
    }

    return;
    
}


void SetHBlankingStart(UCHAR DisplayPath, USHORT Value)
{
    
    Value -= 8;

    if(DisplayPath == DISP1)
    {
        WriteRegToHW(HBnkSt1, Value);
    }
    else
    {
        WriteRegToHW(HBnkSt2, Value);
    }

    return;
    
}


void SetHBlankingEnd(UCHAR DisplayPath, USHORT Value)
{
    
    Value -= 8;

    if(DisplayPath == DISP1)
    {
        WriteRegToHW(HBnkEnd1, Value);
    }
    else
    {
        WriteRegToHW(HBnkEnd2, Value);
    }

    return;
    
}


void SetHSyncStart(UCHAR DisplayPath, USHORT Value)
{
    
    Value -= 0;

    if(DisplayPath == DISP1)
    {
        WriteRegToHW(HSyncSt1, Value);
    }
    else
    {
        WriteRegToHW(HSyncSt2, Value);
    }

    return;
    
}


void SetHSyncEnd(UCHAR DisplayPath, USHORT Value)
{
    
    Value -= 0;

    if(DisplayPath == DISP1)
    {
        WriteRegToHW(HSyncEnd1, Value);
    }
    else
    {
        WriteRegToHW(HSyncEnd2, Value);
    }

    return;
    
}


void SetVTotal(UCHAR DisplayPath, USHORT Value)
{
    
    Value -= 2;

    if(DisplayPath == DISP1)
    {
        WriteRegToHW(VTotal1, Value);
    }
    else
    {
        WriteRegToHW(VTotal2, Value);
    }

    return;
    
}


void SetVDisplayEnd(UCHAR DisplayPath, USHORT Value)
{
    
    Value -= 1;

    if(DisplayPath == DISP1)
    {
        WriteRegToHW(VDispEnd1, Value);
    }
    else
    {
        WriteRegToHW(VDispEnd2, Value);
    }

    return;
    
}


void SetVBlankingStart(UCHAR DisplayPath, USHORT Value)
{
    
    Value -= 1;

    if(DisplayPath == DISP1)
    {
        WriteRegToHW(VBnkSt1, Value);
    }
    else
    {
        WriteRegToHW(VBnkSt2, Value);
    }

    return;
    
}


void SetVBlankingEnd(UCHAR DisplayPath, USHORT Value)
{
    
    Value -= 1;

    if(DisplayPath == DISP1)
    {
        WriteRegToHW(VBnkEnd1, Value);
    }
    else
    {
        WriteRegToHW(VBnkEnd2, Value);
    }

    return;
    
}


void SetVSyncStart(UCHAR DisplayPath, USHORT Value)
{
    
    Value -= 1;

    if(DisplayPath == DISP1)
    {
        WriteRegToHW(VSyncSt1, Value);
    }
    else
    {
        WriteRegToHW(VSyncSt2, Value);
    }

    return;
    
}


void SetVSyncEnd(UCHAR DisplayPath, USHORT Value)
{
    
    Value -= 1;

    if(DisplayPath == DISP1)
    {
        WriteRegToHW(VSyncEnd1, Value);
    }
    else
    {
        WriteRegToHW(VSyncEnd2, Value);
    }
}


void SetHTotalLow3bit(RRATE_TABLE *pRRateTable)
{
    SetSRReg(0x33, (UCHAR)pRRateTable->H_Blank_Time, BIT0+BIT1+BIT2);
}


void ClearHTotalLow3bit()
{
    SetSRReg(0x33, 0, BIT0+BIT1+BIT2);
}


void LockDisplay1Timing()
{
    SetSRReg(0x65, 0xff, 0xff);
}


void UnLockDisplay1Timing()
{
    SetSRReg(0x65, 0x00, 0xff);
}


void UnLockCR0ToCR7()
{
    
    SetCRReg(0x11, 0x00, BIT7);
}


void LockCR0ToCR7()
{
    
    SetCRReg(0x11, 0x80, BIT7);
}


void SetPixelClock(UCHAR bDisplayPath, ULONG dwClock)
{
    UCHAR *pucPCIDataStruct = (UCHAR*)PCIDataStruct;
    PLL_Info PLLInfo;
    UCHAR bPLLDiv=0;
    if(dwClock<25000)
        bPLLDiv|=2;
    dwClock <<= bPLLDiv; 
                         
                         
                         
                         
    if (*(USHORT*)(pucPCIDataStruct + OFF_DID) == 0x2013) 
    {
        PLLInfo = ClockToPLLF4002A(dwClock);
        SetF4002APLLReg(bDisplayPath, PLLInfo, bPLLDiv);
    }
    else 
    {
        PLLInfo = ClockToPLLF9003A(dwClock);
        SetF9003APLLReg(bDisplayPath, PLLInfo, bPLLDiv);
    }
}


PLL_Info ClockToPLLF4002A(ULONG Clock)
{
    ULONG MSCount, NSCount, RSCount, FCKVCO, FCKOUT;    
    ULONG NearestClock = MAX_SUPPORT_CLOCK;
    PLL_Info PLLInfo;

    for (MSCount = 3; MSCount < 6; MSCount++)
    {
        for (NSCount = 1; NSCount < 256; NSCount++)
        {
            FCKVCO = PLLReferenceClock * NSCount / MSCount;
            
            if ( (MaxFCKVCO4002A >= FCKVCO) && (FCKVCO >= MinFCKVCO4002A) )
            {
                for (RSCount = 1; RSCount <= 7; RSCount++)
                {
                    FCKOUT = FCKVCO >> RSCount;
                    
                    if ( Difference(FCKOUT, Clock) < Difference(NearestClock, Clock) )
                    {
                        NearestClock = FCKOUT;
                        PLLInfo.MS = (UCHAR)MSCount;
                        PLLInfo.NS = (UCHAR)NSCount;
                        PLLInfo.RS = (UCHAR)RSCount;
                    }
                }
            }
        }

    }

    
    PLLInfo.MS <<=3 ;

    return PLLInfo;

}


PLL_Info ClockToPLLF9003A(ULONG Clock)
{
    ULONG MSCount, NSCount, RSCount, FCKVCO, FCKOUT;    
    ULONG NearestClock = MAX_SUPPORT_CLOCK;
    PLL_Info PLLInfo = {0, 0, 0};
    
    for (MSCount = 3; MSCount < 6; MSCount++)
    {
        for (NSCount = 1; NSCount < 256; NSCount++)
        {
            FCKVCO = PLLReferenceClock * NSCount / MSCount;
            
            if ( (MaxFCKVCO9003A >= FCKVCO) && (FCKVCO >= MinFCKVCO9003A) )
            {
                for (RSCount = 1; RSCount < 6; RSCount++)
                {
                    FCKOUT = FCKVCO >> RSCount;
                    if ( ((ULONG)(Difference(FCKOUT, Clock))) < ((ULONG)(Difference(NearestClock, Clock))) )
                    {
                        NearestClock = FCKOUT;
                        if (MSCount == 3)
                            PLLInfo.MS = 0x00;
                        if (MSCount == 4)
                            PLLInfo.MS = BIT3;
                        if (MSCount == 5)
                            PLLInfo.MS = BIT4+BIT3;
                        PLLInfo.NS = (UCHAR)NSCount;
                        PLLInfo.RS = (UCHAR)RSCount-1;
                    }
                }
            }
        }
    }

    return PLLInfo;

}


void SetF9003APLLReg(UCHAR DisplayPath, PLL_Info PLLInfo, UCHAR bPLLDiv)
{
    UCHAR RetValue; 

    if (DisplayPath == DISP1)
    {
        SetCRReg(0xC1, PLLInfo.MS, BIT4+BIT3);
        SetCRReg(0xC0, PLLInfo.NS, 0xFF);
        SetCRReg(0xCF, PLLInfo.RS, BIT2+BIT1+BIT0);
    }
    else
    {
        SetCRReg(0xBF, PLLInfo.MS, BIT4+BIT3);
        SetCRReg(0xBE, PLLInfo.NS, 0xFF);
        SetCRReg(0xCE, PLLInfo.RS, BIT2+BIT1+BIT0);
    }

    
    RetValue = GetCRReg(0xBB);
    SetCRReg(0xBB, RetValue, 0xFF);

}


void SetF4002APLLReg(UCHAR DisplayPath, PLL_Info PLLInfo, UCHAR bPLLDiv)
{
    UCHAR RetValue; 

    if (DisplayPath == DISP1)
    {
        SetCRReg(0xC1, PLLInfo.MS, BIT5+BIT4+BIT3);
        SetCRReg(0xC0, PLLInfo.NS, 0xFF);
        SetCRReg(0xCF, PLLInfo.RS, BIT2+BIT1+BIT0);
    }
    else
    {
        SetCRReg(0xBF, PLLInfo.MS, BIT5+BIT4+BIT3);
        SetCRReg(0xBE, PLLInfo.NS, 0xFF);
        SetCRReg(0xCE, PLLInfo.RS, BIT2+BIT1+BIT0);
    }

    
    RetValue = GetCRReg(0xBB);
    SetCRReg(0xBB, RetValue, 0xFF);

}


USHORT GetVDisplayEnd(UCHAR DisplayPath)
{
    USHORT  wDisplayEnd = 0x0;
    
    if(DisplayPath == DISP1)
    {
        wDisplayEnd = ReadRegFromHW(VDispEnd1);
    }
    else
    {
        wDisplayEnd = ReadRegFromHW(VDispEnd2);
    }
    
    
    wDisplayEnd += 1;

    return  wDisplayEnd;
}


void SetPolarity(UCHAR ucDisplayPath, USHORT usValue)
{
    UCHAR       ucDeviceID = Get_DEV_ID(ucDisplayPath);
    PORT_CONFIG *pDevicePortConfig = NULL;

    if (GetDevicePortConfig(ucDeviceID, &pDevicePortConfig))
    {
        switch (pDevicePortConfig->PortID)
        {
            case CRT_PORT:
                if (ucDisplayPath == DISP1)
                    OutPort(MISC_WRITE, ((usValue<<5) & 0xC0) | (InPort(MISC_READ) & 0x3F));
                else
                    OutPort(MISC_WRITE, (InPort(MISC_READ) & 0x3F));
                break;
            
            case DVP1:
            case DVP12:
                SetSRReg(0x20, usValue>>1, BIT1+BIT0);
                SetSRReg(0x20, usValue>>9, BIT2);
                break;

            case DVP2:
                SetSRReg(0x20, usValue<<2, BIT4+BIT3);
                SetSRReg(0x20, usValue>>4, BIT5);
                break;
        }
    }
}

void Set8DotCharacter()
{
    SetSRReg(0x01, 0x01, BIT0);
}


void SetTimingRegs(UCHAR ucDisplayPath, MODE_INFO *pModeInfo, RRATE_TABLE *pRRateTable)
{
    USHORT usHBorder = 0, usVBorder = 0;
    USHORT usHtotal, usHDispEnd, usHBlankStart, usHBlankEnd, usHSyncStart, usHSyncEnd;
    USHORT usVtotal, usVDispEnd, usVBlankStart, usVBlankEnd, usVSyncStart, usVSyncEnd;
    ULONG  ulPixelClock;
    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter SetTimingRegs()==\n");

    if (pRRateTable->Attribute & HB)
    {
        usHBorder = 8;
    }
    if (pRRateTable->Attribute & MHB)
    {
        usHBorder = 70;
    }

    if (pRRateTable->Attribute & VB)
    {
        usVBorder = 8;
    }
    if (pRRateTable->Attribute & MVB)
    {
        usVBorder = 90;
    }

    usHtotal =      pModeInfo->H_Size + usHBorder*2 + pRRateTable->H_Blank_Time;
    usHDispEnd =    pModeInfo->H_Size;
    usHBlankStart = pModeInfo->H_Size + usHBorder;
    usHBlankEnd =   pModeInfo->H_Size + usHBorder + pRRateTable->H_Blank_Time;
    usHSyncStart =  pRRateTable->H_Sync_Start;
    usHSyncEnd =    pRRateTable->H_Sync_Start + pRRateTable->H_Sync_Time;

    usVtotal =      pModeInfo->V_Size + usVBorder*2 + pRRateTable->V_Blank_Time;
    usVDispEnd =    pModeInfo->V_Size;
    usVBlankStart = pModeInfo->V_Size + usVBorder;
    usVBlankEnd =   pModeInfo->V_Size + usVBorder + pRRateTable->V_Blank_Time;
    usVSyncStart =  pRRateTable->V_Sync_Start;
    usVSyncEnd =    pRRateTable->V_Sync_Start + pRRateTable->V_Sync_Time;

    ulPixelClock =  pRRateTable->Clock;
    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "H total = %d\n", usHtotal);
    SetHTotal(ucDisplayPath, usHtotal);
    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "H disp end = %d\n", usHDispEnd);
    SetHDisplayEnd(ucDisplayPath, usHDispEnd);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "H blank start = %d\n", usHBlankStart);
    SetHBlankingStart(ucDisplayPath, usHBlankStart);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "H blank end = %d\n", usHBlankEnd);
    SetHBlankingEnd(ucDisplayPath, usHBlankEnd);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "H sync start = %d\n", usHSyncStart);
    SetHSyncStart(ucDisplayPath, usHSyncStart);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "H sync end = %d\n", usHSyncEnd);
    SetHSyncEnd(ucDisplayPath, usHSyncEnd);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "V total = %d\n", usVtotal);
    SetVTotal(ucDisplayPath, usVtotal);
    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "V disp end = %d\n", usVDispEnd);
    SetVDisplayEnd(ucDisplayPath, usVDispEnd);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "V blank start = %d\n", usVBlankStart);
    SetVBlankingStart(ucDisplayPath, usVBlankStart);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "V blank end = %d\n", usVBlankEnd);
    SetVBlankingEnd(ucDisplayPath, usVBlankEnd);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "V sync start = %d\n", usVSyncStart);
    SetVSyncStart(ucDisplayPath, usVSyncStart);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "V sync end = %d\n", usVSyncEnd);
    SetVSyncEnd(ucDisplayPath, usVSyncEnd);
    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "Pixel clock = %d\n", ulPixelClock);
    SetPixelClock(ucDisplayPath, ulPixelClock);
    PatchPLLbyTVEncoder(ulPixelClock);
    if(DVI_ID==Get_DEV_ID(ucDisplayPath))
        SetTMDSDPAReg(pRRateTable->Clock);

    SetPolarity(ucDisplayPath, pRRateTable->Attribute);

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit SetTimingRegs()==\n");
}


void SetTimingCentering(UCHAR ucDisplayPath, MODE_INFO *pModeInfo, RRATE_TABLE *pRRateTable)
{
    USHORT usHBorder = 0, usVBorder = 0;
    USHORT usHtotal, usHDispEnd, usHBlankStart, usHBlankEnd, usHSyncStart, usHSyncEnd;
    USHORT usVtotal, usVDispEnd, usVBlankStart, usVBlankEnd, usVSyncStart, usVSyncEnd;
    ULONG  ulPixelClock;

    ScrnInfoPtr pScrn = xf86Screens[0];
    RDCRecPtr pRDC = RDCPTR(pScrn);
    USHORT wHSize, wVSize;
    USHORT wUndHSize, wUndVSize;
    USHORT wHDiff=0, wVDiff=0;
    UCHAR ucHdmiType = Get_HDMI_TYPE();

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter SetTimingCentering()==\n");

    wUndHSize = (pModeInfo->H_Size*pRDC->bHRatio)/100;
    wUndVSize = (pModeInfo->V_Size*pRDC->bVRatio)/100;

    if(ucHdmiType==4)
    {
        wHSize = 1920;
        wVSize = 1080;
    }else
    {
        wHSize = 1280;
        wVSize = 720;
    }
    
    if(wHSize > wUndHSize || wVSize > wUndVSize)
    {
        wHDiff = (pModeInfo->H_Size - wUndHSize)>>1;
        wVDiff = (pModeInfo->V_Size - wUndVSize)>>1;
    }
    else
    {
        wUndHSize = pModeInfo->H_Size;
        wUndVSize = pModeInfo->V_Size;
    };

    if (pRRateTable->Attribute & HB)
    {
        usHBorder = 8;
    }
    if (pRRateTable->Attribute & MHB)
    {
        usHBorder = 70;
    }

    if (pRRateTable->Attribute & VB)
    {
        usVBorder = 8;
    }
    if (pRRateTable->Attribute & MVB)
    {
        usVBorder = 90;
    }

    usHBorder += wHDiff;
    usVBorder += wVDiff;

    usHtotal =      wUndHSize + usHBorder*2 + pRRateTable->H_Blank_Time;
    usHDispEnd =    wUndHSize;
    usHBlankStart = wUndHSize + usHBorder;
    usHBlankEnd =   wUndHSize + usHBorder + pRRateTable->H_Blank_Time;
    usHSyncStart =  pRRateTable->H_Sync_Start;
    usHSyncEnd =    pRRateTable->H_Sync_Start + pRRateTable->H_Sync_Time;

    usVtotal =      wUndVSize + usVBorder*2 + pRRateTable->V_Blank_Time;
    usVDispEnd =    wUndVSize;
    usVBlankStart = wUndVSize + usVBorder;
    usVBlankEnd =   wUndVSize + usVBorder + pRRateTable->V_Blank_Time;
    usVSyncStart =  pRRateTable->V_Sync_Start;
    usVSyncEnd =    pRRateTable->V_Sync_Start + pRRateTable->V_Sync_Time;

    ulPixelClock =  pRRateTable->Clock;
    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "H total = %d\n", usHtotal);
    SetHTotal(ucDisplayPath, usHtotal);
    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "H disp end = %d\n", usHDispEnd);
    SetHDisplayEnd(ucDisplayPath, usHDispEnd);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "H blank start = %d\n", usHBlankStart);
    SetHBlankingStart(ucDisplayPath, usHBlankStart);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "H blank end = %d\n", usHBlankEnd);
    SetHBlankingEnd(ucDisplayPath, usHBlankEnd);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "H sync start = %d\n", usHSyncStart);
    SetHSyncStart(ucDisplayPath, usHSyncStart);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "H sync end = %d\n", usHSyncEnd);
    SetHSyncEnd(ucDisplayPath, usHSyncEnd);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "V total = %d\n", usVtotal);
    SetVTotal(ucDisplayPath, usVtotal);
    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "V disp end = %d\n", usVDispEnd);
    SetVDisplayEnd(ucDisplayPath, usVDispEnd);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "V blank start = %d\n", usVBlankStart);
    SetVBlankingStart(ucDisplayPath, usVBlankStart);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "V blank end = %d\n", usVBlankEnd);
    SetVBlankingEnd(ucDisplayPath, usVBlankEnd);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "V sync start = %d\n", usVSyncStart);
    SetVSyncStart(ucDisplayPath, usVSyncStart);

    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "V sync end = %d\n", usVSyncEnd);
    SetVSyncEnd(ucDisplayPath, usVSyncEnd);
    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "Pixel clock = %d\n", ulPixelClock);
    SetPixelClock(ucDisplayPath, ulPixelClock);
    PatchPLLbyTVEncoder(ulPixelClock);

    SetPolarity(ucDisplayPath, pRRateTable->Attribute);

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit SetTimingCentering()==\n");
}

