/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include "typedef.h"
#include "CInt10.h"
#include "vbiosdata.h"
#include "io.h"
#include "output.h"
#include "debug.h"

CI_STATUS GetDevicePortConfig(UCHAR bDeviceIndex, PORT_CONFIG **ppDevicePortConfig)
{
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter %s(bDeviceIndex = %02X)==\n", __func__, bDeviceIndex);
    extern PORT_CONFIG *pPortConfig;
    *ppDevicePortConfig = pPortConfig;

    CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "pPortConfig = 0x%x\n", pPortConfig);
    
    while((*ppDevicePortConfig)->DevID != 0xFF)
    {
        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "(*ppDevicePortConfig)->DevID = %x\n", (*ppDevicePortConfig)->DevID);
        
        if (bDeviceIndex == (*ppDevicePortConfig)->DevID)
        {
            if ((*ppDevicePortConfig)->Attribute & Dev_SUPPORT)
            {
                CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "  Exit1 GetDevicePortConfig()== return success\n");
                return true;
            }
            else
            {
                CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "  Exit1 GetDevicePortConfig()== return fail\n");
                return false;
            }
        }
        (*ppDevicePortConfig)++;
    }

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "  Exit1 GetDevicePortConfig()== return fail!!\n");
    return false;
}

void TurnOnCRTPad()
{
    SetCRReg(0xA8, 0x00, BIT7);
}

void TurnOffCRTPad()
{
    SetCRReg(0xA8, 0x80, BIT7);
}

void TurnOnDVP1Pad()
{
    SetCRReg(0xA3, 0x80, BIT7);
}

void TurnOffDVP1Pad()
{
    SetCRReg(0xA3, 0x00, BIT7);
}

void TurnOnDVP2Pad()
{
    SetCRReg(0xA3, 0x40, BIT6);
}

void TurnOffDVP2Pad()
{
    SetCRReg(0xA3, 0x00, BIT6);
}

void TurnOnDVP12Pad()
{
    TurnOnDVP1Pad();
    TurnOnDVP2Pad();
}

void TurnOffDVP12Pad()
{
    TurnOffDVP1Pad();
    TurnOffDVP2Pad();
}

void SetDPAReg(UCHAR ucDPADelay)
{
    SetSRReg(0x21, ucDPADelay, 0x7);
}

void Set12BitDVP()
{
    SetSRReg(0x1E, 0x00, BIT3);
}

void Set24BitDVP()
{
    SetSRReg(0x1E, 0x08, BIT3);
}

void TurnOnDAC()
{
    SetCRReg(0xDF, 0x00, BIT2);
}
void TurnOffDAC()
{
    SetCRReg(0xDF, 0x04, BIT2);
}

void SetDrivingReg(UCHAR ucDrivingStatus)
{
    SetSRReg(0x4A, ucDrivingStatus, 0x3);
}


void ConfigDigitalPort(UCHAR bDisplayPath)
{
    PORT_CONFIG *pDevicePortConfig;
    UCHAR bDeviceIndex;
    UCHAR bRegValue;

    bDeviceIndex = Get_DEV_ID(bDisplayPath);

    if(bDisplayPath == DISP1)
    {
        bRegValue = 0x3;
    }
    else
    {
        bRegValue = 0x4;
    }

    if (GetDevicePortConfig(bDeviceIndex, &pDevicePortConfig))
    {
        switch(pDevicePortConfig->PortID)
        {
            case CRT_PORT:
                SetSRReg(0x1F, bRegValue, BIT2);
                break;
                
            case DVP1:
                Set12BitDVP();
                SetSRReg(0x1F, bRegValue, BIT0);
                break;
                
            case DVP2:
                Set12BitDVP();
                SetSRReg(0x1F, bRegValue, BIT1);
                break;
                
            case DVP12:
                Set24BitDVP();
                SetSRReg(0x1F, bRegValue, BIT0);
                break;
        }
    }
}


void TurnOnDigitalPort(UCHAR bDeviceIndex)
{
    PORT_CONFIG *pDevicePortConfig;

    
    if ((*(USHORT*)(((UCHAR*)PCIDataStruct) + OFF_DID) == 0x2012))
    {
        if (TransDevIDtoBit(bDeviceIndex) & (B_DVI+B_HDMI+B_TV+B_HDTV))
        {
            TurnOnDVP12Pad();
            return;
        }
    }
    
    if (GetDevicePortConfig(bDeviceIndex, &pDevicePortConfig))
    {
        switch(pDevicePortConfig->PortID)
        {
            case CRT_PORT:
                TurnOnDAC();
                TurnOnCRTPad();
                break;
                
            case DVP1:
                TurnOnDVP1Pad();
                break;
                
            case DVP2:
                TurnOnDVP2Pad();
                break;
                
            case DVP12:
                TurnOnDVP12Pad();
                break;
        }
    }
}       

void TurnOffDigitalPort(UCHAR bDeviceIndex)
{
    PORT_CONFIG *pDevicePortConfig;
    
    if (GetDevicePortConfig(bDeviceIndex, &pDevicePortConfig))
    
    switch(pDevicePortConfig->PortID)
    {
        case CRT_PORT:
            TurnOffCRTPad();

            break;
            
        case DVP1:
            TurnOffDVP1Pad();
            break;
            
        case DVP2:
            TurnOffDVP2Pad();
            break;
            
        case DVP12:
            TurnOffDVP12Pad();
            break;
    }
}       

