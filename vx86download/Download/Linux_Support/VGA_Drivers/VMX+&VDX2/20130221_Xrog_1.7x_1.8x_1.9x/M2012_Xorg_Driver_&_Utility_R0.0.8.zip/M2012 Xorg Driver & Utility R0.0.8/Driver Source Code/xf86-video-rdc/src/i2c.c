/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include "typedef.h"
#include "io.h"
#include "debug.h"


#define I2C_ERROR    0
#define I2C_OK       1
#define I2CWriteCMD  0
#define I2CReadCMD   1

void I2CWriteClock(UCHAR I2CPort, UCHAR data)
{
    ULONG i;
    UCHAR ucMaskData=1, ucTmpData;
    if(data)            
        ucMaskData &= 0;
    for (i=0;i<0x1000; i++)
    {
        SetCRReg(I2CPort, ucMaskData, 0x1);
        ucTmpData = GetCRReg(I2CPort) & 0x01;
        if (ucMaskData == ucTmpData) 
            break;
    }
}

void I2CDelay(UCHAR I2CPort)
{
    UCHAR     i,jtemp;
    
    for (i=0;i<100;i++)
        jtemp = GetCRReg(I2CPort);
}

void I2CWriteData(UCHAR I2CPort, UCHAR data)
{

    ULONG i;
    UCHAR ucMaskData=0x4, ucTmpData;
    if(data)            
        ucMaskData &= 0;
    for (i=0;i<0x1000; i++)
    {
        SetCRReg(I2CPort, ucMaskData, 0x4);
        ucTmpData = GetCRReg(I2CPort) & 0x04;
        if (ucMaskData == ucTmpData) 
            break;
    }
}

void I2CStart(UCHAR I2CPort)
{
    I2CWriteClock(I2CPort, 0x00);               
    I2CDelay(I2CPort);
    I2CWriteData(I2CPort, 0x01);                
    I2CDelay(I2CPort);    
    I2CWriteClock(I2CPort, 0x01);               
    I2CDelay(I2CPort);    
    I2CWriteData(I2CPort, 0x00);                
    I2CDelay(I2CPort);    
    I2CWriteClock(I2CPort, 0x01);                  
    I2CDelay(I2CPort);                    
}

void SendI2CDataByte(UCHAR I2CPort, UCHAR Data)
{
    char i;

    for (i=7;i>=0;i--)
    {
        I2CWriteClock(I2CPort, 0x00);           
        I2CDelay(I2CPort);         
        if((Data>>i)&0x1)
            I2CWriteData(I2CPort, 0x1);           
        else
            I2CWriteData(I2CPort, 0x0);           
        
        I2CDelay(I2CPort);         
        
        I2CWriteClock(I2CPort, 0x01);           
        I2CDelay(I2CPort);                           
    }                
}

UCHAR CheckACK(UCHAR I2CPort)
{    
    I2CWriteClock(I2CPort, 0x00);               
    I2CDelay(I2CPort);    
    I2CWriteData(I2CPort, 0x01);                
    I2CDelay(I2CPort);    
    I2CWriteClock(I2CPort, 0x01);               
    I2CDelay(I2CPort);             
    return ((GetCRReg(I2CPort) & 0x20) ? 0:1);                
}

UCHAR ReceiveI2CDataByte(UCHAR I2CPort, UCHAR I2CSlave)
{
    UCHAR jData=0, jTempData;
    char i;
    ULONG j;

    for (i=7;i>=0;i--)
    {
        I2CWriteClock(I2CPort, 0x00);                
        I2CDelay(I2CPort);     
            
        I2CWriteData(I2CPort, 0x01);                 
        I2CDelay(I2CPort);         
        
        I2CWriteClock(I2CPort, 0x01);                
        I2CDelay(I2CPort);           
        
        for (j=0; j<0x1000; j++)
        {   
            if (((GetCRReg(I2CPort) & 0x10) >> 4))
                break;
        }    
                    
        jTempData =  (GetCRReg(I2CPort) & 0x20) >> 5;
        jData |= ((jTempData & 0x01) << i); 
        
        I2CWriteClock(I2CPort, 0x01);                
        I2CDelay(I2CPort);                           
    }    
    
    return (jData);                              
}

void SendNACK(UCHAR I2CPort)
{
    I2CWriteClock(I2CPort, 0x00);               
    I2CDelay(I2CPort);    
    I2CWriteData(I2CPort, 0x01);                
    I2CDelay(I2CPort);    
    I2CWriteClock(I2CPort, 0x01);               
    I2CDelay(I2CPort);    
}

void I2CStop(UCHAR I2CPort)
{
    I2CWriteClock(I2CPort, 0x00);               
    I2CDelay(I2CPort);    
    I2CWriteData(I2CPort, 0x00);                
    I2CDelay(I2CPort);    
    I2CWriteClock(I2CPort, 0x01);               
    I2CDelay(I2CPort);    
    I2CWriteData(I2CPort, 0x01);                
    I2CDelay(I2CPort);    
    I2CWriteClock(I2CPort, 0x01);                
    I2CDelay(I2CPort);                      
}


UCHAR ReadI2C(UCHAR I2CPort, UCHAR I2CSlave, UCHAR RegIdx, UCHAR* RegData)
{
    I2CStart(I2CPort);

    
    SendI2CDataByte(I2CPort, I2CSlave);
    
    if (!CheckACK(I2CPort))
    {
        return I2C_ERROR;
    }    

    
    SendI2CDataByte(I2CPort, RegIdx);

    if (!CheckACK(I2CPort))
    {
        return I2C_ERROR;
    }    
    
    I2CStart(I2CPort);
   
    
    SendI2CDataByte(I2CPort, I2CSlave+1);
    
    if (!CheckACK(I2CPort))
    {
        return I2C_ERROR;
    }    
    
    *RegData = ReceiveI2CDataByte(I2CPort, I2CSlave);

    SendNACK(I2CPort);

    I2CStop(I2CPort);

    return I2C_OK;       
}

UCHAR WriteI2C(UCHAR I2CPort, UCHAR I2CSlave, UCHAR RegIdx, UCHAR RegData)
{
    CBIOS_PRINTLOG(0, 0, InternalLevel, "WriteI2C(Port=0x%x , addr=0x%x, index=0x%x, value=0x%x)\n", I2CPort, I2CSlave, RegIdx, RegData);
    
    I2CStart(I2CPort);

    
    SendI2CDataByte(I2CPort, I2CSlave);
    if (!CheckACK(I2CPort))
    {
        return I2C_ERROR;
    }    

    
    SendI2CDataByte(I2CPort, RegIdx);
    if (!CheckACK(I2CPort))
    {
        return I2C_ERROR;
    }    

    
    SendI2CDataByte(I2CPort, RegData);
    if (!CheckACK(I2CPort))
    {
        return I2C_ERROR;
    }
    
    SendNACK(I2CPort);
         
    I2CStop(I2CPort);
    return I2C_OK;       
}

UCHAR WriteI2CBits(UCHAR I2CPort, UCHAR I2CSlave, UCHAR RegIdx, UCHAR RegData, UCHAR ucMask)
{
    UCHAR   ucI2CData;
    
    ReadI2C(I2CPort, I2CSlave, RegIdx, &ucI2CData);
    WriteI2C(I2CPort, I2CSlave, RegIdx, (RegData & ucMask)|(ucI2CData & (~ucMask)));
    
    return I2C_OK;       
}

