/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include    "io.h"
#include    "vbiosdata.h"
#include    "debug.h"
#include    "compiler.h"  


__inline void OutPort(UCHAR Index,UCHAR Value)     
{              

    outb(Relocate_IOAddress+Index, Value);

    return;                          
}                                                                       

__inline UCHAR InPort(UCHAR Index)                        
{                                                                      
    UCHAR bInVal = 0x0;    

    bInVal = inb(Relocate_IOAddress+Index);
    
    return bInVal;                                                 
}


void ResetATTR()
{
    InPort(COLOR_INPUT_STATUS1_READ);
    InPort(MONO_INPUT_STATUS1_READ);
}

void EnableATTR()
{
    ResetATTR();
    OutPort(ATTR_DATA_WRITE, 0x20);
}


void SetCRReg(UCHAR bRegIndex, UCHAR bRegValue, UCHAR bMask)
{
    UCHAR btemp = 0x0;
    
    if(bMask != 0xFF)
    {
        OutPort(COLOR_CRTC_INDEX,bRegIndex);
        btemp = (UCHAR)InPort(COLOR_CRTC_DATA);
        bRegValue &= bMask;
        btemp &=~(bMask);
        btemp |= bRegValue;
        OutPort(COLOR_CRTC_DATA,btemp);
    }
    else
    {
        OutPort(COLOR_CRTC_INDEX,bRegIndex);
        OutPort(COLOR_CRTC_DATA,bRegValue);
    }

    return;
}


UCHAR GetCRReg(UCHAR bRegIndex)
{
    UCHAR btemp = 0x0;
    
    OutPort(COLOR_CRTC_INDEX,bRegIndex);
    btemp = (UCHAR)InPort(COLOR_CRTC_DATA);
    return btemp;
}


void SetSRReg(UCHAR bRegIndex, UCHAR bRegValue, UCHAR bMask)
{
    UCHAR btemp = 0x0;
    
    if(bMask != 0xFF)
    {
        OutPort(SEQ_INDEX,bRegIndex);
        btemp = (UCHAR)InPort(SEQ_DATA);
        bRegValue &= bMask;
        btemp &=~(bMask);
        btemp |= bRegValue;
        OutPort(SEQ_DATA,btemp);
    }
    else
    {
        OutPort(SEQ_INDEX,bRegIndex);
        OutPort(SEQ_DATA,bRegValue);
    }

    return;
}


UCHAR GetSRReg(UCHAR bRegIndex)
{
    UCHAR btemp = 0x0;
    
    OutPort(SEQ_INDEX,bRegIndex);
    btemp = (UCHAR)InPort(SEQ_DATA);
        
    return btemp;
}

void SetARReg(UCHAR index,UCHAR value)
{
    OutPort(ATTR_DATA_WRITE,index);
    OutPort(ATTR_DATA_WRITE,value);
}

UCHAR GetARReg(UCHAR index)
{
    UCHAR bTmp;
    InPort(COLOR_INPUT_STATUS1_READ);
    OutPort(ATTR_DATA_WRITE,index);
    bTmp = (UCHAR)InPort(ATTR_DATA_READ);
    InPort(COLOR_INPUT_STATUS1_READ);
    OutPort(ATTR_DATA_WRITE,BIT5);
    return bTmp;
}


void SetGRReg(UCHAR bRegIndex, UCHAR bRegValue, UCHAR bMask)
{
    UCHAR btemp = 0x0;
    
    if(bMask != 0xFF)
    {
        OutPort(GRAPH_INDEX,bRegIndex);
        btemp = (UCHAR)InPort(GRAPH_DATA);
        bRegValue &= bMask;
        btemp &=~(bMask);
        btemp |= bRegValue;
        OutPort(GRAPH_DATA,btemp);
    }
    else
    {
        OutPort(GRAPH_INDEX,bRegIndex);
        OutPort(GRAPH_DATA,bRegValue);
    }

    return;
}

UCHAR GetIS1Reg()
{
    return InPort(COLOR_INPUT_STATUS1_READ);
}

