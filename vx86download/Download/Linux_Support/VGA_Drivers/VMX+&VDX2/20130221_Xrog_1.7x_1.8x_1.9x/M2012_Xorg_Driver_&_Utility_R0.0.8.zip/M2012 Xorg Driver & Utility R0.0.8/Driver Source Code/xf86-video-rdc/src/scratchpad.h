/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#ifndef __SCRATCHPAD_H__
#define __SCRATCHPAD_H__



#define SCRATCH_01                               0x81 * 0x100
#define     IDX_SCRATCH_01                       SCRATCH_01 + 0xFF
#define     IDX_IGA1_DEV_ID                      SCRATCH_01 + 0x0F
#define     IDX_IGA2_DEV_ID                      SCRATCH_01 + 0xF0

#define SCRATCH_02                               0x82 * 0x100
#define     IDX_SCRATCH_02                       SCRATCH_02 + 0xFF
#define     IDX_DISPLAY1_CHANGED                 SCRATCH_02 + 0x01
#define     IDX_DISPLAY2_CHANGED                 SCRATCH_02 + 0x02
#define     IDX_PWR_SEQ_ON                       SCRATCH_02 + 0x04

#define SCRATCH_03                               0x83 * 0x100
#define     IDX_SCRATCH_03                       SCRATCH_03 + 0xFF
#define     IDX_IGA2_VESA_MODE                   SCRATCH_03 + 0xFF

#define SCRATCH_04                               0x84 * 0x100
#define     IDX_SCRATCH_04                       SCRATCH_04 + 0xFF
#define     IDX_IGA2_VESA_MODE_OVERFLOW          SCRATCH_04 + 0x01
#define     IDX_IGA2_RRATE_ID                    SCRATCH_04 + 0xFE

#define SCRATCH_05                               0x85 * 0x100
#define     IDX_SCRATCH_05                       SCRATCH_05 + 0xFF
#define     IDX_TV1_TYPE                         SCRATCH_05 + 0x0F
#define     IDX_TV1_CONNECTION_TYPE              SCRATCH_05 + 0x30

#define SCRATCH_06                               0x86 * 0x100
#define     IDX_SCRATCH_06                       SCRATCH_06 + 0xFF
#define     IDX_TV2_TYPE                         SCRATCH_06 + 0x0F
#define     IDX_TV2_CONNECTION_TYPE              SCRATCH_06 + 0x30

#define SCRATCH_07                               0x87 * 0x100
#define     IDX_SCRATCH_07                       SCRATCH_07 + 0xFF
#define     IDX_HDTV1_TYPE                       SCRATCH_07 + 0x07
#define     IDX_HDTV1_CONNECTION_TYPE            SCRATCH_07 + 0x08
#define     IDX_HDTV2_TYPE                       SCRATCH_07 + 0x70
#define     IDX_HDTV2_CONNECTION_TYPE            SCRATCH_07 + 0x80

#define SCRATCH_08                               0x88 * 0x100
#define     IDX_SCRATCH_08                       SCRATCH_08 + 0xFF
#define     IDX_HDMI1_TYPE                       SCRATCH_08 + 0x0F
#define     IDX_HDMI2_TYPE                       SCRATCH_08 + 0xF0

#define SCRATCH_09                               0x89 * 0x100
#define     IDX_SCRATCH_09                       SCRATCH_09 + 0xFF
#define     IDX_HDMI1_CONNECTION_TYPE            SCRATCH_09 + 0x03
#define     IDX_HDMI2_CONNECTION_TYPE            SCRATCH_09 + 0x30

#define SCRATCH_10                               0x8A * 0x100
#define     IDX_SCRATCH_10                       SCRATCH_10 + 0xFF
#define     IDX_LCD_H_SIZE_OVERFLOW              SCRATCH_10 + 0xF0
#define     IDX_LCD_V_SIZE_OVERFLOW              SCRATCH_10 + 0x0F

#define SCRATCH_11                               0x8B * 0x100
#define     IDX_SCRATCH_11                       SCRATCH_11 + 0xFF
#define     IDX_LCD_H_SIZE                       SCRATCH_11 + 0xFF

#define SCRATCH_12                               0x8C * 0x100
#define     IDX_SCRATCH_12                       SCRATCH_12 + 0xFF
#define     IDX_LCD_V_SIZE                       SCRATCH_12 + 0xFF

#define SCRATCH_13                               0x8D * 0x100
#define     IDX_SCRATCH_13                       SCRATCH_13 + 0xFF
#define     IDX_IGA1_VESA_MODE_OVERFLOW          SCRATCH_13 + 0x01
#define     IDX_IGA1_RRATE_ID                    SCRATCH_13 + 0xFE

#define SCRATCH_14                               0x8E * 0x100
#define     IDX_SCRATCH_14                       SCRATCH_14 + 0xFF
#define     IDX_IGA1_VGA_MODE                    SCRATCH_14 + 0xFF
#define     IDX_IGA1_VESA_MODE                   SCRATCH_14 + 0xFF

#define SCRATCH_15                               0x8F * 0x100
#define     IDX_SCRATCH_15                       SCRATCH_15 + 0xFF
#define     IDX_NEW_IGA1_DEV_ID                  SCRATCH_15 + 0x0F
#define     IDX_NEW_IGA2_DEV_ID                  SCRATCH_15 + 0xF0

#define SCRATCH_16                               0x90 * 0x100
#define     IDX_SCRATCH_16                       SCRATCH_16 + 0xFF
#define     IDX_KEEP_DISPLAY_OFF                 SCRATCH_16 + 0x80
#define     IDX_DPMS_STATE                       SCRATCH_16 + 0x40
#define     IDX_LINEAR_MODE                      SCRATCH_16 + 0x20
#define     IDX_DS_ENABLE                        SCRATCH_16 + 0x10

#define SCRATCH_17                               0x91 * 0x100
#define     IDX_SCRATCH_17                       SCRATCH_17 + 0xFF
#define     IDX_LCD2_H_SIZE_OVERFLOW             SCRATCH_10 + 0xF0
#define     IDX_LCD2_V_SIZE_OVERFLOW             SCRATCH_10 + 0x0F

#define SCRATCH_18                               0x92 * 0x100
#define     IDX_SCRATCH_18                       SCRATCH_18 + 0xFF
#define     IDX_LCD2_H_SIZE                      SCRATCH_18 + 0xFF

#define SCRATCH_19                               0x93 * 0x100
#define     IDX_SCRATCH_19                       SCRATCH_19 + 0xFF
#define     IDX_LCD2_V_SIZE                      SCRATCH_19 + 0xFF

#define SCRATCH_20                               0x94 * 0x100
#define     IDX_SCRATCH_20                       SCRATCH_20 + 0xFF
#define     IDX_LVDS1_TX_ID                      SCRATCH_20 + 0xF0
#define     IDX_LVDS2_TX_ID                      SCRATCH_20 + 0x0F

#define SCRATCH_21                               0x95 * 0x100
#define     IDX_SCRATCH_21                       SCRATCH_21 + 0xFF
#define     IDX_TMDS1_TX_ID                      SCRATCH_21 + 0xF0
#define     IDX_TMDS2_TX_ID                      SCRATCH_21 + 0x0F

#define SCRATCH_22                               0x96 * 0x100
#define     IDX_SCRATCH_22                       SCRATCH_22 + 0xFF
#define     IDX_TV1_ENCODER_ID                   SCRATCH_22 + 0xF0
#define     IDX_TV2_ENCODER_ID                   SCRATCH_22 + 0x0F

#define SCRATCH_23                               0x97 * 0x100
#define     IDX_SCRATCH_23                       SCRATCH_23 + 0xFF
#define     IDX_LCD1_TABLE_INDEX                 SCRATCH_23 + 0xF0
#define     IDX_LCD2_TABLE_INDEX                 SCRATCH_23 + 0x0F

#define SCRATCH_24                               0x98 * 0x100
#define     IDX_TV1_Mode_TABLE_INDEX             SCRATCH_24 + 0xF0
#define     IDX_TV2_Mode_TABLE_INDEX             SCRATCH_24 + 0x0F

#define SCRATCH_25                               0x99 * 0x100
#define     IDX_SCRATCH_25                       SCRATCH_25 + 0xFF
#define     S25_Reserved                         SCRATCH_25 + 0xF0
#define     IDX_BOOT_DEV_ID                      SCRATCH_25 + 0x0F

#endif 

