/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include "typedef.h"
#include "regop.h"
#include "reggroupindex.h"
#include "io.h"


USHORT ReadRegFromHW(REG_OP *pRegOp)
{
    USHORT wValue = 0x0;
    UCHAR    btemp = 0x0, bMasktemp = 0x0;

    while((pRegOp->RegGroup)!= NR)
    {        
        if(pRegOp->RegGroup == CR)
        {
            
            OutPort(COLOR_CRTC_INDEX,(pRegOp->RegIndex));
            btemp = (UCHAR)InPort(COLOR_CRTC_DATA);
        }
        else
        {
            
            OutPort(SEQ_INDEX,(pRegOp->RegIndex));
            btemp = (UCHAR)InPort(SEQ_DATA);
        }
        
        bMasktemp = (pRegOp->RegMask);

        
        btemp &= bMasktemp;

        
        while(!(bMasktemp & BIT0))
        {
            bMasktemp = bMasktemp >> 1;
            btemp = btemp >> 1;
        }

        
        wValue |= (((USHORT)btemp) << (pRegOp->RegShiftBit));
        
        
        pRegOp++;

    }

    return wValue;
}



void WriteRegToHW(REG_OP *pRegOp, USHORT value)
{
    UCHAR btemp, btemp1;
    UCHAR bCount;
    UCHAR bMasktemp;

    while((pRegOp->RegGroup)!= NR)
    {
        btemp = 0x0; btemp1 = 0x0;
        bCount = 0x0; bMasktemp = 0x0;
    
        bMasktemp = (pRegOp->RegMask);

        
        while(!(bMasktemp & BIT0))
        {
            bMasktemp = bMasktemp >> 1;
            bCount ++;
        }
    
        
        btemp = value >> (pRegOp->RegShiftBit);
        btemp &= (bMasktemp);

        
        if(!(pRegOp->RegMask & BIT0))
        {
            btemp = btemp << bCount;
        }
            
        if(pRegOp->RegGroup == CR)
        {
            
            OutPort(COLOR_CRTC_INDEX,(pRegOp->RegIndex));
            btemp1 = (UCHAR)InPort(COLOR_CRTC_DATA);
            btemp1 &= ~(pRegOp->RegMask);
            btemp1 |= btemp;
            OutPort(COLOR_CRTC_DATA,btemp1);
        }
        else
        {
            
            OutPort(SEQ_INDEX,(pRegOp->RegIndex));
            btemp1 = (UCHAR)InPort(SEQ_DATA);
            btemp1 &= ~(pRegOp->RegMask);
            btemp1 |= btemp;
            OutPort(SEQ_DATA,btemp1);            
        }

        pRegOp++;
        
    }
 
}

