/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include "typedef.h"
#include "CInt10.h"
#include "io.h"
#include "output.h"

void PowerSequenceOn();
void PowerSequenceOff();
void WaitPowerSequenceDone();
void ControlPwrSeqOn(UCHAR bDeviceIndex);
void ControlPwrSeqOff(UCHAR bDeviceIndex);

void PowerSequenceOn()
{
    
    if (!(GetSRReg(0x11) & BIT0))
    {
        
        SetSRReg(0x32, BIT1, BIT1);
        
        
        SetSRReg(0x11, BIT0, BIT0);
        
        
        WaitPowerSequenceDone();
    }
}

void PowerSequenceOff()
{
    
    if (GetSRReg(0x11) & BIT0)
    {
        
        SetSRReg(0x11, 0, BIT0);
        
        
        WaitPowerSequenceDone();
        
        
        SetSRReg(0x32, 0, BIT1);
    }
}


void WaitPowerSequenceDone()
{
    UCHAR SR32;
     
    SR32 = GetSRReg(0x32);

    
    while(SR32 == GetSRReg(0x32));
}

void ControlPwrSeqOn(UCHAR bDeviceIndex)
{
    PORT_CONFIG *pDevicePortConfig;
    
    if ((TransDevIDtoBit(bDeviceIndex) & (B_LCD+B_LCD2)) && (GetDevicePortConfig(bDeviceIndex, &pDevicePortConfig)))
    {
        if (pDevicePortConfig->Attribute & TX_PS)
        {
            if (pDevicePortConfig->TX_Enc_ID == TX_VT1636)
            {

            }
        }
        else if ((pDevicePortConfig->PortID == DVP1) || (pDevicePortConfig->PortID == DVP12))
        {
            PowerSequenceOn();
        }
    }    
}

void ControlPwrSeqOff(UCHAR bDeviceIndex)
{
    PORT_CONFIG *pDevicePortConfig;
    
    if ((TransDevIDtoBit(bDeviceIndex) & (B_LCD+B_LCD2)) && (GetDevicePortConfig(bDeviceIndex, &pDevicePortConfig)))
    {
        if (pDevicePortConfig->Attribute & TX_PS)
        {
            if (pDevicePortConfig->TX_Enc_ID == TX_VT1636)
            {

            }
        }
        else if ((pDevicePortConfig->PortID == DVP1) || (pDevicePortConfig->PortID == DVP12))
        {
            PowerSequenceOff();
        }
    }    
}

