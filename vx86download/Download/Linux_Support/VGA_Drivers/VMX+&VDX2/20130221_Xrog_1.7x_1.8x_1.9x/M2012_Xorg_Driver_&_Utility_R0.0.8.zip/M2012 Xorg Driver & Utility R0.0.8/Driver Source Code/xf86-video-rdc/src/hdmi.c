/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include "vbiosdata.h"
#include "typedef.h"
#include "timingtbl.h"
#include "CInt10.h"
#include "reggroupindex.h"
#include "edid.h"
#include "debug.h"
#include "HDMITbl.h"



#define TX_ITE6610  0x01
#define TX_SIL1162  0x02    
#define TX_EP932M   0x03


#define HDMI_TYPE_6x4   0
#define HDMI_TYPE_720P  1
#define HDMI_TYPE_1080I  2
#define HDMI_TYPE_480P  3
#define HDMI_TYPE_1080P 4


#define     HDMICEAExtEDIDStart     0x80
#define     HDMICEAExtDatablock     0x84
#define     HDMICEAExtVersion       0x0302
#define     HDMICEAExtIEEEIDMSB     0x000C
#define     HDMICEAExtIEEEIDLSB     0x03
#define     HDMICEAExtVenderID      0x03

void EP932GPIO2Reset(UCHAR bGPIOMask);
void TurnOnTMDSTX(UCHAR ucDeviceID);
void LoadHDMITiming(UCHAR bDisplayPath, USHORT wModeNum);
void TurnOffTMDSTX();
void SetHDMIAVIInfoframe();
void SetHDMIDVIMode(UCHAR ucMode, UCHAR ucI2CPort, UCHAR ucI2CAddr);
CI_STATUS GetTMDSTxI2CValue(UCHAR *pucI2CPort, UCHAR *pucI2CAddr, UCHAR *pucTX_ID);
void SetTMDSReg(UCHAR ucDeviceID);
USHORT QueryHDMIConnectStatus();
USHORT CheckCEAExtEDIDVersion(UCHAR ucI2CPort, UCHAR ucI2CAddr, UCHAR ucTxId);
UCHAR GetCEAExtEDIDData(UCHAR ucI2CPort, UCHAR ucI2CAddr, UCHAR ucIndex);
CI_STATUS CheckHDMIIDinVSD(UCHAR ucI2CPort, UCHAR ucI2CAddr, UCHAR ucIndex);
void QuickQueryHDMIConnectStatus(USHORT *pusDeviceBit);
void SetTMDSDPAReg(ULONG dwPixelClock);

UCHAR EP932M_HDMIAVI720P[] =
{
    I2C,
    0x66, 0xB3,
    0x67, 0x10,
    0x68, 0xA8,
    0x69, 0x00,
    0x6A, 0x04,
    0x6B, 0x00,
    0x6C, 0x00,
    0x6D, 0x00,
    0x6E, 0x00,
    0x6F, 0x00,
    0x70, 0x00,
    0x71, 0x00,
    0x72, 0x00,
    0x73, 0x00,
    0x74, 0x61,
    0x75, 0x01,
    0x76, 0x0F,
    0x77, 0x00,
    0x78, 0x00,
    0x79, 0x00,
    0xFF, 0xFF
};

UCHAR EP932M_HDMIAVI1080P[]=
    {
    I2C,
    0x66, 0xA7,
    0x67, 0x10,
    0x68, 0xA8,
    0x69, 0x00,
    0x6A, 0x10,
    0x6B, 0x00,
    0x6C, 0x00,
    0x6D, 0x00,
    0x6E, 0x00,
    0x6F, 0x00,
    0x70, 0x00,
    0x71, 0x00,
    0x72, 0x00,
    0x73, 0x00,
    0x74, 0x61,
    0x75, 0x01,
    0x76, 0x0F,
    0x77, 0x00,
    0x78, 0x00,
    0x79, 0x00,
    0xFF, 0xFF
};


void EP932GPIO2Reset(UCHAR bGPIOMask)
{
    UCHAR ucTmpData;
    ULONG i;
    SetCRReg(0xDA,bGPIOMask,bGPIOMask);
    SetCRReg(0xDB,0,bGPIOMask);
    
    for(i=0; i<300000; i++)
        ucTmpData = GetCRReg(0);
    SetCRReg(0xDB,bGPIOMask,bGPIOMask);
}

void TurnOnTMDSTX(UCHAR ucDeviceID)
{
    USHORT usDeviceBit = TransDevIDtoBit(ucDeviceID);
    UCHAR ucI2CPort, ucI2CAddr, ucTX_ID, ucTX_0A;

    
    if (bDVISUPPORT || bHDMISUPPORT)
    {
        if (usDeviceBit & (B_HDMI|B_DVI))
        {
            GetTMDSTxI2CValue(&ucI2CPort, &ucI2CAddr, &ucTX_ID);
            switch(ucTX_ID)
            {
                case TX_ITE6610:
                    WriteI2C(ucI2CPort, ucI2CAddr, 0x04, 0x01);
                    break;
                case TX_SIL1162:
                    WriteI2C(ucI2CPort, ucI2CAddr, 0x08, 0x3b);
                    break;
                case TX_EP932M:
                if(ucDeviceID == DVI_ID)
                    ReadI2C(ucI2CPort, ucI2CAddr, 0x0a, &ucTX_0A); 
                    EP932GPIO2Reset(0x4);
                    SetEP932MInitReg(ucDeviceID,ucI2CPort,ucI2CAddr);
                    if(ucDeviceID == HDMIINDEX) 
                    {                        
                        switch(Get_HDMI_TYPE())
                        { 
                            case HDMI_TYPE_6x4:  
                                SetDPAReg(4);    
                                SetDrivingReg(0); 
                                break;            
                            case HDMI_TYPE_1080P:  
                                WriteI2C(ucI2CPort, ucI2CAddr, 0x0a, 0x1f);
                                
                                SetDPAReg(0);                              
                                SetDrivingReg(3);                         
                                break;                           
                            default: 
                                SetDPAReg(4);
                                SetDrivingReg(3);
                                break;                        
                         }                        
                         SetHDMIInfoframe(Get_HDMI_TYPE(),ucI2CPort,ucI2CAddr);
                     }else 
                     WriteI2C(ucI2CPort, ucI2CAddr, 0x0a, ucTX_0A);
                default:
                    break;
            }

            if (usDeviceBit & B_DVI)
            {
                SetHDMIDVIMode(0, ucI2CPort, ucI2CAddr);
            }
            else
            {
                SetHDMIDVIMode(1, ucI2CPort, ucI2CAddr);
            }
        }
    }
}


void SetEP932MInitReg(UCHAR ucDeviceID,UCHAR I2CPort,UCHAR Addr)
{
    HDMI_I2C_REG *pInitEP932MReg = (HDMI_I2C_REG*)(&EP932M_INIT_Reg);
    UCHAR ucI2CPort=I2CPort, ucAddr=Addr;
    
    
        do{
            
            WriteI2C(ucI2CPort, ucAddr, pInitEP932MReg->ucIndex,pInitEP932MReg->ucData);
            pInitEP932MReg = (HDMI_I2C_REG*)((int)pInitEP932MReg + sizeof(HDMI_I2C_REG));
        }while(pInitEP932MReg->ucIndex!=0xFF);
    
    
}




void GetHDMIVideoCodeID(BYTE ucHDMIType, BYTE* ucHDMIVCID)
{
    
    
    switch(ucHDMIType)
    {
        case HDMI_TYPE_6x4:
            *ucHDMIVCID = 1;  
        break;
        case HDMI_TYPE_720P:
            *ucHDMIVCID = 4;  
        break;
        case HDMI_TYPE_1080I:
            *ucHDMIVCID = 5;  
        break;
        case HDMI_TYPE_480P:        
            *ucHDMIVCID = 2; 
          
        break;
        case HDMI_TYPE_1080P:
            *ucHDMIVCID = 16; 
        break;
        default:
            *ucHDMIVCID = 16; 
             
        break;
    }
}


void SetHDMIInfoframe(UCHAR ucHDMIType,UCHAR I2CPort,UCHAR Addr)
{
    UCHAR ucI2CPort=I2CPort, ucAddr=Addr, i, ucHDMIVCID;
    UCHAR Temp_Data[15];
   
    GetHDMIVideoCodeID(ucHDMIType, &ucHDMIVCID);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    for(i=0;i<15;i++)
        Temp_Data[i]=0;
        
    Temp_Data[1] |= 0x00; 
    Temp_Data[1] |= 0x10; 

        
    Temp_Data[1] |= 0x00; 
                          
                          
    
    
    switch(ucHDMIVCID)
    {
        case  4: case  5: case 16: case 19: case 20: case 31: case 32: 
        case 33: case 34: case 39: case 40: case 41: case 46: case 47:      
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            Temp_Data[2] |= 0x80;
            break;
        default:                                                            
            if(ucHDMIVCID<76)                                               
                Temp_Data[2] |= 0x40;
            else
                Temp_Data[2] |= 0x80;
            break;

    }
    
    Temp_Data[2] |= 0x08; 
    if(ucHDMIVCID < EP932_VDO_Settings_Max) 
        Temp_Data[2] |= EP932_VDO_Settings[ucHDMIVCID].AR_PR & 0x30;
    Temp_Data[2] |= 0x0;
    if(ucHDMIVCID < EP932_VDO_Settings_IT_Start)
        Temp_Data[4] |= EP932_VDO_Settings[ucHDMIVCID].VideoCode;
    if(ucHDMIVCID < EP932_VDO_Settings_Max)
        Temp_Data[5] |= (EP932_VDO_Settings[ucHDMIVCID].AR_PR & 0x0C) >> 2;

    
    Temp_Data[0] = 0x91; 
                         
                         
                         
    for(i=1; i<6; ++i) {
        Temp_Data[0] += Temp_Data[i];
    }
    Temp_Data[0] = ~(Temp_Data[0] - 1); 
    
    for(i=0; i<14; i++)
        WriteI2C(ucI2CPort, ucAddr, Addr_EP932M_AVI_Start+i, Temp_Data[i]);

    
    
    
    
    
    
    
    
    
    
    

    for(i=0;i<15;i++)
        Temp_Data[i]=0;
    
    Temp_Data[1] = 0x1;  
                         
                         
                         
                         
                         
    Temp_Data[2] = 0xF;  
    
    
    Temp_Data[4] = 0x0;
    
    Temp_Data[0] = 0x8F; 
                         
                         
                         
    for(i=1; i<6; ++i)
        Temp_Data[0] += Temp_Data[i];
    Temp_Data[0] = ~(Temp_Data[0] - 1);
    for(i=0; i<6; i++)
        WriteI2C(ucI2CPort, ucAddr, Addr_EP932M_ADO_Start+i ,Temp_Data[i]);
}


void LoadHDMITiming(UCHAR bDisplayPath, USHORT wModeNum)
{
    MODE_INFO *pModeInfo;
    MODE_INFO *pUserModeInfo;
    RRATE_TABLE *pRRateTable;
    UCHAR ucHdmiType = Get_HDMI_TYPE();
    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter LoadHDMITiming()==\n");

    pModeInfo = &(HDMITable[ucHdmiType].ModeInfo);
    pRRateTable = &(HDMITable[ucHdmiType].RRateTable);

    
    
    SetTimingRegs(bDisplayPath, pModeInfo, pRRateTable);
    

    Get_MODE_INFO(wModeNum, &pUserModeInfo);

    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "  pUserModeInfo = 0x%x\n", pUserModeInfo);
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "  pModeInfo = 0x%x\n", pModeInfo);
    
    SetScalingFactor(bDisplayPath, pUserModeInfo, pModeInfo);

    SetHDMIAVIInfoframe();

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit LoadHDMITiming()==\n");
}


void TurnOffTMDSTX()
{
    UCHAR   ucTXIndex;
    UCHAR   ucI2CPort, ucI2CAddr;
    
    if (bDVISUPPORT | bHDMISUPPORT)
    {
        GetTMDSTxI2CValue(&ucI2CPort, &ucI2CAddr, &ucTXIndex);

        switch (ucTXIndex)
        {
            case TX_ITE6610:
                WriteI2C(ucI2CPort, ucI2CAddr, 0x04, 0x1D);
                break;
            case TX_SIL1162:
                WriteI2C(ucI2CPort, ucI2CAddr, 0x08, 0x34);
                break;
            case TX_EP932M:
                WriteI2C(ucI2CPort, ucI2CAddr, 0x08, 0x06);
                break;
            default:
                break;
        }
    }
}

void SetHDMIAVIInfoframe()
{
    int i;
    UCHAR ucI2CPort, ucI2CAddr, ucTX_ID;
    UCHAR *pucIT6610_AVI_Tbl = (UCHAR*)IT6610_AVI_TBL;
    UCHAR *pucEP932M_AVI_Tbl;

    switch (Get_HDMI_TYPE())
    {
        case HDMI_TYPE_6x4:
            pucEP932M_AVI_Tbl = (UCHAR*)EP932M_AVI_TBL;
            break;
        case HDMI_TYPE_720P:
            pucEP932M_AVI_Tbl = (UCHAR*)(&EP932M_HDMIAVI720P);
            break;
        case HDMI_TYPE_480P:
            break;
        case HDMI_TYPE_1080P:
            pucEP932M_AVI_Tbl =(UCHAR*)(&EP932M_HDMIAVI1080P);
            break;
        default:
            break;
    }
    
    GetTMDSTxI2CValue(&ucI2CPort, &ucI2CAddr, &ucTX_ID);
    if (ucTX_ID == TX_ITE6610)
    {
        SerialLoadTable(&pucIT6610_AVI_Tbl, ucI2CPort, ucI2CAddr);
    }
    else if (ucTX_ID == TX_EP932M)
    {
        SerialLoadTable(&pucEP932M_AVI_Tbl, ucI2CPort, ucI2CAddr);
    }
    
}


void SetHDMIDVIMode(UCHAR ucMode, UCHAR ucI2CPort, UCHAR ucI2CAddr)
{
    UCHAR ucTX_ID;
    ucTX_ID = Get_TMDS1_TX_ID();
    switch (ucTX_ID)
    {
        case TX_ITE6610:
            WriteI2C(ucI2CPort, ucI2CAddr, 0xf0, 0x00);
            WriteI2CBits(ucI2CPort, ucI2CAddr, 0xc0, ucMode, BIT0);
            break;
        case TX_EP932M:
            WriteI2C(ucI2CPort, ucI2CAddr, 0xf0, 0x00);
            WriteI2CBits(ucI2CPort, ucI2CAddr, 0x0e, ucMode, BIT0);
            break;
        default:
            break;
    }
}


CI_STATUS GetTMDSTxI2CValue(UCHAR *pucI2CPort, UCHAR *pucI2CAddr, UCHAR *pucTX_ID)
{
    PORT_CONFIG *pDevicePortConfig = NULL;
    HDMITxDetect *pHdmiTxDetect = pTMDSTxTable;
    
    if (bDVISUPPORT || bHDMISUPPORT)
    {
        if (GetDevicePortConfig(DVI_ID, &pDevicePortConfig))
        {
        }
        else if (GetDevicePortConfig(HDMI_ID, &pDevicePortConfig))
        {
        }
        else
        {
            return false;
        }
 
        *pucTX_ID = Get_TMDS1_TX_ID();
        
        *pucI2CPort = pDevicePortConfig->TX_I2C_Port;
        *pucI2CAddr = pDevicePortConfig->TX_I2C_Addr;
         
        while (pHdmiTxDetect->TMDSTxIndex != 0x0FF)
        {
             if (pHdmiTxDetect->TMDSTxIndex == *pucTX_ID)
            {
                 *pucI2CAddr = pHdmiTxDetect->TMDSTxAddr;
                return true;
            }
             pHdmiTxDetect++;
        }
    }
     return false;
}


void SetTMDSReg(UCHAR ucDeviceID)
{
    if (bHDMISUPPORT|bDVISUPPORT)
    {
        if (TransDevIDtoBit(ucDeviceID) | (B_DVI+B_HDMI))
        {
            SetSRReg(0x13, 0x00, BIT0+BIT2);
            SetSRReg(0x22, 0x00, BIT0);
            SetSRReg(0x32, 0x01, BIT0);
        }
    }
}


USHORT QueryHDMIConnectStatus()
{
    UCHAR ucI2CPort, ucI2CAddr, ucTxId;
    USHORT usEdidData;
    UCHAR ucEdidData;
    UCHAR ucIndex, ucMaxIndex;
    
    if (bHDMISUPPORT || bDVISUPPORT)
    {
        GetTMDSTxI2CValue(&ucI2CPort, &ucI2CAddr, &ucTxId);

        usEdidData = CheckMinitorEDID(ucI2CPort, ucTxId);

        if (usEdidData != DDCEDIDWORD)
            return 0;

        usEdidData = CheckCEAExtEDIDVersion(ucI2CPort, 0xa0, ucTxId);

        if (usEdidData != HDMICEAExtVersion)
            return B_DVI;

        ucEdidData = GetCEAExtEDIDData(ucI2CPort, 0xa0, 0x82);
        ucMaxIndex = ucEdidData + HDMICEAExtEDIDStart;

        ucIndex = HDMICEAExtDatablock;

        while (1)
        {
            if (ucIndex > ucMaxIndex)
                return B_DVI;
                
            ucEdidData = GetCEAExtEDIDData(ucI2CPort, 0xa0, ucIndex);
            ucIndex++;

            if ((ucEdidData >> 5) == HDMICEAExtVenderID)
                break;
            
            ucEdidData &= BIT0+BIT1+BIT2+BIT3+BIT4;
            ucIndex += ucEdidData;
        }

        if (!CheckHDMIIDinVSD(ucI2CPort, 0xa0, ucIndex))
            return B_DVI;
        else
            return B_HDMI;
    }
}





CI_STATUS CheckHDMIIDinVSD(UCHAR ucI2CPort, UCHAR ucI2CAddr, UCHAR ucIndex)
{
    UCHAR ucRegData1, ucRegData2;
    
    if (bHDMISUPPORT)
    {
        ReadI2C(ucI2CPort, ucI2CAddr, ucIndex, &ucRegData1);
        if (ucRegData1 != HDMICEAExtIEEEIDLSB)
            return false;

        ReadI2C(ucI2CPort, ucI2CAddr, ucIndex+1, &ucRegData1);
        ReadI2C(ucI2CPort, ucI2CAddr, ucIndex+2, &ucRegData2);
        
        if (((((USHORT)ucRegData2) << 8) | (USHORT)ucRegData1) != HDMICEAExtIEEEIDMSB)
            return false;

        return true;
    }
    return false;
}


void QuickQueryHDMIConnectStatus(USHORT *pusDeviceBit)
{
    UCHAR ucI2CPort;
    UCHAR ucI2CAddr;
    UCHAR ucTX_ID;
    USHORT usEdidData;
    
    if (bHDMISUPPORT)
    {
        GetTMDSTxI2CValue(&ucI2CPort, &ucI2CAddr, &ucTX_ID);
        
        usEdidData = CheckMinitorEDID(ucI2CPort, ucTX_ID);
        if (usEdidData == DDCEDIDWORD)
            *pusDeviceBit |= B_HDMI;
    }
}


UCHAR GetCEAExtEDIDData(UCHAR ucI2CPort, UCHAR ucI2CAddr, UCHAR ucIndex)
{
    UCHAR ucRetValue;

    if (bHDMISUPPORT)
        ReadI2C(ucI2CPort, ucI2CAddr, ucIndex, &ucRetValue);

    return ucRetValue;
}


USHORT CheckCEAExtEDIDVersion(UCHAR ucI2CPort, UCHAR ucI2CAddr, UCHAR ucTxId)
{
    UCHAR ucRetValue1, ucRetValue2;

    if (bHDMISUPPORT)
    {
        ReadI2C(ucI2CPort, 0xa0, HDMICEAExtEDIDStart, &ucRetValue1);
        ReadI2C(ucI2CPort, 0xa0, HDMICEAExtEDIDStart+1, &ucRetValue2);
    }
    return ((((USHORT)ucRetValue2) << 8) | (USHORT)ucRetValue1);
}

void SetTMDSDPAReg(ULONG dwPixelClock)
{
    UCHAR ucI2CPort, ucI2CAddr, ucTX_ID, i=0;

    GetTMDSTxI2CValue(&ucI2CPort, &ucI2CAddr, &ucTX_ID);
    
    if(TX_EP932M ==Get_TMDS1_TX_ID())
    {
        for(i=0; i<(sizeof(TMDS_EP932M)/sizeof(DVPDPA_TABLE)); i++)
        {
            if(dwPixelClock<TMDS_EP932M[i].Clock)
            {
                i--;
                break;
            }
        }
    }
    if(i>0)
        SetDrivingReg(3);
    else
        SetDrivingReg(0);
    SetDPAReg(TMDS_EP932M[i].VGAValue);
    WriteI2C(ucI2CPort, ucI2CAddr, TMDS_EP932M[i].TX_Index, TMDS_EP932M[i].TX_Data); 
}

