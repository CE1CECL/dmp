/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#include "regop.h"
#include "reggroupindex.h"
#include "vbiosdata.h"



REG_OP Pitch1[] = {
             {CR, 0xFF, 0x13,0},
             {CR, 0x3F, 0xB0,8},
             {NR,0x0,0x0,0x0}
};


REG_OP Pitch2[] = {
             {CR, 0xFF, 0x3A,0},
             {CR, 0x3F, 0x3B,8},
             {NR,0x0,0x0,0x0}
};



void SetFIFO(UCHAR DisplayPath)
{
    UCHAR *pucPCIDataStruct = (UCHAR*)PCIDataStruct;

    if (DisplayPath == DISP1)
    {
        if (*(USHORT*)(pucPCIDataStruct + OFF_DID) == 0x2010)
        {
            SetCRReg(0xA7, 0x5F, 0xFF);
            SetCRReg(0xA6, 0x3F, 0xFF);
        }
        else if (*(USHORT*)(pucPCIDataStruct + OFF_DID) == 0x2012)
        {
            SetCRReg(0xA7, 0xBF, 0xFF);
            SetCRReg(0xA6, 0x9F, 0xFF);
        }
        else
        {
            SetCRReg(0xA7, 0x3F, 0xFF);
            SetCRReg(0xA6, 0x3F, 0xFF);
        }
    }
    else if (DisplayPath == DISP2)
    {
        SetCRReg(0x35, 0x3F, 0xFF);
        SetCRReg(0x34, 0x3F, 0xFF);
    }
}


void SetPitch(UCHAR DisplayPath, USHORT Value)
{
    
    Value += 7;
    Value >>= 3;

    if(DisplayPath == DISP1)
    {
        WriteRegToHW(Pitch1, Value);
    }
    else
    {
        WriteRegToHW(Pitch2, Value);
    }

    return;
    
}


USHORT GetPitch(UCHAR DisplayPath)
{
    USHORT wPitch;
    
    if(DisplayPath == DISP1)
    {
        wPitch = ReadRegFromHW(Pitch1);
    }
    else
    {
        wPitch = ReadRegFromHW(Pitch2);
    }

    wPitch <<= 3;

    return wPitch;
}


void SetColorDepth(UCHAR DisplayPath, UCHAR Value)
{
    UCHAR bSetBit = 0x0;

    switch(Value)
    {
        case 8:
            bSetBit = (UCHAR)BIT0;
            break;
        case 16:
            bSetBit = (UCHAR)BIT2;
            break;
        case 32:
            bSetBit = (UCHAR)BIT3;
            break;
        default:
            return;
    }

    if(DisplayPath == DISP1)
    {
        SetCRReg(0xA3, bSetBit, 0x0F);
    }
    else
    {
        
        if(Value == 8)
            return;

        SetCRReg(0x33, bSetBit, 0x0F);
    }
}

void SequencerOn(UCHAR DisplayPath)
{
    if (DisplayPath == DISP1)
        SetSRReg(0x01, 0, BIT5);
    else
        SetCRReg(0x33, 0, BIT0);
}

void SequencerOff(UCHAR bDisplayPath)
{
    if (bDisplayPath == DISP1)
    {
        if (!(GetSRReg(0x01) & BIT5))
        {
            LongWait();
        }
        SetSRReg(0x01, BIT5, BIT5);
    }
    else
        SetCRReg(0x33, BIT0, BIT0);
}

