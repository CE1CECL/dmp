/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 

#include <string.h>

#ifndef XFree86Module
#include "compiler.h"
#else
#include "xf86_ansic.h"
#endif

#include "typedef.h"
#include "CInt10.h"
#include "io.h"
#include "tv.h"
#include "output.h"

#include "timingtbl.h"
#include "vbiosdata.h"
#include "scratchpad.h"
#include "debug.h"


bool bCRTSUPPORT = FALSE;
bool bLCDSUPPORT = FALSE;
bool bDVISUPPORT = FALSE;
bool bTVSUPPORT = FALSE;
bool bHDMISUPPORT = FALSE;

bool bDS_SUPPORT = FALSE;


PORT_CONFIG *pPortConfig;
MODE_INFO   *pLCDTable;
MODE_INFO   *pVESATable;
void *PCIDataStruct;
void *BiosInfoData;
HDMITxDetect *pTMDSTxTable;



void *Display1VESAModeInitRegs;


void *POSTInItRegs;
void *DDRII400Tbl;
void *DDRII533Tbl;
void *ExtendRegs2;


void *EP932M_INIT_TBL;


void *EP932M_AVI_TBL;
void *IT6610_AVI_TBL;
void *PLLFS473TVEnc;


TVTBLDATA *SAA_Table_Start;
TVTBLDATA *FS_Table_Start;
void *FS_REG_RESET_GROUP;
void *FS_REG_GROUP;
void *FS_REG_NTSC_GROUP;
void *FS_REG_PAL_GROUP;
void *TVVESAModeConfig;
void *PLLSAA7105TVEnc;


USHORT Relocate_IOAddress;



void SetVBERerurnStatus(USHORT VBEReturnStatus, CBIOS_ARGUMENTS *pCBiosArguments)
{
    pCBiosArguments->reg.x.AX = VBEReturnStatus;
}


CI_STATUS VBE_SetMode(CBIOS_Extension *pCBIOSExtension)
{
    USHORT    wModeNum = pCBIOSExtension->pCBiosArguments->reg.x.BX & 0x01FF;
    USHORT    wOrgModeNum;
    USHORT    wPitch = 0;
    MODE_INFO   *pModeInfo = NULL;
    UCHAR    bColorDepth = 0;
    UCHAR    bCurDeviceID, bNewDeviceID;

    ScrnInfoPtr pScrn = xf86Screens[0];
    RDCRecPtr pRDC = RDCPTR(pScrn);

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Entry %s Mode number 0x%x== \n",__func__, wModeNum);

    if (wModeNum < 0x100)
    {
        SetVBERerurnStatus(VBEFunctionCallFail, pCBIOSExtension->pCBiosArguments);
        return true;
    }

    bCurDeviceID = Get_DEV_ID(DISP1);
    bNewDeviceID = Get_NEW_DEV_ID(DISP1);

    if(!Get_MODE_INFO(wModeNum, &pModeInfo))
    {
        SetVBERerurnStatus(VBEFunctionCallFail, pCBIOSExtension->pCBiosArguments);
        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit1 VBE_SetMode return 0x%x== \n",VBEFunctionCallFail);
        return true;
    }

    if (bTVSUPPORT)
    {
        if (bNewDeviceID == TV_ID)
        {
            if (pRDC->bEnableTVPanning)
            {
                GetModeColorDepth(wModeNum, pModeInfo, &bColorDepth);
                wOrgModeNum = wModeNum;
                wModeNum = GetTVPanningModeIndex(pRDC, pModeInfo, bColorDepth);

                
                if(!Get_MODE_INFO(wModeNum, &pModeInfo))
                {
                    SetVBERerurnStatus(VBEFunctionCallFail, pCBIOSExtension->pCBiosArguments);
                    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit1 VBE_SetMode return 0x%x== \n",VBEFunctionCallFail);
                    return true;
                }
            };
        
            if (!SetTVVESAModeIndex(wModeNum))
            {
                SetVBERerurnStatus(VBEFunctionCallFail, pCBIOSExtension->pCBiosArguments);
                return true;
            };
        };
    }
    
    
    Set_VESA_MODE(wModeNum, DISP1);

    
    SetSRReg(0x31, 0x03, BIT1+BIT0);
    
    
    TurnOffScaler(DISP1);
    TurnOffHorDownScaler(DISP1);
    TurnOffVerDownScaler(DISP1);

    
    DisableTVClock();

    
    TurnOffTMDSTX();
    
    
    Fire_Starting_Address();

    ClearHTotalLow3bit();
    
    if (bCurDeviceID != bNewDeviceID)
    {
        
        ControlPwrSeqOff(bCurDeviceID);

        

        
        TurnOffDigitalPort(bCurDeviceID);
        
        
        Set_DEV_ID(bNewDeviceID, DISP1);
    }

    

    
    LoadDisplay1VESAModeInitRegs();

    
    LoadTiming(DISP1, wModeNum);

    
    
    if (bNewDeviceID == TV_ID && pRDC->bEnableTVPanning)
        GetModePitch(wOrgModeNum, &wPitch);
    else
        GetModePitch(wModeNum, &wPitch);
    SetPitch(DISP1, wPitch);

    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, " \n");
    Get_MODE_INFO(wModeNum, &pModeInfo);
    GetModeColorDepth(wModeNum, pModeInfo, &bColorDepth);
    SetColorDepth(DISP1, bColorDepth);

    

    

    

    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, " \n");
    SetFIFO(DISP1);

    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, " \n");
    ConfigDigitalPort(DISP1);

    TurnOnDigitalPort(bNewDeviceID);

    

    TurnOnTMDSTX(bNewDeviceID);
    
    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, " \n");
    ControlPwrSeqOn(bNewDeviceID);

    SetTMDSReg(bNewDeviceID);

    
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, " \n");
    SequencerOn(DISP1);

    
    SetSRReg(0x31, 0x00, BIT1+BIT0);
    
    SetVBERerurnStatus(VBEFunctionCallSuccessful, pCBIOSExtension->pCBiosArguments);
    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit2 VBE_SetMode return 0x%x== \n",VBEFunctionCallSuccessful);
    return true;
}

CI_STATUS VBE_SetGetScanLineLength (CBIOS_ARGUMENTS *pCBiosArguments)
{
    USHORT    wModeNum;
    MODE_INFO   *pModeInfo = NULL;
    UCHAR    bColorDepth;
    UCHAR    bDisplayPath;
    ULONG   dwVESAMemSizeInBytes;
    USHORT    wMaxPitchInBytes, wCurrentVDispEnd;
    USHORT    VBEReturnStatus = VBEFunctionCallFail;
    USHORT    wPitchToBeSet = pCBiosArguments->reg.x.CX; 
    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Entry VBE_SetGetScanLineLength== \n");

    if (pCBiosArguments->reg.x.AX == 0x4f06)
    {
        bDisplayPath = DISP1;
    }
    else if ((pCBiosArguments->reg.x.AX == 0x4f14) && ((pCBiosArguments->reg.lh.BH == 0x87)||(pCBiosArguments->reg.lh.BH == 0x08)))
    {
        bDisplayPath = DISP2;
    }
    else
    {
        SetVBERerurnStatus(VBEFunctionCallFail, pCBiosArguments);
        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit1 VBE_SetGetScanLineLength return 0x%x== \n",VBEFunctionCallFail);
        return true;
    }
    
    if (pCBiosArguments->reg.lh.BL <=3)
    {
        wModeNum = Get_VESA_MODE(bDisplayPath);
        
        Get_MODE_INFO(wModeNum, &pModeInfo);
        
        if (GetModeColorDepth(wModeNum, pModeInfo, &bColorDepth))
        {
            VBEReturnStatus = VBEFunctionCallNotSupported;

            dwVESAMemSizeInBytes = ((ULONG)GetVESAMEMSize()) << 20;
            
            wCurrentVDispEnd = GetVDisplayEnd(bDisplayPath);
            
            
            if (((ULONG)(dwVESAMemSizeInBytes / (ULONG)wCurrentVDispEnd) & 0xFFFF0000) == 0)
            {
                wMaxPitchInBytes = (USHORT)(dwVESAMemSizeInBytes / (ULONG)wCurrentVDispEnd) & 0xFFF8;
            }
            else
            {
                wMaxPitchInBytes = 0xFFF8;
            }

            CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "==VBE_SetGetScanLineLength Color Depth = 0x%x== \n",bColorDepth);
            CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "==VBE_SetGetScanLineLength Mem Size = 0x%x== \n",dwVESAMemSizeInBytes);
            CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "==VBE_SetGetScanLineLength Current Disp End = 0x%x== \n",wCurrentVDispEnd);
            CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "==VBE_SetGetScanLineLength Max Pitch = 0x%x== \n",wMaxPitchInBytes);

            if ((pCBiosArguments->reg.lh.BL == 0) || (pCBiosArguments->reg.lh.BL == 2))
            {
                if (pCBiosArguments->reg.lh.BL == 0)
                {
                    
                    wPitchToBeSet <<= (bColorDepth >> 4);
                }
                
                if (wPitchToBeSet <= wMaxPitchInBytes)
                {
                    SetPitch(bDisplayPath, wPitchToBeSet);
                }
                else
                {
                    SetVBERerurnStatus(VBEReturnStatus, pCBiosArguments);
                    return true;
                }
            }

            if (pCBiosArguments->reg.lh.BL == 3)
            {
                
                pCBiosArguments->reg.x.BX = wMaxPitchInBytes;
            }
            else
            {
                
                pCBiosArguments->reg.x.BX =GetPitch(bDisplayPath);
            }

            
            
            pCBiosArguments->reg.x.CX = pCBiosArguments->reg.x.BX >> (bColorDepth >> 4);
            pCBiosArguments->reg.x.DX = (dwVESAMemSizeInBytes / (USHORT)pCBiosArguments->reg.x.BX);
        }
    }

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit2 VBE_SetGetScanLineLength return 0x%x== \n",VBEReturnStatus);

    SetVBERerurnStatus(VBEReturnStatus, pCBiosArguments);
    return true;
}

CI_STATUS OEM_QueryBiosInfo (CBIOS_ARGUMENTS *pCBiosArguments)
{
    USHORT    VBEReturnStatus = VBEFunctionCallFail;
    char bProjCode;
    int wCustomerCode;
    char bRelVersion;
    char szPrj[2], szMajor[3], szMinor[3] ;
    int wYear;
    char bMonth, bDay;
    char szYear[5], szMonth[3], szDay[3];
    char i,ucCRAA,ucCRAB;
    

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Entry %s()== \n", __func__);
    

    
    
    
     
    if (BiosInfoData != NULL)
    {
        szPrj[1] = szMajor[2] = szMinor[2] = '\0';
    	strncpy(szPrj, ((char *)BiosInfoData)+0x10, 1);
    	strncpy(szMajor, ((char *)BiosInfoData)+0x12, 2);
    	strncpy(szMinor, ((char *)BiosInfoData)+0x15, 2);

    	
    	bProjCode = atoi(szPrj) ;
    	wCustomerCode = atoi(szMajor);
    	bRelVersion = atoi(szMinor);
        pCBiosArguments->reg.ex.EBX = (bProjCode<<24) | (wCustomerCode<<8) | bRelVersion;

        CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "Bios version : %d\n",pCBiosArguments->reg.ex.EBX);
    }


    

    
    
    ucCRAA = GetCRReg(0xAA);
    pCBiosArguments->reg.ex.ECX = ucCRAA; 
    pCBiosArguments->reg.ex.ECX <<= 6;          

    
    ucCRAB = GetCRReg(0xAB);
    ucCRAB &= BIT0 + BIT1 + BIT2;                       
    pCBiosArguments->reg.ex.ECX |= ucCRAB;

    

    
    if (BiosInfoData != NULL)
    {
        szMonth[2] = szDay[2] = szYear[4] = '\0';
        strncpy(szMonth, ((char *)BiosInfoData)+0x47, 2);
        strncpy(szDay, ((char *)BiosInfoData)+0x4a, 2);
        strncpy(szYear, ((char *)BiosInfoData)+0x56, 4);

        wYear = atoi(szYear);
        bMonth = atoi(szMonth);
        bDay = atoi(szDay);
        pCBiosArguments->reg.ex.EDX = (wYear<<16) | (bMonth<8) | bDay;
    
        CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "Bios date : %d\n",pCBiosArguments->reg.ex.EDX);
    }

    
    pCBiosArguments->reg.x.SI = 0;
    if(bCRTSUPPORT)
    {
        pCBiosArguments->reg.x.SI |= B_CRT;
    }
    if(bLCDSUPPORT)
    {
        pCBiosArguments->reg.x.SI |= B_LCD;
    }
    if(bTVSUPPORT)
    {
        pCBiosArguments->reg.x.SI |= B_TV;
    }
    if(bDVISUPPORT)
    {
        pCBiosArguments->reg.x.SI |= B_DVI;
    }
    if(bHDMISUPPORT)
    {
        pCBiosArguments->reg.x.SI |= B_HDMI;
    }
    

    VBEReturnStatus = VBEFunctionCallSuccessful;
    SetVBERerurnStatus(VBEReturnStatus, pCBiosArguments);
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit OEM_QueryBiosInfo()== \n");
    return true;
}
CI_STATUS OEM_QueryBiosCaps (CBIOS_ARGUMENTS *pCBiosArguments)
{
    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Entry OEM_QueryBiosCaps()== \n");


    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit OEM_QueryBiosCaps()== \n");
    return true;
}

CI_STATUS OEM_QueryExternalDeviceInfo (CBIOS_ARGUMENTS *pCBiosArguments)
{
    PORT_CONFIG *pDevicePortConfig;
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Entry OEM_QueryExternalDeviceInfo()== \n");

    pCBiosArguments->reg.ex.EBX = 0;
    pCBiosArguments->reg.ex.EDX = 0;

    pCBiosArguments->reg.lh.BL = ReadScratch(IDX_SCRATCH_20);
    pCBiosArguments->reg.ex.EBX <<= 16;

    pCBiosArguments->reg.lh.BH = ReadScratch(IDX_SCRATCH_21);

    pCBiosArguments->reg.lh.BL = ReadScratch(IDX_SCRATCH_22);

    pCBiosArguments->reg.ex.ECX = BIT16;

    if(bHDMISUPPORT | bDVISUPPORT)
    {
        if (GetDevicePortConfig(HDMI_ID, &pDevicePortConfig))
            pCBiosArguments->reg.lh.DH = pDevicePortConfig->TX_I2C_Port;
        else 
        {
            GetDevicePortConfig(DVI_ID, &pDevicePortConfig);
            pCBiosArguments->reg.lh.DH = pDevicePortConfig->TX_I2C_Port;
        }
    }

    if (bTVSUPPORT)
    {
        GetDevicePortConfig(TV_ID, &pDevicePortConfig);
        pCBiosArguments->reg.lh.DL = pDevicePortConfig->TX_I2C_Port;
    }

    pCBiosArguments->reg.ex.EDX <<= 16;

    if (bLCDSUPPORT)
    {
        GetDevicePortConfig(LCD_ID, &pDevicePortConfig);
        pCBiosArguments->reg.lh.DH = pDevicePortConfig->TX_I2C_Port;
    }
    
    if (bCRTSUPPORT)
    {
        GetDevicePortConfig(CRT_ID, &pDevicePortConfig);
        pCBiosArguments->reg.lh.DL = pDevicePortConfig->TX_I2C_Port;
    }
    
    SetVBERerurnStatus(VBEFunctionCallSuccessful, pCBiosArguments);
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit OEM_QueryExternalDeviceInfo()== \n");
    return true;
}



CI_STATUS OEM_QueryDisplayPathInfo (CBIOS_ARGUMENTS *pCBiosArguments)
{
    UCHAR ScratchTempData;
    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Entry OEM_QueryDisplayPathInfo()== \n");

    pCBiosArguments->reg.ex.EBX = 0;

    ScratchTempData = GetSRReg(0x58);               
    if (ScratchTempData & BIT0)
    {
        ScratchTempData &= (BIT2 + BIT1);             
        ScratchTempData >>= 1;
        pCBiosArguments->reg.lh.BL |= ScratchTempData;
    }

    if (bDS_SUPPORT)
    {
        ScratchTempData = GetSRReg(0x70) & BIT7;
        ScratchTempData >>= 7;
        pCBiosArguments->reg.lh.BL |= ScratchTempData;
        ScratchTempData = GetSRReg(0x74) & BIT7;
        ScratchTempData >>= 6;
        pCBiosArguments->reg.lh.BL |= ScratchTempData;
    }
    
    pCBiosArguments->reg.ex.EBX <<= 4;
    pCBiosArguments->reg.lh.BL |= Get_DEV_ID(DISP1);

    pCBiosArguments->reg.ex.EBX <<= 7;
    pCBiosArguments->reg.lh.BL |= Get_RRATE_ID(DISP1);
    
    pCBiosArguments->reg.ex.EBX <<= 9;   
    pCBiosArguments->reg.x.BX |= Get_VESA_MODE(DISP1);
    

    pCBiosArguments->reg.ex.ECX = 0;

    ScratchTempData = GetSRReg(0x50);               
    if (ScratchTempData & BIT0)
    {
        ScratchTempData &= (BIT2 + BIT1);             
        ScratchTempData >>= 1;
        pCBiosArguments->reg.lh.CL |= ScratchTempData;
    }
    
    pCBiosArguments->reg.ex.ECX <<= 4;
    pCBiosArguments->reg.lh.CL |= Get_DEV_ID(DISP2);

    pCBiosArguments->reg.ex.ECX <<= 7;
    pCBiosArguments->reg.lh.CL |= Get_RRATE_ID(DISP2);
    
    pCBiosArguments->reg.ex.ECX <<= 9;   
    pCBiosArguments->reg.x.CX |= Get_VESA_MODE(DISP2);
    
    SetVBERerurnStatus(VBEFunctionCallSuccessful, pCBiosArguments);

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit OEM_QueryDisplayPathInfo()== \n");

    return true;

}

CI_STATUS OEM_QueryDeviceConnectStatus (CBIOS_ARGUMENTS *pCBiosArguments)
{
    UCHAR *pucPCIDataStruct = (UCHAR*)PCIDataStruct;
    USHORT usSupportedDevice;
    UCHAR ucHardCodeDevice;
    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Entry OEM_QueryDeviceConnectStatus()== \n");

    pCBiosArguments->reg.x.BX = 0;

    if (pCBiosArguments->reg.x.CX != 1)
    {
        if (bHDMISUPPORT)
        {
            pCBiosArguments->reg.x.BX |= QueryHDMIConnectStatus();
        }

        if (bTVSUPPORT)
        {
            if (SenseTV())
            {
                CBIOS_PRINTLOG(0, X_INFO, InternalLevel, " tv sensed\n");
                pCBiosArguments->reg.x.BX |= B_TV;
            }
        }

        if (bLCDSUPPORT)
        {
            pCBiosArguments->reg.x.BX |= B_LCD;
        }

        if (bDVISUPPORT)
        {
            if (*(USHORT*)(((UCHAR*)PCIDataStruct) + OFF_DID) == 0x2010)
            {
                if (GetSRReg(0x3c) & BIT1)
                {
                    pCBiosArguments->reg.x.BX |= B_DVI;
                }
            }
            else
            {
                
                
            }
        }
    }
    else 
    {
        QuickQueryHDMIConnectStatus();
    }

    if (bCRTSUPPORT)
    {
        if (SenseCRT())
            pCBiosArguments->reg.x.BX |= B_CRT;   
    }

    usSupportedDevice = 0;
    if (bCRTSUPPORT)
        usSupportedDevice |= B_CRT;
    if (bLCDSUPPORT)
        usSupportedDevice |= B_LCD;
    if (bDVISUPPORT)
        usSupportedDevice |= B_DVI;
    if (bCRTSUPPORT)
        usSupportedDevice |= B_TV;
    if (bHDMISUPPORT)
        usSupportedDevice |= B_HDMI;

    pCBiosArguments->reg.x.BX &= usSupportedDevice;

    if (pCBiosArguments->reg.x.CX != 1)
    {
        if (pCBiosArguments->reg.x.BX == 0)
        {
            ucHardCodeDevice = ReadScratch(IDX_BOOT_DEV_ID);
            pCBiosArguments->reg.x.BX = TransDevIDtoBit(ucHardCodeDevice);
        }
    }

    SetVBERerurnStatus(VBEFunctionCallSuccessful, pCBiosArguments);

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit OEM_QueryDeviceConnectStatus()== \n");

    return true;
}

CI_STATUS OEM_QuerySupportedMode (CBIOS_ARGUMENTS *pCBiosArguments)
{
    MODE_INFO   *pModeInfo;
    RRATE_TABLE *pRRateTable;
    int RRateTableIndex = 0;
    int ModeNumIndex;
    USHORT wModeNum;
    USHORT wSerialNumber;
    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter OEM_QuerySupportedMode()== \n");

    wSerialNumber = pCBiosArguments->reg.x.CX;
    pModeInfo     = (MODE_INFO*)pVESATable;
    
    while (pModeInfo->H_Size != 0xFFFF)
    {
        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "pModeInfo->H_Size = %d \n", pModeInfo->H_Size);
        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "pModeInfo->V_Size = %d \n", pModeInfo->V_Size);
        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "sizeof(RRATE_TABLE) = %d \n", sizeof(RRATE_TABLE));

        for (ModeNumIndex = 0; ModeNumIndex < 3; ModeNumIndex++)
        {
            switch (ModeNumIndex)
            {
                case 0:
                    wModeNum = pModeInfo->Mode_ID_8bpp;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "case 0: wModeNum = 0x%x \n", wModeNum);
                    break;
                case 1:
                    wModeNum = pModeInfo->Mode_ID_16bpp;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "case 1: wModeNum = 0x%x \n", wModeNum);
                    break;
                case 2:
                    wModeNum = pModeInfo->Mode_ID_32bpp;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "case 2: wModeNum = 0x%x \n", wModeNum);
                    break;
            }

            pRRateTable = (RRATE_TABLE*)((int)pModeInfo + sizeof(MODE_INFO));

            for (RRateTableIndex = 0; RRateTableIndex < pModeInfo->RRTableCount; RRateTableIndex++, pRRateTable++)
            {

                CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "pRRateTable = 0x%x \n", pRRateTable);

                if ((pRRateTable->Attribute & DISABLE) == 0)
                {
                    if (wSerialNumber == 0)
                    {
                        
                        pCBiosArguments->reg.x.BX = wModeNum;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "mode num = 0x%x \n", pCBiosArguments->reg.x.BX);

                        
                        GetModeColorDepth(wModeNum, pModeInfo, &pCBiosArguments->reg.lh.CL);
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "color depth = %d \n", pCBiosArguments->reg.lh.CL);
                        
                        
                        pCBiosArguments->reg.lh.CH = pRRateTable->RRate_ID;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "RRate ID = %d \n", pCBiosArguments->reg.lh.CH);
                        
                        
                        pCBiosArguments->reg.ex.EDX = (((ULONG)pModeInfo->V_Size) << 16) | (ULONG)pModeInfo->H_Size;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "H x V = %d x %d \n", pCBiosArguments->reg.x.DX, pCBiosArguments->reg.ex.EDX>>16);
                        
                        
                        pCBiosArguments->reg.x.SI = pRRateTable->Attribute;
                        
                        
                        pCBiosArguments->reg.ex.EDI = pRRateTable->Clock;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "dot clk = %dkhz \n", pCBiosArguments->reg.ex.EDI);

                        SetVBERerurnStatus (VBEFunctionCallSuccessful, pCBiosArguments);

                        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "  Exit1 OEM_QuerySupportedMode() return 0x%x== \n", VBEFunctionCallSuccessful);

                        return true;
                    }
                    else
                    {
                        wSerialNumber--;
                    }
                }
            }
        }
        pModeInfo = (MODE_INFO*)((int)pModeInfo + sizeof(MODE_INFO) + pModeInfo->RRTableCount*sizeof(RRATE_TABLE));
    }

    pModeInfo = (MODE_INFO*)(&CInt10VESATable);
    CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "*pModeInfo = %X \n", *pModeInfo);
    
    while (pModeInfo->H_Size != 0xFFFF)
    {
        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "pModeInfo->H_Size = %d \n", pModeInfo->H_Size);
        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "pModeInfo->V_Size = %d \n", pModeInfo->V_Size);
        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "sizeof(RRATE_TABLE) = %d \n", sizeof(RRATE_TABLE));

        for (ModeNumIndex = 0; ModeNumIndex < 3; ModeNumIndex++)
        {
            switch (ModeNumIndex)
            {
                case 0:
                    wModeNum = pModeInfo->Mode_ID_8bpp;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "case 0: wModeNum = 0x%x \n", wModeNum);
                    break;
                case 1:
                    wModeNum = pModeInfo->Mode_ID_16bpp;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "case 1: wModeNum = 0x%x \n", wModeNum);
                    break;
                case 2:
                    wModeNum = pModeInfo->Mode_ID_32bpp;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "case 2: wModeNum = 0x%x \n", wModeNum);
                    break;
            }

            pRRateTable = (RRATE_TABLE*)((int)pModeInfo + sizeof(MODE_INFO));

            for (RRateTableIndex = 0; RRateTableIndex < pModeInfo->RRTableCount; RRateTableIndex++, pRRateTable++)
            {

                CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "pRRateTable = 0x%x \n", pRRateTable);

                if ((pRRateTable->Attribute & DISABLE) == 0)
                {
                    if (wSerialNumber == 0)
                    {
                        
                        pCBiosArguments->reg.x.BX = wModeNum;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "mode num = 0x%x \n", pCBiosArguments->reg.x.BX);

                        
                        GetModeColorDepth(wModeNum, pModeInfo, &pCBiosArguments->reg.lh.CL);
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "color depth = %d \n", pCBiosArguments->reg.lh.CL);
                        
                        
                        pCBiosArguments->reg.lh.CH = pRRateTable->RRate_ID;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "RRate ID = %d \n", pCBiosArguments->reg.lh.CH);
                        
                        
                        pCBiosArguments->reg.ex.EDX = (((ULONG)pModeInfo->V_Size) << 16) | (ULONG)pModeInfo->H_Size;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "H x V = %d x %d \n", pCBiosArguments->reg.x.DX, pCBiosArguments->reg.ex.EDX>>16);
                        
                        
                        pCBiosArguments->reg.x.SI = pRRateTable->Attribute;
                        
                        
                        pCBiosArguments->reg.ex.EDI = pRRateTable->Clock;
                        CBIOS_PRINTLOG(0, X_INFO, InternalLevel, "dot clk = %dkhz \n", pCBiosArguments->reg.ex.EDI);

                        SetVBERerurnStatus (VBEFunctionCallSuccessful, pCBiosArguments);

                        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "  Exit1 OEM_QuerySupportedMode() return 0x%x== \n", VBEFunctionCallSuccessful);

                        return true;
                    }
                    else
                    {
                        wSerialNumber--;
                    }
                }
            }
        }
        pModeInfo = (MODE_INFO*)((int)pModeInfo + sizeof(MODE_INFO) + pModeInfo->RRTableCount*sizeof(RRATE_TABLE));
    }        

    SetVBERerurnStatus (VBEFunctionCallFail, pCBiosArguments);

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "  Exit2 OEM_QuerySupportedMode() return 0x%x== \n", VBEFunctionCallFail);

    return true;

}

CI_STATUS OEM_QueryLCDPanelSizeMode (CBIOS_ARGUMENTS *pCBiosArguments)
{
    MODE_INFO   *pModeInfo;
    PANEL_TABLE *pPanelTable;
    UCHAR        bColorDepth = pCBiosArguments->reg.lh.CL;
    USHORT        wModeNum;

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter OEM_QueryLCDPanelSizeMode()== \n");

    SetVBERerurnStatus (VBEFunctionCallFail, pCBiosArguments);
    
    if (!bLCDSUPPORT)
        return true;
        
    if (!GetModePointerFromLCDTable(LCD_ID, &pModeInfo, &pPanelTable))
        return true;

    switch (bColorDepth)
    {
        case 0:
            wModeNum = pModeInfo->Mode_ID_8bpp;
            pCBiosArguments->reg.lh.CL = 8;
            break;
        case 1:
            wModeNum = pModeInfo->Mode_ID_16bpp;
            pCBiosArguments->reg.lh.CL = 16;
            break;
        case 2:
            wModeNum = pModeInfo->Mode_ID_32bpp;
            pCBiosArguments->reg.lh.CL = 32;
            break;
        default:
            SetVBERerurnStatus (VBEFunctionCallFail, pCBiosArguments);

            CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit2 OEM_QueryLCDPanelSizeMode() return 0x%x== \n", VBEFunctionCallFail);

            return true;
    }
        
    
    pCBiosArguments->reg.x.BX = wModeNum;
    
    
    pCBiosArguments->reg.lh.CH = pPanelTable->Timing.RRate_ID;
    
    
    pCBiosArguments->reg.ex.EDX = (ULONG)pModeInfo->H_Size  | ((ULONG)pModeInfo->V_Size) << 16;
    
    
    pCBiosArguments->reg.x.SI = pPanelTable->Timing.Attribute;
    
    
    pCBiosArguments->reg.ex.EDI = pPanelTable->Timing.Clock;
    
    SetVBERerurnStatus (VBEFunctionCallSuccessful, pCBiosArguments);

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit1 OEM_QueryLCDPanelSizeMode() return 0x%x== \n", VBEFunctionCallSuccessful);

    return true;
}

CI_STATUS OEM_QueryLCDPWMLevel(CBIOS_ARGUMENTS *pCBiosArguments)
{
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Entry OEM_QueryLCDPWMLevel()== \n");

    SetVBERerurnStatus (VBEFunctionCallFail, pCBiosArguments);
    
    if (!bLCDSUPPORT)
        return true;

    if ((GetSRReg(0x30)&0x03) == 0x03 )
        pCBiosArguments->reg.lh.BL = GetSRReg(0x30);
    else
        pCBiosArguments->reg.lh.BL = 0;
        
    SetVBERerurnStatus (VBEFunctionCallSuccessful, pCBiosArguments);
    
    return true;
}

CI_STATUS OEM_QueryTVConfiguration (CBIOS_ARGUMENTS *pCBiosArguments)
{
    if (bTVSUPPORT)
    {
        pCBiosArguments->reg.lh.BL = (Get_TV_ConnectorType() << 4) |Get_TV_TYPE();
    }
    SetVBERerurnStatus(VBEFunctionCallSuccessful, pCBiosArguments);
    return true;
}
CI_STATUS OEM_QueryTV2Configuration (CBIOS_ARGUMENTS *pCBiosArguments)
{
    return true;
}
CI_STATUS OEM_QueryHDTVConfiguration (CBIOS_ARGUMENTS *pCBiosArguments)
{
    return true;
}
CI_STATUS OEM_QueryHDTV2Configuration (CBIOS_ARGUMENTS *pCBiosArguments)
{
    return true;
}
CI_STATUS OEM_QueryHDMIConfiguration (CBIOS_ARGUMENTS *pCBiosArguments)
{
    if (pCBiosArguments->reg.x.BX = QueryHDMIConfiguration)
    {
        pCBiosArguments->reg.x.BX = Get_HDMI_TYPE();
        pCBiosArguments->reg.x.BX <<= 8;
        SetVBERerurnStatus(VBEFunctionCallSuccessful, pCBiosArguments);
    }   
    else if (pCBiosArguments->reg.x.BX = QueryHDMI2Configuration)
    {
        SetVBERerurnStatus(VBEFunctionCallFail, pCBiosArguments);
    }

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit2 %s() return 0x%x== \n", __func__, VBEFunctionCallSuccessful);
    
    return true;
}
CI_STATUS OEM_QueryHDMI2Configuration (CBIOS_ARGUMENTS *pCBiosArguments)
{
    return true;
}

CI_STATUS OEM_SetActiveDisplayDevice (CBIOS_ARGUMENTS *pCBiosArguments)
{
    UCHAR bDeviceIndex1 = Get_DEV_ID(DISP1);
    UCHAR bDeviceIndex2 = Get_DEV_ID(DISP2);
    UCHAR bNewDeviceIndex1 = pCBiosArguments->reg.lh.CL & 0x0F;
    UCHAR bNewDeviceIndex2 = (pCBiosArguments->reg.lh.CL >> 4) & 0x0F;

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Entry OEM_SetActiveDisplayDevice()== \n");

    
    if ((!CheckForNewDeviceAvailable(bNewDeviceIndex1)&& (bNewDeviceIndex1!=0)) || (!CheckForNewDeviceAvailable(bNewDeviceIndex2)&& (bNewDeviceIndex2!=0)))
    {
        SetVBERerurnStatus(VBEFunctionCallFail, pCBiosArguments);
        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit1 OEM_SetActiveDisplayDevice() return 0x%x== \n", VBEFunctionCallFail);
        return true;
    }
    
    if (bDeviceIndex1 != bNewDeviceIndex1)
    {
        if (bNewDeviceIndex1 == 0)
        {
            DisableDisplayPathAndDevice(DISP1);
            Set_DEV_ID(bNewDeviceIndex1, DISP1);
        }
        Set_NEW_DEV_ID(bNewDeviceIndex1, DISP1);
    }

    if (bDeviceIndex2 != bNewDeviceIndex2)
    {
        if (bNewDeviceIndex2 == 0)
        {
            DisableDisplayPathAndDevice(DISP2);
            Set_DEV_ID(bNewDeviceIndex2, DISP2);
        }
        Set_NEW_DEV_ID(bNewDeviceIndex2, DISP2);
    }

    SetVBERerurnStatus(VBEFunctionCallSuccessful, pCBiosArguments);

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit2 OEM_SetActiveDisplayDevice() return 0x%x== \n", VBEFunctionCallSuccessful);

    return true;
}
CI_STATUS OEM_SetVESAModeForDisplay2 (CBIOS_Extension *pCBIOSExtension)
{
    USHORT    wModeNum = pCBIOSExtension->pCBiosArguments->reg.x.CX & 0x01FF;
    USHORT    wPitch = 0;
    MODE_INFO   *pModeInfo = NULL;
    UCHAR    bColorDepth = 0;
    UCHAR    bCurDeviceID, bNewDeviceID;

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Entry OEM_SetVESAModeForDisplay2()== \n");

    if (wModeNum < 0x100)
    {
        SetVBERerurnStatus(VBEFunctionCallFail, pCBIOSExtension->pCBiosArguments);
        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit1 OEM_SetVESAModeForDisplay2() return 0x%x== \n", VBEFunctionCallFail);
        return true;
    }
    
    bCurDeviceID = Get_DEV_ID(DISP2);
    bNewDeviceID = Get_NEW_DEV_ID(DISP2);

    
    if(!Get_MODE_INFO(wModeNum, &pModeInfo))
    {
        SetVBERerurnStatus(VBEFunctionCallFail, pCBIOSExtension->pCBiosArguments);
        CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit2 OEM_SetVESAModeForDisplay2() return 0x%x== \n", VBEFunctionCallFail);
        return true;
    }
    
    Set_VESA_MODE(wModeNum, DISP2);
    
    
    SequencerOff(DISP2);

    
    TurnOffScaler(DISP2);

    if (bCurDeviceID != bNewDeviceID)
    {
        
        ControlPwrSeqOff(bCurDeviceID);

        

        
        TurnOffDigitalPort(bCurDeviceID);

        
        Set_DEV_ID(bNewDeviceID, DISP2);
    }
    
    
    
    
    LoadTiming(DISP2, wModeNum);

    
    GetModePitch(wModeNum, &wPitch);
    SetPitch(DISP2, wPitch);

    
    Get_MODE_INFO(wModeNum, &pModeInfo);
    GetModeColorDepth(wModeNum, pModeInfo, &bColorDepth);
    SetColorDepth(DISP2, bColorDepth);

    

    

    
    if(!(pCBIOSExtension->pCBiosArguments->reg.x.CX & BIT15))
    {
        ClearFrameBuffer(DISP2,(ULONG*)(pCBIOSExtension->VideoVirtualAddress),pModeInfo,bColorDepth);
    }

    
    SetFIFO(DISP2);

    
    ConfigDigitalPort(DISP2);

    TurnOnDigitalPort(bNewDeviceID);

    

    
    ControlPwrSeqOn(bNewDeviceID);
    
    SequencerOn(DISP2);
    
    SetVBERerurnStatus(VBEFunctionCallSuccessful, pCBIOSExtension->pCBiosArguments);
    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit3 OEM_SetVESAModeForDisplay2() return 0x%x== \n", VBEFunctionCallSuccessful);

    return true;
}

CI_STATUS OEM_SetDevicePowerState (CBIOS_ARGUMENTS *pCBiosArguments)
{
    UCHAR display1DeviceID, display2DeviceID, TargetDevice, DMPSState;
    USHORT VBEReturnStatus = VBEFunctionCallFail;
    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Entry OEM_SetDevicePowerState()== \n");

    TargetDevice = pCBiosArguments->reg.lh.CL & 0x0F;
    DMPSState = pCBiosArguments->reg.lh.CL & (BIT1+BIT0);
    display1DeviceID = Get_DEV_ID(DISP1);
    display2DeviceID = Get_DEV_ID(DISP2);

    if (display1DeviceID == TargetDevice)
    {
        SetDPMS(DMPSState, DISP1);
        VBEReturnStatus = VBEFunctionCallSuccessful;
    }
    else if (display2DeviceID == TargetDevice)
    {
        SetDPMS(DMPSState, DISP2);
        VBEReturnStatus = VBEFunctionCallSuccessful;
    }

    SetVBERerurnStatus(VBEReturnStatus, pCBiosArguments);

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit OEM_SetDevicePowerState() return 0x%x== \n", VBEFunctionCallSuccessful);

    return true;
}

CI_STATUS OEM_SetRefreshRate (CBIOS_ARGUMENTS *pCBiosArguments)
{
    UCHAR bRRateID, bDisplayPath;
    bRRateID = pCBiosArguments->reg.lh.CL & 0x7F;

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Entry OEM_SetRefreshRate()== \n");

    if ( pCBiosArguments->reg.x.BX == SetDisplay1RefreshRate)
        bDisplayPath = DISP1;
    else
        bDisplayPath = DISP2;

    Set_RRATE_ID(bRRateID, bDisplayPath);

    SetVBERerurnStatus(VBEFunctionCallSuccessful, pCBiosArguments);

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit OEM_SetRefreshRate() return 0x%x== \n", VBEFunctionCallSuccessful);

    return true;
}

CI_STATUS OEM_SetLCDPWMLevel (CBIOS_ARGUMENTS *pCBiosArguments)
{
    SetSRReg(0x2F,7,0xFF);
    SetSRReg(0x30,pCBiosArguments->reg.lh.CL,0xFF);
    return true;
}

CI_STATUS OEM_SetTVConfiguration (CBIOS_ARGUMENTS *pCBiosArguments)
{
    Set_TV_Confiuration(pCBiosArguments->reg.lh.CL);
    SetVBERerurnStatus(VBEFunctionCallSuccessful, pCBiosArguments);
    return true;
}
CI_STATUS OEM_SetTV2Configuration (CBIOS_ARGUMENTS *pCBiosArguments)
{
    return true;
}
CI_STATUS OEM_SetHDTVConnectType (CBIOS_ARGUMENTS *pCBiosArguments)
{
    return true;
}
CI_STATUS OEM_SetHDTV2ConnectType (CBIOS_ARGUMENTS *pCBiosArguments)
{
    return true;
}

CI_STATUS OEM_SetHDMIType (CBIOS_ARGUMENTS *pCBiosArguments)
{
    WriteScratch(IDX_HDMI1_TYPE, pCBiosArguments->reg.lh.CL);
    SetVBERerurnStatus(VBEFunctionCallSuccessful, pCBiosArguments);
    return true;
}
CI_STATUS OEM_SetHDMIOutputSignal (CBIOS_ARGUMENTS *pCBiosArguments)
{
    return true;
}
CI_STATUS OEM_SetHDMI2OutputSignal (CBIOS_ARGUMENTS *pCBiosArguments)
{
    return true;
}

CI_STATUS OEM_VideoPOST (CBIOS_ARGUMENTS *pCBiosArguments)
{
    UCHAR i = 0,btemp = 0x0,btemp1 = 0x0;
    CI_STATUS bDDRII400 = true;
    UCHAR *pucPOSTInItRegs = POSTInItRegs;
    UCHAR *pucDDRII400Tbl = DDRII400Tbl;
    UCHAR *pucDDRII533Tbl = DDRII533Tbl;
    UCHAR *pucExtendRegs2 = ExtendRegs2;

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Entry OEM_VideoPOST()== \n");

    
    btemp = InPort(RIO_VGA_ENABLE); 
    btemp |= 1;
    OutPort(RIO_VGA_ENABLE,btemp);

    
    btemp = InPort(MISC_READ); 
    btemp |= 3;
    OutPort(MISC_WRITE,btemp);
    
    
    SetCRReg(0x80, 0xA8, 0xFF);
    
    
    for(i = 0x81;i < 0x9F;i++)
    {
        SetCRReg(i, 0x00, 0xFF);
    }

    
    
    btemp = GetCRReg(0xAB);
    if((btemp & 0x3) == 0x3)
    {
        bDDRII400 = false;
    }

    if(bDDRII400)
    {
        
        SetCRReg(0xD9, 0x00, 0x80);
        SetCRReg(0xD8, 0x9B, 0xFF);
    }
    else
    {
        
        SetCRReg(0xD9, 0x80, 0x80);
        SetCRReg(0xD8, 0x78, 0xFF);
    }
    
    
    
    btemp = 0x00;
    SetCRReg(0xBB, btemp, 0xFF);
    
    
    

    
    SerialLoadTable(&pucPOSTInItRegs, 0, 0);

    
    Set_NEW_DEV_ID(0, DISP1);

    if(bDDRII400)
    {
        
        SerialLoadTable(&pucDDRII400Tbl, 0, 0);
    }
    else
    {
        
        SerialLoadTable(&pucDDRII533Tbl, 0, 0);    
    }

    
    do{
        btemp = GetCRReg(0x5D);
        btemp &= 0x80;
        btemp1 = GetCRReg(0x5E);
        btemp1 &= 0x01;
    }while((btemp != 0x80)||(btemp1 != 0x01));

    
    SerialLoadTable(&pucExtendRegs2, 0, 0);

    
    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit OEM_VideoPOST()== \n");

    return true;
}


CI_STATUS OEM_CINT10DataInit (CBIOS_ARGUMENTS *pCBiosArguments)
{
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "BIOS virtual = %x\n", pCBiosArguments->reg.ex.ECX);
    
    ParseTable("PCFG", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&pPortConfig));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "Port Config = %x\n", pPortConfig);
    
    ParseTable("VPIT", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&pVESATable));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "VESA Table = %x\n", pVESATable);
    
    ParseTable("LCDTBL", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&pLCDTable));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "LCD Table = %x\n", pLCDTable);

    ParseTable("TXTBL", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&pTMDSTxTable));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "TMDS TX Table = %x\n", pTMDSTxTable);

    ParseTable("932M-0", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&EP932M_INIT_TBL));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "EP932M init Table = %x\n", EP932M_INIT_TBL);

    ParseTable("932M-1", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&EP932M_AVI_TBL));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "EP932M infoframe Table = %x\n", EP932M_AVI_TBL);

    ParseTable("ITE6610", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&IT6610_AVI_TBL));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "IT6610 infoframe Table = %x\n", IT6610_AVI_TBL);
    
    ParseTable("TV01", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&PLLFS473TVEnc));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "FS473 PLL Table = %x\n", PLLFS473TVEnc);
    
    ParseTable("TV02", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&SAA_Table_Start));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "SAA_Table_Start = %x\n", SAA_Table_Start);
    
    ParseTable("TV03", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&FS_Table_Start));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "FS_Table_Start = %x\n", FS_Table_Start);

    ParseTable("TV04", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&FS_REG_RESET_GROUP));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "FS_REG_RESET_GROUP Table = %x\n", FS_REG_RESET_GROUP);

    ParseTable("TV05", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&FS_REG_GROUP));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "FS_REG_GROUP Table = %x\n", FS_REG_GROUP);

    ParseTable("TV06", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&FS_REG_NTSC_GROUP));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "FS_REG_NTSC_GROUP Table = %x\n", FS_REG_NTSC_GROUP);

    ParseTable("TV07", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&FS_REG_PAL_GROUP));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "FS_REG_PAL_GROUP Table = %x\n", FS_REG_PAL_GROUP);
    
    ParseTable("TV08", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&TVVESAModeConfig));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "TV VESA Mode Config Table = %x\n", TVVESAModeConfig);
    
    ParseTable("TV09", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&PLLSAA7105TVEnc));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "7105 PLL Table = %x\n", PLLSAA7105TVEnc);
    
    ParseTable("PCIR", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&PCIDataStruct));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "PCI Data Struct = %x\n", PCIDataStruct);

    BiosInfoData = (UCHAR*)pCBiosArguments->reg.ex.ECX;
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "Bios info data (header) = %x\n", BiosInfoData);

    ParseTable("D1INIT", (UCHAR*)pCBiosArguments->reg.ex.ECX, (UCHAR**)(&Display1VESAModeInitRegs));
    CBIOS_PRINTLOG(0, X_INFO, InfoLevel, "Display1 VESA Mode Init Regs = %x\n", Display1VESAModeInitRegs);

    SetDeviceSupport();

    Relocate_IOAddress = pCBiosArguments->reg.x.DX;
    if (*(USHORT*)(PCIDataStruct + OFF_DID) == 0x2012)
    {
        bDS_SUPPORT = true;
    }
    
#if 0 
    ParseTable("??????", &ExtendRegs);  
    ParseTable("??????", &ExtendRegs2); 
    ParseTable("??????", &DDRII400Tbl); 
    ParseTable("??????", &DDRII533Tbl); 
#endif
    SetVBERerurnStatus(VBEFunctionCallSuccessful, pCBiosArguments);
}

CI_STATUS CInt10(CBIOS_Extension *pCBIOSExtension)
{
    CI_STATUS CInt10_Status = false;

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Enter CInt10(EAX = %x, EBX = %x, ECX = %x, EDX = %x, ESI = %x, EDI = %x)==\n",
                   pCBIOSExtension->pCBiosArguments->reg.ex.EAX, pCBIOSExtension->pCBiosArguments->reg.ex.EBX,
                   pCBIOSExtension->pCBiosArguments->reg.ex.ECX, pCBIOSExtension->pCBiosArguments->reg.ex.EDX,
                   pCBIOSExtension->pCBiosArguments->reg.ex.ESI, pCBIOSExtension->pCBiosArguments->reg.ex.EDI);    

    switch(pCBIOSExtension->pCBiosArguments->reg.x.AX)
    {
        case VBESetMode:
            CInt10_Status = VBE_SetMode(pCBIOSExtension);
            break;

        case VBESetGetScanLineLength:
            CInt10_Status = VBE_SetGetScanLineLength(pCBIOSExtension->pCBiosArguments);
            break;
            
        case OEMFunction:
            switch(pCBIOSExtension->pCBiosArguments->reg.x.BX)
            {
                case QueryBiosInfo:             
                    CInt10_Status = OEM_QueryBiosInfo(pCBIOSExtension->pCBiosArguments);
                    break;
                case QueryBiosCaps:             
                    CInt10_Status = OEM_QueryBiosCaps(pCBIOSExtension->pCBiosArguments);
                    break;
                case QueryExternalDeviceInfo:   
                    CInt10_Status = OEM_QueryExternalDeviceInfo(pCBIOSExtension->pCBiosArguments);
                    break;
                case QueryDisplayPathInfo:      
                    CInt10_Status = OEM_QueryDisplayPathInfo(pCBIOSExtension->pCBiosArguments);
                    break;
                case QueryDeviceConnectStatus:  
                    CInt10_Status = OEM_QueryDeviceConnectStatus(pCBIOSExtension->pCBiosArguments);
                    break;
                case QuerySupportedMode:        
                    CInt10_Status = OEM_QuerySupportedMode(pCBIOSExtension->pCBiosArguments);
                    break;
                case QueryLCDPanelSizeMode:      
                    CInt10_Status = OEM_QueryLCDPanelSizeMode(pCBIOSExtension->pCBiosArguments);
                    break;
                case QueryLCDPWMLevel:           
                    CInt10_Status = OEM_QueryLCDPWMLevel(pCBIOSExtension->pCBiosArguments);
                    break;
                case QueryTVConfiguration:       
                    CInt10_Status = OEM_QueryTVConfiguration(pCBIOSExtension->pCBiosArguments);
                    break;
                case QueryTV2Configuration:
                    break;
                case QueryHDTVConfiguration:
                    break;
                case QueryHDTV2Configuration:
                    break;
                case QueryHDMIConfiguration:
                case QueryHDMI2Configuration:
                    CInt10_Status = OEM_QueryHDMIConfiguration(pCBIOSExtension->pCBiosArguments);
                    break;
                case QueryDisplay2Pitch:
                case GetDisplay2MaxPitch:
                    CInt10_Status = VBE_SetGetScanLineLength(pCBIOSExtension->pCBiosArguments);
                    break;

                case SetActiveDisplayDevice:    
                    CInt10_Status = OEM_SetActiveDisplayDevice(pCBIOSExtension->pCBiosArguments);
                    break;
                case SetVESAModeForDisplay2:
                    CInt10_Status = OEM_SetVESAModeForDisplay2(pCBIOSExtension);
                    break;
                case SetDevicePowerState:       
                    CInt10_Status = OEM_SetDevicePowerState(pCBIOSExtension->pCBiosArguments);
                    break;
                case SetDisplay1RefreshRate:    
                case SetDisplay2RefreshRate:    
                    CInt10_Status = OEM_SetRefreshRate(pCBIOSExtension->pCBiosArguments);
                    break;
                case SetLCDPWMLevel:            
                    CInt10_Status = OEM_SetLCDPWMLevel(pCBIOSExtension->pCBiosArguments);
                    break;
                case SetTVConfiguration:        
                    CInt10_Status = OEM_SetTVConfiguration(pCBIOSExtension->pCBiosArguments);
                    break;
                case SetHDTVConnectType:
                    break;
                case SetHDTV2ConnectType:
                    break;
                case SetHDMIType:
                    CInt10_Status = OEM_SetHDMIType(pCBIOSExtension->pCBiosArguments);
                    break;
                case SetHDMI2Type:
                    break;
                case SetHDMIOutputSignal:
                    break;
                case SetHDMI2OutputSignal:
                    break;
                case SetDisplay2PitchInPixels:
                case SetDisplay2PitchInBytes:
                    CInt10_Status = VBE_SetGetScanLineLength(pCBIOSExtension->pCBiosArguments);
                    break;
                case SetVideoPOST:
                    CInt10_Status = OEM_VideoPOST(pCBIOSExtension->pCBiosArguments);
                    break;
                case CINT10DataInit:
                    
                    CInt10_Status = OEM_CINT10DataInit(pCBIOSExtension->pCBiosArguments);
                    break;
                default:
                    pCBIOSExtension->pCBiosArguments->reg.x.AX = 0x014F;
                    break;
            }
            break;

        default:
            break;
    }

    CBIOS_PRINTLOG(0, X_INFO, DefaultLevel, "==Exit CInt10(EAX = %x, EBX = %x, ECX = %x, EDX = %x, ESI = %x, EDI = %x)== \n",
                   pCBIOSExtension->pCBiosArguments->reg.ex.EAX, pCBIOSExtension->pCBiosArguments->reg.ex.EBX,
                   pCBIOSExtension->pCBiosArguments->reg.ex.ECX, pCBIOSExtension->pCBiosArguments->reg.ex.EDX,
                   pCBIOSExtension->pCBiosArguments->reg.ex.ESI, pCBIOSExtension->pCBiosArguments->reg.ex.EDI);

    return CInt10_Status;
} 

