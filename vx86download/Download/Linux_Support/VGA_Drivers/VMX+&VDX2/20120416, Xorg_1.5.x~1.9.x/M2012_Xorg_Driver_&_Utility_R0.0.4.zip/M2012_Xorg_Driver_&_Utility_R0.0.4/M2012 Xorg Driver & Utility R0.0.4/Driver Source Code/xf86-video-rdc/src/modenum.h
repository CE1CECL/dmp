/*
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */
 
#ifndef __MODENUM_H__
#define __MODENUM_H__




#define MODE_640x480x8      0x101
#define MODE_800x600x8      0x103
#define MODE_1024x768x8     0x105
#define MODE_1280x1024x8    0x107
#define MODE_640x480x16     0x111
#define MODE_640x480x32     0x112
#define MODE_800x600x16     0x114
#define MODE_800x600x32     0x115
#define MODE_1024x768x16    0x117
#define MODE_1024x768x32    0x118
#define MODE_1280x1024x16   0x11A
#define MODE_1280x1024x32   0x11B

#define MODE_1600x1200x8    0x120
#define MODE_1600x1200x16   0x121
#define MODE_1600x1200x32   0x122

#define MODE_320x240x8      0x123
#define MODE_320x240x16     0x124
#define MODE_320x240x32     0x125

#define MODE_720x480x8      0x126
#define MODE_720x480x16     0x127
#define MODE_720x480x32     0x128

#define MODE_1360x768x8     0x129
#define MODE_1360x768x16    0x12A
#define MODE_1360x768x32    0x12B

#define MODE_848x480x8      0x12C
#define MODE_848x480x16     0x12D
#define MODE_848x480x32     0x12E

#define MODE_1440x900x8     0x12F
#define MODE_1440x900x16    0x130
#define MODE_1440x900x32    0x131

#define MODE_1152x864x8     0x132
#define MODE_1152x864x16    0x133
#define MODE_1152x864x32    0x134

#define MODE_1280x960x8     0x135
#define MODE_1280x960x16    0x136
#define MODE_1280x960x32    0x137

#define MODE_1400x1050x8    0x138
#define MODE_1400x1050x16   0x139
#define MODE_1400x1050x32   0x13A

#define MODE_800x480x8      0x13B
#define MODE_800x480x16     0x13C
#define MODE_800x480x32     0x13D

#define MODE_1024x600x8     0x13E
#define MODE_1024x600x16    0x13F
#define MODE_1024x600x32    0x140

#define MODE_1366x768x8     0x141
#define MODE_1366x768x16    0x142
#define MODE_1366x768x32    0x143

#define MODE_1280x720x8     0x147
#define MODE_1280x720x16    0x148
#define MODE_1280x720x32    0x149

#define MODE_1280x768x8     0x150
#define MODE_1280x768x16    0x151
#define MODE_1280x768x32    0x152
    
#define MODE_1400x960x8     0x153
#define MODE_1400x960x16    0x154
#define MODE_1400x960x32    0x155

#define MODE_1440x960x8     0x156
#define MODE_1440x960x16    0x157
#define MODE_1440x960x32    0x158
    
#define MODE_1680x1050x8    0x159
#define MODE_1680x1050x16   0x15a
#define MODE_1680x1050x32   0x15b

#define MODE_1920x1080x8    0x15c
#define MODE_1920x1080x16   0x15d
#define MODE_1920x1080x32   0x15e

#define MODE_1920x1200x8    0x15f
#define MODE_1920x1200x16   0x160
#define MODE_1920x1200x32   0x161

#define MODE_1920x1440x8    0x162 
#define MODE_1920x1440x16   0x163
#define MODE_1920x1440x32   0x164


#define MODE_USR_DEF1x8     0x1F1
#define MODE_USR_DEF1x16    0x1F2
#define MODE_USR_DEF1x32    0x1F3

#define MODE_USR_DEF2x8     0x1F4
#define MODE_USR_DEF2x16    0x1F5
#define MODE_USR_DEF2x32    0x1F6

#endif 

