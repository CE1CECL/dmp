#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0x89e24b9c, "struct_module" },
	{ 0x4c3af445, "__request_region" },
	{ 0x4ac7b024, "pci_bus_read_config_byte" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0x89b301d4, "param_get_int" },
	{ 0xdc3eaf70, "iomem_resource" },
	{ 0xe19a7d74, "framebuffer_release" },
	{ 0xab978df6, "malloc_sizes" },
	{ 0x56179c5f, "mtrr_add" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x56e59ecc, "cfb_fillrect" },
	{ 0x2fd1d81c, "vfree" },
	{ 0x98bd6f46, "param_set_int" },
	{ 0xaa136450, "param_get_charp" },
	{ 0xfb1e2797, "cfb_imageblit" },
	{ 0x1b7d4074, "printk" },
	{ 0x7a890c8, "fb_alloc_cmap" },
	{ 0xb7046d9a, "pci_find_device" },
	{ 0x674c6a7, "register_framebuffer" },
	{ 0x56134363, "pci_bus_write_config_dword" },
	{ 0x9eac042a, "__ioremap" },
	{ 0x7dceceac, "capable" },
	{ 0x19070091, "kmem_cache_alloc" },
	{ 0x78021fa2, "pci_bus_read_config_word" },
	{ 0x7561ed, "pci_bus_read_config_dword" },
	{ 0x8bb33e7d, "__release_region" },
	{ 0x7423476b, "pci_unregister_driver" },
	{ 0x2cd7da6c, "param_set_charp" },
	{ 0x96b9a119, "framebuffer_alloc" },
	{ 0x2e60bace, "memcpy" },
	{ 0xedc03953, "iounmap" },
	{ 0x13f3405e, "__pci_register_driver" },
	{ 0xcc6ebaab, "cfb_copyarea" },
	{ 0xdd994dbd, "pci_enable_device" },
	{ 0x9e7d6bd0, "__udelay" },
	{ 0x1d7cb64, "unregister_framebuffer" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("pci:v000018CAd00000020sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000018CAd00000021sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000018CAd00000027sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000018CAd00000040sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v000018CAd00000042sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "6D1571AEC936553FD41AD62");
