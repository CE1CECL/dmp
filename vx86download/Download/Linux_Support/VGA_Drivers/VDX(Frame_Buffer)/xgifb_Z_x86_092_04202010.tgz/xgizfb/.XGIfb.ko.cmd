cmd_/root/fb/XGIfb.ko := ld -m elf_i386 -m elf_i386 -r -o /root/fb/XGIfb.ko /root/fb/XGIfb.o /root/fb/XGIfb.mod.o
