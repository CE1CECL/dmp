/root/fb/XGIfb.ko
/root/fb/XGI_main_26.o /root/fb/XGI_accel.o /root/fb/vb_init.o /root/fb/vb_setmode.o /root/fb/vb_util.o /root/fb/vb_ext.o /root/fb/vb_ch7007.o /root/fb/vb_i2c.o /root/fb/floatlib.o
