cmd_/root/fb/floatlib.o := gcc -m32 -Wp,-MD,/root/fb/.floatlib.o.d  -nostdinc -isystem /usr/lib/gcc/i386-redhat-linux/4.1.2/include -D__KERNEL__ -Iinclude  -include include/linux/autoconf.h  -Wall -Wundef -Wstrict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -Wstrict-prototypes -Wundef -Werror-implicit-function-declaration -Os -pipe -msoft-float -fno-builtin-sprintf -fno-builtin-log2 -fno-builtin-puts  -mpreferred-stack-boundary=2  -march=i686 -mtune=generic -mtune=generic -mregparm=3 -ffreestanding -Iinclude/asm-i386/mach-generic -Iinclude/asm-i386/mach-default -fomit-frame-pointer -g  -fno-stack-protector -Wdeclaration-after-statement -Wno-pointer-sign   -DMODULE -D"KBUILD_STR(s)=\#s" -D"KBUILD_BASENAME=KBUILD_STR(floatlib)"  -D"KBUILD_MODNAME=KBUILD_STR(XGIfb)" -c -o /root/fb/.tmp_floatlib.o /root/fb/floatlib.c

deps_/root/fb/floatlib.o := \
  /root/fb/floatlib.c \

/root/fb/floatlib.o: $(deps_/root/fb/floatlib.o)

$(deps_/root/fb/floatlib.o):
