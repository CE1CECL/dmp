/* 
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */


#ifndef GENERIC_PCI_HEADER
#define GENERIC_PCI_HEADER 1



#ifndef PCI_VENDER_ID_RDC
#define PCI_VENDER_ID_RDC 0x17F3
#endif

#define PCI_DEVICE_ID_RDC_M2010 0x2010
#define PCI_DEVICE_ID_RDC_M2012 0x2012

#endif
