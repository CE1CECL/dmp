/* 
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */


#ifndef GENERICV4L_HEADER
#define GENERICV4L_HEADER 1

#include <linux/version.h>

#if defined(CONFIG_MODVERSIONS) && ! defined(MODVERSIONS)
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,15)
#include <linux/modversions.h>
#else
#include <config/modversions.h>
#define MODVERSIONS
#endif
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
#define IRQF_SHARED                    SA_SHIRQ
#endif

#include <linux/pci.h>
#include <linux/videodev.h>
#include <linux/poll.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,15)
#include <media/v4l2-dev.h>
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,18)
#include <media/v4l2-common.h>
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,27)
#include <media/v4l2-ioctl.h>
#endif
#define GENERIC_VERSION_CODE KERNEL_VERSION(0,0,3)
#define MAX_CARDS 1
#ifdef dprintk
# undef dprintk
#endif
#define dprintk(level,fmt, arg...)    if (debug >= level) \
        printk(KERN_DEBUG "genericv4l: " fmt, ## arg)

#define BIT31       0x80000000
#define BIT30       0x40000000
#define BIT29       0x20000000
#define BIT28       0x10000000
#define BIT27       0x08000000
#define BIT26       0x04000000
#define BIT25       0x02000000
#define BIT24       0x01000000
#define BIT23       0x00800000
#define BIT22       0x00400000
#define BIT21       0x00200000
#define BIT20       0x00100000
#define BIT19       0x00080000
#define BIT18       0x00040000
#define BIT17       0x00020000
#define BIT16       0x00010000
#define BIT15       0x00008000
#define BIT14       0x00004000
#define BIT13       0x00002000
#define BIT12       0x00001000
#define BIT11       0x00000800
#define BIT10       0x00000400
#define BIT9        0x00000200
#define BIT8        0x00000100
#define BIT7        0x00000080
#define BIT6        0x00000040
#define BIT5        0x00000020
#define BIT4        0x00000010
#define BIT3        0x00000008
#define BIT2        0x00000004
#define BIT1        0x00000002
#define BIT0        0x00000001

#define ALIGN_TO_8(f)             (((f) + 7) & ~7)
#define ALIGN_TO_16(f)            (((f) + 15) & ~15)
#define ALIGN_TO_32(f)            (((f) + 31) & ~31)
#define ALIGN_TO_64(f)            (((f) + 63) & ~63)
#define ALIGN_TO_PAGE(f)          (((f)+ PAGE_SIZE -1) & ~(PAGE_SIZE -1))

#define OutPort(port,val)       outb(val,port)
#define InPort(port)            inb(port)

#define FALSE 0
#define TRUE  1

typedef u8   BOOL;


typedef struct _DMADescriptor
{
    u32 DMAControl_FBBase;
    u32 SMBase;
    u32 FID_BC;
    u32 NextDescrX;
}DMADescriptor;


typedef struct _DMAINFO
{
    u32 dwCount; 
    u32 dwCurrent; 
    dma_addr_t PhyAddress; 
    DMADescriptor *pDMADescriptorBase; 
}DMAINFO;

#define RESOURCE_OVERLAY       1
#define RESOURCE_VIDEO         2
#define RESOURCE_VBI           4

#define VBI_MAXLINES 32

#define VIDEO_MAX_FRAMES 3
#define VIDEO_V4L1_BUF 2

#define FORMAT_FLAGS_DITHER       0x01
#define FORMAT_FLAGS_PACKED       0x02
#define FORMAT_FLAGS_PLANAR       0x04
#define FORMAT_FLAGS_RAW          0x08
#define FORMAT_FLAGS_CrCb         0x10

#define FRAME_BUFFER_TO_SYSTEM  0x1


#define STATUS_CAPTURING (BIT0)
#define STATUS_BUF_READY (BIT1)
#define STATUS_DMABUF_READY (BIT2)
#define STATUS_VBI_CAPTURE (BIT3)
#define STATUS_VBI_READY (BIT4)
#define STATUS_VBI_DMABUF_READY (BIT5)
#define STATUS_POLL_READY (BIT6)


#define RDC_CAP_M2010 BIT0
#define RDC_CAP_M2012 BIT1
#define RDC_CAP_COMM  (BIT0|BIT1)



struct generici2cchip {
  int   deviceid;
  int   revision;
  char* ident;
  char* name;
  u8    addr;
};
typedef struct S_GENERIC_FH GENERIC_FH;
typedef struct S_GENERIC_CARD GENERIC_CARD;
struct generic_buffer;


enum videobuf_state {
  STATE_NEEDS_INIT = 0,
  STATE_PREPARED   = 1,
  STATE_QUEUED     = 2,
  STATE_ACTIVE     = 3,
  STATE_DONE       = 4,
  STATE_ERROR      = 5,
  STATE_IDLE       = 6,
};


enum
{
    RGB32 = 0,
    RGB24 = 1,
    YUY2  = 2,
};

struct videobuf_dmabuf {
  
  int                 offset;
  struct page         **pages;

  
  void                *vmalloc;

  
  struct scatterlist  *sglist;
  int                 sglen;
  int                 nr_pages;
  int                 direction;
};

struct videobuf_buffer {
   unsigned int            i;

   
   unsigned int            width;
   unsigned int            height;
   unsigned long           size;
   enum v4l2_field         field;
   enum videobuf_state     state;
   struct videobuf_dmabuf  dma;
   struct list_head        stream;  

   
   size_t                  boff;    
   size_t                  bsize;   
   unsigned long           baddr;   
   struct videobuf_mapping *map;

   
   struct list_head        queue;
   wait_queue_head_t       done;
   unsigned int            field_count;
   struct timeval          ts;
};

struct btcx_riscmem {
        unsigned int   size;
        u32            *cpu;
        u32            *jmp;
        dma_addr_t     dma;
};

struct generic_buffer {
        struct videobuf_buffer     vb;

        struct btcx_riscmem        top;
        struct btcx_riscmem        bottom;
};

struct videobuf_queue_ops {
  int (*buf_setup)(struct file *file,
                   unsigned int *count, unsigned int *size);
  int (*buf_prepare)(struct file *file,struct videobuf_buffer *vb,
                     enum v4l2_field field);
  void (*buf_queue)(struct file *file,struct videobuf_buffer *vb);
  void (*buf_release)(struct file *file,struct videobuf_buffer *vb);
};

struct videobuf_queue {
  struct semaphore           lock;
  spinlock_t                 *irqlock;
  struct pci_dev             *pci;

  enum v4l2_buf_type         type;
  unsigned int               msize;
  enum v4l2_field            field;
  enum v4l2_field            last; 
  struct videobuf_buffer     *bufs[VIDEO_MAX_FRAME];
  struct videobuf_queue_ops  *ops;

  
  unsigned int               streaming;
  struct list_head           stream;

  
  unsigned int               reading;
  unsigned int               read_off;
  struct videobuf_buffer     *read_buf;
};

struct videobuf_mapping {
        unsigned int count;
        int highmem_ok;
        unsigned long start;
        unsigned long end;
        struct videobuf_queue *q;
};

struct tuner_types {
  int type; 
  int tunertype;
  char *vendor; 
  char *ident; 
  char *system; 
};

struct generic_tvnorm {
        int   v4l2_id;
        char  *name;
        u32   Fsc;
        u16   swidth, sheight; 
        u16   totalwidth;
        u8    adelay, bdelay, iform;
        u32   scaledtwidth;
        u16   hdelayx1, hactivex1;
        u16   vdelay;
        u8    vbipack;
        u16   vtotal;
        int   sram;
};

#define GENERIC_IFORM_AUTO       0
#define GENERIC_IFORM_NTSC       1
#define GENERIC_IFORM_NTSC_J     2
#define GENERIC_IFORM_PAL_BDGHI  3
#define GENERIC_IFORM_PAL_M      4
#define GENERIC_IFORM_PAL_N      5
#define GENERIC_IFORM_SECAM      6
#define GENERIC_IFORM_PAL_NC     7
#define GENERIC_IFORM_NORM       1
#define GENERIC_IFORM_XT0        (1<<3)
#define GENERIC_IFORM_XT1        (2<<3)

struct generic_tvcard
{
        char *name;
        unsigned int video_inputs;
        unsigned int audio_inputs;
        unsigned int tuner;
        unsigned int svhs;
	unsigned int captmin_x, captmin_y;
};

struct generic_format {
        char *name;
        int  palette;         
        int  fourcc;          
        int  depth;           
        int  flags;
};

struct generic_overlay {
  int tvnorm;
  struct v4l2_rect       w;
  enum v4l2_field        field;
  struct v4l2_clip       *clips;
  int                    nclips;
};


struct S_GENERIC_FH {
  GENERIC_CARD *card;
  int resources;
  enum v4l2_buf_type type;
  struct videobuf_queue    cap;
  struct videobuf_queue    vbi;
  const struct generic_format *fmt;
  const struct generic_format *ovfmt;
  int width;
  int height;
  int lines;

  struct generic_overlay      ov;
};

typedef struct {
  u32 from_addr;
  u32 to_addr;
  u32 size;
  u32 next;
} DMA_BM_TABLE;

typedef struct fifo {
  int front, back, data[VIDEO_MAX_FRAMES+1];
} FIFO;


struct S_GENERIC_CARD {

  
  struct pci_dev *dev; 

  
  int cardnum; 

  
  int v4lmmaptype;
  FIFO frame_queue;
  int fbmallocsize; 

  
  unsigned char revision; 

   
  unsigned char *rdcfb; 
  unsigned char *MMR;
  volatile u32 *MEM_0, *MEM_1; 
  int videoram;        
  u32 buffer[VIDEO_MAX_FRAMES]; 
  
  
  u32           dwFBPhysicalAddress;
  unsigned char *pjRDC_CAP_START; 
  u32            dwCAPStartOffset; 
  u8             bI2C_PORT;       
  u8             bCapChipSlaveAddr;
  u32            dwCapSrcPitch;    
  u32            dwCapSrcHWPitch;    
  u32            dwCapCtl;         
  u32            dwCapActCount;    
  u32            dwMaxBufSize;
  u32            dwMinifyCtl;
  DMAINFO        DMAInfo[VIDEO_MAX_FRAMES];
  unsigned int   dwPOLLCount; 

  
  u32            dwVPStreamCtrl;
  u32            VPostOutBuf;
  int            vpost_color_convert;
  u32            dwVPostCapSrcHWPitch;
  
  

  
  struct i2c_funcs *i2c;

  

  

  
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
   struct video_device video_dev;
   struct video_device vbi_dev;
#else
  struct video_device *video_dev;
  struct video_device *vbi_dev;
#endif

  unsigned int type; 
  ulong driver_data; 

  
  
  struct semaphore lock;
  struct semaphore lockcap;
  int resources;
  spinlock_t s_lock;

  



  
  
  int width,height;
  int OriWidth,OriHeight;
  unsigned long freq;
  unsigned long lastfreq; 
  int tvnorm,hue,contrast,bright,saturation;
  unsigned int mux; 
  int cbsense;
  u16 luma, sat_u, sat_v;
  
  struct video_buffer fbuf;

  int status; 
  GENERIC_FH init;

   u32 saved_bus_cntl,saved_crtc_cntl;

   
   DMA_BM_TABLE *dma_table_buf[VIDEO_MAX_FRAMES];
   u8 *framebuffer[VIDEO_MAX_FRAMES];
   dma_addr_t dmabuf[VIDEO_MAX_FRAMES];
   int frame; 
   int whichfield; 
   unsigned int field_count; 
   u32 CapBufIndex;
   u32 CapProcIndex;
   bool bRGB32;
   bool bSingleBufMode;
   bool bobmode;
};

extern int debug;
extern int disableinterlace;
extern int tunertype;
extern struct generic_tvnorm generic_tvnorms[];


#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
int __devinit generic_probe(struct pci_dev *dev,
   const struct pci_device_id *pci_id);
void __devexit generic_remove(struct pci_dev *pci_dev);
void generic_irq_handler(int irq, void *dev_id, struct pt_regs * regs);
#else
int generic_probe(struct pci_dev *dev,
   const struct pci_device_id *pci_id);
void generic_remove(struct pci_dev *pci_dev);
#endif
int register_irq_handler(GENERIC_CARD *card);
int register_video4linux(GENERIC_CARD *card);
ssize_t generic_read(struct file *file, char *data,
                         size_t count, loff_t *ppos);
ssize_t generic_write(struct file *file, const char *buf,
        size_t count, loff_t *ppos);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,32)
int generic_open(struct file *file);
long generic_ioctl(struct file *file, unsigned int cmd, unsigned long arg);
int generic_release(struct file *file);
#else
int generic_open(struct inode *inode, struct file *file);
int generic_ioctl(struct inode *inode, struct file *file,
                      unsigned int cmd, unsigned long arg);
int generic_release(struct inode *inode, struct file *file);
#endif
int generic_mmap(struct file *file, struct vm_area_struct *vma);
unsigned int generic_poll(struct file *file, poll_table *wait);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)
long generic_do_ioctl(struct file *file, unsigned int cmd, void *arg);
#else
int generic_do_ioctl(struct inode *inode, struct file *file,
                         unsigned int cmd, void *arg);
#endif

int set_tvnorm(GENERIC_CARD *card, unsigned int norm);
void generic_enable_capture(GENERIC_CARD *card);
void generic_disable_capture(GENERIC_CARD *card);
void generic_blockhandler(unsigned long param);
void generic_mmap_vopen(struct vm_area_struct *vma);
void generic_mmap_vclose(struct vm_area_struct *vma);
void grab_frame(GENERIC_CARD *card);
int proc_read(char *buffer, char **start, off_t offset, int size, int *eof, void *data);
int proc_write(struct file *file, const char *buffer, unsigned long count, void *data);
void CovertYUY2ToRGB32UsingVPost(GENERIC_CARD *card);


BOOL bInitDMA(GENERIC_CARD *card);
BOOL bSetDMADes(GENERIC_CARD *card, u32 dwFBSrcId, u32 dwSMDstId);
BOOL bFireDMA(GENERIC_CARD *card);


#endif
