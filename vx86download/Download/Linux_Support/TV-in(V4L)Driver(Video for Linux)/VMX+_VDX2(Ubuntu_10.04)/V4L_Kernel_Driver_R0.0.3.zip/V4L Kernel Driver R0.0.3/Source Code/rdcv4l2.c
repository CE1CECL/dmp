/* 
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */


#include "rdcv4l2.h"

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/interrupt.h>
#include <linux/proc_fs.h>


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)
#include <linux/sched.h>
#endif

#include "i2c.h"
#include "rdcard.h"
#include "queue.h"
#include "pci_id.h"

MODULE_DESCRIPTION("v4l/v4l2 driver module for RDC");
MODULE_AUTHOR("Eric Sellers <sellers-eric@rogers.com>");
MODULE_LICENSE("GPL");


int debug=0;
module_param(debug, int , 0);
MODULE_PARM_DESC(debug, "Debugging level");
int disablev4l2=1;
module_param(disablev4l2, int, 0);
MODULE_PARM_DESC(disablev4l2, "disable v4l2 support");
int disabledma=0;
module_param(disabledma, int, 0);
MODULE_PARM_DESC(disabledma, "disable dma support");
int disableinterlace=0;
module_param(disableinterlace, int, 0);
MODULE_PARM_DESC(disableinterlace, "disable interlace modes");
int halfwidth=0;
module_param(halfwidth, int, 0);
MODULE_PARM_DESC(halfwidth, "cut max width in half (640 becomes 320)");
int forceromaddr=0;
module_param(forceromaddr, int, 0);
MODULE_PARM_DESC(forceromaddr, "Force romaddr to 0x000C0000");

int tunertype=1;
module_param(tunertype, int, 0);
MODULE_PARM_DESC(tunertype, "Tuner type, 0=pal, 1=ntsc, 2=secam, 3=pal nc, 4=pal m, 5= pal n, 6=ntsc jp");
int i2cport=0xb5;
module_param(i2cport, int, 0);
MODULE_PARM_DESC(i2cport, "I2C port assigned to capture, 181 or 183 ");
int format=0;
module_param(format, int, 0);
MODULE_PARM_DESC(format, "Video format = YUV ");

int bob=1;
module_param(bob, int, 0);
MODULE_PARM_DESC(bob, "Deinterlace mode = bob ");

int singlebuf=0;
module_param(singlebuf, int, 0);
MODULE_PARM_DESC(singlebuf, "Single buffer mode ");

int vpost_color_convert=0;
module_param(vpost_color_convert, int, 0);
MODULE_PARM_DESC(singlebuf, "Convert YUY2 to RGB32 by using VPOST engine");

#define CAP_IN_ACTIVE  (*(u32 volatile *)(pjMMIO + CAP_INT_Control_and_Flags) & CAP_VIDEO_STATUS)
#define CAP_IN_BLANKING (!CAP_IN_ACTIVE)

struct proc_dir_entry *proc_dir;


static struct pci_device_id generic_pci_tbl[] __devinitdata = {
     
    {
     vendor:      PCI_VENDER_ID_RDC,
     device:      PCI_DEVICE_ID_RDC_M2010,
     subvendor:   PCI_ANY_ID,
     subdevice:   PCI_ANY_ID,
     class:       0,
     class_mask:  0,
     driver_data: RDC_CAP_M2010 
    },
    {
     vendor:      PCI_VENDER_ID_RDC,
     device:      PCI_DEVICE_ID_RDC_M2012,
     subvendor:   PCI_ANY_ID,
     subdevice:   PCI_ANY_ID,
     class:       0,
     class_mask:  0,
     driver_data: RDC_CAP_M2012 
    },
    {0,}
};


MODULE_DEVICE_TABLE(pci, generic_pci_tbl);

char *tag="genericv4l";
GENERIC_CARD cards[MAX_CARDS];


unsigned int num_cards_detected;

static DECLARE_WAIT_QUEUE_HEAD(generic_wait);
static DECLARE_TASKLET_DISABLED(generic_tasklet, generic_blockhandler, 0);






static struct pci_driver generic_pci_driver = {
        name:      "RDC_v4l",
        id_table:  generic_pci_tbl,
        probe:     generic_probe,
        remove:    __devexit_p(generic_remove),
};


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,32)
static struct v4l2_file_operations generic_fops =
#else
static struct file_operations generic_fops =
#endif
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,32)
        llseek:    no_llseek, 
#endif
        read:      generic_read,
        write:     generic_write,
        ioctl:     generic_ioctl,
        mmap:      generic_mmap,
        open:      generic_open,
        release:   generic_release,
        poll:      generic_poll,
        owner:     THIS_MODULE
};


static struct video_device generic_video_template =
{
        name:      "UNSET",
        fops:      &generic_fops, 
        release:   video_device_release, 
        minor:     -1,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,27)	
        owner:     THIS_MODULE,
        type:      VID_TYPE_CAPTURE
                   
                   
                   
                   
                   
#endif
};




struct generic_tvcard generic_tvcards[] = {
{
        name:            "RDC M2010 CAP",
        video_inputs:    1, 
        audio_inputs:    0,
        tuner:           0,
        svhs:            0,
        captmin_x:       720,
        captmin_y:       480,
}
};
const unsigned int generic_num_tvcards = ARRAY_SIZE(generic_tvcards);

static const struct v4l2_queryctrl no_ctl = {
  .name  = "NOTUSED",
  .flags = V4L2_CTRL_FLAG_DISABLED,
};


static const struct v4l2_queryctrl generic_ctls[] = {
        
        {
                id:             V4L2_CID_BRIGHTNESS,
                name:           "Brightness",
                minimum:        0,
                maximum:        65535,
                step:           256,
                default_value:  32768,
                type:           V4L2_CTRL_TYPE_INTEGER,
        },{
                id:             V4L2_CID_CONTRAST,
                name:           "Contrast",
                minimum:        0,
                maximum:        65535,
                step:           128,
                default_value:  32768,
                type:           V4L2_CTRL_TYPE_INTEGER,
        },{
                id:             V4L2_CID_SATURATION,
                name:           "Saturation",
                minimum:        0,
                maximum:        65535,
                step:           128,
                default_value:  32768,
                type:           V4L2_CTRL_TYPE_INTEGER,
        },{
                id:             V4L2_CID_HUE,
                name:           "Hue",
                minimum:        0,
                maximum:        65535,
                step:           256,
                default_value:  32768,
                type:           V4L2_CTRL_TYPE_INTEGER,
       }
};
const int GENERIC_CTLS = ARRAY_SIZE(generic_ctls);


const struct generic_format generic_formats[] = {
        {
                name:      "32 bpp RGB, le",
                palette:   VIDEO_PALETTE_RGB32,
                fourcc:    V4L2_PIX_FMT_BGR32,
                depth:     32,
                flags:     FORMAT_FLAGS_PACKED,
        },
        {
                name:      "24 bpp RGB, le",
                palette:   VIDEO_PALETTE_RGB24,
                fourcc:    V4L2_PIX_FMT_BGR24,
                depth:     24,
                flags:     FORMAT_FLAGS_PACKED,
        }
        ,
        {
                name:      "4:2:2, packed, YUYV",
                palette:   VIDEO_PALETTE_YUV422,
                fourcc:    V4L2_PIX_FMT_YUYV,
                depth:     16,
                flags:     FORMAT_FLAGS_PACKED,
        }
};

const unsigned int GENERIC_FORMATS = ARRAY_SIZE(generic_formats);

struct generic_tvnorm generic_tvnorms[] = {
        {
                v4l2_id:         V4L2_STD_PAL_Nc,
                name:            "PAL-Nc",
                Fsc:             28636363,
                swidth:          720,
                sheight:         576,
                totalwidth:      910,
                adelay:          0x68,
                bdelay:          0x5d,
                iform:           (GENERIC_IFORM_PAL_NC|GENERIC_IFORM_XT0),
                scaledtwidth:    780,
                hdelayx1:        130,
                hactivex1:       754,
                vdelay:          0x1a,
                vbipack:         144,
                sram:            -1,
        },{
                v4l2_id:         V4L2_STD_NTSC_M,
                name:            "NTSC",
                Fsc:             28636363,
                swidth:          720,
                sheight:         480,
                totalwidth:      910,
                adelay:          0x68,
                bdelay:          0x5d,
                iform:           (GENERIC_IFORM_NTSC|GENERIC_IFORM_XT0),
                scaledtwidth:    910,
                hdelayx1:        135,
                hactivex1:       754,
                vdelay:          0x1a,
                vbipack:         144,
                sram:            1,
        },{
                v4l2_id:         V4L2_STD_SECAM,
                name:            "SECAM",
                Fsc:             35468950,
                swidth:          720,  
                sheight:         576,
                totalwidth:      1135,
                adelay:          0x7F,
                bdelay:          0xA0,
                iform:           (GENERIC_IFORM_SECAM|GENERIC_IFORM_XT1),
                scaledtwidth:    1135,
                hdelayx1:        186,
                hactivex1:       922,
                vdelay:          0x20,
                vbipack:         255,
                sram:           0,
        },{
                v4l2_id:         V4L2_STD_PAL,
                name:            "PAL",
                Fsc:             35468950,
                swidth:          768,
                sheight:         576,
                totalwidth:      1135,
                adelay:          0x7f,
                bdelay:          0x72,
                iform:           (GENERIC_IFORM_PAL_BDGHI|GENERIC_IFORM_XT1),
                scaledtwidth:    1135,
                hdelayx1:        186,
                hactivex1:       922,
                vdelay:          0x20,
                vbipack:         255,
                sram:            0,
        },{
                v4l2_id:         V4L2_STD_PAL_M,
                name:            "PAL-M",
                Fsc:             28636363,
                swidth:          720,
                sheight:         480,
                totalwidth:      910,
                adelay:          0x68,
                bdelay:          0x5d,
                iform:           (GENERIC_IFORM_PAL_M|GENERIC_IFORM_XT0),
                scaledtwidth:    780,
                hdelayx1:        135,
                hactivex1:       754,
                vdelay:          0x1a,
                vbipack:         144,
                sram:            -1,
        },{
                v4l2_id:         V4L2_STD_PAL_N,
                name:            "PAL-N",
                Fsc:             35468950,
                swidth:          768,
                sheight:         576,
                totalwidth:      1135,
                adelay:          0x7f,
                bdelay:          0x72,
                iform:           (GENERIC_IFORM_PAL_N|GENERIC_IFORM_XT1),
                scaledtwidth:    944,
                hdelayx1:        186,
                hactivex1:       922,
                vdelay:          0x20,
                vbipack:         144,
                sram:            -1,
        },{
                v4l2_id:         V4L2_STD_NTSC_M_JP,
                name:            "NTSC-JP",
                Fsc:             28636363,
                swidth:          720,
                sheight:         480,
                totalwidth:      910,
                adelay:          0x68,
                bdelay:          0x5d,
                iform:           (GENERIC_IFORM_NTSC_J|GENERIC_IFORM_XT0),
                scaledtwidth:    780,
                hdelayx1:        135,
                hactivex1:       754,
                vdelay:          0x16,
                vbipack:         144,
                sram:            -1,
        }
};
const unsigned int GENERIC_TVNORMS = ARRAY_SIZE(generic_tvnorms);



int set_tvnorm(GENERIC_CARD *card, unsigned int norm)
{
  const struct generic_tvnorm *tvnorm;
  u8 bTmp,bTmp88;
  
  if (norm < 0 || norm >= GENERIC_TVNORMS)
    return -EINVAL;
  if(card->tvnorm!=norm)
      dprintk(1,"set_tvnorm: new card->tvnorm=%d \n", norm);
      
  card->tvnorm = norm;
  card->OriWidth = generic_tvnorms[norm].swidth;
  card->OriHeight = generic_tvnorms[norm].sheight;

  tvnorm = &generic_tvnorms[norm];

  switch(generic_tvnorms[norm].v4l2_id)
  {
    case V4L2_STD_PAL:
      bTmp = i2c_readreg8(card,card->bCapChipSlaveAddr, 0x0e)&0x8f;
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x0e, bTmp|0x00);  
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x8f, 0x0b);  
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x9a, 0x22);  
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x9b, 0x01); 
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x9e, 0x20);
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x9f, 0x01); 
      break;
    case V4L2_STD_SECAM:
      bTmp = i2c_readreg8(card,card->bCapChipSlaveAddr, 0x0e)&0x8f;
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x0e, bTmp|0x50);      
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x8f, 0x0b);  
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x9a, 0x22);  
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x9b, 0x01); 
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x9e, 0x20);
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x9f, 0x01); 
      break;
    case V4L2_STD_NTSC_M:
    default:
      bTmp = i2c_readreg8(card,card->bCapChipSlaveAddr, 0x0e)&0x8f;
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x0e, bTmp|0x00);      
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x8f, 0x0b);  
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x9a, 0xf2);  
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x9b, 0x00); 
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x9e, 0xf0);
      i2c_writereg8(card,card->bCapChipSlaveAddr, 0x9f, 0x00);    
      break;
  }
  bTmp88 = i2c_readreg8(card,card->bCapChipSlaveAddr, 0x88);
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x88, 0);    
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x88, bTmp88);

  return 0;
}


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,32)
int generic_open(struct file *file)
#else
int generic_open(struct inode *inode, struct file *file)
#endif
{
  GENERIC_CARD *card=NULL;
  GENERIC_FH *fh;
  enum v4l2_buf_type type = 0;
  unsigned int i;

  dprintk(2, "Enter generic_open()\n");

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
  int minor = minor(inode->i_rdev);

  MOD_INC_USE_COUNT;
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,5,0) && LINUX_VERSION_CODE < KERNEL_VERSION(2,6,32)
  int minor = iminor(inode);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,32)
    int minor = iminor(file->f_path.dentry->d_inode);
    printk(KERN_INFO "minor = %d\n", minor);
#endif

  
  for (i = 0; i < num_cards_detected; i++) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
    if (cards[i].video_dev.minor == minor) {
#else
    if (cards[i].video_dev->minor == minor) {
#endif
      card = &cards[i];
      type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
      break;
    }
  }
  
  if (card == NULL){
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
    MOD_DEC_USE_COUNT;
#endif
    printk(KERN_INFO "card is null!!\n");
    return -ENODEV;
  }

  dprintk(2, "card is got.\n");

  
  fh = kmalloc(sizeof(*fh),GFP_KERNEL);
  if (fh == NULL){
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
    MOD_DEC_USE_COUNT;
#endif
    return -ENOMEM;
  }

  init_MUTEX(&fh->cap.lock);
  init_MUTEX(&fh->vbi.lock);
  
  file->private_data = fh;


  fh->type = type;
  fh->card = card;
  fh->resources = 0;
  dprintk(2, "card(%d) generic_open called\n", card->cardnum);

  return 0;
}


void generic_enable_capture(GENERIC_CARD *card) 
{

  dprintk(2,"card(%d) generic_enable_capture called\n",card->cardnum);
  
  down_interruptible(&card->lock);

  
  card->status &= ~(STATUS_DMABUF_READY | STATUS_BUF_READY);
  
  card->field_count = 0;
  card->dwPOLLCount = 0;

  if (card->driver_data & RDC_CAP_COMM) 
  {
    rdc_enable_capture(card);
  }
  
  
  set_brightness(card,0x95<<8);
  set_contrast(card,0x48<<8);
  set_hue(card,0x0<<8);
  set_saturation(card,0x40<<8);

  
  if (card->tvnorm == 2)
  {
    printk (KERN_INFO "Enabling HFILT for SECAM video\n");
  }

  
  up(&card->lock);
}


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,32)
int generic_release(struct file *file)
#else
int generic_release(struct inode *inode, struct file *file)
#endif
{
  GENERIC_FH *fh = (GENERIC_FH *) file->private_data;
  GENERIC_CARD *card = fh->card;
  
  

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
MOD_DEC_USE_COUNT;
#endif
  dprintk (1, "generic_release called\n");

  switch (fh->type) {
    case V4L2_BUF_TYPE_VIDEO_CAPTURE:
      
      if (fh->resources & STATUS_CAPTURING){
        generic_disable_capture(card);
      }
      break;
    default:
      BUG();
  }


  file->private_data = NULL;
  kfree(fh);
  
  return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)
long generic_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
#else
int generic_ioctl(struct inode *inode, struct file *file,
                      unsigned int cmd, unsigned long arg)
#endif
{

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)
  return video_usercopy(file, cmd, arg, generic_do_ioctl);
#else
  return video_usercopy(inode, file, cmd, arg, generic_do_ioctl);
#endif

  return 0;
}

void generic_blockhandler(unsigned long param)
{
   wake_up_interruptible(&generic_wait);
   return;
}

ssize_t generic_read(struct file *file, char *data,
                         size_t count, loff_t *ppos) 
{
  GENERIC_FH *fh = file->private_data;
  GENERIC_CARD *card = fh->card;
  int retval = 0;

  
  dprintk(2,"card(%d) generic_read called\n",card->cardnum);

  switch (fh->type) 
  {
    case V4L2_BUF_TYPE_VIDEO_CAPTURE:
     
      if (!(fh->resources & STATUS_CAPTURING))
      {
        if (card->status & STATUS_CAPTURING)
        {
            return -EBUSY;
        } 
        else 
        {
            fh->resources = STATUS_CAPTURING;
            generic_enable_capture(card);
        }
      }
      grab_frame(card);
      
      retval = card->fbmallocsize; 
      
      if(count<retval)
      {
          dprintk(2,"generic_read: if(count<retval);\n");
          return -EFAULT;
      }
      

      if (copy_to_user(data,card->framebuffer[card->frame],retval))
      {
         dprintk(0,"generic_read: copy_to_user framebuffer[%d] error;\n",card->frame);
         return -EFAULT;
      } 
      
      break;
    default:
      dprintk(2,"generic_read: BUG();\n");
      BUG();
  }
  
  return retval;
}


static struct vm_operations_struct generic_mmap_vm_ops = {
  open:    generic_mmap_vopen, 
  close:  generic_mmap_vclose,

};


void generic_mmap_vopen(struct vm_area_struct *vma)
{
     
    dprintk(2,"generic_mmap_vopen called\n");
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
    OD_INC_USE_COUNT;
#endif
}


void generic_mmap_vclose(struct vm_area_struct *vma)
{
    dprintk(2,"generic_mmap_vclose called\n");

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
    OD_DEC_USE_COUNT;
#endif
}

int generic_mmap(struct file *file, struct vm_area_struct *vma)
{
  GENERIC_FH *fh = file->private_data;
  GENERIC_CARD *card = fh->card;
  int i,j;

unsigned long start = vma->vm_start;
unsigned long size  = vma->vm_end - vma->vm_start;
unsigned long page=0,pos=0;

  dprintk(2,"card(%d) generic_mmap called\n",card->cardnum);
  dprintk(2,"mmap card->v4lmmaptype= %d\n",card->v4lmmaptype);

  down_interruptible(&card->lock);
  
  

  
  if (card->v4lmmaptype)
  {
      size = (vma->vm_end - vma->vm_start);
      j = 1;
  } 
  else 
  { 
      j = VIDEO_V4L1_BUF;
  }
  
  for (i=0;i<j;i++){
    if (card->v4lmmaptype)
    {
      dprintk(2,"mmap card->fram= %d\n",card->frame);
      pos = (unsigned long)card->framebuffer[card->frame];

    } 
    else 
    { 
      size = (vma->vm_end - vma->vm_start) / VIDEO_V4L1_BUF;
      pos = (unsigned long)card->framebuffer[i];
    }
    dprintk(2,"(vma->vm_end - vma->vm_start) = 0x%x\n",(u32)size);
    while (size > 0)
    {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
      page = kvirt_to_pa(pos);
      if (remap_page_range(start,page,PAGE_SIZE, PAGE_SHARED)) {
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,10)
      page = kvirt_to_pa(pos);
      if (remap_page_range(vma,start,page,PAGE_SIZE, PAGE_SHARED)) {
#else
      page = vmalloc_to_pfn((void *)pos);
      
      
      if (remap_pfn_range(vma,start,page,PAGE_SIZE, PAGE_SHARED)) {	      
#endif
#endif
        printk(KERN_INFO "remap page range failed\n");
        up(&card->lock);
        return -EAGAIN;
      }
      start += PAGE_SIZE;
      pos += PAGE_SIZE;
      if (size > PAGE_SIZE){
        size -= PAGE_SIZE;
      } else {
        size = 0;
      }
    }
  }
  up(&card->lock);

  vma->vm_ops = &generic_mmap_vm_ops;
  

  
  return 0;
}

unsigned int generic_poll(struct file *file, poll_table *wait)
{
  GENERIC_FH *fh = file->private_data;
  GENERIC_CARD *card = fh->card;
  int ret=1;
  dprintk(3,"card(%d) generic_poll called\n",card->cardnum);
  if (!(card->status & STATUS_CAPTURING))
  {
      dprintk(3,"not in capture\n");
      return 0;
      
  }
  
  
  
  
  if(!(card->status&STATUS_BUF_READY))
    ret = wait_event_interruptible_timeout(generic_wait, (card->status & STATUS_BUF_READY), HZ * 1);
  
  if(ret == 0)
    printk ("generic_poll: Timed out \n");  
  else
  {
    
    
    card->status &= ~STATUS_BUF_READY;
  }
  
  
  
  
  return POLLIN|POLLRDNORM;
  
}

ssize_t generic_write(struct file *file, const char *buf,
        size_t count, loff_t *ppos)
{
  GENERIC_FH *fh = file->private_data;
  GENERIC_CARD *card = fh->card;

  dprintk(1,"card(%d) generic_write called (unsupported)\n",card->cardnum);
  return 0;
}

#define DUMP_BT_REG(REG) \
  len += sprintf (buffer+len,"%-20s (0x%02X) = 0x%02X\n",#REG,REG, BTREAD(card,REG))

#define DUMP_BOARD_REG(REG) \
  len += sprintf (buffer+len,"%-20s = 0x%02X\n",#REG,REG)


int proc_read(char *buffer, char **start, off_t offset, int size,
                        int *eof, void *data)
{
  GENERIC_CARD *card = data;
  int len=0;

  len += sprintf (buffer+len,"Field Count: %d\n",card->field_count);

  if (len <= offset+size) *eof = 1;
  *start = buffer + offset;
  len -= offset;
  if (len > size) len = size;
  if (len < 0) len = 0;
  return len;
}

int proc_write(struct file *file, const char *buffer,
                      unsigned long count, void *data)
{
  GENERIC_CARD *card = data;
  char inbuf[80];

  if (count > 79){
    count = 79;
  }
  if (copy_from_user(inbuf, buffer, count)){
    return -EFAULT;
  }
  inbuf[count] = '\0';

  printk(KERN_INFO "card(%d) Write called you sent [%s]\n",card->cardnum, inbuf);

  return count;
}

static int get_control(GENERIC_CARD *card, struct v4l2_control *c)
{
  int i;

  for (i = 0; i < GENERIC_CTLS; i++)
    if (generic_ctls[i].id == c->id)
      break;
  if (i == GENERIC_CTLS)
    return -EINVAL;

  c->value = 0;
  switch (c->id) {
    case V4L2_CID_BRIGHTNESS:
    c->value = card->bright;
      break;
    case V4L2_CID_HUE:
      c->value = card->hue;
      break;
    case V4L2_CID_CONTRAST:
        c->value = card->contrast;
      break;
    case V4L2_CID_SATURATION:
        c->value = card->saturation;
      break;



    case V4L2_CID_AUDIO_VOLUME:
      dprintk(1,"card(%d) Get volume (not done yet)\n",card->cardnum);
      break;
    case V4L2_CID_AUDIO_BALANCE:
      dprintk(1,"card(%d) Get balance (not done yet)\n",card->cardnum);
      break;
    case V4L2_CID_AUDIO_BASS:
      dprintk(1,"card(%d) Get bass (not done yet)\n",card->cardnum);
      break;
    case V4L2_CID_AUDIO_TREBLE:
      dprintk(1,"card(%d) Get treble (not done yet)\n",card->cardnum);
      break;
    default:
      return -EINVAL;
  }
  return 0;
}

static int set_control(GENERIC_CARD *card, struct v4l2_control *c)
{
  int i;

  for (i = 0; i < GENERIC_CTLS; i++)
    if (generic_ctls[i].id == c->id)
      break;
  if (i == GENERIC_CTLS)
  {
    dprintk(1,"card(%d) VIDIOC_S_CTRL c->id %d\n",card->cardnum,c->id);
    return -EINVAL;
  }

  switch (c->id) {
    case V4L2_CID_BRIGHTNESS:
      
      break;
    case V4L2_CID_HUE:
      
      break;
    case V4L2_CID_CONTRAST:
      
      break;
    case V4L2_CID_SATURATION:
      
      break;
    default:
      return -EINVAL;
  }
  return 0;
}

static int generic_g_fmt(GENERIC_FH *fh, struct v4l2_format *f)
{
    GENERIC_CARD *card = fh->card;
    switch (f->type)
    {
        case V4L2_BUF_TYPE_VIDEO_CAPTURE:
                memset(&f->fmt.pix,0,sizeof(struct v4l2_pix_format));
                f->fmt.pix.width        = card->width;
                f->fmt.pix.height       = card->height;
                f->fmt.pix.field        = fh->cap.field;
                f->fmt.pix.pixelformat  = generic_formats[format].fourcc;
                f->fmt.pix.bytesperline = card->dwCapSrcPitch;
                return 0;
        case V4L2_BUF_TYPE_VBI_CAPTURE:
        default:
                return -EINVAL;
    }
}


void generic_disable_capture(GENERIC_CARD *card) 
{
  int grabbingvbi;

  
  down_interruptible(&card->lockcap);
  down_interruptible(&card->lock);

  
  grabbingvbi = (card->status & STATUS_VBI_CAPTURE);

  if (card->driver_data & RDC_CAP_COMM) 
  {
    rdc_disable_capture(card);
  }

  
  card->status = grabbingvbi;

  up(&card->lock);
  up(&card->lockcap);
}

void set_input(GENERIC_CARD *card, unsigned int input)
{
  card->mux = input;
}


int v4l2_video_std_const(struct v4l2_standard *vs,
                             int id, char *name)
{
        memset(vs, 0, sizeof(struct v4l2_standard));

        vs->id = id;
        if (id & (V4L2_STD_NTSC | V4L2_STD_PAL_M)) {
                vs->frameperiod.numerator = 1001;
                vs->frameperiod.denominator = 30000;
                vs->framelines = 525;
        } else {
                vs->frameperiod.numerator = 1;
                vs->frameperiod.denominator = 25;
                vs->framelines = 625;
        }
        strncpy(vs->name,name,sizeof(vs->name));
        return 0;
}


void grab_frame(GENERIC_CARD *card)
{
  int ret = 0;
  u8* pjMMIO;
  u32 dwFilpID,dwBottom,dwTmp;
  pjMMIO = card->MMR;
  
  down_interruptible(&card->lockcap);

  
  if (!(card->status & STATUS_CAPTURING))
  {
    dprintk(2,"grab_frame: not in capture\n");
    up(&card->lockcap);
    return;
  }
  dprintk(2,"grab_frame: card->frame= %d, field_count= %d \n",card->frame,card->field_count);
  
  if(card->bSingleBufMode)
  {
      if(card->CapProcIndex == 0)
      {
         card->CapBufIndex = 2;
      }
      else if (card->CapProcIndex == 1)
      {
         card->CapBufIndex = 0;
      }
      else if (card->CapProcIndex == 2)
      {
         card->CapBufIndex = 1;
      }  
  }
  else
  {
      dwTmp = (*(u32 volatile *)(pjMMIO + CAP_INT_Control_and_Flags));  
      dwFilpID = (dwTmp>>8)&0x3;  
      dwBottom = (dwTmp>>6)&0x1;
      
      switch(dwFilpID)
      {
         case 0:
         if (card->driver_data & RDC_CAP_M2010) 
         {
             if(dwBottom)
               card->CapBufIndex = 0;
             else
               card->CapBufIndex = 2;
         }
         else
         {
             card->CapBufIndex = 2;  
         }
         break;
         case 1:
         if (card->driver_data & RDC_CAP_M2010) 
         {
             if(dwBottom)
               card->CapBufIndex = 1;
             else
               card->CapBufIndex = 0;
         }
         else
         {
             card->CapBufIndex = 0;  
         }
         break;
        case 2:
        if (card->driver_data & RDC_CAP_M2010)
        {
             if(dwBottom)
               card->CapBufIndex = 2;
             else
               card->CapBufIndex = 1;
        }
        else
        {
             card->CapBufIndex = 1;
        }
        break;
        default:
          dprintk(0,"grab_frame: dwFilpID error = %d \n",dwFilpID);
          break;
      }
  }

  if ((format == RGB24 || format == RGB32) && card->vpost_color_convert)
    CovertYUY2ToRGB32UsingVPost(card);

  if (!disabledma) 
  { 
    if((card->status&STATUS_DMABUF_READY)!=STATUS_DMABUF_READY)
    {
      
      bSetDMADes(card,card->CapBufIndex,card->frame);     
      bFireDMA(card);
      
      ret = wait_event_interruptible_timeout(generic_wait, (card->status & STATUS_DMABUF_READY), HZ * 5);
    }
     
  }
  else
  { 
    
    MoveRGB32ToRGB24ByCPU(card);
    
    ret = 1;   
    
    
  }

  if(ret)
  {
    
    if (card->driver_data & RDC_CAP_M2012) 
      (*(u32 volatile *)(pjMMIO + CAP_INT_Control_and_Flags)) = CAP_END_OF_ACTIVE;
    card->status &= ~STATUS_DMABUF_READY;    
  }
  else
  {
    printk ("Timed out sending frame\n");
  } 
  
  up(&card->lockcap);
  
}




#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32)
long generic_do_ioctl(struct file *file, unsigned int cmd, void *arg)
#else
int generic_do_ioctl(struct inode *inode, struct file *file,
                         unsigned int cmd, void *arg)
#endif
{
  GENERIC_FH *fh = (GENERIC_FH *) file->private_data;
  GENERIC_CARD *card = fh->card;
  
  

  switch (cmd) {
      
      
      case VIDIOCGCAP:
       {
        struct video_capability *cap = arg;
         dprintk(2,"card(%d) VIDIOCGCAP called\n",card->cardnum);
         memset(cap,0,sizeof(*cap));
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
        strncpy(cap->name,card->video_dev.name,32);
#else
        strncpy(cap->name,card->video_dev->name,32);
#endif
        if (fh->type == V4L2_BUF_TYPE_VBI_CAPTURE) 
        {
          return -EINVAL;;
        } 
        else 
        {
          
          cap->type = VID_TYPE_CAPTURE;
  
          cap->channels  = 1; 
          cap->audios    = 0;
          cap->maxwidth  = generic_tvnorms[card->tvnorm].swidth;
          cap->maxheight = generic_tvnorms[card->tvnorm].sheight;
          cap->minwidth  = generic_tvcards[card->type].captmin_x;
          cap->minheight = generic_tvcards[card->type].captmin_y;
        }
       return 0;
       }
      
      case VIDIOCGPICT:
       {
         struct video_picture *pic = arg;
         dprintk(2,"card(%d) VIDIOCGPICT called\n",card->cardnum);
         memset(pic,0,sizeof(*pic));
         pic->brightness = card->bright;
         pic->contrast   = card->contrast;
         pic->hue        = card->hue;
         pic->colour     = card->saturation;
         pic->depth      = generic_formats[format].depth; 
         pic->palette    = generic_formats[format].palette;   
         return 0;
      }
      
      case VIDIOCSPICT:
       {
            struct video_picture *pic = arg;
            dprintk(2,"card(%d) VIDIOCSPICT called\n",card->cardnum);
            
            if (pic->palette != generic_formats[format].palette)
            {        
               dprintk(1,"card(%d) VIDIOCGPICT call failed %d != %d\n",card->cardnum,pic->palette, generic_formats[format].palette);
               return -EAGAIN;
            }
         
            dprintk(1,"VIDIOCSPICT called:Video format = %d\n",pic->palette);
            
            set_brightness(card,pic->brightness);
            set_contrast(card,pic->contrast);
            set_hue(card,pic->hue);
            set_saturation(card,pic->colour);
  
            return 0;
       }
     
      case VIDIOCGWIN:
       {
        struct video_window *win = arg;
        dprintk(2,"card(%d) VIDIOCGWIN called\n",card->cardnum);
  
        memset(win,0,sizeof(*win));
        win->x      = 0;
        win->y      = 0; 
        win->width  = card->width;
        win->height = card->height;
        return 0;
       }
      
      case VIDIOCSWIN:
       {
        struct video_window *win = arg;
        u8 framerate;
  
        dprintk(2,"card(%d) VIDIOCSWIN called\n",card->cardnum);
  
        framerate = win->flags;
        if (framerate >= 1 && framerate <= 60)
        {
           printk(KERN_INFO "card(%d) I WOULD set frame rate set to %d but it doesnt seem to work\n",card->cardnum,60-framerate);
        }
  
        
        if (win->width > generic_tvnorms[card->tvnorm].swidth)
          win->width = generic_tvnorms[card->tvnorm].swidth;
        if (win->width < generic_tvcards[card->type].captmin_x)
          win->width = generic_tvcards[card->type].captmin_x;
        if (win->height > generic_tvnorms[card->tvnorm].sheight)
          win->height = generic_tvnorms[card->tvnorm].sheight;
        if (win->height < generic_tvcards[card->type].captmin_y)
          win->height = generic_tvcards[card->type].captmin_y;
  
        if (win->width != card->width ||
            win->height != card->height)
        {
          card->width = win->width;
          card->height = win->height;
  
          if (card->status & STATUS_CAPTURING)
          {
            
            
            generic_disable_capture(card);
            generic_enable_capture(card);
          }
        }
        return 0;
       }
      
      case VIDIOCGFBUF: 
       {
        
        dprintk(2,"card(%d) VIDIOCGFBUF called\n",card->cardnum);
        
        return 0;
       }
      
      case VIDIOCSFBUF:
       {
       dprintk(2,"card(%d) VIDIOCSFBUF called\n",card->cardnum);
       return -EINVAL;
       }
       
      case VIDIOCGUNIT:
          dprintk(2,"card(%d) VIDIOCGUNIT called\n",card->cardnum);
          return -EINVAL;
      
      case VIDIOCGCAPTURE:
          dprintk(2,"card(%d) VIDIOCGCAPTURE called\n",card->cardnum);
          return -EINVAL;      
       
      case VIDIOCSCAPTURE:
          dprintk(2,"card(%d) VIDIOCSCAPTURE called\n",card->cardnum);
          return -EINVAL;    
      
      case VIDIOCGPLAYINFO:
          dprintk(2,"card(%d) VIDIOCGPLAYINFO called\n",card->cardnum);
          return -EINVAL;           
      
      case VIDIOCCAPTURE:
       {
       dprintk(2,"card(%d) VIDIOCCAPTURE called\n",card->cardnum);
        return -EINVAL;
       }
      case VIDIOC_OVERLAY:
       {
       dprintk(2,"card(%d) VIDIOC_OVERLAY called\n",card->cardnum);
        return -EINVAL;
       }
      
      case VIDIOCGMBUF:
       {
        struct video_mbuf *mbuf = arg;
  
        dprintk(2,"card(%d) VIDIOCGMBUF called %dx%d\n",card->cardnum,card->width, card->height);
  
        if (!(fh->resources & STATUS_CAPTURING))
        {
          if (card->status & STATUS_CAPTURING){
             return -EBUSY;
          } else {
             fh->resources = STATUS_CAPTURING;
          }
        }
        down_interruptible(&fh->cap.lock);
        
        card->v4lmmaptype = 0;
        memset(mbuf,0,sizeof(*mbuf));
        mbuf->frames = VIDEO_V4L1_BUF;
        
        mbuf->size   = card->dwMaxBufSize * VIDEO_V4L1_BUF;
        mbuf->offsets[0] = 0;
        mbuf->offsets[1] = card->dwMaxBufSize;
        up(&fh->cap.lock);
  
        return 0;
       }
      
      case VIDIOCMCAPTURE:
       {
        struct video_mmap *vm = arg;
        dprintk(1,"card(%d) VIDIOCMCAPTURE called frame = %d\n",card->cardnum,vm->frame);
        if (vm->frame < 0 || vm->frame >= VIDEO_V4L1_BUF)
        {
           return -EINVAL;
        }
        down_interruptible(&fh->cap.lock);
        card->frame = vm->frame;

        if (vm->format != generic_formats[format].palette)
        {
            up(&fh->cap.lock);
            return -EINVAL;
        }  
        
        dprintk(1,"video format = %d\n",vm->format);

        if (card->width != vm->width || card->height != vm->height)
        {
          if (vm->width > generic_tvnorms[card->tvnorm].swidth)
            vm->width = generic_tvnorms[card->tvnorm].swidth;

          if (vm->height > generic_tvnorms[card->tvnorm].sheight)
            vm->height = generic_tvnorms[card->tvnorm].sheight;
            
          card->width = vm->width;
          card->height = vm->height;

          card->dwCapSrcPitch = vm->width * (generic_formats[format].depth/8);
          if (card->driver_data & RDC_CAP_M2012) 
          {
            if(format == RGB24)       
                card->dwCapSrcHWPitch = vm->width*4; 
            else
                card->dwCapSrcHWPitch = vm->width * (generic_formats[format].depth/8);

            
            if (card->vpost_color_convert)
                card->dwVPostCapSrcHWPitch = vm->width * (generic_formats[YUY2].depth/8);
          }

          card->fbmallocsize = ALIGN_TO_PAGE(card->dwCapSrcPitch * vm->height);  
          
          if (card->status & STATUS_CAPTURING)
          {
            dprintk(2,"card(%d) VIDIOCMCAPTURE called %dx%d\n",card->cardnum, vm->width, vm->height);
            generic_disable_capture(card);
            generic_enable_capture(card);
          }
        }

        
        if (!(card->status & STATUS_CAPTURING))
        {
          generic_enable_capture(card);
        }

        grab_frame(card);
  
        up(&fh->cap.lock);
        return 0;
       }
      
      case VIDIOCSYNC:
       {
        int *frame = arg;
        int ret=1;
        
        dprintk(1,"card(%d) VIDIOCSYNC called frame = %d\n",card->cardnum,*frame);
        
        if (*frame < 0 || *frame >= VIDEO_V4L1_BUF){
          return -EINVAL;
        }
        
        
        if(!(card->status&STATUS_BUF_READY))
          ret = wait_event_interruptible_timeout(generic_wait, (card->status & STATUS_BUF_READY), HZ * 1);
        
        if(ret == 0)
          printk ("generic_poll: Timed out \n");  
        else
        {
          
          
          card->status &= ~STATUS_BUF_READY;
        }        
       
        return 0;
       }
      
      case VIDIOCGVBIFMT:
       {
      
        dprintk(1,"card(%d) VIDIOCGVBIFMT called \n",card->cardnum);
        return -EINVAL;
       }
  
      
      case VIDIOCGFREQ:
       {
         unsigned long *freq = arg;
         *freq = card->freq;
         dprintk(2,"card(%d) VIDIOCGFREQ called %ld\n",card->cardnum,card->freq);
         return -EINVAL;
         return 0;
      }
      
      case VIDIOCSFREQ:
      {
        unsigned long *freq = arg;
        dprintk(2,"card(%d) VIDIOCSFREQ called %ld\n",card->cardnum, *freq);
        return -EINVAL;
        down_interruptible(&card->lock);
        card->freq=*freq;
        up(&card->lock);
        return 0;
      }
      
      case VIDIOCGTUNER:
      {
       
       
       dprintk(1,"card(%d) VIDIOCSYNC called \n",card->cardnum);
       return -EINVAL;

       }
      
      
      case VIDIOCSTUNER:
       dprintk(2,"card(%d) VIDIOCSTUNER called (not done)\n",card->cardnum);
       return 0;
      
      case VIDIOCGCHAN:
      {
        struct video_channel *v = arg;
        unsigned int channel = v->channel;
        BOOL bSignalStandard;

        dprintk(2,"card(%d) VIDIOCGCHAN called\n",card->cardnum);
        
        if (channel >= generic_tvcards[card->type].video_inputs)
            return -EINVAL;
   
        bSignalStandard = (i2c_readreg8(card, card->bCapChipSlaveAddr, 0x1F) & BIT5);
        if(bSignalStandard)
        {
           card->tvnorm = 1; 
        }
        else
        {
           card->tvnorm = 0; 
        }

        memset(v, 0, sizeof(*v));        
        v->tuners=0;
        v->flags = 0;
        v->type = VIDEO_TYPE_CAMERA;
        v->norm = card->tvnorm;
        v->channel = 0;
        strcpy(v->name, "composite");
        
        return 0;
      }
      
      case VIDIOCSCHAN:
       {
       struct video_channel *v = arg;
       unsigned int channel = v->channel;
       dprintk(2,"card(%d) VIDIOCSCHAN called\n",card->cardnum);
  
       if (channel >= generic_tvcards[card->type].video_inputs)
               return -EINVAL;
       if (v->norm != card->tvnorm)
               return -EINVAL;            
               
       down_interruptible(&card->lock);
       set_tvnorm(card, v->norm);
       set_input(card,v->channel+1);
       up(&card->lock);
       return 0;
       }
      
      case VIDIOCGAUDIO:
       {
          dprintk(2,"card(%d) VIDIOCGAUDIO called\n",card->cardnum);
          return -EINVAL;
        }
      
      case VIDIOCSAUDIO:
      {
          struct video_audio *v = arg;
          unsigned int audio = v->audio;

          dprintk(2,"card(%d) VIDIOCSAUDIO called %d flags %d mode %d\n",card->cardnum,audio, v->flags,v->mode);
          return -EINVAL;
     }  
     case VIDIOCKEY:
       dprintk(2,"card(%d) VIDIOCKEY called\n",card->cardnum);
       return 0;
    
    
    case VIDIOC_QUERYCAP:
     {
      struct v4l2_capability *cap = arg;
      if (disablev4l2 == 1)
        return -EINVAL;
      dprintk(2,"card(%d) VIDIOC_QUERYCAP called\n",card->cardnum);
      memset(cap,0,sizeof(*cap));
      
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
      strncpy(cap->card,card->video_dev.name,sizeof(cap->card));
      
#else
      strncpy(cap->card,card->video_dev->name,sizeof(cap->card));
      
#endif
      cap->version = GENERIC_VERSION_CODE;
      cap->capabilities =  V4L2_CAP_VIDEO_CAPTURE |
                           
                           
                           
                           V4L2_CAP_STREAMING |
                           V4L2_CAP_READWRITE;
      return 0;
     }
    
    case VIDIOC_ENUM_FMT:
     {
      struct v4l2_fmtdesc *f = arg;
      enum v4l2_buf_type type;
      unsigned int i;
      int index;

      dprintk(2,"card(%d) VIDIOC_ENUM_FMT called\n",card->cardnum);
      type  = f->type;

      
      index = -1;
      for (i = 0; i < GENERIC_FORMATS; i++) 
      {
        if (generic_formats[i].fourcc != -1)
          index++;
        if ((unsigned int)index == f->index)
          break;
      }
      if (i == GENERIC_FORMATS)
      {
        return -EINVAL;
      }

      switch (f->type) 
      {
        case V4L2_BUF_TYPE_VIDEO_CAPTURE:
          break;
        default:
          dprintk(2,"f->type error\n");
          return -EINVAL;
      }
      memset(f,0,sizeof(*f));
      f->index       = index;
      f->type        = type;
      f->pixelformat = generic_formats[format].fourcc;
      strncpy(f->description,generic_formats[format].name,sizeof(f->description));
      return 0;
     }
    
    case VIDIOC_TRY_FMT:
     dprintk(2,"card(%d) VIDIOC_TRY_FMT called\n",card->cardnum);
     
     
     {
      struct v4l2_format *f = arg;
      u32 dwBytesperline;
      dprintk(2,"card(%d) vcap in VIDIOC_TRY_FMT x %d y %d fmt 0x%x\n",
        card->cardnum,f->fmt.pix.width, f->fmt.pix.height, f->fmt.pix.pixelformat);      
      switch (f->type)
      {
        case V4L2_BUF_TYPE_VIDEO_CAPTURE:
          
          if(f->fmt.pix.pixelformat != generic_formats[format].fourcc)
          {
              dprintk(2,"f->fmt.pix.pixelformat = 0x%x not support \n",f->fmt.pix.pixelformat);
              return -EINVAL;
          }
             
          dprintk(2,"card(%d) V4L2_BUF_TYPE_VIDEO_CAPTURE x %d y %d fmt 0x%x\n",card->cardnum,f->fmt.pix.width, f->fmt.pix.height, f->fmt.pix.pixelformat);

          if (f->fmt.pix.width != card->width ||
            f->fmt.pix.height != card->height)
          {
             if (f->fmt.pix.width > generic_tvnorms[card->tvnorm].swidth)
               f->fmt.pix.width = generic_tvnorms[card->tvnorm].swidth;
            
             if (f->fmt.pix.height > generic_tvnorms[card->tvnorm].sheight)
               f->fmt.pix.height = generic_tvnorms[card->tvnorm].sheight;
          
             dwBytesperline = ALIGN_TO_8(f->fmt.pix.width*(generic_formats[format].depth/8));
             f->fmt.pix.bytesperline = dwBytesperline;
             f->fmt.pix.sizeimage = ALIGN_TO_PAGE(dwBytesperline * f->fmt.pix.height);  
          }
          else
          {
            f->fmt.pix.sizeimage = card->fbmallocsize;  
            f->fmt.pix.bytesperline = card->dwCapSrcPitch;   
          }
          return 0;
          break;
    default:
      dprintk(3,"input type error \n");
      return -EINVAL;
      }

      return 0;
     }     
    
    case VIDIOC_G_FMT:
     {
      struct v4l2_format *f = arg;
      dprintk(2,"card(%d) VIDIOC_G_FMT called\n",card->cardnum);
      return generic_g_fmt(fh,f);
     }
    
    case VIDIOC_S_FMT:
     {
      struct v4l2_format *f = arg;
      dprintk(2,"card(%d) VIDIOC_S_FMT called\n",card->cardnum);
      switch (f->type)
      {
        case V4L2_BUF_TYPE_VIDEO_CAPTURE:
          
          if(f->fmt.pix.pixelformat != generic_formats[format].fourcc)
          {
              dprintk(2,"f->fmt.pix.pixelformat = 0x%x not support \n",f->fmt.pix.pixelformat);
              return -EINVAL;
          }
     
          dprintk(2,"card->tvnorm=%d, card->type=%d\n",card->tvnorm,card->type);
          dprintk(2,"card(%d) vcap in VIDIOC_S_FMT x %d y %d fmt %d\n",card->cardnum,f->fmt.pix.width, f->fmt.pix.height, f->fmt.pix.pixelformat);

          if (f->fmt.pix.width != card->width ||
            f->fmt.pix.height != card->height)
          {
             if (f->fmt.pix.width > generic_tvnorms[card->tvnorm].swidth)
               f->fmt.pix.width = generic_tvnorms[card->tvnorm].swidth;
           
             if (f->fmt.pix.height > generic_tvnorms[card->tvnorm].sheight)
               f->fmt.pix.height = generic_tvnorms[card->tvnorm].sheight;
            
             card->width = f->fmt.pix.width;
             card->height = f->fmt.pix.height;
             card->dwCapSrcPitch = ALIGN_TO_8(f->fmt.pix.width*(generic_formats[format].depth / 8));
             if (card->driver_data & RDC_CAP_M2012) 
             {
                if(format == RGB24)       
                  card->dwCapSrcHWPitch = f->fmt.pix.width*4; 
                else
                  card->dwCapSrcHWPitch = ALIGN_TO_8(f->fmt.pix.width*(generic_formats[format].depth / 8));

                
                if (card->vpost_color_convert)
                  card->dwVPostCapSrcHWPitch = ALIGN_TO_8(f->fmt.pix.width*(generic_formats[YUY2].depth / 8));
             }
             
             card->fbmallocsize = ALIGN_TO_PAGE(card->dwCapSrcPitch * f->fmt.pix.height);  
             f->fmt.pix.sizeimage = card->fbmallocsize;
             dprintk(2,"set size to x %d y %d\n",card->width,card->height);
             
             
             if (card->status & STATUS_CAPTURING)
             {
               
               
               generic_disable_capture(card);
               generic_enable_capture(card);
             }
             
          }
          f->fmt.pix.sizeimage = card->fbmallocsize;
          f->fmt.pix.bytesperline = card->dwCapSrcPitch;          
          
          
          return 0;
          break;
     case V4L2_BUF_TYPE_VBI_CAPTURE:
       dprintk(3,"card(%d) V4L2_BUF_TYPE_VBI_CAPTURE called\n",card->cardnum);
       
        
    default:
      return -EINVAL;
      }

      return 0;
     }
    
    case VIDIOC_G_FBUF:
     {
      struct v4l2_framebuffer *fb = arg;

      dprintk(2,"card(%d) VIDIOC_G_FBUF called\n",card->cardnum);
      memset(fb,0,sizeof(*fb));
      fb->base       = (void*)card->dwFBPhysicalAddress;
      fb->fmt.width  = 800;
      fb->fmt.height = 2047;      
      fb->fmt.bytesperline = 800*4;
      fb->capability = V4L2_FBUF_CAP_CHROMAKEY;
      fb->fmt.pixelformat  = generic_formats[format].fourcc;
      return 0;

     }
    
    case VIDIOC_S_FBUF:
     {
       
       dprintk(2,"card(%d) VIDIOC_S_FBUF called\n",card->cardnum);
       
       return 0;
       
     }
    
    case VIDIOC_REQBUFS: 
      {
      struct v4l2_requestbuffers *req = arg;
      dprintk(2,"card(%d) VIDIOC_REQBUFS called\n",card->cardnum);
      if (req->memory != V4L2_MEMORY_MMAP)
      {
         dprintk(2,"VIDIOC_REQBUFS ERROR 1\n");
         return -EINVAL;
      }
      if (req->type != V4L2_BUF_TYPE_VIDEO_CAPTURE)
      {
         dprintk(2,"VIDIOC_REQBUFS ERROR 2\n");
         return -EINVAL;
      }
      if (req->count < 1)
      {
         dprintk(2,"VIDIOC_REQBUFS ERROR 3\n");
         return -EINVAL;
      }
        
        card->v4lmmaptype = 1;
        init_frame_queue(&card->frame_queue);
        req->count = VIDEO_MAX_FRAMES;
        return 0; 
      }
    
    case VIDIOC_QUERYMENU:
      dprintk(1, "card(%d) VIDIOC_QUERYMENU called (not done)\n",card->cardnum);
      return -EINVAL;
    
    case VIDIOC_QUERYBUF:
      {
      struct v4l2_buffer *b = arg;

      dprintk(2,"card(%d) VIDIOC_QUERYBUF\n",card->cardnum);
      if (b->memory != V4L2_MEMORY_MMAP)
      {
        dprintk(2,"VIDIOC_QUERYBUF ERROR 1\n");
        return -EINVAL;
      }
      if (b->type != V4L2_BUF_TYPE_VIDEO_CAPTURE)
      {
        dprintk(2,"VIDIOC_QUERYBUF ERROR 2\n");
        return -EINVAL;
      }
      if ((b->index < 0) || (b->index >= VIDEO_MAX_FRAMES))
        return -EINVAL;
      
      down_interruptible(&fh->cap.lock);
      b->flags = V4L2_BUF_FLAG_MAPPED | V4L2_BUF_FLAG_DONE;
      b->bytesused = card->fbmallocsize;
      b->memory = V4L2_MEMORY_MMAP;
      b->m.offset = 0; 
      b->length = card->fbmallocsize;
      card->frame = b->index; 
      
      if(!disabledma)
          bSetDMADes(card,card->frame,card->frame);
      
      up(&fh->cap.lock);
     
      return 0;
      }
    
    case VIDIOC_QBUF:
      {
        struct v4l2_buffer *b = arg;
        dprintk(2,"card(%d) VIDIOC_QBUF called\n",card->cardnum);
        if (b->type != V4L2_BUF_TYPE_VIDEO_CAPTURE)
        {
          dprintk(2,"VIDIOC_QBUF error 1\n");
          return -EINVAL;
        }
        if (b->index < 0 || b->index >= VIDEO_MAX_FRAMES)
        {
          dprintk(2,"VIDIOC_QBUF error 2\n");
          return -EINVAL;
        }
        add_frame_to_queue(&card->frame_queue,b->index);
        return 0;
      }
    
    case VIDIOC_DQBUF:
      {
       struct v4l2_buffer *b = arg;
       u32 dwBufNum;
       dprintk(2,"card(%d) VIDIOC_DQBUF called\n",card->cardnum);
       if (b->type != V4L2_BUF_TYPE_VIDEO_CAPTURE)
       {
         dprintk(2,"VIDIOC_DQBUF error 1\n");
         return -EINVAL;
       }
      
       if (!(fh->resources & STATUS_CAPTURING))
       {
         dprintk(2,"VIDIOC_DQBUF not in cap\n");
         return -EINVAL;
       }

       down_interruptible(&fh->cap.lock);

       card->frame = remove_frame_from_queue(&card->frame_queue);
       dwBufNum = card->frame;
      
       if (card->frame < 0)
       {
         if (file->f_flags & O_NONBLOCK)
         {
           if (fh->resources & STATUS_CAPTURING)
           {
             dprintk(1,"VIDIOC_DQBUF should do something here cause we ran out of buffers and we are still capturing\n");
           }
           dprintk(2,"VIDIOC_DQBUF error 2\n");
           return -EAGAIN;
         }
         if (fh->resources & STATUS_CAPTURING)
         {
           
           card->frame = 0;
         } 
         else 
         {
           
           dprintk(2,"VIDIOC_DQBUF error 3\n");
           return -EAGAIN;
         }
      }
      
      do_gettimeofday(&b->timestamp);
      card->dwPOLLCount = card->field_count;
      
      grab_frame(card);
            
      if (fh->resources & STATUS_CAPTURING)
      {
        b->flags = V4L2_BUF_FLAG_MAPPED | V4L2_BUF_FLAG_DONE;
        b->bytesused = card->fbmallocsize;
        b->memory = V4L2_MEMORY_MMAP;
        b->m.offset = 0; 
        b->length = card->fbmallocsize;
        b->index = dwBufNum;
        b->sequence = card->dwPOLLCount;
      }
      else
      {
        b->flags = 0;
        b->bytesused = 0;
        b->memory = 0;
        b->m.offset = 0; 
        b->length = 0;
        b->index = 0;
        b->sequence = 0;
      }
 
      
      up(&fh->cap.lock);

      return 0;
      }
    
    case VIDIOC_STREAMON:
        dprintk(2,"card(%d) VIDIOC_STREAMON called\n",card->cardnum);
       
      if (!(fh->resources & STATUS_CAPTURING))
      {
        if (card->status & STATUS_CAPTURING)
        {
           return -EBUSY;
        } 
        else 
        {
           fh->resources = STATUS_CAPTURING;
           generic_enable_capture(card);
        }
      }
      else
        return -EBUSY;
        
      return 0;
    
    case VIDIOC_STREAMOFF:
        dprintk(2,"card(%d) VIDIOC_STREAMOFF called\n",card->cardnum);
        
        if (fh->resources & STATUS_CAPTURING)
        {
           fh->resources &= ~STATUS_CAPTURING;
           generic_disable_capture(card);
        }
        return 0;
         
    
    case VIDIOC_QUERYCTRL:
     {
      struct v4l2_queryctrl *c = arg;
      int i;

      dprintk(2,"card(%d) VIDIOC_QUERYCTRL called\n",card->cardnum);
      if (c->id <  V4L2_CID_BASE || c->id >= V4L2_CID_LASTP1)
        return -EINVAL;

      
      for (i = 0; i < GENERIC_CTLS; i++)
        if (generic_ctls[i].id == c->id)
          break; 

      if (i == GENERIC_CTLS) 
      {
         *c = no_ctl;
         
         return 0;
      }
      *c = generic_ctls[i];
      return 0;
     }
    
    case VIDIOC_G_CTRL:
      dprintk(2,"card(%d) VIDIOC_G_CTRL called\n",card->cardnum);
      return get_control(card,arg);
      
    
    case VIDIOC_S_CTRL:
      dprintk(2,"card(%d) VIDIOC_S_CTRL called\n",card->cardnum);
      return set_control(card,arg);
      
    
    case VIDIOC_G_PARM:
     dprintk(2,"card(%d) VIDIOC_G_PARM called\n",card->cardnum);
     {
      struct v4l2_streamparm *parm = arg;
      struct v4l2_standard s;
      if (parm->type != V4L2_BUF_TYPE_VIDEO_CAPTURE)
              return -EINVAL;
      memset(parm,0,sizeof(*parm));
      if (card->tvnorm >= GENERIC_TVNORMS){
        card->tvnorm = 0;
      }
      v4l2_video_std_const(&s, generic_tvnorms[card->tvnorm].v4l2_id,
                               generic_tvnorms[card->tvnorm].name);
      parm->parm.capture.timeperframe = s.frameperiod;
      return 0;
     }
     
    
    case VIDIOC_S_PARM:
     {
      
      dprintk(2,"card(%d) VIDIOC_S_PARM called (not done)\n",card->cardnum);
      return -EINVAL;
     }
     
    
    case VIDIOC_CROPCAP:
     dprintk(2,"card(%d) VIDIOC_CROPCAP (not done)\n",card->cardnum);
     
     {
       struct v4l2_cropcap *cap = arg;
       
       switch(cap->type)
       {
         case V4L2_BUF_TYPE_VIDEO_CAPTURE:
           break;
         default:
           return -EINVAL;
       }
       
       cap->bounds.left = 0;
       cap->bounds.top = 0;
       cap->bounds.width = 720;
       cap->bounds.height = 480;
       
       cap->defrect.left = 0;
       cap->defrect.top = 0;
       cap->defrect.width = 720;
       cap->defrect.height = 480;
       
       cap->pixelaspect.numerator = 11;
       cap->pixelaspect.denominator = 10;
       
       return 0;
     }
     break;
    
    case VIDIOC_G_CROP:
     {
      dprintk(2,"card(%d) VIDIOC_G_CROP (not done)\n",card->cardnum);
      return -EINVAL;
     }
    
    case VIDIOC_S_CROP:
     {
      dprintk(2,"card(%d) VIDIOC_S_CROP (not done)\n",card->cardnum);
      return -EINVAL;
     }

    
    case VIDIOC_ENUMSTD:
     {
      struct v4l2_standard *e = arg;
      unsigned int index = e->index;
      dprintk(2,"card(%d) VIDIOC_ENUMSTD called\n",card->cardnum);
      
      if (index >= GENERIC_TVNORMS)
      { 
        dprintk(2,"if (index >= GENERIC_TVNORMS) \n");
        return -EINVAL;
      }
      v4l2_video_std_const(e, generic_tvnorms[e->index].v4l2_id,
             generic_tvnorms[e->index].name);
      e->index = index;
      return 0;
     }
     
     
     case VIDIOC_G_STD:
     {
      v4l2_std_id *id = arg;
      *id = generic_tvnorms[card->tvnorm].v4l2_id;
      dprintk(2,"card(%d) VIDIOC_G_STD called\n",card->cardnum);
      return 0;
     }
     
     case VIDIOC_S_STD:
     {
      v4l2_std_id *id = arg;

      dprintk(2,"card(%d) VIDIOC_S_STD called\n",card->cardnum);
                  
      if (*id != generic_tvnorms[card->tvnorm].v4l2_id)
           return -EINVAL;


      down_interruptible(&card->lock);
      set_tvnorm(card,card->tvnorm);
      up(&card->lock);
      return 0;
     }
     
     
     case VIDIOC_ENUMINPUT:
      {
       struct v4l2_input *i = arg;
       unsigned int n;

       dprintk(2,"card(%d) VIDIOC_ENUMINPUT i->index= %d called\n",card->cardnum,i->index);
       n = i->index;
       if (n >= generic_tvcards[card->type].video_inputs)
       {
         
         return -EINVAL;
       }

       i->index    = n;
       i->type     = V4L2_INPUT_TYPE_CAMERA;
       i->audioset = 0;
       i->tuner = 0;
       i->status = 0;
       
       for (n = 0; n < GENERIC_TVNORMS; n++)
       {
         i->std |= generic_tvnorms[n].v4l2_id;
         strncpy(i->name,"Composite",sizeof("Composite"));
       }
       
       return 0;
      }
     
     case VIDIOC_G_INPUT:
      {
       int *i = arg;
       dprintk(2,"card(%d) VIDIOC_G_INPUT called\n",card->cardnum);
       *i = card->mux - 1;
       return 0;
      }
      
     
     case VIDIOC_S_INPUT:
      {
       unsigned int *i = arg;

       dprintk(2,"card(%d) VIDIOC_S_INPUT called\n",card->cardnum);
       if (*i > generic_tvcards[card->type].video_inputs)
          return -EINVAL;
       down_interruptible(&card->lock);
       set_input(card,*i+1);
       up(&card->lock);
      dprintk(2,"card(%d) VIDIOC_S_INPUT change input mux to %d\n",card->cardnum, *i);
      return 0;
      }

     default:
       dprintk(2,"ENOIOCTLCMD\n");
       return -ENOIOCTLCMD;
  } 
  return 0;
}
static void mark_pages2(void *res, int order)
{
	struct page *page = virt_to_page(res);
	struct page *last_page = page + (1 << order);
	
	while (page < last_page)
		SetPageReserved(page++);
}

static void unmark_pages2(void *res, int order)
{
	struct page *page = virt_to_page(res);
	struct page *last_page = page + (1 << order);
	while (page < last_page)
		ClearPageReserved(page++);
}
static void mark_pages(void *res, unsigned sz)
{
int pg;
for (pg = 0; PAGE_SIZE * (1 << pg) < sz; pg++);
 mark_pages2(res,pg);
}

static void unmark_pages(void *res, unsigned sz)
{
int pg;
for (pg = 0; PAGE_SIZE * (1 << pg) < sz; pg++);
unmark_pages2(res,pg);

}


int __devinit generic_probe(struct pci_dev *dev,
                                const struct pci_device_id *pci_id)
{
  GENERIC_CARD *card;
  unsigned char lat;
  int refclock;
  struct proc_dir_entry *proc_handler;
  char buf[10];
  int bufsize,i;


  
  if (num_cards_detected == MAX_CARDS)
    return -ENOMEM;

  
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
  printk(KERN_INFO "genericv4l: %s found card #%d.\n", dev->name, num_cards_detected);
#else
  printk(KERN_INFO "genericv4l: %s found card #%d.\n", pci_name(dev), num_cards_detected);
#endif
  
  card=&cards[num_cards_detected];

  memset(card,0,sizeof(*card)); 
  refclock = 0;
  card->cardnum = num_cards_detected;
  card->dev = dev; 

  
  init_MUTEX(&card->lock);
  init_MUTEX(&card->lockcap); 
  spin_lock_init(&card->s_lock);

   
  card->driver_data = pci_id->driver_data;

  if (pci_enable_device(dev) != 0) {
    printk(KERN_WARNING "genericv4l(%d): Can't enable device.\n", num_cards_detected);
    return -EIO;
  }

  
  if (!disabledma) {
    if (pci_set_dma_mask(dev, 0xffffffff) != 0) {
      printk(KERN_WARNING "genericv4l(%d): No suitable DMA available.\n", num_cards_detected);
      return -EIO;
    }
  }

  
  if (!request_mem_region(pci_resource_start(dev,1),
  			  pci_resource_len(dev,1),
  			  tag)) {
    printk(KERN_WARNING "genericv4l(%d): can't lock MMIO register.\n", num_cards_detected);
    
  }

  
  pci_set_master(dev);

  
  pci_set_drvdata(dev,card);

  
  pci_read_config_byte(dev, PCI_CLASS_REVISION, &card->revision);

  
  pci_read_config_byte(dev, PCI_LATENCY_TIMER, &lat);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
  printk(KERN_INFO "genericv4l(%d): rev %d at %s, irq: %d, latency: %d, rdcfb: 0x%lx\n", num_cards_detected, card->revision, dev->slot_name, dev->irq, lat, pci_resource_start(dev,0));
#else
  printk(KERN_INFO "genericv4l(%d): rev %d at %s, irq: %d, latency: %d, rdcfb: 0x%lx\n", num_cards_detected, card->revision, pci_name(dev), dev->irq, lat, (ulong) pci_resource_start(dev,0));
#endif

  printk(KERN_INFO "MMIO at 0x%08lx 0x%08lx\n", (ulong) pci_resource_start(dev, 1), (ulong) pci_resource_end(dev, 1));

   
  
  card->dwFBPhysicalAddress = pci_resource_start(dev, 0);
  card->dwCAPStartOffset = pci_resource_len(dev, 0) - MAX_CAP_RESERVE; 
  card->rdcfb=ioremap((pci_resource_start(dev, 0) + card->dwCAPStartOffset)
                      ,MAX_CAP_RESERVE);     
  card->pjRDC_CAP_START = card->rdcfb;                     
  printk (KERN_INFO "RDC fb vaddr is 0x%p\n", card->pjRDC_CAP_START); 
  printk (KERN_INFO "RDC fb phy-addr is 0x%x\n", (u32)(pci_resource_start(dev, 0) + card->dwCAPStartOffset));
  card->MMR=ioremap_nocache(pci_resource_start(dev, 1),pci_resource_len(dev, 1));
  printk (KERN_INFO "pci_resource_len(dev, 1)= 0x%x\n", (u32)pci_resource_len(dev, 1));  
  printk (KERN_INFO "RDC mmio vaddr is 0x%p\n", card->MMR);  
  card->MEM_0 = 0;  
  card->MEM_1 = 0;  
  


  if(card->driver_data & RDC_CAP_COMM) 
  {
    printk (KERN_INFO "RDC I2C port is 0x%x\n", i2cport);  
    card->bI2C_PORT = i2cport;
    if(rdc_cap_init(card) != 0)
    {
      printk(KERN_ERR "rdc_cap_init failed\n");
      iounmap(card->rdcfb);
      iounmap(card->MMR);
      release_mem_region(pci_resource_start(dev,1),pci_resource_len(dev,1));
      pci_set_drvdata(dev, NULL);
      return -ENODEV;    
    }
  }
  

  
  
  
  
  if (register_irq_handler(card) != 0){
    iounmap(card->rdcfb);
    iounmap(card->MMR);
    release_mem_region(pci_resource_start(dev,1),pci_resource_len(dev,1));
    pci_set_drvdata(dev, NULL);
    return -EIO;
  }

  
  register_video4linux(card);
  
  
  if (tunertype != -1)
  {
    BOOL bSignalStandard;
    
    card->tvnorm = tunertype;
    bSignalStandard = (i2c_readreg8(card, card->bCapChipSlaveAddr, 0x1F) & BIT5);
    if(bSignalStandard)
    {
        card->tvnorm = 1; 
    }
    else
    {
        card->tvnorm = 0; 
    }
    
  }
  set_tvnorm(card, card->tvnorm);
  printk (KERN_INFO "generic_probe: card->tvnorm=%d \n", card->tvnorm);

  
  card->width=generic_tvnorms[card->tvnorm].swidth;
  card->height=generic_tvnorms[card->tvnorm].sheight;
  card->frame=0;
  card->status=0;
  card->v4lmmaptype = 1;
  card->bobmode = bob;
  card->vpost_color_convert = vpost_color_convert;
  
  
  
  
  
  switch(format)
  {
       case RGB32:
        card->dwCapSrcPitch = (ALIGN_TO_8(MAX_CAP_WIDTH*4));
        card->dwCapSrcHWPitch = (ALIGN_TO_8(MAX_CAP_WIDTH*4)); 
        card->fbmallocsize = ALIGN_TO_PAGE(card->dwCapSrcHWPitch * MAX_CAP_HEIGHT);
        card->bRGB32 = 1;
        card->bSingleBufMode = singlebuf;
        break;
       case RGB24:
        card->dwCapSrcPitch = (ALIGN_TO_8(MAX_CAP_WIDTH*3));
        card->dwCapSrcHWPitch = (ALIGN_TO_8(MAX_CAP_WIDTH*4)); 
        card->fbmallocsize = ALIGN_TO_PAGE(card->dwCapSrcHWPitch * MAX_CAP_HEIGHT);
        disabledma = 1;
        card->CapBufIndex = 0;
        card->bRGB32 = 1;
        if (card->driver_data & RDC_CAP_M2010)
           card->bSingleBufMode = 1;
        else
           card->bSingleBufMode = singlebuf;
        break;
       case YUY2:
        card->dwCapSrcPitch = (ALIGN_TO_8(MAX_CAP_WIDTH*2));
        card->dwCapSrcHWPitch = card->dwCapSrcPitch;
        card->fbmallocsize = ALIGN_TO_PAGE(card->dwCapSrcPitch * MAX_CAP_HEIGHT);
        card->bRGB32 = 0;
        card->bSingleBufMode = singlebuf;
        break;
      default:
        card->dwCapSrcPitch = (ALIGN_TO_8(MAX_CAP_WIDTH*4));
        card->dwCapSrcHWPitch = (ALIGN_TO_8(MAX_CAP_WIDTH*4)); 
        card->fbmallocsize = ALIGN_TO_PAGE(card->dwCapSrcHWPitch * MAX_CAP_HEIGHT);
        card->bRGB32 = 1;
        card->bSingleBufMode = singlebuf;
  }

  
  if (card->vpost_color_convert)
    card->dwVPostCapSrcHWPitch = ALIGN_TO_8(MAX_CAP_WIDTH*2);
  
  card->dwMaxBufSize = card->fbmallocsize;
  
  
  bufsize = card->dwMaxBufSize;
  
    
  for(i=0;i<VIDEO_MAX_FRAMES;i++)
  {
    printk (KERN_INFO "1.card->buffer[%d] = %d\n", i, card->buffer[i]);
    card->buffer[i] = card->buffer[i] + (bufsize * i);
    printk (KERN_INFO "2.card->buffer[%d] = %d\n", i, card->buffer[i]);
  }

  if (card->vpost_color_convert)
  {
      
      card->VPostOutBuf = card->buffer[VIDEO_MAX_FRAMES-1] + bufsize;
      printk (KERN_INFO "card->VPostOutBuf = %d\n", card->VPostOutBuf);
  }

  
  
  if (!disabledma)
  {
    if(bInitDMA(card)==FALSE)
    {
      iounmap(card->rdcfb);
      iounmap(card->MMR);
      release_mem_region(pci_resource_start(dev,1),pci_resource_len(dev,1));
      pci_set_drvdata(dev, NULL);
      return -ENOMEM;    
    }
  } 
  else 
  {  
      for(i=0;i<VIDEO_MAX_FRAMES;i++)
        card->framebuffer[i] = kmalloc(bufsize,GFP_KERNEL);
    
    printk (KERN_INFO "framebuffer0 is 0x%p\n", card->framebuffer[0]);
    printk (KERN_INFO "framebuffer1 is 0x%p\n", card->framebuffer[1]);
    printk (KERN_INFO "framebuffer2 is 0x%p\n", card->framebuffer[2]);
  }
  
  
  sprintf (buf,"%d",card->cardnum);
  proc_handler = create_proc_entry(buf, 0666, proc_dir);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 32)
  proc_handler->owner = THIS_MODULE;
#endif
  proc_handler->read_proc = proc_read;
  proc_handler->write_proc = proc_write;
  proc_handler->data = card;

  num_cards_detected++;
  return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,5,0)
static struct video_device *vdev_init(GENERIC_CARD *card,
                                      struct video_device *template,
                                      char *type)
{
        struct video_device *vfd;

        vfd = video_device_alloc();
        if (vfd == NULL)
        {
                printk(KERN_INFO "vdev_init: video_device_alloc() fail \n");
                return NULL;
        }
        *vfd = *template;
        vfd->minor   = -1;
        
        vfd->release = video_device_release;
        snprintf (vfd->name, sizeof(vfd->name),
        "rdc v4l rev %d",card->revision);
    
        return vfd;
}
#endif

int __devinit register_video4linux(GENERIC_CARD *card)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)

  printk(KERN_INFO "register_video4linux: LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)\n");
  
  memcpy(&card->video_dev, &generic_video_template, sizeof(generic_video_template));

  
  card->video_dev.priv = card;

  
  snprintf (card->video_dev.name, sizeof(card->video_dev.name),
        "RDCv4l rev %d",card->revision);

  
  if (video_register_device(&card->video_dev,VFL_TYPE_GRABBER, -1) < 0)
  {
    printk(KERN_INFO "register_video4linux: video_register_device fail\n");
    return -1;
  }
  printk(KERN_INFO "genericv4l(%d): registered device /dev/video%d\n",
                 card->cardnum,card->video_dev.minor & 0x1f);
  
#else
  printk(KERN_INFO "register_video4linux: LINUX_VERSION_CODE >= KERNEL_VERSION(2,5,0)\n");
  card->video_dev = vdev_init(card, &generic_video_template, "video");
  if (card->video_dev == NULL) {
    return -1;
  }

  
  if (video_register_device(card->video_dev,VFL_TYPE_GRABBER, -1) < 0)
    return -1;

  printk(KERN_INFO "genericv4l(%d): registered device /dev/video%d\n",
                 card->cardnum,card->video_dev->minor & 0x1f);
#endif
  return 0;
}



#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
void generic_irq_handler(int irq, void *dev_id, struct pt_regs * regs)
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,20)
static irqreturn_t generic_irq_handler(int irq, void *dev_id, struct pt_regs * regs)
#else 
static irqreturn_t generic_irq_handler(int irq, void *dev_id)
#endif
#endif
{
  GENERIC_CARD *card = (GENERIC_CARD *)dev_id;
  int handled = 0;
  u32   ulStatus=0,ulIntEnStatus=0;
  u8   *pjMMIO = card->MMR;

  if (card->driver_data & RDC_CAP_COMM)
  {
    ulStatus = *(u32 volatile *)(pjMMIO + INT_STATES);
    ulIntEnStatus = *(u32 volatile *)(pjMMIO + INT_ENABLE);
    
    if ((ulIntEnStatus & INT_ENABLE_CAP_VIDEO)&&
        (ulStatus & INT_CAPTURE_ACT))
    {
      
      card->field_count++;
      card->status |= STATUS_BUF_READY | STATUS_POLL_READY;
      handled = 1;  
      if(card->bSingleBufMode)
      {
          u32   Startaddress;
          Startaddress = *(u32 volatile *)(pjMMIO + CAP_VIDEO_0_START_ADDRESS) - card->dwCAPStartOffset;
          
          
          *(u32 volatile *)(pjMMIO + CAP_VBI_0_START_ADDRESS) = (CAP_VBI_ENABLE|CAP_VBI_MODE);
      
          if(CAP_IN_BLANKING)
          {
              if(Startaddress == card->buffer[0])
              {
                  card->CapProcIndex = 0;
                  if(card->CapBufIndex != 1)
                  {
                     *(u32 volatile *)(pjMMIO + CAP_VIDEO_0_START_ADDRESS) = card->buffer[1] + card->dwCAPStartOffset;
                     (*(u32 volatile *)(pjMMIO + CAP_INT_Control_and_Flags)) = CAP_END_OF_ACTIVE;
                  }
              }
              else if(Startaddress == card->buffer[1])
              {
                  card->CapProcIndex = 1;
                  if(card->CapBufIndex != 2)
                  {
                     *(u32 volatile *)(pjMMIO + CAP_VIDEO_0_START_ADDRESS) = card->buffer[2] + card->dwCAPStartOffset;
                     (*(u32 volatile *)(pjMMIO + CAP_INT_Control_and_Flags)) = CAP_END_OF_ACTIVE;
                  }
              }
              else
              {
                  card->CapProcIndex = 2;
                  if(card->CapBufIndex != 0)
                  {
                     *(u32 volatile *)(pjMMIO + CAP_VIDEO_0_START_ADDRESS) = card->buffer[0] + card->dwCAPStartOffset;
                     (*(u32 volatile *)(pjMMIO + CAP_INT_Control_and_Flags)) = CAP_END_OF_ACTIVE;
                  }
              }
          }
          
          
      }

      *(u32 volatile *)(pjMMIO + INT_STATES) = INT_CAPTURE_ACT;
    }
    
    if ((ulIntEnStatus & INT_ENABLE_DMA)&&
        (ulStatus & INT_DMA))
    {
      card->status |= STATUS_DMABUF_READY;
      handled = 1;     
      *(u32 volatile *)(pjMMIO + INT_STATES) = INT_DMA;
    }  
  
    if(handled) 
      tasklet_schedule(&generic_tasklet);
  }

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,5,0)
  return IRQ_RETVAL(handled);
#endif
}


int register_irq_handler(GENERIC_CARD *card)
{
  switch ((request_irq(card->dev->irq, generic_irq_handler, IRQF_SHARED, tag, (void *)card))){
    case -EINVAL: 
      printk(KERN_ERR "genericv4l(%d): bad irq number or handler\n",card->cardnum);
      break;
    case -EBUSY: 
      printk(KERN_ERR "genericv4l(%d): IRQ %d busy\n", card->cardnum, card->dev->irq);
      break;
    case 0: 
      printk(KERN_INFO"genericv4l(%d): IRQ %d SUCCESS\n", card->cardnum, card->dev->irq);
      return 0;
    default: printk(KERN_ERR "genericv4l(%d): could not install irq handler\n", card->cardnum);
  }
  printk(KERN_ERR " Could not install irq handler...\n");
  printk(KERN_ERR " Perhaps you need to let your BIOS assign an IRQ to your video card\n");
  printk(KERN_ERR " Some ATI cards have a jumper that needs to be set for the card to get an IRQ\n");
  return -1;
}

static int generic_init_module(void) {
  int i,retval;

  printk(KERN_INFO "genericv4l: driver version %d.%d.%d loaded\n",
    (GENERIC_VERSION_CODE >> 16) & 0xff,
    (GENERIC_VERSION_CODE >> 8) & 0xff,
     GENERIC_VERSION_CODE & 0xff);

  
  num_cards_detected = 0;

  if (disableinterlace){
    for (i = 0; i < GENERIC_TVNORMS; i++){
      generic_tvnorms[i].sheight /= 2;
    }
  }
  if (halfwidth){
    for (i = 0; i < GENERIC_TVNORMS; i++){
      generic_tvnorms[i].swidth /= 2;
    }
  }
  
  proc_dir = proc_mkdir("RDC_v4l", NULL);
  if (!proc_dir) {
    return -ENOMEM; 
  }  
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 32)
  proc_dir->owner = THIS_MODULE;
#endif

  
  retval = pci_register_driver(&generic_pci_driver);

  
  tasklet_enable(&generic_tasklet);

  return retval;
}

void __devexit generic_remove(struct pci_dev *pci_dev)
{
  GENERIC_CARD *card = pci_get_drvdata(pci_dev);
  char buf[10];
  int i;

  printk("genericv4l(%d): unloading\n",card->cardnum);  

  
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,5,0)
  if (card->video_dev.minor!=-1)
          video_unregister_device(&card->video_dev);
#else
  if (card->video_dev->minor!=-1)
          video_unregister_device(card->video_dev);
#endif

  
  free_irq(card->dev->irq,card);

  
  iounmap(card->rdcfb);
  iounmap(card->MMR);

  
  release_mem_region(pci_resource_start(pci_dev,1),pci_resource_len(pci_dev,1));

  
  pci_set_drvdata(pci_dev, NULL);


  
  if (!disabledma)
  {
    
    for(i=0;i<VIDEO_MAX_FRAMES;i++)
    {
      if (card->framebuffer[i] != NULL)  unmark_pages(card->framebuffer[i],card->fbmallocsize);
        pci_free_consistent(pci_dev,card->fbmallocsize,card->framebuffer[i],card->dmabuf[i]);
    }

    for(i=0;i<VIDEO_MAX_FRAMES;i++)
    {
      if (card->DMAInfo[i].pDMADescriptorBase != NULL)  
        unmark_pages((void*)card->DMAInfo[i].pDMADescriptorBase,card->DMAInfo[i].dwCount<<4);
      pci_free_consistent(pci_dev,
                          card->DMAInfo[i].dwCount<<4,
                          (u8*)card->DMAInfo[i].pDMADescriptorBase,
                          card->DMAInfo[i].PhyAddress);        
    }



  }
  else
  {
      for(i=0;i<VIDEO_MAX_FRAMES;i++)
        kfree(card->framebuffer[i]);
  }

  
  sprintf (buf, "%d", card->cardnum);
  remove_proc_entry(buf, proc_dir);
}

static void generic_cleanup_module(void)
{
  
  tasklet_disable(&generic_tasklet);

  
  pci_unregister_driver(&generic_pci_driver);

  remove_proc_entry("genericv4l", NULL);
  return;
}

BOOL bInitDMA(GENERIC_CARD *card)
{
    struct pci_dev *dev;
    DMAINFO *pDMAInfoTmp;
    u32 dwDMARingSize;
    u32 i,j;
    u8* pjMMIO;
    BOOL bAllocFail=FALSE;
    DMADescriptor *pDMADescriptor;
    
    dev = card->dev;
    dwDMARingSize = ALIGN_TO_PAGE(DMADescSize);
    pjMMIO = card->MMR;
    for(j=0;j<VIDEO_MAX_FRAMES;j++)
    {
      card->framebuffer[j] = pci_alloc_consistent(dev,card->dwMaxBufSize,&card->dmabuf[j]);
      if (card->framebuffer[j] != NULL)  
        mark_pages(card->framebuffer[j],card->fbmallocsize);
      else
      {
          bAllocFail= TRUE;
          goto bInitDMAFAIL;
      }
      
      pDMAInfoTmp = &card->DMAInfo[j];
      pDMAInfoTmp->pDMADescriptorBase = 
                   (DMADescriptor *)pci_alloc_consistent(dev,dwDMARingSize,&pDMAInfoTmp->PhyAddress);
      if(pDMAInfoTmp->pDMADescriptorBase==NULL)
      {
          bAllocFail= TRUE;
          goto bInitDMAFAIL;
      }
      mark_pages((void*)pDMAInfoTmp->pDMADescriptorBase,dwDMARingSize);
      pDMAInfoTmp->dwCount = dwDMARingSize>>4;
      for(i=0;i<pDMAInfoTmp->dwCount;i++)
      {
          pDMADescriptor = (DMADescriptor*)((pDMAInfoTmp->pDMADescriptorBase )+ i);
  
          if(i != ((pDMAInfoTmp->dwCount)-1))
          {
              pDMADescriptor->DMAControl_FBBase = (u32 volatile )0;
              pDMADescriptor->SMBase            = (u32 volatile )0;
              pDMADescriptor->FID_BC            = (u32 volatile )0;
              pDMADescriptor->NextDescrX        = (u32 volatile )(pDMAInfoTmp->PhyAddress+((i+1)<<4));
          }
          else
          {
              pDMADescriptor->DMAControl_FBBase = (u32 volatile )0;
              pDMADescriptor->SMBase            = (u32 volatile )0;
              pDMADescriptor->FID_BC            = (u32 volatile )0;    
              pDMADescriptor->NextDescrX        = (u32 volatile )pDMAInfoTmp->PhyAddress;
          }        
      }
    }

    

    *(u32 volatile *)(pjMMIO + INT_STATES ) = INT_DMA;   
    *(u32 volatile *)(pjMMIO + INT_ENABLE )= INT_ENABLE_DMA|
                                   (*(u32 volatile *)(pjMMIO + INT_ENABLE ));                             
    *(u32 volatile *)(pjMMIO + DMA_CONTROL) = DMA_ENABLE;
    return TRUE;
    
bInitDMAFAIL:
    if (bAllocFail == TRUE)
    {
       printk("Could not allocate dma buffer\n");
    }
    return FALSE;

}

BOOL bSetDMADes(GENERIC_CARD *card, u32 dwFBSrcId, u32 dwSMDstId)
{
  u32 dwSrc;
  u32 dwDst;
  DMAINFO *pDMAInfoTmp;
  DMADescriptor volatile *pDMADescriptor;
  u32 dwFenceID,i;
  BOOL bUseSingleDes=0;
  u32  dwLastdesc;

  
  pDMAInfoTmp = &card->DMAInfo[dwFBSrcId];
  dwSrc = (u32)card->buffer[dwFBSrcId] + card->dwCAPStartOffset;
  dwDst = (u32)card->dmabuf[dwSMDstId];
  dwFenceID = dwSMDstId;
  dprintk(1,"card->dwCapSrcPitch= %x\n",card->dwCapSrcPitch);
  dprintk(1,"card->dwCapSrcHWPitch= %x\n",card->dwCapSrcHWPitch);	
  pDMADescriptor = pDMAInfoTmp->pDMADescriptorBase;
  if(bUseSingleDes)
  {
    pDMADescriptor->DMAControl_FBBase = (u32 volatile) (dwSrc         |
                                                        FBtoSM        |
                                                        DMA_INT_ENABLE|
                                                        DMA_END);
    pDMADescriptor->SMBase = (u32 volatile) dwDst;
    pDMADescriptor->FID_BC = (u32 volatile) (card->fbmallocsize|
                                             DescriptorValid   |
                                             (dwFenceID<<DMA_FenceID_BITSHIFT));  
  }
  else
  {
    dwLastdesc = (u32)card->height - 1;
    if(dwLastdesc > (DMADescSize/16))
    {
      printk(KERN_INFO "genericv4l: bSetDMADes SIZE ERROR\n");
      return FALSE;
    }
    if(card->dwCapSrcPitch <= card->dwCapSrcHWPitch)
    {
      for(i=0;i<dwLastdesc;i++)
      {
        pDMADescriptor->DMAControl_FBBase = (u32 volatile) (dwSrc | FBtoSM );
        pDMADescriptor->SMBase = (u32 volatile) dwDst;
        pDMADescriptor->FID_BC = (u32 volatile) (card->dwCapSrcPitch|
                                                 DescriptorValid   |
                                                 (dwFenceID<<DMA_FenceID_BITSHIFT));
        if(bob)
        {
            if (i & 0x1)   
                dwSrc += (card->dwCapSrcHWPitch << 1);
        }
        else
        {
            dwSrc += card->dwCapSrcHWPitch;
        }
        dwDst += card->dwCapSrcPitch;
        pDMADescriptor++;
      }
      
      pDMADescriptor->DMAControl_FBBase = (u32 volatile) (dwSrc         |
                                                          FBtoSM        |
                                                          DMA_INT_ENABLE|
                                                          DMA_END);
      pDMADescriptor->SMBase = (u32 volatile) dwDst;
      pDMADescriptor->FID_BC = (u32 volatile) (card->dwCapSrcPitch|
                                               DescriptorValid   |
                                               (dwFenceID<<DMA_FenceID_BITSHIFT));
    }
    else
    {
      for(i=0;i<dwLastdesc;i++)
      {
        pDMADescriptor->DMAControl_FBBase = (u32 volatile) (dwSrc | FBtoSM );
        pDMADescriptor->SMBase = (u32 volatile) dwDst;
        pDMADescriptor->FID_BC = (u32 volatile) (card->dwCapSrcHWPitch|
                                                 DescriptorValid   |
                                                 (dwFenceID<<DMA_FenceID_BITSHIFT));
        if(bob)
        {
            if (i & 0x1)   
                dwSrc += (card->dwCapSrcHWPitch << 1);
        }
        else
        {
            dwSrc += card->dwCapSrcHWPitch;
        }
        dwDst += card->dwCapSrcPitch;
        pDMADescriptor++;
      }
      
      pDMADescriptor->DMAControl_FBBase = (u32 volatile) (dwSrc         |
                                                          FBtoSM        |
                                                          DMA_INT_ENABLE|
                                                          DMA_END);
      pDMADescriptor->SMBase = (u32 volatile) dwDst;
      pDMADescriptor->FID_BC = (u32 volatile) (card->dwCapSrcHWPitch|
                                               DescriptorValid   |
                                               (dwFenceID<<DMA_FenceID_BITSHIFT));    
    }
    
  }
  return TRUE;
}
BOOL bFireDMA(GENERIC_CARD *card)
{
    DMAINFO *pDMAInfoTmp;
    u8  *pjMMIO;
    pjMMIO = card->MMR;
    
    
    do{
        if((*(u32 volatile *)(pjMMIO + DMA_STATUS_AND_INTERRUPT))&DMA_IDLE)
            break;
    }while(TRUE);
 

    pDMAInfoTmp = &card->DMAInfo[card->CapBufIndex];

    *(u32 volatile *)(pjMMIO + DMA_DESCRIPTION_START_ADDRESS) = (u32)pDMAInfoTmp->PhyAddress;
    *(u32 volatile *)(pjMMIO + DMA_CONTROL) = DMA_ENABLE|DMA_FIRE;
    dprintk(3,"Fire DMA\n");
    return TRUE;

}




void CovertYUY2ToRGB32UsingVPost(GENERIC_CARD *card)
{
    u8 volatile *pjSrc, *pjSrcPhy;
    u8 volatile *pjDst, *pjDstPhy;
    u8 volatile *pjMMIO;
    u32 dwVPStreamCtrl;
    int iPixelCount;

    dprintk(2,"Enter CovertToRGB32UsingVPost()\n");

    iPixelCount = card->dwCapSrcHWPitch*card->OriHeight;
    dwVPStreamCtrl = card->dwVPStreamCtrl;
    pjMMIO = card->MMR;
      
    pjSrc    = (u8 *)(card->dwCAPStartOffset + card->buffer[card->CapBufIndex]);
    pjDst    = (u8 *)(card->dwCAPStartOffset + card->VPostOutBuf);
    pjSrcPhy = (u8 *)(card->rdcfb + card->buffer[card->CapBufIndex]);
    pjDstPhy = (u8 *)(card->rdcfb + card->VPostOutBuf);

    *(u32 volatile *)(pjMMIO + VP_STREAM_CTL) = dwVPStreamCtrl;
    *(u32 volatile *)(pjMMIO + VP_VIDEO_SIZE) = (card->OriWidth-1)<<16 | (card->OriHeight-1);
    *(u32 volatile *)(pjMMIO + VP_H_SCALE) = 0;
    *(u32 volatile *)(pjMMIO + VP_V_SCALE) = 0;
    *(u32 volatile *)(pjMMIO + VP_CSC_CTL) = VPS_CSC_ENABLE | VPS_RGB32_OUTPUT;
    *(u32 volatile *)(pjMMIO + VP_SW_SRC_BUF_LUMA_START) = pjSrc;
    *(u32 volatile *)(pjMMIO + VP_DEST_STRIDE) = card->dwCapSrcHWPitch;
    *(u32 volatile *)(pjMMIO + VP_SRC_BUF_STRIDE) = card->dwVPostCapSrcHWPitch;
    *(u32 volatile *)(pjMMIO + VP_DEST_FB0) = pjDst;
    *(u32 volatile *)(pjMMIO + VP_SUB_PIC_STRIDE_CONTROL) = 0;
    *(u32 volatile *)(pjMMIO + VP_STREAM_CTL) = dwVPStreamCtrl | VPS_SRC_SW_FLIP;

    
    
    

    while(!(*((u32 volatile *)(pjMMIO+0x624)) & BIT0))
    {}

    memcpy(pjSrcPhy, pjDstPhy, iPixelCount);
    
    dprintk(2,"Exit CovertToRGB32UsingVPost()\n");
}

module_init(generic_init_module);
module_exit(generic_cleanup_module);
