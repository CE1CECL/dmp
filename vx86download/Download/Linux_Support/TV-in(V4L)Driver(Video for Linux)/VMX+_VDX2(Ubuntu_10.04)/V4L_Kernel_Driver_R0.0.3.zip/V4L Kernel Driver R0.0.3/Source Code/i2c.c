/* 
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */




#define __NO_VERSION__

#include <linux/delay.h>

#include "rdcv4l2.h"
#include "i2c.h"
#include "rdcard.h"

static struct i2c_funcs* i2c_getfuncs(void); 



static int rdc_init (GENERIC_CARD *card, u32 *saves) 
{
 u8*      pjCRTAddrPort;
 pjCRTAddrPort = card->MMR + SEQ_INDEX;   
 printk(KERN_INFO "rdc_init called\n");
 
 
 
 
 
 card->bCapChipSlaveAddr = 0x42;
 SetIndexRegData(pjCRTAddrPort, 0x1E, 0xF7, 0);
 
 SetIndexRegData(pjCRTAddrPort, HW_I2C_Control2, 0x0, 0x0);
 vSet7114(card);

 return 0;
}

static void rdc_deinit (GENERIC_CARD *card, u32 *saves) { }

static void rdc_scldir(GENERIC_CARD * card,int set)
{
  I2C_SLEEP;
}

static void rdc_sdadir(GENERIC_CARD * card,int set)
{
  I2C_SLEEP;
}

static void rdc_setsda(GENERIC_CARD * card,int set)
{
    u8*      pjCRTAddrPort;
    u8       ujCRB7, jtemp;
    u32       i;
    u8       data = (u8)set;
    
    pjCRTAddrPort = card->MMR + COLOR_CRTC_INDEX;          
    for (i=0;i<0x1000; i++)
    {        
        ujCRB7 = ((data & 0x01) ? 0:1) << 2;        
        SetIndexRegData(pjCRTAddrPort, card->bI2C_PORT, 0xFB, ujCRB7);
        jtemp = GetIndexRegData(pjCRTAddrPort, card->bI2C_PORT, 0x04);
        if (ujCRB7 == jtemp) break;        
    }

    I2C_SLEEP;
}

static void rdc_setscl(GENERIC_CARD * card,int set)
{
    u8*      pjCRTAddrPort;   
    u8       ujCRB7, jtemp;
    u32       i;
    u8          data = (u8) set;
    
    pjCRTAddrPort = card->MMR + COLOR_CRTC_INDEX;     
    for (i=0;i<0x1000; i++)
    {
        ujCRB7 = ((data & 0x01) ? 0:1); 
        SetIndexRegData(pjCRTAddrPort, card->bI2C_PORT, 0xFE, ujCRB7);
        jtemp = GetIndexRegData(pjCRTAddrPort, card->bI2C_PORT, 0x01);
        if (ujCRB7 == jtemp) break;
    }

    I2C_SLEEP;
}

static int rdc_getscl(GENERIC_CARD *card)
{  
    u8*      pjCRTAddrPort;
    u8       volatile ujCRB7;
          
    pjCRTAddrPort = card->MMR + COLOR_CRTC_INDEX;         
    ujCRB7 = GetIndexRegData(pjCRTAddrPort, card->bI2C_PORT, 0x10) >> 4;
    
    return (int)((ujCRB7 & 0x01) ? 1:0);
}

static int rdc_getsda(GENERIC_CARD *card)
{
    u8*      pjCRTAddrPort;
    u8       volatile ujCRB7;
          
    pjCRTAddrPort = card->MMR + COLOR_CRTC_INDEX;  
    ujCRB7 = GetIndexRegData(pjCRTAddrPort, card->bI2C_PORT, 0x20) >> 5;

    return (int)((ujCRB7 & 0x01) ? 1:0);

}


int i2c_init(GENERIC_CARD *card)
{
  struct i2c_funcs *i2cf;
  int idx;
  u32 saves[4];
  
  i2cf = i2c_getfuncs(); 
  printk(KERN_INFO "i2c function get.\n");
  if (card->driver_data & RDC_CAP_COMM)
  {
    idx = I2C_FUNC_SW;
    card->i2c = &i2cf[idx];
    dprintk(3, "card(%d) Trying %s I2C driver\n",
        card->cardnum,i2cf[idx].name);
        
    card->i2c->init(card,saves);
    return 0;
  }
  return (-ENODEV);
}


void i2c_start(GENERIC_CARD *card)
{
  
  
  card->i2c->setsda(card,1);
  card->i2c->setscl(card,1);
  card->i2c->setsda(card,0);
  card->i2c->setscl(card,0);
}

void i2c_stop(GENERIC_CARD * card)
{
  
  card->i2c->setscl(card,1);
  card->i2c->setsda(card,0);
  card->i2c->setsda(card,1);
  card->i2c->setsda(card,1);
  card->i2c->setscl(card,1);
  
  
}

int i2c_sendbyte(GENERIC_CARD *card, u8 data)
{
  int i;

  for (i=7; i>=0; i--) {
    card->i2c->setscl(card,0);
    card->i2c->setsda(card,(data>>i)&0x1);
    card->i2c->setscl(card,1);
  }

  return 1 ;
}

int i2c_device(GENERIC_CARD * card,u8 addr)
{
  int nack=0 ;

  i2c_start(card);
  nack = i2c_sendbyte(card,addr);
  i2c_stop(card);
  
  dprintk(7, "%s @ %x result %d\n", card->i2c->name, addr, !nack);
  return !nack;
}

u8 i2c_read(GENERIC_CARD *card,u8 addr) 
{
  return 0;
}

u8 i2c_readbyte(GENERIC_CARD *card,int last)
{
  int i,j;
  u8 data=0,bTmp;

  card->i2c->sdadir(card,0) ;
  for (i=7;i>=0;i--) 
  {
    card->i2c->setscl(card,0);
    card->i2c->setsda(card,1);
    card->i2c->setscl(card,1);
    for(j = 0;j < 0x1000;j++)
    {
        if(rdc_getscl(card))
            break;
    }    
    bTmp = card->i2c->getsda(card);
    data |= ((bTmp & 0x1) << i);      
    
    I2C_SLEEP;
    card->i2c->setscl(card,1);
  }
  
  
  
  
  

  return data;
}

u8 i2c_readreg8(GENERIC_CARD *card,u8 addr, u8 reg)
{
    u8 btemp;
    
    
    card->i2c->setscl(card,1);
    card->i2c->setsda(card,1);
    
    i2c_start(card);

    
    i2c_sendbyte(card,addr);
    
    if(!i2c_checkack(card))
    {
        return 0x0;
    }
    
    
    i2c_sendbyte(card,reg);
    if(!i2c_checkack(card))
    {
        return 0x0;
    }

    i2c_start(card);

    
    i2c_sendbyte(card,addr|0x1);
    if(!i2c_checkack(card))
    {
        return 0x0;
    }
    
    btemp = i2c_readbyte(card,1);
    i2c_sendnack(card);

    i2c_stop(card);

    return btemp;
}

int i2c_writereg8(GENERIC_CARD *card,u8 addr, u8 reg, u8 value)
{
  int iRetryTime = 5;
  
  
  card->i2c->setscl(card,1);
  card->i2c->setsda(card,1);
  i2c_start(card);

  
  
  i2c_sendbyte(card,addr);
  
  if(!i2c_checkack(card))
  {
      do
      {
          
          i2c_stop(card);
  
          i2c_start(card);
  
          
          i2c_sendbyte(card,addr);
          if(!i2c_checkack(card))
          {
              iRetryTime--;
          }
          else
          {
              break;
          }
  
      }while(iRetryTime);
  
      if(iRetryTime == 0)
      {
          return FALSE;
      }
  }
  
  
  i2c_sendbyte(card,reg);
  if(!i2c_checkack(card))
  {
      return FALSE;
  }
  
  
  i2c_sendbyte(card,value);
  if(!i2c_checkack(card))
  {
      return FALSE;
  }
  
  i2c_stop(card);

  return TRUE;
}

int i2c_write(GENERIC_CARD *card,u8 addr, u8 *data, int count)
{
  return 0;
}

int i2c_checkack(GENERIC_CARD *card)
{
    u8 btemp;

    
    card->i2c->setscl(card,0);

    
    card->i2c->setsda(card,1);

    
    card->i2c->setscl(card,1);

    btemp = card->i2c->getsda(card);

    if(btemp)
    {
        btemp = FALSE;
    }
    else
    {
        btemp = TRUE;
    }
    
    
    card->i2c->setscl(card,0);

    return btemp;  
}

int i2c_sendnack(GENERIC_CARD *card)
{
    
    card->i2c->setscl(card,0);

    
    card->i2c->setsda(card,1);

    
    card->i2c->setscl(card,1);
    return TRUE;
}



static struct i2c_funcs generic_i2c_driver[] = {
  { "RDC M2010 I2C", &rdc_init, &rdc_deinit,
    &rdc_scldir, &rdc_setscl, &rdc_getscl,
    &rdc_sdadir, &rdc_setsda, &rdc_getsda },    
  { NULL, NULL, NULL, 
    NULL, NULL, NULL, 
    NULL, NULL, NULL} 
};

static struct i2c_funcs *i2c_getfuncs(void) { return generic_i2c_driver; };
