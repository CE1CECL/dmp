/* 
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */


#ifndef GENERIC_RDC_HEADER
#define GENERIC_RDC_HEADER 1


#define CARD_RDC_M2010_CAP 0


#define MAX_CAP_RESERVE 0x700000
#define MAX_CAP_WIDTH   720
#define MAX_CAP_HEIGHT  576


#define CAP_INT_Control_and_Flags   0x100
#define CAP_CONTROL                 0x104
#define CAP_VIDEO_H_RANGE           0x108
#define CAP_VIDEO_V_RANGE           0x10C
#define CAP_VBI_H_RANGE             0x110
#define CAP_VBI_V_RANGE             0x114
#define CAP_ANC_DATA_SETTING        0x118
#define CAP_VIDEO_MAXDATACOUNT      0x11C
#define CAP_VBI_MAXDATACOUNT        0x120
#define CAP_DATACOUNT_STATUS        0x124
#define CAP_VIDEO_0_START_ADDRESS   0x128
#define CAP_VIDEO_1_START_ADDRESS   0x12C
#define CAP_VIDEO_2_START_ADDRESS   0x130
#define CAP_VBI_0_START_ADDRESS     0x134
#define CAP_VBI_1_START_ADDRESS     0x138
#define CAP_VIDEO_AND_VBI_STRIDE    0x13C
#define CAP_CSC_CONTROL1            0x140
#define CAP_CSC_CONTROL2            0x144
#define CAP_CSC_CONTROL3            0x148
#define CAP_MINIFY_CONTROL          0x14c


#define ATTR_ADDR                   0x3C0
#define ATTR_DATA_WRITE             0x3C0
#define ATTR_DATA_READ              0x3C1
#define MISC_WRITE                  0x3C2
#define INPUT_STATUS_0_READ         0x3C2
#define VGA_ENABLE                  0x3C3
#define SEQ_INDEX                   0x3C4
#define SEQ_DATA                    0x3C5
#define PEL_MASK                    0x3C6
#define DAC_INDEX_READ              0x3C7
#define DAC_INDEX_WRITE             0x3C8
#define DAC_DATA                    0x3C9
#define FEAT_CTRL_READ              0x3CA
#define MISC_READ                   0x3CC
#define GRAPH_INDEX                 0x3CE
#define GRAPH_DATA                  0x3CF

#define MONO_CRTC_INDEX             0x3B4
#define MONO_CRTC_DATA              0x3B5
#define MONO_INPUT_STATUS1_READ     0x3BA

#define COLOR_CRTC_INDEX            0x3D4
#define COLOR_CRTC_DATA             0x3D5
#define COLOR_INPUT_STATUS1_READ    0x3DA                                        


#define CAP_INT_Control_and_Flags   0x100
#define CAP_CONTROL                 0x104
#define CAP_VIDEO_H_RANGE           0x108
#define CAP_VIDEO_V_RANGE           0x10C
#define CAP_VBI_H_RANGE             0x110
#define CAP_VBI_V_RANGE             0x114
#define CAP_ANC_DATA_SETTING        0x118
#define CAP_VIDEO_MAXDATACOUNT      0x11C
#define CAP_VBI_MAXDATACOUNT        0x120
#define CAP_DATACOUNT_STATUS        0x124
#define CAP_VIDEO_0_START_ADDRESS   0x128
#define CAP_VIDEO_1_START_ADDRESS   0x12C
#define CAP_VIDEO_2_START_ADDRESS   0x130
#define CAP_VBI_0_START_ADDRESS     0x134
#define CAP_VBI_1_START_ADDRESS     0x138
#define CAP_VIDEO_AND_VBI_STRIDE    0x13C
#define CAP_CSC_CONTROL1            0x140
#define CAP_CSC_CONTROL2            0x144
#define CAP_CSC_CONTROL3            0x148
#define CAP_MINIFY_CONTROL          0x14c


#define MMIOBASE_VIDEO                  0x600
#define VP_VIDEO_SIZE                   0x620
#define VP_RO_REG                       0x624
#define VP_PARAMETERS_QUALITY           0x628
#define VP_COLOR_ENHANCE_CTL1           0x630
#define VP_COLOR_ENHANCE_CTL2           0x634
#define VP_COLOR_ENHANCE_CTL3           0x638
#define VP_COLOR_ENHANCE_CTL4           0x63C
#define VP_H_SCALE                      0x640
#define VP_V_SCALE                      0x644
#define VP_CSC_CTL                      0x648
#define VP_PULL_DOWN                    0x64C
#define VP_SUB_PIC_STRIDE_CONTROL       0x650
#define VP_SUB_PIC_START                0x654
#define VP_SUB_PIC_4X16_RAM_TABLE       0x658
#define VP_STREAM_CTL                   0x660
#define VP_SW_SRC_BUF_LUMA_START        0x664
#define VP_SW_SRC_BUF_CHROMA_START      0x668
#define VP_SRC_BUF_STRIDE               0x66C
#define VP_DEST_FB0                     0x670
#define VP_DEST_FB1                     0x674
#define VP_DEST_FB2                     0x678
#define VP_DEST_STRIDE                  0x67C
#define VP_YV12_Y_Base                  0x664
#define VP_YV12_U_Base                  0x668
#define VP_YV12_V_Base                  0x680
#define VP_ROTATION_CTL                 0x684


#define VDP_CTL                      0x700
#define VDP_REG_UPDATE_MOD_SELECT    0x704
#define VDP_FIFO_THRESHOLD           0x708
#define VDP_FETCH_COUNT              0x70C
#define VDP_START_OFFSET             0x710
#define VDP_SRC_DISP_COUNT_ON_SCR    0x714
#define VDP_START_LOCATION           0x718
#define VDP_END_LOCATION             0x71C
#define VDP_FIRST_COLORKEY           0x720
#define VDP_CHROMA_KEY_LOW           0x724
#define VDP_CHROMA_KEY_UPPER         0x728
#define VDP_ZOOM_CTL                 0x72C
#define VDP_FB0                      0x730
#define VDP_FB1                      0x734
#define VDP_FB2                      0x738
#define VDP_FB_STRIDE                0x73C
#define VDP_COLOR_ENHANCE_CTL1       0x740
#define VDP_COLOR_ENHANCE_CTL2       0x744
#define VDP_COLOR_ENHANCE_CTL3       0x748
#define VDP_COLOR_ENHANCE_CTL4       0x74C
#define VDP_SECOND_COLORKEY          0x750


#define VPS_STREAM_YUY2                 0
#define VPS_STREAM_NV12                 0x10000000
#define VPS_STREAM_YV12                 0x20000000
#define VPS_TRIPLE_BUFFER               BIT26
#define VPS_DOUBLE_BUFFER               0
#define VPS_SINGLE_BUFFER               BIT6
#define VPS_SRC_CAPTURE                 0x02000000
#define VPS_SRC_SW                      0
#define VPS_WAVE_MODE                   0
#define VPS_BOB_MODE                    BIT23
#define VPS_SRC_CHROMINANCE_FRAME       0
#define VPS_SRC_CHROMINANCE_FIELD       BIT20
#define VPS_INVERSE_INPUT_FIELD         BIT19
#define VPS_FRAME_TO_FIELD              BIT18
#define VPS_FIELD_TO_FRAME              BIT17
#define VPS_SUB_PIC_FLIP                BIT15
#define VPS_INT_ENABLE                  BIT7
#define VPS_SRC_INPUT_TOP               0
#define VPS_SRC_INPUT_BOTTOM            BIT5
#define VPS_SRC_SW_FLIP                 BIT4
#define VPS_ENABLE                      BIT27
#define VPS_END_FRAME_STATUS            BIT0
#define VPS_SCALE_ENABLE                BIT31
#define VPS_SCALE_DOWN                  BIT30
#define VPS_ENABLE_PULL_DOWN            BIT15
#define VPS_FLIP_CTL_10                 BIT17   
#define VPS_SRC_UV_FIELD_IN_PLANAR      BIT20
#define VPS_SUB_PIC_ENABLE              BIT16
#define VPS_CSC_ENABLE                  BIT30
#define VPS_RGB16_OUTPUT                0
#define VPS_RGB32_OUTPUT                BIT31
#define VPS_ROTATION_ENABLE             BIT31
#define VPS_IDEL_RO_REG                 BIT0
#define VPS_COLOR_HNHANCE               BIT28


#define VDPS_ENABLE                  BIT0
#define VDPS_SW_FLIP                 0x00010000
#define VDPS_HW_FLIP                 0
#define VDPS_DISP_REQ_EXPIRE         0x00000140
#define VDPS_DISP_PRE_FETCH          BIT20
#define VDPS_DISP1                   0x0
#define VDPS_DISP2                   BIT18
#define VDPS_FIRE                    BIT7
#define VDPS_FIFO_THRESHOLD          0x60006000
#define VDPS_H_ZOOM                  BIT31
#define VDPS_H_INTERPOLATION         BIT30
#define VDPS_V_ZOOM                  BIT15
#define VDPS_V_INTERPOLATION         BIT14
#define VDPS_STREAM_YUY2             0x00000000
#define VDPS_STREAM_RGB16            0x00000004
#define VDPS_CSC_DISENABLE           BIT1
#define VDPS_MAX_WIDTH               800
#define VDPS_COLOR_HNHANCE           BIT17


#define CAP_VBI_STATUS              0x00000000
#define CAP_VIDEO_STATUS            0x00000010
#define CAP_CURRENT_VIDEO_FRAME_ID  0x00000300
#define CAP_CURRENT_VBI_FRAME_ID    0x00000400
#define CAP_FLIP_VIDEO_FRAME_ID     0x00001800
#define CAP_FLIP_VBI_FRAME_ID       0x00002000


#define CAP_ENABLE                  0x00000001
#define CAP_CCIR601_8               0x00000000
#define CAP_CCIR656_8               0x00000004
#define CAP_DATA_SWAP               0x00000100
#define CAP_CSC_ENABLE              0x00010000
#define CAP_CHROMA_SIGN_ENABLE      0x00020000
#define CAP_TRIPLE_BUFFER           0x00000000
#define CAP_DISABLE_TRIPLE_BUFFER   0x00040000

#define CAP_SINGLE_BUFFER           0x00040000
#define CAP_FIFO_Threshold          0x00003000
#define CAP_END_OF_ACTIVE           BIT0
#define CAP_HMINIFY_ENABLE          BIT15
#define CAP_VMINIFY_ENABLE          BIT14


#define CAP_VBI_ENABLE              0x80000000
#define CAP_VBI_MODE                0x40000000



#define INT_ENABLE                  0x04
#define INT_STATES                  0x00


#define INT_ENABLE_ALLMASK          BIT31
#define INT_ENABLE_I2C              BIT8
#define INT_ENABLE_CRT              BIT7
#define INT_ENABLE_DVP0             BIT6
#define INT_ENABLE_DVP1             BIT5
#define INT_ENABLE_DMA              BIT4
#define INT_ENABLE_CAP_VIDEO        BIT3
#define INT_ENABLE_VBI              BIT2
#define INT_ENABLE_VSync            BIT1


#define INT_CRT_SENSE_L2H           0x00000004
#define INT_I2C                     0x00000008
#define INT_DISP2_VSYNC             0x00000100
#define INT_DISP1_VSYNC             0x00000200
#define INT_CAPTURE_VBI             0x00000400
#define INT_CAPTURE_ACT             0x00000800
#define INT_DMA                     0x00001000
#define INT_DVP0_SENSE              0x00004000
#define INT_DVP1_SENSE              0x00008000
#define INT_CRT_SENSE_H2L           0x04000000




#define I2C_Data_Input               0x20
#define I2C_Clock_Input              0x10
#define I2C_Data_Output              0x08
#define I2C_Data_Output_En           0x04
#define I2C_Clock_Output             0x02
#define I2C_Clock_Output_En          0x01


#define HW_I2C_Control                0x40
#define HW_I2C_Status                 0x41
#define HW_I2C_Slave_Address          0x42
#define HW_I2C_Device_Address         0x43
#define HW_I2C_Write_Data             0x44
#define HW_I2C_Freq_Set1              0x45
#define HW_I2C_Freq_Set2              0x46
#define HW_I2C_Extra_Control          0x47
#define HW_I2C_Read_Data              0x48
#define HW_I2C_Control2               0x49


#define HW_I2C_SetStop                  0x02
#define HW_I2C_Reset                    0x80
#define HW_I2C_ReadDataS_Flag           0x40
#define HW_I2C_SendDataS_Flag           0x20
#define HW_I2C_Nak_Error_Flag           0x10
#define HW_I2C_BusUsed_Flag             0x02


#define DMA_DESCRIPTION_START_ADDRESS    0x14
#define DMA_DESCRIPTION_CURRENT_ADDRESS  0x18
#define DMA_STATUS_AND_INTERRUPT         0x20
#define DMA_CONTROL                      0x24



#define DMADescSize  12288

#define FBtoSM      BIT29
#define SMtoFB      0x0
#define DMA_INT_ENABLE     BIT30
#define DMA_END            BIT31
#define DMA_BCMask      0x003FFFFF
#define DMA_FBMask      0x07FFFFFF
#define DMA_FIDMask     0x000000FF
#define DMA_FenceID_BITSHIFT 24
#define DescriptorValid     BIT22
#define DescriptorNonValid  ~BIT22
#define DMA_ENABLE          BIT0
#define DMA_FIRE            BIT1
#define DMA_RESET           BIT2
#define DMA_IDLE            BIT1

int rdc_cap_init(GENERIC_CARD *card);
void rdc_enable_capture(GENERIC_CARD *card);
void rdc_disable_capture(GENERIC_CARD *card);
void vSet7114(GENERIC_CARD *card);
void vWaitForVsync(GENERIC_CARD *card);
void set_brightness(GENERIC_CARD *card, int value);
void set_hue(GENERIC_CARD *card, int value);
void set_contrast(GENERIC_CARD *card, int value);
void set_saturation(GENERIC_CARD *card, int value);


BOOL MoveRGB32ToRGB24ByCPU(GENERIC_CARD *card);


u8 GetIndexRegData(
    u8*  pRIOPort,
    u8   jIndex,
    u8   jAndData
    );   

void SetIndexRegData(
   u8* pRIOPort,
   u8  jIndex,
   u8  jAndData,
   u8  jOrData
   );



#endif
