#!/bin/sh

BOARD_DIR="$(dirname $0)"
ISO_FILENAME="${BINARIES_DIR}/usblinux.iso"
ISOIMAGE_TARGET_DIR="${BUILD_DIR}/isoimage-isolinux"

# Create an iso9660 image with isolinux (isohybrid)

mkdir -p ${ISOIMAGE_TARGET_DIR}/isolinux
mkdir -p ${ISOIMAGE_TARGET_DIR}/images
touch ${ISOIMAGE_TARGET_DIR}/USBLINUX

install -D -m 644 ${BINARIES_DIR}/syslinux/isolinux.bin ${ISOIMAGE_TARGET_DIR}/isolinux/
install -D -m 644 ${BINARIES_DIR}/syslinux/ldlinux.c32 ${ISOIMAGE_TARGET_DIR}/isolinux/
install -D -m 644 ${BINARIES_DIR}/bzImage ${ISOIMAGE_TARGET_DIR}/isolinux/kernel
install -D -m 644 ${BINARIES_DIR}/rootfs.cpio.gz ${ISOIMAGE_TARGET_DIR}/isolinux/initramfs

install -D -m 644 ${BOARD_DIR}/images/bzImage ${ISOIMAGE_TARGET_DIR}/images/bzImage
install -D -m 644 ${BOARD_DIR}/images/rootfs.tar.gz ${ISOIMAGE_TARGET_DIR}/images/rootfs.tar.gz

cat > ${ISOIMAGE_TARGET_DIR}/isolinux/isolinux.cfg << EOF
prompt 0
default linux

label linux
kernel kernel
append initrd=initramfs
EOF

${HOST_DIR}/usr/bin/genisoimage -r -l -b isolinux/isolinux.bin -no-emul-boot \
	-boot-load-size 4 -boot-info-table -o ${ISO_FILENAME} -V USBLINUX \
	-c isolinux/boot.cat ${ISOIMAGE_TARGET_DIR}

${HOST_DIR}/usr/bin/isohybrid ${ISO_FILENAME}

rm -rf ${ISOIMAGE_TARGET_DIR}

exit 0
