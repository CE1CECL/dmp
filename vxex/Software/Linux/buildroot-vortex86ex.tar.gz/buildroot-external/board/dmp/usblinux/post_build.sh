#!/bin/sh

rm ${TARGET_DIR}/etc/ssh/ssh_host_*

ssh-keygen -t rsa1 -N '' -f ${TARGET_DIR}/etc/ssh/ssh_host_key
ssh-keygen -t rsa -N '' -f ${TARGET_DIR}/etc/ssh/ssh_host_rsa_key
ssh-keygen -t dsa -N '' -f ${TARGET_DIR}/etc/ssh/ssh_host_dsa_key
ssh-keygen -t ecdsa -N '' -f ${TARGET_DIR}/etc/ssh/ssh_host_ecdsa_key
ssh-keygen -t ed25519 -N '' -f ${TARGET_DIR}/etc/ssh/ssh_host_ed25519_key

exit 0
