syslinux-target-extlinux:
	$(INSTALL) -D -m 0755 $(HOST_DIR)/sbin/extlinux \
		$(TARGET_DIR)/sbin

ifeq ($(BR2_TARGET_SYSLINUX_EXTLINUX),y)
TARGETS += syslinux-target-extlinux
endif
