include package/gstreamer/*/*.mk
