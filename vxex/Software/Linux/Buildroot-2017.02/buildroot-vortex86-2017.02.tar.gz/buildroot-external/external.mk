include $(sort $(wildcard $(BR2_EXTERNAL_VORTEX86_PATH)/boot/*/*.mk))
include $(sort $(wildcard $(BR2_EXTERNAL_VORTEX86_PATH)/package/*/*.mk))
