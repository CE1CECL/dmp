################################################################################
#
# grub2-mod
#
################################################################################

GRUB2_MOD_VERSION = 2.02
GRUB2_MOD_SITE = $(BR2_GNU_MIRROR)/grub
GRUB2_MOD_SOURCE = grub-$(GRUB2_MOD_VERSION).tar.xz
GRUB2_MOD_LICENSE = GPLv3+
GRUB2_MOD_LICENSE_FILES = COPYING
GRUB2_MOD_DEPENDENCIES = host-bison host-flex

GRUB2_MOD_BUILTIN_MODULES = $(call qstrip,$(BR2_TARGET_GRUB2_MOD_BUILTIN_MODULES))
GRUB2_MOD_BUILTIN_CONFIG = $(call qstrip,$(BR2_TARGET_GRUB2_MOD_BUILTIN_CONFIG))
GRUB2_MOD_BOOT_PARTITION = $(call qstrip,$(BR2_TARGET_GRUB2_MOD_BOOT_PARTITION))

ifeq ($(BR2_TARGET_GRUB2_MOD_I386_PC),y)
GRUB2_MOD_IMAGE = $(BINARIES_DIR)/grub/core.img
GRUB2_MOD_BOOT_IMAGE = $(BINARIES_DIR)/grub/boot.img
GRUB2_MOD_PREFIX = ($(GRUB2_MOD_BOOT_PARTITION))/boot/grub
GRUB2_MOD_TUPLE = i386-pc
GRUB2_MOD_TARGET = i386
GRUB2_MOD_PLATFORM = pc
endif

# Grub2 is kind of special: it considers CC, LD and so on to be the
# tools to build the native tools (i.e to be executed on the build
# machine), and uses TARGET_CC, TARGET_CFLAGS, TARGET_CPPFLAGS,
# TARGET_LDFLAGS to build the bootloader itself. However, to add to
# the confusion, it also uses NM, OBJCOPY and STRIP to build the
# bootloader itself; none of these are used to build the native
# tools.
#
# NOTE: TARGET_STRIP is overridden by BR2_STRIP_none, so always
# use the cross compile variant to ensure grub2 builds

GRUB2_MOD_CONF_ENV = \
	$(HOST_CONFIGURE_OPTS) \
	CPP="$(HOSTCC) -E" \
	TARGET_CC="$(TARGET_CC)" \
	TARGET_CFLAGS="$(TARGET_CFLAGS)" \
	TARGET_CPPFLAGS="$(TARGET_CPPFLAGS)" \
	TARGET_LDFLAGS="$(TARGET_LDFLAGS)" \
	TARGET_NM="$(TARGET_NM)" \
	TARGET_OBJCOPY="$(TARGET_OBJCOPY)" \
	TARGET_RANLIB="$(TARGET_RANLIB)" \
	STRIP="$(TARGET_CROSS)strip"

GRUB2_MOD_CONF_OPTS = \
	--target=$(GRUB2_MOD_TARGET) \
	--with-platform=$(GRUB2_MOD_PLATFORM) \
	--disable-grub-mkfont \
	--enable-efiemu=no \
	--enable-liblzma=no \
	--enable-device-mapper=no \
	--enable-libzfs=no \
	--enable-grub-mount=no \
	--disable-werror

# We don't want all the native tools and Grub2 modules to be installed
# in the target. So we in fact install everything into the host
# directory, and the image generation process (below) will use the
# grub-mkimage tool and Grub2 modules from the host directory.

GRUB2_MOD_INSTALL_TARGET_OPTS = DESTDIR=$(HOST_DIR) install

define GRUB2_MOD_IMAGE_INSTALLATION
	mkdir -p $(dir $(GRUB2_MOD_IMAGE))
	$(HOST_DIR)/usr/bin/grub-mkimage \
		-d $(HOST_DIR)/usr/lib/grub/$(GRUB2_MOD_TUPLE) \
		-O $(GRUB2_MOD_TUPLE) \
		-o $(GRUB2_MOD_IMAGE) \
		-p "$(GRUB2_MOD_PREFIX)" \
		$(if $(GRUB2_MOD_BUILTIN_CONFIG),-c $(GRUB2_MOD_BUILTIN_CONFIG)) \
		$(GRUB2_MOD_BUILTIN_MODULES)
	$(INSTALL) -D -m 0644 \
		$(HOST_DIR)/usr/lib/grub/$(GRUB2_MOD_TUPLE)/boot.img \
		$(GRUB2_MOD_BOOT_IMAGE)
endef
GRUB2_MOD_POST_INSTALL_TARGET_HOOKS += GRUB2_MOD_IMAGE_INSTALLATION

$(eval $(autotools-package))
