#!/bin/sh

ISO_FILENAME="${BINARIES_DIR}/usblinux.iso"
ISOIMAGE_TARGET_DIR="${BUILD_DIR}/isoimage-isolinux"

# Create an iso9660 image with isolinux (isohybrid)

mkdir -p "${ISOIMAGE_TARGET_DIR}/isolinux"
mkdir -p "${ISOIMAGE_TARGET_DIR}/images"
touch "${ISOIMAGE_TARGET_DIR}/USBLINUX"

install -m 0644 "${BINARIES_DIR}/bzImage" \
		"${ISOIMAGE_TARGET_DIR}/isolinux/kernel"
install -m 0644 "${BINARIES_DIR}/rootfs.cpio.gz" \
		"${ISOIMAGE_TARGET_DIR}/isolinux/initramfs"

install -m 0644 "${BINARIES_DIR}/syslinux/isolinux.bin" \
		"${ISOIMAGE_TARGET_DIR}/isolinux/"
install -m 0644 "${BINARIES_DIR}/syslinux/ldlinux.c32" \
		"${ISOIMAGE_TARGET_DIR}/isolinux/"

if [ -d "${BINARIES_DIR}/image_files" ] ; then
	cp -RLp "${BINARIES_DIR}"/image_files/* "${ISOIMAGE_TARGET_DIR}/images/"
fi

cat > "${ISOIMAGE_TARGET_DIR}/isolinux/isolinux.cfg" << EOF
prompt 0
default linux

label linux
kernel kernel
EOF

APPEND_OPTS="initrd=initramfs"

eval "$(grep ^BR2_USBLINUX_KERNEL_CMDLINE ${BR2_CONFIG})"
if [ -n "${BR2_USBLINUX_KERNEL_CMDLINE}" ] ; then
	APPEND_OPTS="${APPEND_OPTS} ${BR2_USBLINUX_KERNEL_CMDLINE}"
fi

printf "append %s\\n" "${APPEND_OPTS}" \
	>> "${ISOIMAGE_TARGET_DIR}/isolinux/isolinux.cfg"

"${HOST_DIR}/usr/bin/genisoimage" -r -l -b isolinux/isolinux.bin -no-emul-boot \
	-boot-load-size 4 -boot-info-table -o "${ISO_FILENAME}" -V USBLINUX \
	-c isolinux/boot.cat "${ISOIMAGE_TARGET_DIR}"

"${HOST_DIR}/usr/bin/isohybrid" "${ISO_FILENAME}"

rm -rf "${ISOIMAGE_TARGET_DIR}"

exit 0
