#!/bin/sh

split() {
	local string IFS

	string="${1}"
	IFS="${2}"
	shift 2
	read -r -- "$@" <<EOF
${string}
EOF
}

# Copy bootloader images
if [ -d "${BINARIES_DIR}/grub" ] ; then
	install -D -m 0644 "${BINARIES_DIR}/grub/boot.img" \
		"${TARGET_DIR}/usr/lib/grub/boot.img"
	install -D -m 0644 "${BINARIES_DIR}/grub/core.img" \
		"${TARGET_DIR}/usr/lib/grub/core.img"
fi

if [ -d "${BINARIES_DIR}/syslinux" ] ; then
	install -D -m 0644 "${BINARIES_DIR}/syslinux/mbr.bin" \
		"${TARGET_DIR}/usr/lib/syslinux/mbr.bin"
fi

BOARD_DIR="$(dirname "$0")"

mkdir -p "${BINARIES_DIR}/image_files"

if [ -d "${BOARD_DIR}/images" ] ; then
	cp -au "${BOARD_DIR}"/images/* "${BINARIES_DIR}/image_files/"
fi

# Generate ssh keys
rm "${TARGET_DIR}/etc/ssh/"ssh_host_*

ssh-keygen -t rsa1 -N '' -f "${TARGET_DIR}/etc/ssh/ssh_host_key"
ssh-keygen -t rsa -N '' -f "${TARGET_DIR}/etc/ssh/ssh_host_rsa_key"
ssh-keygen -t dsa -N '' -f "${TARGET_DIR}/etc/ssh/ssh_host_dsa_key"
ssh-keygen -t ecdsa -N '' -f "${TARGET_DIR}/etc/ssh/ssh_host_ecdsa_key"
ssh-keygen -t ed25519 -N '' -f "${TARGET_DIR}/etc/ssh/ssh_host_ed25519_key"

# sshd_config
sed -i "s/^[[:blank:]]*[#]PermitRootLogin .*/PermitRootLogin yes/" \
	"${TARGET_DIR}/etc/ssh/sshd_config"

eval $(grep ^BR2_USBLINUX "${BR2_CONFIG}")

for ARG in ${BR2_USBLINUX_KERNEL_CMDLINE} ; do
	case "${ARG}" in
	console=ttyS*)
		ARG="${ARG#console=}"
		split "${ARG%n8}" ',' SERIAL BAUD
		printf "${SERIAL}::respawn:/sbin/getty -L -n -l /sbin/autologin ${BAUD} ${SERIAL} vt100\n" >> "${TARGET_DIR}/etc/inittab"
		;;
	esac
done

if [ -z "${BR2_USBLINUX_IP}" ] ; then
	BR2_USBLINUX_IP="192.168.100.100"
fi

if [ -z "${BR2_USBLINUX_NETMASK}" ] ; then
	BR2_USBLINUX_NETMASK="255.255.255.0"
fi

cat >>"${TARGET_DIR}/etc/network/interfaces" <<EOF
# Configure eth0
auto eth0
iface eth0 inet static
address ${BR2_USBLINUX_IP}
netmask ${BR2_USBLINUX_NETMASK}
EOF

if [ -n "${BR2_USBLINUX_GATEWAY}" ] ; then
	cat >>"${TARGET_DIR}/etc/network/interfaces" <<EOF
gateway ${BR2_USBLINUX_GATEWAY}
EOF
fi

cat >>"${TARGET_DIR}/etc/hosts" <<EOF
${BR2_USBLINUX_IP}	usblinux
EOF

exit 0
