#include <stdio.h>
#include <stdlib.h>
#include <err.h>
#include <blkid/blkid.h>

int main(int argc, char *argv[])
{
	blkid_probe pr;
	const char *uuid;

	if (argc != 2) {
		fprintf(stderr, "Usage: %s devname\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	pr = blkid_new_probe_from_filename(argv[1]);
	if (!pr) {
		fprintf(stderr, "Failed to open %s\n", argv[1]);
		exit(2);
	}

	blkid_do_probe(pr);

	if (blkid_probe_lookup_value(pr, "UUID", &uuid, NULL) == -1) {
		fprintf(stderr, "Cannot get UUID of %s\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	printf("%s\n", uuid);

	blkid_free_probe(pr);

	exit(EXIT_SUCCESS);
}
