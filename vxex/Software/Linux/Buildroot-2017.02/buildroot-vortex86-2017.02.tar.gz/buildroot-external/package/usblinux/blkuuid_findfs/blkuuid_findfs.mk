BLKUUID_FINDFS_VERSION = 20141227
BLKUUID_FINDFS_SITE = $(BR2_EXTERNAL_VORTEX86_PATH)/package/usblinux/blkuuid_findfs/src
BLKUUID_FINDFS_SITE_METHOD = local

define BLKUUID_FINDFS_BUILD_CMDS
	$(MAKE) $(TARGET_CONFIGURE_OPTS) -C $(@D)
endef

define BLKUUID_FINDFS_INSTALL_TARGET_CMDS
	$(INSTALL) -m 0755 -D $(@D)/blkuuid \
		$(TARGET_DIR)/sbin/blkuuid
	$(INSTALL) -m 0755 -D $(@D)/findfs \
		$(TARGET_DIR)/sbin/findfs
endef

$(eval $(generic-package))
