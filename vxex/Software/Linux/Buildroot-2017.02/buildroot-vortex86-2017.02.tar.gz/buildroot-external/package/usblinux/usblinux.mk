include $(sort $(wildcard $(BR2_EXTERNAL_VORTEX86_PATH)/package/usblinux/*/*.mk))
