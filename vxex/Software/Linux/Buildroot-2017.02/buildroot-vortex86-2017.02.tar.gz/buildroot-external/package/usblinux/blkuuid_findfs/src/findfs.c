#include <stdio.h>
#include <stdlib.h>
#include <blkid/blkid.h>

int main(int argc, char *argv[])
{
	char *dev;

	if (argc != 2) {
		fprintf(stderr, "Usage: %s UUID=<value>\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	dev = blkid_evaluate_tag(argv[1], NULL, NULL);
	if (!dev) {
		fprintf(stderr, "Unable to resolve '%s'\n", argv[1]);
		exit(EXIT_FAILURE);
	}

	printf("%s\n", dev);


	exit(EXIT_SUCCESS);
}
