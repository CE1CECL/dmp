/* 
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */



#ifndef GENERIC_I2C_HEADER
#define GENERIC_I2C_HEADER 1

#define I2C_FUNC_SW 0


#define MPPTRIES        100000
#define MPP_CONFIG            (*(card->MEM_1+0x30))
#define MPP_CONFIG3           (*(((volatile u8*)(card->MEM_1+0x30))+3))
#define MPPREAD         0x84038CB0L     
#define MPP_DATA0             (*(((volatile u8*)(card->MEM_1+0x33))+0))
#define MPPREADBYTE           (*(((volatile u8*)(card->MEM_1+0x33))+0))
#define MPPNORMAL       0x80038CB0L     
#define MPPNORMALINC    0x80338CB0L     
#define MPP_ADDR              (*(card->MEM_1+0x32))


#define I2C_SLEEP


struct i2c_funcs {
  char *name;
  int (*init)(GENERIC_CARD *, u32 *saves);
  void (*deinit)(GENERIC_CARD *, u32 *saves);
  void (*scldir)(GENERIC_CARD *,int);
  void (*setscl)(GENERIC_CARD *,int);
  int (*getscl)(GENERIC_CARD *);
  void (*sdadir)(GENERIC_CARD *,int);
  void (*setsda)(GENERIC_CARD *,int);
  int (*getsda)(GENERIC_CARD *);
};

void i2c_start(GENERIC_CARD *card);
void i2c_stop(GENERIC_CARD * card);
int i2c_sendbyte(GENERIC_CARD *card, u8 data);
int i2c_device(GENERIC_CARD * card,u8 addr);
u8 i2c_read(GENERIC_CARD *card,u8 addr);
u8 i2c_readbyte(GENERIC_CARD *card,int last);
u8 i2c_readreg8(GENERIC_CARD *card,u8 addr, u8 reg);
int i2c_writereg8(GENERIC_CARD *card,u8 addr, u8 reg, u8 value);
int i2c_write(GENERIC_CARD *card,u8 addr, u8 *data, int count);
int i2c_init(GENERIC_CARD *card);
int i2c_checkack(GENERIC_CARD *card);
int i2c_sendnack(GENERIC_CARD *card);
void detect_cpature_port(GENERIC_CARD *card);


#endif
