/* 
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */





#define __NO_VERSION__

#include "rdcv4l2.h"
#include "rdcard.h"
#include "i2c.h"

#include <asm/io.h>

int rdc_cap_init(GENERIC_CARD *card)
{

  u8* pjMMIO;
  pjMMIO=card->MMR;
  
  
  OutPort(0x3d4,0x80);
  OutPort(0x3d5,0xa8);
  
  
  OutPort(0x3d4,0xa4);
  OutPort(0x3d5,InPort(0x3d5)|BIT0); 

  
  
  if (i2c_init(card) != 0)
  {
    printk (KERN_ERR "Could not find i2c bus driver\n");
    return -ENODEV;
  }
  
  card->type=CARD_RDC_M2010_CAP;
  
  card->videoram = MAX_CAP_RESERVE/1024;
  printk(KERN_INFO "videoram is %d\n",card->videoram);

  return 0;
}

void rdc_enable_capture(GENERIC_CARD *card)
{
  u8 *pjMMIO = card->MMR;
  int i;
  u32 dwWFactor=0,dwHFactor=0;
  card->dwMinifyCtl = 0;
  dprintk(1,"card(%d) rdc_enable_capture called, port = 0x%x\n",card->cardnum,card->bI2C_PORT);
  
  
  
  vWaitForVsync(card);

  
  *(u32 volatile *)(pjMMIO + INT_ENABLE ) = (*(u32 volatile *)(pjMMIO + INT_ENABLE )) & ~INT_ENABLE_ALLMASK;
  *(u32 volatile *)(pjMMIO + INT_STATES ) = INT_CAPTURE_ACT;

  
  card->status &= ~(STATUS_CAPTURING|STATUS_BUF_READY);

  if(card->bMinifyCtl)
  {
    if((card->width < card->OriWidth || card->height <  card->OriHeight) && 
        (card->width > 0 && card->height > 0))
    {
        dprintk(2,"OriWidth = %d,OriHeight = %d\n",card->OriWidth,card->OriHeight);
        dprintk(2,"ScaleWidth = %d,ScaleHeight = %d\n",card->width,card->height);

        if(card->width < card->OriWidth)
        {
            dwWFactor = (card->width * 0x1000)/card->OriWidth;
            if(dwWFactor>0xfff)
                dwWFactor = 0xfff;
            card->dwMinifyCtl |= CAP_HMINIFY_ENABLE;
        }
    
        if(card->height < card->OriHeight)
        {
            dwHFactor = (card->height * 0x1000)/card->OriHeight;
            if(dwHFactor>0xfff)
                dwHFactor = 0xfff;
            card->dwMinifyCtl |= CAP_VMINIFY_ENABLE;
        }
        card->dwMinifyCtl |= (dwWFactor<<16)|(dwHFactor);
     }
   }
  
   
   
   card->dwCapCtl = CAP_FIFO_Threshold|CAP_ENABLE|CAP_TRIPLE_BUFFER|CAP_CCIR656_8|CAP_DATA_SWAP;
   if (card->vpost_color_convert)
       card->dwCapActCount = (card->height<<16)|(card->dwVPostCapSrcHWPitch>>3);
   else
       card->dwCapActCount = (card->height<<16)|(card->dwCapSrcHWPitch>>3);
   
   if(card->bSingleBufMode)
   {
     card->dwCapCtl |= CAP_DISABLE_TRIPLE_BUFFER;
     *(u32 volatile *)(pjMMIO + CAP_VIDEO_0_START_ADDRESS ) = card->buffer[0] + card->dwCAPStartOffset;
   }
   else
   {
     card->dwCapCtl &= ~CAP_DISABLE_TRIPLE_BUFFER;
     *(u32 volatile *)(pjMMIO + CAP_VIDEO_0_START_ADDRESS ) = card->buffer[0] + card->dwCAPStartOffset;
     *(u32 volatile *)(pjMMIO + CAP_VIDEO_1_START_ADDRESS ) = card->buffer[1] + card->dwCAPStartOffset;
     *(u32 volatile *)(pjMMIO + CAP_VIDEO_2_START_ADDRESS ) = card->buffer[0] + card->dwCAPStartOffset;   
   }

   if (card->vpost_color_convert)
       *(u32 volatile *)(pjMMIO + CAP_VIDEO_AND_VBI_STRIDE )  = card->dwVPostCapSrcHWPitch;
   else
       *(u32 volatile *)(pjMMIO + CAP_VIDEO_AND_VBI_STRIDE )  = card->dwCapSrcHWPitch;
    
   *(u32 volatile *)(pjMMIO + CAP_VIDEO_MAXDATACOUNT )    = card->dwCapActCount;
   *(u32 volatile *)(pjMMIO + CAP_MINIFY_CONTROL )        = card->dwMinifyCtl;

   if(card->bRGB32)
   {
      if (card->vpost_color_convert)
      {
        card->dwCapCtl &= ~(CAP_CSC_ENABLE|CAP_CHROMA_SIGN_ENABLE);
        *(u32 volatile *)(pjMMIO + CAP_CSC_CONTROL1) = 0;
        *(u32 volatile *)(pjMMIO + CAP_CSC_CONTROL2) = 0;
        *(u32 volatile *)(pjMMIO + CAP_CSC_CONTROL3) = 0;

        card->dwVPStreamCtrl = VPS_ENABLE|
                               VPS_SINGLE_BUFFER|
                               VPS_SRC_SW|
                               VPS_END_FRAME_STATUS|
                               VPS_STREAM_YUY2;
      }
      else
      {
        card->dwCapCtl |= (CAP_CSC_ENABLE|CAP_CHROMA_SIGN_ENABLE);
        *(u32 volatile *)(pjMMIO + CAP_CSC_CONTROL1) = 0x13000ded;
        *(u32 volatile *)(pjMMIO + CAP_CSC_CONTROL2) = 0x13171000;
        *(u32 volatile *)(pjMMIO + CAP_CSC_CONTROL3) = 0xeded0000;
      }
   }
   else
   {
        card->dwCapCtl &= ~(CAP_CSC_ENABLE|CAP_CHROMA_SIGN_ENABLE);
        *(u32 volatile *)(pjMMIO + CAP_CSC_CONTROL1) = 0;
        *(u32 volatile *)(pjMMIO + CAP_CSC_CONTROL2) = 0;
        *(u32 volatile *)(pjMMIO + CAP_CSC_CONTROL3) = 0;  
   }

   if(card->bEnableHWRGB24)
   {       
        card->dwCapCtl |= CAP_ENABLE_24BITMOD;
   }
   
   *(u32 volatile *)(pjMMIO + CAP_CONTROL ) = card->dwCapCtl;
   
 
 
 *(u32 volatile *)(pjMMIO + INT_ENABLE )= INT_ENABLE_ALLMASK|INT_ENABLE_CAP_VIDEO|
                                (*(u32 volatile *)(pjMMIO + INT_ENABLE ));
  
  card->status |= STATUS_CAPTURING;
  dprintk(1,"waiting for capture stable\n");
  
  
  for(i=0;i<6;i++)
  {   
      
      while(!((*(u32 volatile *)(pjMMIO + INT_STATES ))&INT_CAPTURE_ACT))
      {}

      if(card->bSingleBufMode)
      {
          card->dwCapCtl |= CAP_DISABLE_TRIPLE_BUFFER;
          *(u32 volatile *)(pjMMIO + CAP_VIDEO_0_START_ADDRESS ) = card->buffer[i%VIDEO_MAX_FRAMES] + card->dwCAPStartOffset;
          
          (*(u32 volatile *)(pjMMIO + CAP_INT_Control_and_Flags)) = CAP_END_OF_ACTIVE;  
      }
      else
      {
        if(!(card->driver_data & RDC_CAP_M2010))
          
          (*(u32 volatile *)(pjMMIO + CAP_INT_Control_and_Flags)) = CAP_END_OF_ACTIVE;  
      }     
      (*(u32 volatile *)(pjMMIO + INT_STATES ))=INT_CAPTURE_ACT;    
  }  
  dprintk(2,"rdc_enable_capture exit\n");
  
}

void rdc_disable_capture(GENERIC_CARD *card)
{
  u8 *pjMMIO = card->MMR;
  dprintk(2,"card(%d) rdc_disable_capture called\n",card->cardnum);

  
  vWaitForVsync(card);

  
  *(u32 volatile *)(pjMMIO + INT_ENABLE ) = *(u32 volatile *)(pjMMIO + INT_ENABLE ) & 
                                  ~(INT_ENABLE_CAP_VIDEO);
  
  card->dwCapCtl = card->dwCapCtl& ~CAP_ENABLE;
  *(u32 volatile *)(pjMMIO + CAP_CONTROL) = card->dwCapCtl;
  
  
  card->status &= ~STATUS_CAPTURING;

  
  
  card->dwVPStreamCtrl = 0;
  *(u32 volatile *)(pjMMIO + VP_STREAM_CTL) = card->dwVPStreamCtrl;
  
}




u8 GetIndexRegData(
    u8*  pRIOPort,
    u8   jIndex,
    u8   jAndData)
{
    u8 volatile jTemp;
    u8 volatile *pvolRIOPort;
    pvolRIOPort = pRIOPort;
    *pvolRIOPort = jIndex;
    pvolRIOPort ++;
    jTemp = *pvolRIOPort;
    
    jTemp &= jAndData;
    return jTemp;
} 


void SetIndexRegData(
   u8* pRIOPort,
   u8  jIndex,
   u8  jAndData,
   u8  jOrData
   )
{
    u8 volatile jTemp;
    u8 volatile *pvolRIOPort;
    pvolRIOPort = pRIOPort;    
    *pvolRIOPort = jIndex;
    pvolRIOPort++;
    jTemp  = *pvolRIOPort;
    
    jTemp &= jAndData;
    jTemp |= jOrData;
    *pvolRIOPort = jTemp;
    
} 

void vSet7114(GENERIC_CARD *card)
{
    int i = 0;
    u8 bTV[256]=
    {
        
        
        0x00,0x08,0xC2,0x23,0x00,0x00,0xEB,0xE0,0xB0,0x57,0x95,0x48,0x40,0x00,0x0B,0x2E,
        0x0E,0x00,0x00,0x80,0x24,0x11,0xFE,0x58,0x40,0x80,0x77,0x52,0xA9,0x01,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0xDE,0x6F,0x01,0x00,0x66,0x66,0x1D,0x00,0x03,0x10,0x80,0x00,0x00,0x00,0x00,0x00,
        0x00,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
        0xFF,0xFF,0x00,0x55,0x44,0xFF,0xFF,0xFF,0x00,0x47,0x06,0x03,0x00,0x01,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x10,0x00,0x00,0x11,0x00,0x01,0x45,0x20,0xE0,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x08,0x19,0x80,0x00,0x00,0xd0,0x02,0x0a,0x00,0xFD,0x00,0xD0,0x02,0x06,0x01,
        0x01,0x00,0x00,0x00,0x80,0x3F,0x3F,0x00,0x00,0x04,0x00,0x00,0x00,0x02,0x00,0x00,
        0x00,0x04,0x00,0x04,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x08,0x00,0x08,0x00,0x00,0xD0,0x02,0x00,0x00,0x06,0x01,0xD0,0x02,0x06,0x01,
        0x01,0x00,0x00,0x00,0x80,0x3F,0x3F,0x00,0x00,0x05,0x00,0x00,0x00,0x02,0x00,0x00,
        0x00,0x04,0x00,0x04,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x07,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        
    };

    for(i=0;i<256;i++)
    {
        i2c_writereg8(card,card->bCapChipSlaveAddr, (u8)i, bTV[i]);
    }
    
    i2c_writereg8(card,card->bCapChipSlaveAddr, 0x88, 0);
    i2c_writereg8(card,card->bCapChipSlaveAddr, 0x88, bTV[0x88]);

}



#define GETCPUCYCLECOUNT 0

bool GetCPUCount(unsigned long long *lpCPUCount)
{
     rdtscll(*lpCPUCount);
     
     return true;
}


#if 1

BOOL MoveRGB32ToRGB24ByCPU(GENERIC_CARD *card)
{
  u32 *pjSrc,*ptmpSrc;
  u32 dwSrcPitch,dwDstPitch,dwLine=0;
  u8 *ptmpDst,*pjDst;
#if GETCPUCYCLECOUNT
  unsigned long long StartCount, EndCount, DiffCount;
#endif
  u32 i,j;
  dprintk(2,"card(%d) Optimal MoveRGB32ToRGB24ByCPU called\n",card->cardnum);
  dprintk(2,"dwSrcPitch = %d\n",card->dwCapSrcHWPitch);
  dprintk(2,"dwDstPitch = %d\n",card->dwCapSrcPitch);
  
  pjSrc = (u32*)(card->rdcfb + card->buffer[card->CapBufIndex]);
  pjDst = (u8*)card->framebuffer[card->frame];

  ptmpSrc = pjSrc;
  ptmpDst = pjDst;
  dwSrcPitch = card->dwCapSrcHWPitch;
  dwDstPitch = card->dwCapSrcPitch;
  
#if GETCPUCYCLECOUNT
  GetCPUCount((unsigned long long*)&StartCount);
#endif

  for(i=0 ; i < card->height ; i++)
  {
    if(card->bobmode)
    {
       if((i%2)==1)
          dwLine = i - 1;
       ptmpSrc = pjSrc + dwLine * (dwSrcPitch/4);
    }
    else
    {
       ptmpSrc = pjSrc + i * (dwSrcPitch/4);
    }
    ptmpDst = pjDst + i * dwDstPitch;

    for(j=0 ; j < dwDstPitch ;j+=8,ptmpSrc+=8,ptmpDst+=24)
    {
       *(u32*)ptmpDst      = *(ptmpSrc);
       *(u32*)(ptmpDst+3)  = *(ptmpSrc+1);
       *(u32*)(ptmpDst+6)  = *(ptmpSrc+2);
       *(u32*)(ptmpDst+9)  = *(ptmpSrc+3);
       *(u32*)(ptmpDst+12) = *(ptmpSrc+4);
       *(u32*)(ptmpDst+15) = *(ptmpSrc+5);
       *(u32*)(ptmpDst+18) = *(ptmpSrc+6);
       *(u32*)(ptmpDst+21) = *(ptmpSrc+7);
       
    }
  }
  
#if GETCPUCYCLECOUNT
  GetCPUCount((unsigned long long*)&EndCount);
  if(EndCount >= StartCount) 
  {
      DiffCount = EndCount - StartCount;
  }
  else
  {
     DiffCount = (int)EndCount + 1 + (0xffffffff - (int)StartCount);
  }
  
  dprintk(2,"CPU Cycle Count = %d\n",DiffCount);
#endif

  return TRUE;
}
#else

BOOL MoveRGB32ToRGB24ByCPU(GENERIC_CARD *card)
{
  u32 *pjSrc,*ptmpSrc,data;
  u32 dwSrcPitch,dwDstPitch,dwLine=0;
  u8 *ptmpDst,*pjDst;
#if GETCPUCYCLECOUNT
  unsigned long long StartCount, EndCount, DiffCount;
#endif
  u32 i,j;
  dprintk(2,"card(%d) MoveRGB32ToRGB24ByCPU called\n",card->cardnum);
  dprintk(2,"dwSrcPitch = %d\n",card->dwCapSrcHWPitch);
  dprintk(2,"dwDstPitch = %d\n",card->dwCapSrcPitch);
  
  pjSrc = (u32*)(card->rdcfb + card->buffer[card->CapBufIndex]);
  pjDst = (u8*)card->framebuffer[card->frame];
 
  ptmpSrc = pjSrc;
  ptmpDst = pjDst;
  dwSrcPitch = card->dwCapSrcHWPitch;
  dwDstPitch = card->dwCapSrcPitch;

#if GETCPUCYCLECOUNT
  GetCPUCount((unsigned long long*)&StartCount);
#endif

  for(i=0 ; i < card->height ; i++)
  {
    if(card->bobmode)
    {
       if((i%2)==1)
          dwLine = i - 1;
       ptmpSrc = pjSrc + dwLine * (dwSrcPitch/4);
    }
    else
    {
       ptmpSrc = pjSrc + i * (dwSrcPitch/4);
    }
    ptmpDst = pjDst + i * dwDstPitch;

    for(j=0 ; j < dwDstPitch ; j++)
    {
        data = *(ptmpSrc);
        *(ptmpDst+0) = (u8)(data&0x000000ff);        
        *(ptmpDst+1) = (u8)((data&0x0000ff00)>>8);   
        *(ptmpDst+2) = (u8)((data&0x00ff0000)>>16);  
        ptmpSrc +=1;
        ptmpDst +=3;
    }
  }
  
#if GETCPUCYCLECOUNT
  GetCPUCount((unsigned long long*)&EndCount);
  if(EndCount >= StartCount) 
  {
      DiffCount = EndCount - StartCount;
  }
  else
  {
     DiffCount = (int)EndCount + 1 + (0xffffffff - (int)StartCount);
  }
  
  dprintk(2,"CPU Cycle Count = %d\n",DiffCount);
#endif

  return TRUE;
}
#endif

void vWaitForVsync(GENERIC_CARD *card)
{
  u8 volatile *pjMMIO = card->MMR;
  return ;
  while(1)
  {
    if(!((*(u32 volatile *)(pjMMIO + INT_STATES ))&BIT0))
    {
      break;
    }
  }  
  
  while(1)
  {
    if((*(u32 volatile *)(pjMMIO + INT_STATES ))&BIT0)
    {
      break;
    }
  }    
  
}



void set_brightness(GENERIC_CARD *card, int value)
{
  u8 bShiftValue=0,bTmp88=0;
  card->bright = value;
  bShiftValue = (value&0xffff)>>8;
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x0a, bShiftValue);   
  bTmp88 = i2c_readreg8(card,card->bCapChipSlaveAddr, 0x88);
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x88, 0);    
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x88, bTmp88);  
}

void set_contrast(GENERIC_CARD *card, int value)
{
  u8 bShiftValue=0,bTmp88=0;
  card->contrast = value;
  bShiftValue = (value&0xffff)>>8;
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x0b, bShiftValue);   
  bTmp88 = i2c_readreg8(card,card->bCapChipSlaveAddr, 0x88);
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x88, 0);    
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x88, bTmp88);  
}

void set_hue(GENERIC_CARD *card, int value)
{
  u8 bShiftValue=0,bTmp88=0;
  card->hue = value;
  bShiftValue = (value&0xffff)>>8;
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x0d, bShiftValue);   
  bTmp88 = i2c_readreg8(card,card->bCapChipSlaveAddr, 0x88);
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x88, 0);    
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x88, bTmp88);  
}

void set_saturation(GENERIC_CARD *card, int value)
{
  u8 bShiftValue=0,bTmp88=0;
  card->saturation = value;
  bShiftValue = (value&0xffff)>>8;
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x0c, bShiftValue);   
  bTmp88 = i2c_readreg8(card,card->bCapChipSlaveAddr, 0x88);
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x88, 0);    
  i2c_writereg8(card,card->bCapChipSlaveAddr, 0x88, bTmp88);  
}

