/* 
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */




#define __NO_VERSION__

#include "rdcv4l2.h"
#include "queue.h"

void init_frame_queue(FIFO *queue)
{
  int i;
  for (i=0;i<VIDEO_MAX_FRAMES;i++){
    queue->data[i] = -1;
  }
  queue->front = 0;
  queue->back = 0;
}

void add_frame_to_queue(FIFO *queue, int frame)
{
  queue->data[queue->back] = frame;
  queue->back = (queue->back+1) % (VIDEO_MAX_FRAMES+1);
}

int frame_queue_empty(FIFO *queue)
{
  return queue->front == queue->back;
}

int remove_frame_from_queue(FIFO *queue)
{
  int frame;

  if (frame_queue_empty(queue))
  {
    dprintk(2,"remove_frame_from_queue frame_queue_empty\n");
    return -1;
  }

  frame = queue->data[queue->front];
  queue->front = (queue->front+1) % (VIDEO_MAX_FRAMES+1);
  return (frame);
}

int read_frame_from_queue(FIFO *queue)
{

  if (frame_queue_empty(queue))
  {
    dprintk(2,"remove_frame_from_queue frame_queue_empty\n");
    return -1;
  }

  return (queue->data[queue->front]);
}

