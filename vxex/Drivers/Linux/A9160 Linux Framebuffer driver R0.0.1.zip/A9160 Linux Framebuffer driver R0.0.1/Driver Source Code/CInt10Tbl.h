/* 
 * Copyright (C) 2009 RDC Semiconductor Co.,Ltd
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * For technical support : 
 *     <rdc_xorg@rdc.com.tw>
 */


PORT_CONFIG *pPortConfig;
MODE_INFO   *pLCDTable;
MODE_INFO   *pVESATable;
void *PCIDataStruct;

rdcbool bCRTSUPPORT = rdc_false;
rdcbool bLCDSUPPORT = rdc_false;
rdcbool bDVISUPPORT = rdc_false;
rdcbool bTVSUPPORT = rdc_false;


void *Display1VESAModeInitRegs;


void *POSTInItRegs;
void *DDRII400Tbl;
void *DDRII533Tbl;
void *ExtendRegs2;



REG_OP HTotal1[] = {
            {CR, 0xFF, 0x00,3},                 
            {CR, BIT0, 0xAC,11},                  
            {NR,0x0,0x0,0x0}
};


REG_OP HDispEnd1[] = {
            {SR, BIT6+BIT5+BIT4, 0x33,0},
            {CR, 0xFF, 0x01,3},
            {CR, BIT2, 0xAC,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HBnkSt1[] = {
            {SR, BIT2+BIT1+BIT0, 0x34,0},
            {CR, 0xFF, 0x02,3},
            {CR, BIT4, 0xAC,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HBnkEnd1[] = {
            {SR, BIT6+BIT5+BIT4, 0x34,0},
            {CR, 0x1F, 0x03,3},
            {CR, BIT7, 0x05,8},
            {CR, BIT0, 0xAD,9},
            {NR,0x0,0x0,0x0}
};


REG_OP HSyncSt1[] = {
            {SR, BIT2+BIT1+BIT0, 0x35,0},
            {CR, 0xFF, 0x04,3},
            {CR, BIT6, 0xAC,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HSyncEnd1[] = {
            {SR, BIT6+BIT5+BIT4, 0x35,0},
            {CR, 0x1F, 0x05,3},
            {CR, BIT2, 0xAD,8},
            {NR,0x0,0x0,0x0}
};


REG_OP VTotal1[] = {
            {CR, 0xFF, 0x06,0},
            {CR, BIT0, 0x07,8},
            {CR, BIT5, 0x07,9},
            {CR, BIT0, 0xAE,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VDispEnd1[] = {
            {CR, 0xFF, 0x12,0},
            {CR, BIT1, 0x07,8},
            {CR, BIT6, 0x07,9},
            {CR, BIT1, 0xAE,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VBnkSt1[] = {
            {CR, 0xFF, 0x15,0},
            {CR, BIT3, 0x07,8},
            {CR, BIT5, 0x09,9},
            {CR, BIT2, 0xAE,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VBnkEnd1[] = {
            {CR, 0xFF, 0x16,0},
            {CR, BIT4, 0xAE,8},
            {NR,0x0,0x0,0x0}
};


REG_OP VSyncSt1[] = {
             {CR, 0xFF, 0x10,0},
             {CR, BIT2, 0x07,8},
             {CR, BIT7, 0x07,9},
             {CR, BIT3, 0xAE,10},
             {NR,0x0,0x0,0x0}
};


REG_OP VSyncEnd1[] = {
             {CR, BIT3+BIT2+BIT1+BIT0, 0x11,0},
             {CR, BIT6+BIT5, 0xAE,4},
             {NR,0x0,0x0,0x0}
};


REG_OP Pitch1[] = {
             {CR, 0xFF, 0x13,0},
             {CR, 0x3F, 0xB0,8},
             {NR,0x0,0x0,0x0}
};




REG_OP HTotal2[] = {
            {CR, 0xFF, 0x23,3},                 
            {CR, BIT0, 0x29,11},                  
            {NR,0x0,0x0,0x0}
};


REG_OP HDispEnd2[] = {
            {SR, BIT6+BIT5+BIT4, 0x36,0},
            {CR, 0xFF, 0x24,3},
            {CR, BIT2, 0x29,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HBnkSt2[] = {
            {SR, BIT2+BIT1+BIT0, 0x37,0},
            {CR, 0xFF, 0x25,3},
            {CR, BIT4, 0x29,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HBnkEnd2[] = {
            {SR, BIT6+BIT5+BIT4, 0x37,0},
            {CR, 0x1F, 0x26,3},
            {CR, BIT7, 0x28,8},
            {CR, BIT0, 0x2A,9},
            {NR,0x0,0x0,0x0}
};


REG_OP HSyncSt2[] = {
            {SR, BIT2+BIT1+BIT0, 0x38,0},
            {CR, 0xFF, 0x27,3},
            {CR, BIT6, 0x29,11},
            {NR,0x0,0x0,0x0}
};


REG_OP HSyncEnd2[] = {
            {SR, BIT6+BIT5+BIT4, 0x38,0},
            {CR, 0x1F, 0x28,3},
            {CR, BIT2, 0x2A,8},
            {NR,0x0,0x0,0x0}
};


REG_OP VTotal2[] = {
            {CR, 0xFF, 0x2B,0},
            {CR, BIT0, 0x31,8},
            {CR, BIT5, 0x31,9},
            {CR, BIT0, 0x32,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VDispEnd2[] = {
            {CR, 0xFF, 0x2C,0},
            {CR, BIT1, 0x31,8},
            {CR, BIT6, 0x31,9},
            {CR, BIT1, 0x32,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VBnkSt2[] = {
            {CR, 0xFF, 0x2D,0},
            {CR, BIT3, 0x31,8},
            {CR, BIT5, 0x29,9},
            {CR, BIT2, 0x32,10},
            {NR,0x0,0x0,0x0}
};


REG_OP VBnkEnd2[] = {
            {CR, 0xFF, 0x2E,0},
            {CR, BIT4, 0x32,8},
            {NR,0x0,0x0,0x0}
};


REG_OP VSyncSt2[] = {
             {CR, 0xFF, 0x2F,0},
             {CR, BIT2, 0x31,8},
             {CR, BIT7, 0x31,9},
             {CR, BIT3, 0x32,10},
             {NR,0x0,0x0,0x0}
};


REG_OP VSyncEnd2[] = {
             {CR, BIT3+BIT2+BIT1+BIT0, 0x30,0},
             {CR, BIT6+BIT5, 0x32,4},
             {NR,0x0,0x0,0x0}
};


REG_OP Pitch2[] = {
             {CR, 0xFF, 0x3A,0},
             {CR, 0x3F, 0x3B,8},
             {NR,0x0,0x0,0x0}
};


REG_OP HSource1[] = {
            {SR, 0xFF,                0x4B, 0},
            {SR, BIT3+BIT2+BIT1+BIT0, 0x4C, 8},
            {NR,0x0,0x0,0x0}
};

REG_OP HSource2[] = {
            {SR, 0xFF,                0x4D, 0},
            {SR, BIT3+BIT2+BIT1+BIT0, 0x4E, 8},
            {NR,0x0,0x0,0x0}
};

REG_OP HScalingFactor1[] = {
            {SR, 0xFF,                0x59, 0},
            {SR, BIT3+BIT2+BIT1+BIT0, 0x5B, 8},
            {NR,0x0,0x0,0x0}
};
        
REG_OP VScalingFactor1[] = {
            {SR, 0xFF,                0x5A, 0},
            {SR, BIT6+BIT5+BIT4,      0x5B, 8},
            {NR,0x0,0x0,0x0}
};
        
REG_OP HScalingFactor2[] = {
            {SR, 0xFF,                0x51, 0},
            {SR, BIT3+BIT2+BIT1+BIT0, 0x53, 8},
            {NR,0x0,0x0,0x0}
};

REG_OP VScalingFactor2[] = {
            {SR, 0xFF,                0x52, 0},
            {SR, BIT6+BIT5+BIT4,      0x53, 8},
            {NR,0x0,0x0,0x0}
};


VESA_TABLE CInt10VESATable[] = {
        {
            {1280, 720, 0x147, 0x148, 0x149, 1},
            {74250, RR60, PHS+PVS, 370, 1390, 40,  30,  725,  5}
        },
        {
            {1280, 768, 0x144, 0x145, 0x146, 1},
            { 79500, RR60, NHS+PVS, 384, 1344, 128,  30,  771,  7}
        },
        {
            {1280, 960, 0x135, 0x136, 0x137, 1},
            {108000, RR60, PHS+PVS, 520, 1376, 112, 40,  961,  3}
        },
        {
            {1366, 768, 0x141, 0x142, 0x143, 1},
            { 85860, RR60, NHS+PVS, 434, 1440, 144,  27,  769,  3}
        },
        {
            {1400,1050, 0x138, 0x139, 0x13A, 1},
            {121750, RR60, NHS+PVS, 464, 1488, 144, 39, 1053, 4}
        },
        {
            {0xffff,1050, 0x138, 0x139, 0x13A, 1},
            {121750, RR60, NHS+PVS, 464, 1488, 144, 39, 1053, 4}
        }

};


