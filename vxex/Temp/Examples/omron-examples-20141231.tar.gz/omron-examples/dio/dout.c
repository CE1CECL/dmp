#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/io.h>

#define GPIO_DATA_BASE 0x78
#define GPIO_DIR_BASE  0x98

#define DIN_BASE  (GPIO_DATA_BASE + 0) // 0x78
#define DOUT_BASE (GPIO_DATA_BASE + 2) // 0x7A

enum dout_port {
	DOUT0 = 0x01,
	DOUT1 = 0x02,
	DOUT2 = 0x04,
	DOUT3 = 0x08,
	DOUT4 = 0x10,
	DOUT5 = 0x20,
	DOUT6 = 0x40,
	DOUT7 = 0x80,
};

enum din_port {
	DIN0 = 0x01,
	DIN1 = 0x02,
	DIN2 = 0x04,
	DIN3 = 0x08,
	DIN4 = 0x10,
	DIN5 = 0x20,
	DIN6 = 0x40,
	DIN7 = 0x80,
};

#if 1
/* read dout latch value */
unsigned char dout_read(unsigned char p)
{
	unsigned char reg;

	reg = inb(DOUT_BASE);

	if (reg & p)
		return 1;
	else
		return 0;
}
#endif

void dout_write(enum dout_port p, unsigned char v)
{
	unsigned char reg;

	reg = inb(DOUT_BASE);


	if (v)
		outb(reg | p, DOUT_BASE);
	else
		outb(reg & ~p, DOUT_BASE);

	reg = inb(DOUT_BASE);
}

unsigned char din_read(enum din_port p)
{
	unsigned char reg;

	reg = inb(DIN_BASE);

	if (reg & p)
		return 1;
	else
		return 0;
}

int main(int argc, char *argv[])
{
	unsigned int val;
	unsigned int pidx;
	unsigned char port[] = { DOUT0, DOUT1, DOUT2, DOUT3,
				 DOUT4, DOUT5, DOUT6, DOUT7 };

	if (argc != 3) {
		fprintf(stderr, "%s <dout> <value>\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	sscanf(argv[1], "%u", &pidx);
	if (pidx > 7) {
		fprintf(stderr, "Please specify port 0 ~ 7\n");
		exit(EXIT_FAILURE);
	}

	sscanf(argv[1], "%u", &val);
	if (val)
		val = 1;

	if (iopl(3)) {
		perror("iopl");
		exit(EXIT_FAILURE);
	}

	dout_write(port[pidx], val);
	val = dout_read(port[pidx]);
	printf("%u\n", val);

	iopl(0);

	return 0;
}
