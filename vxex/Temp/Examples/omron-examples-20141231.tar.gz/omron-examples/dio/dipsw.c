#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/io.h>

#define GPIO_DATA_BASE 0x102
#define GPIO_DIR_BASE  0x94

#define DIPSW_BASE  (GPIO_DATA_BASE + 0) // 0x102

enum dipsw_port {
	DIPSW0 = 0x01,
	DIPSW1 = 0x02,
	DIPSW2 = 0x04,
	DIPSW3 = 0x08,
};

unsigned char dipsw_read(enum dipsw_port p)
{
	unsigned char reg;

	reg = inb(DIPSW_BASE);

	if (reg & p)
		return 1;
	else
		return 0;
}

int main(int argc, char *argv[])
{
	unsigned char val;
	unsigned int pidx;
	unsigned char port[] = { DIPSW0, DIPSW1, DIPSW2, DIPSW3 };

	if (argc != 2) {
		fprintf(stderr, "%s <dipsw>\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	sscanf(argv[1], "%u", &pidx);
	if (pidx > 3) {
		fprintf(stderr, "Please specify port 0 ~ 3\n");
		exit(EXIT_FAILURE);
	}

	if (iopl(3)) {
		perror("iopl");
		exit(EXIT_FAILURE);
	}

	val = dipsw_read(port[pidx]);
	printf("%u\n", val);

	iopl(0);

	return 0;
}
