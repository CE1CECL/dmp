#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/io.h>
#include <signal.h>
#include <time.h>
#include <libgen.h>

#define GP2_DATA_ADDR 0x7A
#define GP2_DIR_ADDR  0x9A

#define DOUT0 0x01
#define DOUT1 0x02
#define DOUT2 0x04

#define DELAY_TIME_NS (10 * 1000 * 1000)

static unsigned int cnt;
static unsigned char dout_mask;

static void sig_handler(int sig, siginfo_t *si, void *uc)
{
	unsigned char reg;

	reg = inb(GP2_DATA_ADDR);
	outb(reg ^ (dout_mask & 0xff), GP2_DATA_ADDR);
	cnt -= 1;
}

int main(int argc, char *argv[])
{
	timer_t timerid;
	struct sigevent sev;
	struct itimerspec its;
	struct sigaction sa;
	unsigned int chan;

	if ((argc == 3) && argv[1] && argv[2]) {
		sscanf(argv[1], "%u", &chan);
		sscanf(argv[2], "%u", &cnt);
	}
	else {
		printf("%s [bit] [pulse count]\n", basename(argv[0]));
		exit(EXIT_FAILURE);
	}

	/* get IO permission */
	if (iopl(3)) {
		printf("Please get root permission\n");
		exit(EXIT_FAILURE);
	}

	if (chan < 0 && chan > 2) {
		printf("%s [bit] [pulse count]\n", basename(argv[0]));
		exit(EXIT_FAILURE);
	}

	switch (chan) {
	case 0:
		dout_mask = DOUT0;
		break;
	case 1:
		dout_mask = DOUT1;
		break;
	case 2:
		dout_mask = DOUT2;
		break;
	default:
		printf("%s [bit] [pulse count]\n", basename(argv[0]));
		exit(EXIT_FAILURE);
	}

	/* Establish hanlder for timer signal */
	sa.sa_flags = SA_SIGINFO;
	sa.sa_sigaction = sig_handler;
	sigemptyset(&sa.sa_mask);
	if (sigaction(SIGRTMIN, &sa, NULL) == -1) {
		perror("sigaction");
		exit(EXIT_FAILURE);
	}

	/* Create the timer */
	sev.sigev_notify = SIGEV_SIGNAL;
	sev.sigev_signo = SIGRTMIN;
	sev.sigev_value.sival_ptr = &timerid;
	if (timer_create(CLOCK_REALTIME, &sev, &timerid) == -1) {
		perror("timer_create");
		exit(EXIT_FAILURE);
	}

	/* Start the timer */
	its.it_value.tv_sec = DELAY_TIME_NS / 1000000000;
	its.it_value.tv_nsec = DELAY_TIME_NS % 1000000000;
	its.it_interval.tv_sec = its.it_value.tv_sec;
	its.it_interval.tv_nsec = its.it_value.tv_nsec;

	if (timer_settime(timerid, 0 , &its, NULL) == -1) {
		perror("timer_settime");
		exit(EXIT_FAILURE);
	}

	cnt = cnt * 2;
	while (cnt > 0) {
		pause();
	}

	exit(EXIT_SUCCESS);
}
