#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/io.h>
#include <libgen.h>

#define GP2_DATA_ADDR 0x7A
#define GP2_DIR_ADDR  0x9A

#define DOUT0 0x01
#define DOUT1 0x02
#define DOUT2 0x04

#define DELAY_TIME_US (10 * 1000)

void send_pulsecnt(unsigned char doutbit, unsigned int pcnt)
{
	unsigned char reg;
	unsigned int i = pcnt;

	outb(0x00, GP2_DATA_ADDR);

	while (i--) {
		reg = inb(GP2_DATA_ADDR);
		outb(reg | doutbit, GP2_DATA_ADDR);
		usleep(DELAY_TIME_US);

		reg = inb(GP2_DATA_ADDR);
		outb(reg & ~doutbit, GP2_DATA_ADDR);
		usleep(DELAY_TIME_US);
	}
}

int main(int argc, char *argv[])
{
	unsigned int chan;
	unsigned int pcnt;

	if ((argc == 3) && argv[1] && argv[2]) {
		sscanf(argv[1], "%u", &chan);
		sscanf(argv[2], "%u", &pcnt);
	}
	else {
		printf("%s [bit] [pulse count]\n", basename(argv[0]));
		exit(EXIT_FAILURE);
	}

	/* get IO permission */
	if (iopl(3)) {
		printf("Please get root permission\n");
		exit(EXIT_FAILURE);
	}

	if (chan < 0 && chan > 2) {
		printf("%s [bit] [pulse count]\n", basename(argv[0]));
		exit(EXIT_FAILURE);
	}

	switch (chan) {
	case 0:
		send_pulsecnt(DOUT0, pcnt);
		break;
	case 1:
		send_pulsecnt(DOUT1, pcnt);
		break;
	case 2:
		send_pulsecnt(DOUT2, pcnt);
		break;
	default:
		printf("%s [bit] [pulse count]\n", basename(argv[0]));
		exit(EXIT_FAILURE);
	}

	exit(EXIT_SUCCESS);
}
