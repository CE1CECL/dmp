#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/io.h>
#include <sys/types.h>
#include <fcntl.h>

#undef DEBUG

#define VEXMC_REG_WINDOWIDX 0xD0
#define VEXMC_IDX_GEN 0x01
#define VEXMC_IDX_MC0 0x02
#define VEXMC_IDX_MC1 0x04
#define VEXMC_IDX_MC2 0x08
#define VEXMC_IDX_MC3 0x10

#define VEXMC_REG_MCMODE	0x00
#define VEXMC_REG_MEN1		0x08
#define VEXMC_REG_MEN2		0x0C
#define VEXMC_REG_WRPROTION     0x10
#define VEXMC_REG_INTMNS	0x38
#define VEXMC_REG_IS		0x3A
#define VEXMC_REG_UNLOCK	0x3C

#define VEXMC_REG_PWMA_PERWID   0x08
#define VEXMC_REG_PWMA_PHA0WID  0x0C
#define VEXMC_REG_PWMA_CTRLNSAM 0x10
#define VEXMC_REG_PWMA_OUTCTRL  0x24
#define VEXMC_REG_PWMA_RLCTRL   0x30

#define VEXMC_REG_PWMB_PERWID   0x34
#define VEXMC_REG_PWMB_PHA0WID  0x38
#define VEXMC_REG_PWMB_CTRLNSAM 0x3C
#define VEXMC_REG_PWMB_OUTCTRL  0x50
#define VEXMC_REG_PWMB_RLCTRL   0x5C

#define VEXMC_REG_PWMC_PERWID   0x60
#define VEXMC_REG_PWMC_PHA0WID  0x64
#define VEXMC_REG_PWMC_CTRLNSAM 0x68
#define VEXMC_REG_PWMC_OUTCTRL  0x7C
#define VEXMC_REG_PWMC_RLCTRL   0x88

/* Base address of MC controller*/
static unsigned int iobase;

static unsigned int pci_config_read(unsigned char offset)
{
	char *config_path = "/sys/bus/pci/devices/0000:00:10.0/config";
	unsigned int reg;
	int fd, result;

	if ((fd = open(config_path, O_RDONLY)) < 0) {
		printf("open pci config file failed\n");
		exit(EXIT_FAILURE);
	}

	if ((lseek(fd, offset, SEEK_SET)) < 0) {
		printf("offset %u is invalid.\n", offset);
		exit(EXIT_FAILURE);
	}

	result = read(fd, &reg, sizeof(reg));
	if (result < sizeof(reg)) {
		printf("read pci config eroor\n");
		exit(EXIT_FAILURE);
	}

	close(fd);

	return reg;
}

static void switch_reg_window(unsigned int iobase, unsigned int index)
{
	outl(index, iobase + VEXMC_REG_WINDOWIDX);
}

static void mc_write(unsigned int val, unsigned int offset)
{
	outl(val, iobase + offset);

#ifdef DEBUG
	{
		unsigned int reg;
		reg = inl(iobase + offset);
		printf("offseet 0x%X: 0x%X\n", iobase + offset, reg);
	}
#endif
}

static unsigned int mc_read(unsigned int offset)
{
	unsigned int reg;

	reg = inl(iobase + offset);

#ifdef DEBUG
	printf("offseet 0x%X: 0x%X\n", iobase + offset, reg);
#endif

	return reg;
}

void power_led_on()
{
	switch_reg_window(iobase, VEXMC_IDX_MC1);
	mc_write(200000000 - 1, VEXMC_REG_PWMA_PERWID);
	mc_write(0, VEXMC_REG_PWMA_PHA0WID);
	mc_write(0x70000002, VEXMC_REG_PWMA_RLCTRL);
}

void power_led_off()
{
	switch_reg_window(iobase, VEXMC_IDX_MC1);
	mc_write(200000000 - 1, VEXMC_REG_PWMA_PERWID);
	mc_write(200000000 - 1, VEXMC_REG_PWMA_PHA0WID);
	mc_write(0x70000002, VEXMC_REG_PWMA_RLCTRL);
}

void power_led_blink(unsigned int period_ms, unsigned int phase0_ms)
{
	switch_reg_window(iobase, VEXMC_IDX_MC1);
	mc_write((period_ms * 100000) - 1, VEXMC_REG_PWMA_PERWID);
	mc_write((phase0_ms * 100000) - 1, VEXMC_REG_PWMA_PHA0WID);
	mc_write(0x70000002, VEXMC_REG_PWMA_RLCTRL);
}

void err_led_on()
{
	switch_reg_window(iobase, VEXMC_IDX_MC1);
	mc_write(200000000 - 1, VEXMC_REG_PWMB_PERWID);
	mc_write(0, VEXMC_REG_PWMB_PHA0WID);
	mc_write(0x70000002, VEXMC_REG_PWMB_RLCTRL);
}

void err_led_off()
{
	switch_reg_window(iobase, VEXMC_IDX_MC1);
	mc_write(200000000 - 1, VEXMC_REG_PWMB_PERWID);
	mc_write(200000000 - 1, VEXMC_REG_PWMB_PHA0WID);
	mc_write(0x70000002, VEXMC_REG_PWMB_RLCTRL);
}

void err_led_blink(unsigned int period_ms, unsigned int phase0_ms)
{
	switch_reg_window(iobase, VEXMC_IDX_MC1);
	mc_write((period_ms * 100000) - 1, VEXMC_REG_PWMB_PERWID);
	mc_write((phase0_ms * 100000) - 1, VEXMC_REG_PWMB_PHA0WID);
	mc_write(0x70000002, VEXMC_REG_PWMB_RLCTRL);
}

#define MC1_PWMA_EN 0x08
#define MC1_PWMB_EN 0x10
#define MC1_PWMC_EN 0x20

void init_power_led()
{
	unsigned int reg;

	switch_reg_window(iobase, VEXMC_IDX_GEN);
	reg = mc_read(VEXMC_REG_MEN1);
        mc_write(reg & ~MC1_PWMA_EN, VEXMC_REG_MEN1);

	switch_reg_window(iobase, VEXMC_IDX_MC1);
	mc_write(200000000 - 1, VEXMC_REG_PWMA_PERWID);
	mc_write(100000000 - 1, VEXMC_REG_PWMA_PHA0WID);
	mc_write(0x8000003B, VEXMC_REG_PWMA_CTRLNSAM);
	mc_write(0x30000000, VEXMC_REG_PWMA_OUTCTRL);
	mc_write(0x10700002, VEXMC_REG_PWMA_RLCTRL);

        switch_reg_window(iobase, VEXMC_IDX_GEN);
	reg = mc_read(VEXMC_REG_MEN1);
        mc_write(reg | MC1_PWMA_EN, VEXMC_REG_MEN1);
}

void init_err_led()
{
	unsigned int reg;

	switch_reg_window(iobase, VEXMC_IDX_GEN);
	reg = mc_read(VEXMC_REG_MEN1);
        mc_write(reg & ~MC1_PWMB_EN, VEXMC_REG_MEN1);

	switch_reg_window(iobase, VEXMC_IDX_MC1);
	mc_write(0x8000003B, VEXMC_REG_PWMB_CTRLNSAM);
	mc_write(0x30000000, VEXMC_REG_PWMB_OUTCTRL);
	mc_write(200000000 - 1, VEXMC_REG_PWMB_PERWID);
	mc_write(100000000 - 1, VEXMC_REG_PWMB_PHA0WID);
	mc_write(0x10700000, VEXMC_REG_PWMB_RLCTRL);

        switch_reg_window(iobase, VEXMC_IDX_GEN);
	reg = mc_read(VEXMC_REG_MEN1);
        mc_write(reg | MC1_PWMB_EN, VEXMC_REG_MEN1);
}

int main()
{
	/* get motor controller I/O base address */
	iobase = pci_config_read(0x10) & 0xfffe;

	iopl(3);

	init_power_led();
	init_err_led();
	sleep(5);

	power_led_on();
	sleep(5);

	err_led_on();
	sleep(5);

	power_led_off();
	sleep(5);

	err_led_off();
	sleep(5);

	power_led_blink(1000, 500);
	sleep(5);

	err_led_blink(1000, 500);
	sleep(5);

	iopl(0);
}
