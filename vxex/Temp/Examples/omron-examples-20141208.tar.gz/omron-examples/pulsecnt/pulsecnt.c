#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <poll.h>

#define PUINPUT_DEVICE "/dev/vex_pcnt0"

/* functions used to configure stdin to not wait for a linefeed */
static void initTermios(int echo);
static void restoreTermios();
static struct termios _old, _new;

/* Initialize new terminal i/o settings */
static void initTermios(int echo)
{
	tcgetattr(0, &_old);	/* grab old terminal i/o settings */
	_new = _old;		/* make new settings same as old settings */
	_new.c_lflag &= ~ICANON;	/* disable buffered i/o */
	_new.c_lflag &= echo ? ECHO : ~ECHO;	/* set echo mode */
	tcsetattr(0, TCSANOW, &_new);	/* use these new terminal i/o settings now */
}

/* Restore old terminal i/o settings */
static void restoreTermios(void)
{
	tcsetattr(0, TCSANOW, &_old);
}

static void poll_loop(int fd)
{
	unsigned int pcnt;
	int numReady, stopPolling = 0;
	short pollevent = POLLIN;
	const int fdCount = 2;
	struct pollfd fds[fdCount];
	fds[0].fd = fd;
	fds[0].events = pollevent;

	fds[1].fd = STDIN_FILENO;
	fds[1].events = pollevent;

	initTermios(0);

	char data;
	int readBytes;

	printf("Please press the 'q' key to quit\n");

	do {
		numReady = poll(fds, fdCount, -1);

		if (numReady == -1	/* indicates that an error occurred  */
		    || numReady == 0) {	/* indicates that a timeout occurred */
			stopPolling = 1;/* either way, we stop polling */
		}
		else {
			if (fds[0].revents & pollevent) {
				readBytes = read(fd, &pcnt, sizeof(pcnt));
				if (readBytes < 0) {
					stopPolling = 1;
				}
				printf("pulse %lu\n", pcnt);
			}

			/* stdin */
			if (fds[1].revents & pollevent) {
				readBytes = read(STDIN_FILENO, &data, 1);

				/* quit the loop when the 'q' key was pressed */
				if (data == 'q') {
					printf
					    ("q key pressed, terminating...\n");
					stopPolling = 1;
				}
			}

		}

	} while (!stopPolling);

	restoreTermios();
}

int main(int argc, char *argv[])
{
	int fd, rdbytes;
	char *pudev = PUINPUT_DEVICE;

	if ((argc > 1) && argv[1])
		pudev = argv[1];
		
	if ((fd = open(pudev, O_RDONLY)) < 0) {
		printf("open file failed.\n");
		return -1;
	}

	poll_loop(fd);

	close(fd);

	return 0;
}
