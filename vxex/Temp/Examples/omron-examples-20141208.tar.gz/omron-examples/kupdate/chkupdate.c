#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <mtd/mtd-user.h>

#define MTD_BOOTCONF_NAME "/dev/mtd0"

#define BUFSIZE (10 * 1024)

struct omron_bootconf {
	unsigned char boot_flag; 
	unsigned char trial_run;
	unsigned char trial_run_start;
} __attribute__((packed));

static int bconf_fd = -1;

static void safe_read (int fd, const char *fname,void *buf, size_t count)
{
	ssize_t result;
	result = read (fd, buf, count);
	if (count != result) {
		if (result < 0) {
			printf("read file error: %s\n",fname);
			exit (EXIT_FAILURE);
		}
		printf("Short read count returned while reading from %s\n",
			fname);
		exit(EXIT_FAILURE);
	}
}

static void safe_rewind (int fd,const char *fname)
{
	if (lseek(fd, 0L, SEEK_SET) < 0) {
		printf("seek to start error %s", fname);
		exit(EXIT_FAILURE);
	}
}

static void cleanup(void)
{
	if (bconf_fd > 0)
		close(bconf_fd);
}

int main(int argc, char *argv[])
{
	int i;
	int size, written;
	ssize_t result;
	struct mtd_info_user mtd;
	struct erase_info_user erase;
	struct omron_bootconf obconf, nbconf;


	atexit(cleanup);

	if ((bconf_fd = open(MTD_BOOTCONF_NAME, O_RDWR)) < 0) {
		printf("open mtd-bootconf failed\n");
		exit(EXIT_FAILURE);
	}

	result = read(bconf_fd, &obconf, sizeof(obconf));
	if (result < sizeof(obconf)) {
		printf("read mtd-bootconf failed\n");
		exit(EXIT_FAILURE);
	}
	memcpy(&nbconf, &obconf, sizeof(obconf));

	/* Check trial_run and trial_run_start flag */
	if (obconf.trial_run == 1 && obconf.trial_run_start == 1) {
		nbconf.trial_run = 0;
		nbconf.trial_run_start = 0;
	}
	else if (obconf.trial_run == 0 && obconf.trial_run_start == 0) {
		exit(EXIT_SUCCESS);
	}
	else {
		printf("trial_run: %u, trial_run_start: %u is unexpected\n",
		       obconf.trial_run, obconf.trial_run_start);
		exit(EXIT_FAILURE);
	}

	printf("Trial run success. We will clear trial run flags.\n");

	/*
	 * No need to erase flash, because we write 0 to clear trial_run
	 * and trial_run_start flag.
	 */
#if 0
	erase.start = 0;
	erase.length = mtd.erasesize;

	if (ioctl(bconf_fd, MEMERASE, &erase) < 0) {
		printf("erase mtd-bootconf block error\n");
		exit(EXIT_FAILURE);
	}
#endif

	safe_rewind(bconf_fd, MTD_BOOTCONF_NAME);

	result = write(bconf_fd, &nbconf, sizeof(nbconf));
	if (result != sizeof(nbconf)) {
		printf("write mtd-bootconf failed\n");
		exit(EXIT_FAILURE);
	}

	printf("write %s done\n", MTD_BOOTCONF_NAME);

	safe_rewind(bconf_fd, MTD_BOOTCONF_NAME);

	safe_read(bconf_fd, MTD_BOOTCONF_NAME, &obconf, sizeof(obconf));

	if (memcmp(&obconf, &nbconf, i)) {
		printf("mtd-bootconf mismatch found\n");
		exit(EXIT_FAILURE);
	}

	printf("verify %s done\n", MTD_BOOTCONF_NAME);

	exit(EXIT_SUCCESS);
}
