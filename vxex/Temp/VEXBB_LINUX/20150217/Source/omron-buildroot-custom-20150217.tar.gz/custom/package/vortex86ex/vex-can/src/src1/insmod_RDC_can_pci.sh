#!/bin/sh
module="RDC_CAN_pci"
device="RDCCAN"
mode="664"
maxports="32"

echo -e "Load can module and can protocol"
modprobe module_can
modprobe module_canraw

echo -e "Load candev module and CAN Controller driver"
modprobe module_candev
modprobe module_RDC_SocketCAN
modprobe module_RDC_CAN_pci
