LINUX_UPDATE_VERSION = 20141227
LINUX_UPDATE_SITE = $(BR2_EXTERNAL)/package/linux_update
LINUX_UPDATE_SITE_METHOD = file

ifeq ($(BR2_PACKAGE_LINUX_UPDATE_INITRAMFS), y)
define LINUX_UPDATE_BUILD_CMDS
	$(MAKE) $(TARGET_CONFIGURE_OPTS) -C $(@D)/initramfs
endef
else
define LINUX_UPDATE_BUILD_CMDS
	$(MAKE) $(TARGET_CONFIGURE_OPTS) -C $(@D)
endef
endif

ifeq ($(BR2_PACKAGE_LINUX_UPDATE_INITRAMFS), y)
define LINUX_UPDATE_INSTALL_TARGET_CMDS
	$(INSTALL) -m 0755 -D $(@D)/initramfs/check_rootconf_init \
		$(TARGET_DIR)/sbin/check_rootconf_init
	$(INSTALL) -m 0755 -D $(@D)/initramfs/read_rootconf_uuid \
		$(TARGET_DIR)/sbin/read_rootconf_uuid
endef
else
define LINUX_UPDATE_INSTALL_TARGET_CMDS
	$(INSTALL) -m 0755 -D $(@D)/clean_bootconf \
		$(TARGET_DIR)/sbin/clean_bootconf
	$(INSTALL) -m 0755 -D $(@D)/clean_rootconf \
		$(TARGET_DIR)/sbin/clean_rootconf
endef
endif

$(eval $(generic-package))
