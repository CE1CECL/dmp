#!/bin/sh

export PATH="/sbin:/usr/sbin:$PATH"

ROOTFS_FILE=$1

if [ ! -f "${ROOTFS_FILE}" ] ; then
	echo "* rootfs (${ROOTFS_FILE}) is not found"
	exit 1
fi

UUID=`./read_rootconf_uuid`
if [ ${?} -ne 0 ] ; then
	echo "cannot get proper UUID from rootconf"
	exit 1
fi

ROOTDEV=`./findfs UUID=${UUID}`
if [ ${?} -ne 0 ] ; then
	echo "cannot match device via the UUID"
	exit 1
fi

echo "* rootconf.uuid=\"${UUID}\""
echo "* It is belong to ${ROOTDEV}"

if [ "${ROOTDEV}" = "/dev/hda1" ] ; then       
	TARGETDEV="/dev/hda2"
elif [ "${ROOTDEV}" = "/dev/hda2" ] ; then
	TARGETDEV="/dev/hda1"
else
	echo "the UUID is not belong to any rootfs parition"
	exit 1
fi

echo "* Installing new rootfs to ${TARGETDEV}"
./install_rootfs.sh ${ROOTFS_FILE} ${TARGETDEV}
if [ ${?} -ne 0 ]
then
	echo "* rootfs installation failed"
	exit 1
fi

echo "* Updating rootconf"
UUID=`./blkuuid ${TARGETDEV}`
if [ ${?} -ne 0 ] ; then
	echo "cannot get UUID from ${TARGETDEV}"
	exit 1
fi
./update_rootconf $UUID

