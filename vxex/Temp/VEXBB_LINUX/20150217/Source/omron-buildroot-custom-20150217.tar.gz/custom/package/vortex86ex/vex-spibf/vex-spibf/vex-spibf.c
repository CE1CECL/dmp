/*
 * DMP Votex86EX SPI boot flash driver
 *
 * Author: jf TRAP <jean-francois.trap@wit.fr>
 *         Shawn Lin <shawn@dmp.com.tw>
 * Copyright (C) 2014 WIT SA.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */

#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/device.h>
#include <linux/platform_device.h>
#include <linux/mtd/mtd.h>
#include <linux/mtd/partitions.h>
#include <linux/mtd/physmap.h>
#include <linux/err.h>
#include <linux/io.h>
#include <linux/spi/spi.h>
#include <linux/spi/flash.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <asm/unaligned.h>

#define DRIVER_NAME	"vex-spibf"

#define VEX_SPIBF_NUM_CHIPSELECTS        1	// only one slave is supported

#define VEX_SPIBF_OUTPUT_REG(x)       outb_p((x), vspi->base + 0x00)
#define VEX_SPIBF_STUFFING_REG(x)     outb_p((x), vspi->base + 0x01)
#define VEX_SPIBF_INPUT_REG()         inb_p(vspi->base + 0x01)
#define VEX_SPIBF_CTRL_REG(x)         outb_p((x), vspi->base + 0x02)
#define VEX_SPIBF_CTRL_R_REG()        inb_p(vspi->base + 0x02)
#define VEX_SPIBF_STATUS_REG()        inb_p(vspi->base + 0x03)
#define VEX_SPIBF_CS_LOW()            outb_p(0, vspi->base + 0x04)
#define VEX_SPIBF_CS_HIGH()           outb_p(1, vspi->base + 0x04)
#define VEX_SPIBF_ERROR_REG()         inb_p(vspi->base + 0x05)
#define VEX_SPIBF_ERROR_CLEAR_REG(x)  outb_p((x), vspi->base + 0x05)

#define VEX_SPIBF_BUSY                 0x80
#define VEX_SPIBF_FIFO_FULL            0x40
#define VEX_SPIBF_INPUT_DATA_READY     0x20
#define VEX_SPIBF_OUTPUT_COMPLETE      0x10

#define VEX_SPIBF_CS                   0x01

#define VEX_SPIBF_CTRL_FAST_READ       0x40
#define VEX_SPIBF_CTRL_AUTO_FETCH      0x20
#define VEX_SPIBF_CTRL_FIFO_MODE       0x10
#define VEX_SPIBF_CTRL_CLOCK_DIV(x)    ((x) & 0x0f)

#define VEX_SPIBF_ERROR_BUSY           0x10
#define VEX_SPIBF_ERROR_OVERLAP        0x08
#define VEX_SPIBF_ERROR_UNDERRUN       0x04
#define VEX_SPIBF_ERROR_OVERRUN        0x02
#define VEX_SPIBF_ERROR_FETCH          0x01

#define FLASH_START		0x00000000
#define FLASH_BOOTLOADER_SIZE	0x00080000
#define FLASH_SIZE		0x00800000
#define FLASH_KERNEL_SIZE	(959 * 4096)

struct vex_spi {
	struct spi_master *master;

	struct workqueue_struct *workqueue;
	struct work_struct work;

	struct list_head queue;
	spinlock_t lock;

	u32 base;
};

/*----------------------------------------------------------------------------------------------------*/
/*	                              ACCESS READ / WRITE FLASH MEMORY                      */
/*  IMPORTANT: To get the bytes read must write to the registry " STUFFING "          */
/*----------------------------------------------------------------------------------------------------*/
static inline int
vex_spibf_write_read_byte(struct spi_device *spidev, const u8 ** tx_buf,
			      u8 ** rx_buf)
{
	struct vex_spi *vspi;
	u32 MyLoop;

	vspi = spi_master_get_devdata(spidev->master);

	if (tx_buf && *tx_buf) {
		VEX_SPIBF_OUTPUT_REG(*(*tx_buf)++);	// Emission
	} else {
		VEX_SPIBF_STUFFING_REG(0);	// Jam for reading
	}

	MyLoop = 1000;
	while ((VEX_SPIBF_STATUS_REG() & VEX_SPIBF_OUTPUT_COMPLETE) ==
	       0) {
		if (MyLoop-- == 0) {
			dev_err(&spidev->dev, "Base %x Error %x\n", vspi->base,
				VEX_SPIBF_STATUS_REG());
			break;
		}
	}

	if (rx_buf && *rx_buf) {
		*(*rx_buf)++ = VEX_SPIBF_INPUT_REG();
	}
	return 1;
}

/*----------------------------------------------------------------------------------------------------*/
/*                                 FUNCTION IN READING / WRITING                                  */
/*----------------------------------------------------------------------------------------------------*/
static unsigned int
vex_spibf_write_read(struct spi_device *spidev, struct spi_transfer *xfer)
{
	unsigned int count;
	const u8 *tx;
	u8 *rx;

	count = xfer->len;
	tx = xfer->tx_buf;
	rx = xfer->rx_buf;

	do {
		if (vex_spibf_write_read_byte(spidev, &tx, &rx) < 0) {
			goto out;
		}
		count--;
	}
	while (count);

 out:
	return xfer->len - count;
}

/*----------------------------------------------------------------------------------------------------*/
/*                                        DATA EXCHANGE OF DRIVER                               */
/*----------------------------------------------------------------------------------------------------*/
static int
vex_spibf_transfer_one_message(struct spi_master *master,
				   struct spi_message *m)
{
	struct vex_spi *vspi = spi_master_get_devdata(master);
	struct spi_device *spidev = m->spi;
	struct spi_transfer *t = NULL;
	int status = 0;
	int cs_active = 0;
	u8 MySpeedDiv;

	list_for_each_entry(t, &m->transfers, transfer_list) {

		if (((VEX_SPIBF_STATUS_REG() & VEX_SPIBF_BUSY) == 0)
		    && !cs_active) {	// SPI only when at rest and not CS
			if ((t != NULL) && t->speed_hz) {
				MySpeedDiv = 100000000 / (2 * t->speed_hz);
			} else {
				MySpeedDiv =
				    100000000 / (2 * spidev->max_speed_hz);
			}
			if (!MySpeedDiv)
				MySpeedDiv = 1;
			VEX_SPIBF_CTRL_REG((VEX_SPIBF_CTRL_R_REG() &
						0xF0) | MySpeedDiv);
		}

		if (!t->tx_buf && !t->rx_buf) {
			dev_err(&spidev->dev, "%s Tx and Rx buffer NULL\n",
				__func__);
			status = -EINVAL;
			goto msg_done;
		}

		if (!t->len) {
			dev_err(&spidev->dev, "%s Transfer length invalid\n",
				__func__);
			status = -EINVAL;
			goto msg_done;
		}
//              dev_dbg(&spidev->dev, "%s Tx/Rx buffer valid. Transfer length"
//                      " valid\n", __func__);

		if (!cs_active) {
			VEX_SPIBF_CS_LOW();
			cs_active = 1;
		}

		if (t->len) {
			m->actual_length += vex_spibf_write_read(spidev, t);
		}

		if (t->cs_change) {
			VEX_SPIBF_CS_HIGH();
			cs_active = 0;
		}
	}

 msg_done:
	if (cs_active) {
		VEX_SPIBF_CS_HIGH();
	}

	m->status = status;
	m->complete(m->context);
	return 0;
}

static void vex_spi_work(struct work_struct *work)
{
	struct vex_spi *vspi = container_of(work,
			struct vex_spi, work);

	spin_lock_irq(&vspi->lock);
	while (!list_empty(&vspi->queue)) {
		struct spi_message *msg = container_of(vspi->queue.next,
				struct spi_message, queue);

		list_del_init(&msg->queue);
		spin_unlock_irq(&vspi->lock);

		vex_spibf_transfer_one_message(vspi->master, msg);

		spin_lock_irq(&vspi->lock);
	}
    spin_unlock_irq(&vspi->lock);
}

/*----------------------------------------------------------------------------------------------------*/
/*                                        INSTALLING THE DRIVER                                     */
/*----------------------------------------------------------------------------------------------------*/
static int vex_spibf_setup(struct spi_device *spidev)
{
	struct vex_spi *vspi;
	u8 dummy;

	vspi = spi_master_get_devdata(spidev->master);

	VEX_SPIBF_CS_HIGH();
	VEX_SPIBF_CTRL_REG(0x0A | VEX_SPIBF_CTRL_AUTO_FETCH |
			       VEX_SPIBF_CTRL_FIFO_MODE);

	dummy = VEX_SPIBF_INPUT_REG();
	dummy = dummy;

	return 0;
}

/*----------------------------------------------------------------------------------------------------*/
/*                                STRUCTURE OF THE PARTITIONING FlashBoot                        */
/*----------------------------------------------------------------------------------------------------*/
static struct mtd_partition vex_spibf_partition[] = {
	{
		.name = "bootconf",
		.size = 4096,
		.offset = FLASH_START,
		.mask_flags = 0,
	},
	{
		.name = "kernel-1",
		.size = FLASH_KERNEL_SIZE,
		.offset = MTDPART_OFS_NXTBLK,
		.mask_flags = 0,
	},
	{
		.name = "kernel-2",
		.size = FLASH_KERNEL_SIZE,
		.offset = MTDPART_OFS_NXTBLK,
		.mask_flags = 0,
	},
	{
		.name = "rootconf",
		.size = 4096,
		.offset = MTDPART_OFS_NXTBLK,
		.mask_flags = 0,
	},
	{
		.name = "bootloader",
		.size = MTDPART_SIZ_FULL,	// Reserved for the bootloader size
		.offset = MTDPART_OFS_APPEND,	// Bootloader end of flash
		.mask_flags = MTD_WRITEABLE,	// Read-only partition
	}
};

/*----------------------------------------------------------------------------------------------------*/
/*                              STRUCTURE DESCRIPTION OF THE PERIPHERY FlashBoot                      */
/*----------------------------------------------------------------------------------------------------*/
static struct flash_platform_data vex_spibf_describ = {
	//.name = "mx25u6435f",
	.parts = vex_spibf_partition,
	.nr_parts = ARRAY_SIZE(vex_spibf_partition),
	//.type = "mx25u6435f",
};

/*----------------------------------------------------------------------------------------------------*/
/*                              FlashBoot STRUCTURE AS PERIPHERY                      */
/*----------------------------------------------------------------------------------------------------*/
static struct spi_board_info spibf_device[] = {
	{
	 .modalias = "m25p80",
	 .bus_num = 0,
	 .max_speed_hz = 10000000,	// 58000000 selon la Datasheet.
	 .platform_data = &vex_spibf_describ,
	 }
};

/*
 * 
 */
static int vex_spibf_transfer(struct spi_device *spid,
		struct spi_message *m)
{
	struct vex_spi *vspi;
	unsigned long flags;

	vspi = spi_master_get_devdata(spid->master);

	m->actual_length = 0;
	m->status = -EINPROGRESS;

	spin_lock_irqsave(&vspi->lock, flags);
	list_add_tail(&m->queue, &vspi->queue);
	queue_work(vspi->workqueue, &vspi->work);
	spin_unlock_irqrestore(&vspi->lock, flags);

	return 0;
}

static int register_spi_flash(struct vex_spi *vspi)
{
	unsigned char txbuf[1] = { 0x9f };
	unsigned char rxbuf[3];
	struct spi_device *sdev;
	struct spi_transfer xfer;
	struct spi_master *master = vspi->master;
	struct spi_board_info spifb_dev;
	struct flash_platform_data *spifb_desc = &vex_spibf_describ;
	int status = 0;

	memset(&spifb_dev, 0, sizeof(spifb_dev));
	spifb_dev.bus_num = 0;
	spifb_dev.max_speed_hz = 10000000;

	sdev = spi_new_device(master, &spifb_dev);

	VEX_SPIBF_CS_LOW();
	memset(&xfer, 0, sizeof(xfer));
	xfer.tx_buf = &txbuf;
	xfer.len = 1;
	vex_spibf_write_read(sdev, &xfer);

	memset(&xfer, 0, sizeof(xfer));
	xfer.rx_buf = &rxbuf;
	xfer.len = 3;
	vex_spibf_write_read(sdev, &xfer);
	VEX_SPIBF_CS_HIGH();

	spi_unregister_device(sdev);

	dev_dbg(&sdev->dev, "%x %x %x\n", rxbuf[0], rxbuf[1], rxbuf[2]);
	if (rxbuf[0] == 0xc2 && rxbuf[1] == 0x25 && rxbuf[2] == 0x37) {
		spifb_desc->name = "mx25u6435f";
		spifb_desc->type = "mx25u6435f";
		vex_spibf_partition[1].size = 959 * 4096;
		vex_spibf_partition[2].size = 959 * 4096;
		vex_spibf_partition[4].offset = 0x800000 - 0x40000;
	}
	else if (rxbuf[0] == 0xc2 && rxbuf[1] == 0x25 && rxbuf[2] == 0x38) {
		spifb_desc->name = "mx25u12835f";
		spifb_desc->type = "mx25u12835f";
		vex_spibf_partition[1].size = 2015 * 4096;
		vex_spibf_partition[2].size = 2015 * 4096;
		vex_spibf_partition[4].offset = 0x1000000 - 0x40000;
	}
	else
		status = -ENODEV;

	sdev = spi_new_device(master, spibf_device);

	return status;
}

/*----------------------------------------------------------------------------------------------------*/
/*                                          DETECTION OF DRIVER                                       */
/*----------------------------------------------------------------------------------------------------*/
static int vex_spibf_probe(struct platform_device *pdev)
{
	struct spi_master *master;
	struct vex_spi *vspi;
	struct pci_dev *pcidev;
	int status = 0;
	int size;
	u32 retval;
	u8 dummy;
	u16 MyVendorID;
	u16 MyDeviceID;

	master = spi_alloc_master(&pdev->dev, sizeof(*vspi));
	if (master == NULL) {
		dev_err(&pdev->dev, "master allocation failed\n");
		return -ENOMEM;
	}

	if (pdev->id != -1) {
		master->bus_num = pdev->id;
	}

	/* we support only mode 0, and no options */
	master->mode_bits = SPI_CPHA | SPI_CPOL;

	master->setup = vex_spibf_setup;
	master->transfer = vex_spibf_transfer;
	master->num_chipselect = VEX_SPIBF_NUM_CHIPSELECTS;
	master->bus_num = 0;

	dev_set_drvdata(&pdev->dev, master);

	vspi = spi_master_get_devdata(master);
	vspi->master = master;

	pcidev = pci_get_bus_and_slot(0, PCI_DEVFN(7, 0));
	if (pcidev == NULL) {
		dev_err(&pdev->dev, "Device 00:07.0 not found\n");	// PCI South Bridge
		return -ENODEV;
	}
	pci_read_config_word(pcidev, 0x00, &MyVendorID);
	dev_dbg(&pdev->dev, "VendorID: %04x\n", MyVendorID);
	pci_read_config_word(pcidev, 0x02, &MyDeviceID);
	dev_dbg(&pdev->dev, "DeviceID: %04x\n", MyDeviceID);

	pci_write_config_byte(pcidev, 0xC4, 0x01);	// Write Flash Enabled

	pcidev = pci_get_bus_and_slot(0, PCI_DEVFN(0, 0));	// PCI North Bridge

	if (pcidev == NULL) {
		dev_err(&pdev->dev, "Device 00:00.0 not found\n");
		return -ENODEV;
	}
	pci_read_config_word(pcidev, 0x00, &MyVendorID);
	dev_dbg(&pdev->dev, "VendorID: %04x\n", MyVendorID);
	pci_read_config_word(pcidev, 0x02, &MyDeviceID);
	dev_dbg(&pdev->dev, "DeviceID: %04x\n", MyDeviceID);

	if (pci_read_config_dword(pcidev, 0x40, &retval)) {
		dev_err(&pdev->dev, "Cannot get base address\n");
		return -EIO;
	}

	vspi->base = retval & ~0x0F;
	dev_dbg(&pdev->dev, "Base address %x\n", vspi->base);	// Debug

	if (!request_region(vspi->base, 8, dev_name(&pdev->dev))) {
		dev_err(&pdev->dev, "Cannot request io\n");
		return -EBUSY;
	}

	VEX_SPIBF_CS_HIGH();
	VEX_SPIBF_CTRL_REG(0x0A | VEX_SPIBF_CTRL_AUTO_FETCH |
			       VEX_SPIBF_CTRL_FIFO_MODE);

	dummy = VEX_SPIBF_INPUT_REG();
	dummy = dummy;

	/* init queue */
	spin_lock_init(&vspi->lock);
	INIT_LIST_HEAD(&vspi->queue);

	INIT_WORK(&vspi->work, vex_spi_work);
	vspi->workqueue = create_singlethread_workqueue(
			dev_name(master->dev.parent));
	if (vspi->workqueue == NULL) {
		status = -EBUSY;
		goto out_rel_mem;
	}

	status = spi_register_master(master);
	if (status < 0) {
		dev_err(&pdev->dev, "Cannot register SPI master\n");
		goto out_rel_mem;
	}

	status = register_spi_flash(vspi);

	return status;

out_rel_mem:
	release_region(vspi->base, 8);
	spi_master_put(master);
	return status;
}

/*----------------------------------------------------------------------------------------------------*/
/*                                          LIBERATION DU DRIVER                                      */
/*----------------------------------------------------------------------------------------------------*/
static int vex_spibf_remove(struct platform_device *pdev)
{
	struct spi_master *master;
	struct vex_spi *vspi;

	master = dev_get_drvdata(&pdev->dev);
	vspi = spi_master_get_devdata(master);

	release_region(vspi->base, 8);
	spi_unregister_master(master);

	return 0;
}

static void vex_spibf_device_release(struct device *dev)
{
}

/*----------------------------------------------------------------------------------------------------*/
/*                                    RECORD DE LA STRUCTURE DU DRIVER                                */
/*----------------------------------------------------------------------------------------------------*/
static struct platform_driver vex_spibf_driver = {
	.probe = vex_spibf_probe,
	.remove = vex_spibf_remove,
	.driver = {
		   .name = DRIVER_NAME,
		   .owner = THIS_MODULE,
		   },
};

/*----------------------------------------------------------------------------------------------------*/
/*                                  RECORD DE LA STRUCTURE DU PERIPHERIE                              */
/*----------------------------------------------------------------------------------------------------*/
static struct platform_device vex_spibf_device = {
	.name = DRIVER_NAME,
	.id = 0,
	.dev = {
		.release = vex_spibf_device_release,
		},
};

/*----------------------------------------------------------------------------------------------------*/
/*                                        CREATION DU DRIVER                                          */
/* ACTION: Enregistrement du driver et du périphérie                                                  */
/*----------------------------------------------------------------------------------------------------*/
static int __init vex_spibf_init(void)
{
	int MyResult;

	MyResult = platform_driver_register(&vex_spibf_driver);
	if (!MyResult) {
		MyResult = platform_device_register(&vex_spibf_device);
		if (MyResult) {
			platform_driver_unregister(&vex_spibf_driver);
		}
	}
	return (MyResult);
}

module_init(vex_spibf_init);

/*----------------------------------------------------------------------------------------------------*/
/*                                      SUPPRESSION DU DRIVER                                         */
/*----------------------------------------------------------------------------------------------------*/
static void __exit vex_spibf_exit(void)
{
	platform_device_unregister(&vex_spibf_device);
	platform_driver_unregister(&vex_spibf_driver);
}

module_exit(vex_spibf_exit);

/*----------------------------------------------------------------------------------------------------*/
/*                                      INFORMATION DU DRIVER                                         */
/*----------------------------------------------------------------------------------------------------*/
MODULE_AUTHOR("Shawn Lin <shawn@dmp.com.tw>");
MODULE_DESCRIPTION("Vortex86EX SPI boot flash driver");
MODULE_LICENSE("GPL");
