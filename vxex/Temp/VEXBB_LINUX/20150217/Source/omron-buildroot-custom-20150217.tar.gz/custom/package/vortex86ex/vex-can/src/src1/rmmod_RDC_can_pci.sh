#!/bin/sh
module="RDC_CAN_pci"
device="RDCCAN"
mode="664"
maxports="32"

echo -e "Unload candev module and CAN Controller driver"
modprobe -r module_RDC_CAN_pci
modprobe -r module_RDC_SocketCAN
modprobe -r module_candev

echo -e "Unload can module and can protocol"
modprobe -r module_canraw
modprobe -r module_can
