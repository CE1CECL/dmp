#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include <fcntl.h>      /* open */
//#include <unistd.h>     /* exit */
#include <sys/ioctl.h>  /* ioctl */

#include "SPtype.h"
 
int main(int argc, char** argv)
{
    int result;
    
    int i;
    
    char    devicename[64];
    int     Device_tty;
    
    FILE    *fp;
    char    cmd[100];
    char    cmdoutput[256];
    
    
    for (i = 0; i < 32; i++)
    {
        sprintf(devicename, "/sys/class/net/can%d/dev_id", i);
        
        Device_tty = open(devicename, O_RDONLY);
        if (Device_tty < 0)
        {
            printf("%s can not find \n", devicename);
        }
        else
        {
            printf("CAN%d ", i);
            sprintf(cmd, "/bin/cat /sys/class/net/can%d/drivername", i);
            fp = NULL;
            fp = popen(cmd, "r");
            if (fp == NULL)
            {
                printf("Failed to get drivername \n" );
            }
            else
            {
                /* Read the output a line at a time - output it. */
                fgets(cmdoutput, sizeof(cmdoutput), fp);
                
                printf("drivername:%s ", cmdoutput);
                
                /* close */
                pclose(fp);
                fp = NULL;
            }
            
            
            sprintf(cmd, "/bin/cat /sys/class/net/can%d/device/resources", i);
            fp = NULL;
            fp = popen(cmd, "r");
            if (fp == NULL)
            {
                printf("Failed to get resources \n" );
            }
            else
            {
                
                /* Read the output a line at a time - output it. */
                fgets(cmdoutput, sizeof(cmdoutput), fp);    // state = active
                printf("%s ", cmdoutput);
                fgets(cmdoutput, sizeof(cmdoutput), fp);    // io = 
                printf("%s ", cmdoutput);
                fgets(cmdoutput, sizeof(cmdoutput), fp);    // irq = 
                printf("%s ", cmdoutput);
                
                /* close */
                pclose(fp);
                fp = NULL;
            }
            
            printf("\n");
            
            //close(Device_tty);
        }
    }
    
    
    return 0;
}
