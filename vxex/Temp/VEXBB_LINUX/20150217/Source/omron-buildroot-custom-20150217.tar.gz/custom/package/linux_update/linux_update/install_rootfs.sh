#!/bin/sh

ROOTFS_FILE=$1
ROOTPAT=$2
                                             
if [ ! -f "${ROOTFS_FILE}" ] ; then
	echo "* ${ROOTFS_FILE} is not found"
	exit 1                               
fi

if [ ! -b "${ROOTPAT}" ] ; then
	echo "* ${ROOTPAT} is not block device"
	exit 1
fi

echo "* Formatting ${ROOTPAT}"
mkfs.ext3 -E lazy_itable_init ${ROOTPAT} >/dev/null
if [ "$?" -ne 0 ]
then
	echo "* mkfs.ext3 error!!!"
	exit 1
fi

mkdir -p /mnt/hd

echo "* Unpacking rootfs"
mount ${ROOTPAT} /mnt/hd
tar -xf ${ROOTFS_FILE} -C /mnt/hd
umount /mnt/hd

rmdir /mnt/hd

exit 0
