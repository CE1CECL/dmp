#!/bin/sh

export PATH="/sbin:/usr/sbin:$PATH"

BZIMAGE_FILE=$1

if [ ! -f "${BZIMAGE_FILE}" ] ; then
	echo "* bzimage (${BZIMAGE_FILE}) is not found"
	exit 1
fi

KPARAM=
BDEV=`./read_bootflag`

if [ "$BDEV" -eq 1 ] ; then
	echo "bootflag is 1"
elif [ "$BDEV" -eq 2 ]; then
	echo "bootflag is 2"
else
	echo "* Cannot get proper bootflag"
	exit 1
fi

rm -f ${BZIMAGE_FILE}.elf ${BZIMAGE_FILE}.self
./mkelfImage --append=${KPARAM} ${BZIMAGE_FILE} ${BZIMAGE_FILE}.elf
./convert_simple_elf ${BZIMAGE_FILE}.elf ${BZIMAGE_FILE}.self

echo "* Installing new kernel"
./install_kernel ${BZIMAGE_FILE}.self
if [ "$?" -ne 0 ]
then
	echo "* kernel update failed"
	exit 1
fi

echo "* Updating bootconf"
./update_bootconf
