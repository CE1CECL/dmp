#!/bin/sh
module="RDC_CAN_pnp"
device="RDCCAN"
mode="664"
maxports="32"

echo -e "Unload candev module and CAN Controller driver"
rmmod module_RDC_CAN_pnp
rmmod module_RDC_SocketCAN
rmmod module_candev

echo -e "Unload can module and can protocol"
rmmod module_canraw
rmmod module_can
