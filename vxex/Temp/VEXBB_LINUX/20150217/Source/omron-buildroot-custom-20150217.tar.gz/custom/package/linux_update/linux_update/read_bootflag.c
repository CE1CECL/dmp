#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <mtd/mtd-user.h>

#define MTD_BOOTCONF_NAME "/dev/mtd0"

struct omron_bootconf {
	unsigned char boot_flag; 
	unsigned char trial_run;
	unsigned char trial_run_start;
} __attribute__((packed));

static int bconf_fd = -1;

static void cleanup(void)
{
	if (bconf_fd > 0)
		close(bconf_fd);
}

int main(int argc, char *argv[])
{
	ssize_t result;
	struct omron_bootconf obconf;

	atexit(cleanup);

	if ((bconf_fd = open(MTD_BOOTCONF_NAME, O_RDWR)) < 0) {
		printf("open mtd-bootconf failed\n");
		exit(EXIT_FAILURE);
	}

	result = read(bconf_fd, &obconf, sizeof(obconf));
	if (result < sizeof(obconf)) {
		printf("read mtd-bootconf failed\n");
		exit(EXIT_FAILURE);
	}

	if (obconf.boot_flag == 1)
		printf("1\n");
	else if (obconf.boot_flag == 2)
		printf("2\n");
	else {
		printf("boot_flag is not 1 or 2\n");
		exit(EXIT_FAILURE);
	}

	exit(EXIT_SUCCESS);
}
