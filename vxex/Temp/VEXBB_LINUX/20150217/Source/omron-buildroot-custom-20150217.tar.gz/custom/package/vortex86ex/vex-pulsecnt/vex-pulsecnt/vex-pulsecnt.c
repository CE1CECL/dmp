/*
 * Vortex86EX Pulse-Counter Driver
 *
 * Copyright (C) 2014 DMP Electronics Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */

/*
 * PulseIn0: MC0, SIFB
 * PulseIn1: MC0, SIFA
 * PulseIn2: MC3, SIFB
 */
#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/err.h>
#include <linux/file.h>
#include <linux/spinlock.h>
#include <linux/io.h>
#include <linux/cdev.h>
#include <linux/interrupt.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/sched.h>
#include <linux/poll.h>

#define DEBUG 1
#include <linux/pci.h>
#include <linux/platform_device.h>

/* for testing */
#define _PWM_OUTPUT

#define VEXMC_REG_MCMODE	0x00
#define VEXMC_REG_MEN1		0x08
#define VEXMC_REG_MEN2		0x0C
#define VEXMC_REG_INTMNS	0x38
#define VEXMC_REG_IS		0x3A

/* Common registers of modules */
#define VEXMC_REG_MOD_IE	0x00
#define VEXMC_REG_MOD_IS	0x04

/* Mode.SIF = Pulse/DIR */
#define VEXMC_REG_SIF_CTRL	0x00
#define VEXMC_REG_SIF_PULSECNT	0x0C
#define VEXMC_REG_SIF_CNTMIN	0x10
#define VEXMC_REG_SIF_CNTMAX	0x14
#define VEXMC_REG_SIF_CNTCTRL	0x20
#define VEXMC_REG_SIF_INSTAT	0x28
#define VEXMC_REG_SIF_CAPCTRL	0x2C
#define VEXMC_REG_SIF_CAPFIFO	0x30

#ifdef _PWM_OUTPUT
#define VEXMC0_BASE		0x40
#define VEXMC1_BASE		0x110
#define VEXMC2_BASE		0x1E0
#define VEXMC3_BASE		0x2B0

#define VEXMC_REG_PWMA_IE	0x00
#define VEXMC_REG_PWMB_IE	0x01
#define VEXMC_REG_PWMC_IE	0x02
#define VEXMC_REG_PWMA_IS	0x04
#define VEXMC_REG_PWMB_IS	0x05
#define VEXMC_REG_PWMC_IS	0x06

#define VEXMC_REG_PWMA_PERWID	0x08
#define VEXMC_REG_PWMA_PHA0WID	0x0C
#define VEXMC_REG_PWMA_CTRLNSAM 0x10
#define VEXMC_REG_PWMA_OUTCTRL  0x24
#define VEXMC_REG_PWMA_RLCTRL   0x30

#define VEXMC_REG_PWMB_PERWID	0x34
#define VEXMC_REG_PWMB_PHA0WID	0x38
#define VEXMC_REG_PWMB_CTRLNSAM 0x3C
#define VEXMC_REG_PWMB_OUTCTRL  0x50
#define VEXMC_REG_PWMB_RLCTRL   0x5C

#define VEXMC_REG_PWMC_PERWID	0x60
#define VEXMC_REG_PWMC_PHA0WID	0x64
#define VEXMC_REG_PWMC_CTRLNSAM 0x68
#define VEXMC_REG_PWMC_OUTCTRL  0x7C
#define VEXMC_REG_PWMC_RLCTRL   0x88
#endif

enum vexmc_addr {
	GEN = 0x00,
	MC0 = 0x40,
	MC1 = 0x110,
	MC2 = 0x1E0,
	MC3 = 0x2B0,
};

enum vexmc_module_addr {
	NONE     = 0x00,
	INT      = 0x00,
	PWMA     = 0x08,
	PWMB     = 0x34,
	PWMC     = 0x60,
	SERVOA   = 0x08,
	SERVOB   = 0x34,
	SERVOC   = 0x60,
	SERVOEXT = 0xC0,
	SIFA     = 0x08,
	SIFB     = 0x8C,
};

#define DRIVER_NAME "vex-pulsecnt"

struct vex_pi {
	struct	cdev cdev;
	dev_t	devnum;

	u32	iobase;
	u32	membase;
	char	irq;

	char __iomem *vmem;

	struct vex_pi_data *pidata[3];

	struct	platform_device *pdev;
	struct	pci_dev *pcidev;

	spinlock_t open_lock;
	spinlock_t data_lock;
};

struct vex_pi_data {
	u32	pulse_cnt_hw;

	/* 28-bit hardware timer */
	u32	new_timer;
	u32	last_timer;
	u32	timer_ov; // timer overflow

	/* 30 depth fifo overflow */
	u32	timer_fifo_ov;

	/* vex_pi_pulse_data */
	u64	pulse_cnt;
	u64	timer;
	char	updated;

	struct vex_pi *vexpi;

	wait_queue_head_t waitq;

	enum vexmc_addr mcaddr;
	enum vexmc_module_addr modaddr;
};

static struct class *vexpi_class;
static int vex_pi_major;

static void vexmc_write(struct vex_pi *vexpi, enum vexmc_addr mcaddr,
			enum vexmc_module_addr modaddr, u8 offset, u32 val)
{
	u8 *vmem = vexpi->vmem;
	u32 addr;

	addr = mcaddr + modaddr + offset;

	iowrite32(val, vmem + addr); 
}

static u32 vexmc_read(struct vex_pi *vexpi, enum vexmc_addr mcaddr,
		      enum vexmc_module_addr modaddr, u8 offset)
{
	u8 *vmem = vexpi->vmem;
	u32 addr;

	addr = mcaddr + modaddr + offset;

	return ioread32(vmem + addr); 
}

static int update_pulse_data(struct vex_pi_data *pidata)
{
	u8 fcnt;
	u8 capev;
	u32 reg;
	struct vex_pi *vexpi = pidata->vexpi;
	enum vexmc_addr mcaddr = pidata->mcaddr;
	enum vexmc_module_addr modaddr = pidata->modaddr;

	if (pidata == NULL)
		return -EFAULT;

	reg = vexmc_read(vexpi, mcaddr, modaddr, VEXMC_REG_SIF_INSTAT) & 0x03;
	/* Capture FIFO empty */
	if (reg == 0x03)
		return 0;
	/* Capture FIFO overflow */
	if (reg == 0x02)
		pidata->timer_fifo_ov += 1;

	fcnt = 30;
	while (fcnt--) {
		reg = vexmc_read(vexpi, mcaddr, modaddr, VEXMC_REG_SIF_CAPFIFO);
		capev = reg >> 28;

		/* Capture timer overflow */
		if (capev == 0x08) {
			pidata->timer_ov += 1;
		}
		/* pulse counter falling edge or pulse counter overflow */
		else if ((capev == 0x00) || (capev == 0x05) ||
				(capev == 0x0a)) {
			while (pidata->timer_ov > 0) {
				pidata->timer += 0x10000000 - pidata->new_timer;
				pidata->last_timer = 0;
				pidata->new_timer = 0;

				pidata->timer_ov -= 1;
			}

			pidata->pulse_cnt += 1;
			pidata->last_timer = pidata->new_timer;
			pidata->new_timer = reg & 0x0fffffff;
			pidata->timer += pidata->new_timer - pidata->last_timer;

			pidata->updated = 1;
		}
		/* Capture FIFO is empty */
		else if (capev == 0x0f) {
			break;
		}
	}

#if 1
	/* store hareware pulse counter */
	reg = vexmc_read(vexpi, mcaddr, modaddr,
			VEXMC_REG_SIF_PULSECNT);
	pidata->pulse_cnt_hw = reg;
#endif

	if (pidata->updated == 1)
		wake_up_interruptible(&pidata->waitq);

	return 0;
}

static irqreturn_t vex_pi_isr(int irq, void *data)
{
	struct vex_pi *vexpi = data;
	struct vex_pi_data *pidata;
	u32 reg;
	u16 mc_intmask;

	reg = vexmc_read(vexpi, GEN, NONE, VEXMC_REG_INTMNS);
	mc_intmask = reg & 0x0f;

	/* MC Interrupt Status */
	reg = reg >> 16;

	if (!(reg & 0x0f))
		return IRQ_NONE;

	/* Mask all interrupts */
	vexmc_write(vexpi, GEN, NONE, VEXMC_REG_INTMNS, 0x0f);

	/*
	 * After handle interrupt, it needs to clear interrupt status
	 *
	 * MC0 Interrupt happended
	 */
	if (reg & 0x01) {
		reg = vexmc_read(vexpi, MC0, INT, VEXMC_REG_MOD_IS);
		/* SIFA interrupt status */
		if ((reg & 0x00000020) && (vexpi->pidata[1] != NULL)) {
			pidata = vexpi->pidata[1];

			update_pulse_data(pidata);

			vexmc_write(vexpi, pidata->mcaddr, INT,
					VEXMC_REG_MOD_IS, 0x00000020);
		}
		/* SIFB interrupt status */
		if ((reg & 0x20000000) && (vexpi->pidata[0] != NULL)) {
			pidata = vexpi->pidata[0];

			update_pulse_data(pidata);

			vexmc_write(vexpi, pidata->mcaddr, INT,
					VEXMC_REG_MOD_IS, 0x20000000);
		}
	}

	/* MC3 Interrupt happended */
	if (reg & 0x08) {
		reg = vexmc_read(vexpi, MC3, INT, VEXMC_REG_MOD_IS);
		/* SIFB interrupt status */
		if ((reg & 0x20000000) && (vexpi->pidata[2] != NULL)) {
			pidata = vexpi->pidata[2];

			update_pulse_data(pidata);

			vexmc_write(vexpi, pidata->mcaddr, INT,
					VEXMC_REG_MOD_IS, 0x20000000);
		}
	}

	/* Restore MC Interrupt Mask */
	vexmc_write(vexpi, GEN, NONE, VEXMC_REG_INTMNS, mc_intmask);

	return IRQ_HANDLED;
}

static void vex_pi_setup(struct vex_pi *vexpi)
{
	u32 reg;

	/* Disable Sensor Interface A,B of MC-0,3 */
	vexmc_write(vexpi, GEN, NONE, VEXMC_REG_MEN1, 0);
	vexmc_write(vexpi, GEN, NONE, VEXMC_REG_MEN2, 0);

	/* Set Motion Controller Mode */
	vexmc_write(vexpi, GEN, NONE, VEXMC_REG_MCMODE, 0x00003005);

#ifdef _PWM_OUTPUT
	/*
	 * Configure PWM for testing
	 */
	{
	u8 *vmem = vexpi->vmem;
	iowrite32(0x800007d0, vmem + VEXMC3_BASE + VEXMC_REG_PWMA_CTRLNSAM);
	iowrite32(0x30000000, vmem + VEXMC3_BASE + VEXMC_REG_PWMA_OUTCTRL);
	iowrite32(1000000, vmem + VEXMC3_BASE + VEXMC_REG_PWMA_PERWID);
	iowrite32(500000, vmem + VEXMC3_BASE + VEXMC_REG_PWMA_PHA0WID);
	iowrite32(0x10700000, vmem + VEXMC3_BASE + VEXMC_REG_PWMA_RLCTRL);

	iowrite32(0x800007d0, vmem + VEXMC3_BASE + VEXMC_REG_PWMB_CTRLNSAM);
	iowrite32(0x30000000, vmem + VEXMC3_BASE + VEXMC_REG_PWMB_OUTCTRL);
	iowrite32(2000000, vmem + VEXMC3_BASE + VEXMC_REG_PWMB_PERWID);
	iowrite32(500000, vmem + VEXMC3_BASE + VEXMC_REG_PWMB_PHA0WID);
	iowrite32(0x10700000, vmem + VEXMC3_BASE + VEXMC_REG_PWMB_RLCTRL);

	iowrite32(0x800007d0, vmem + VEXMC3_BASE + VEXMC_REG_PWMC_CTRLNSAM);
	iowrite32(0x30000000, vmem + VEXMC3_BASE + VEXMC_REG_PWMC_OUTCTRL);
	iowrite32(3000000, vmem + VEXMC3_BASE + VEXMC_REG_PWMC_PERWID);
	iowrite32(500000, vmem + VEXMC3_BASE + VEXMC_REG_PWMC_PHA0WID);
	iowrite32(0x10700000, vmem + VEXMC3_BASE + VEXMC_REG_PWMC_RLCTRL);

	vexmc_write(vexpi, GEN, NONE, VEXMC_REG_MEN1, 0x0e00);
	}
#endif
}

static int vex_pi_enable(struct vex_pi *vexpi, int pif)
{
	u32 reg;
	enum vexmc_addr mcaddr;
	enum vexmc_module_addr modaddr;
	u32 mcen1 = 0, mcen2 = 0;
	u32 mcmod_ie = 0, mcint_mask = 0;

	switch (pif) {
	case 0:
		mcaddr       = MC0;
		modaddr      = SIFB;
		mcen2        = 0x10;
		mcmod_ie     = 0x20000000;
		mcint_mask   = 0x01;
		break;
	case 1:
		mcaddr       = MC0;
		modaddr      = SIFA;
		mcen1        = 0x01;
		mcmod_ie     = 0x20;
		mcint_mask   = 0x01;
		break;
	case 2:
		mcaddr       = MC3;
		modaddr      = SIFB;
		mcen2        = 0x80; 
		mcmod_ie     = 0x20000000;
		mcint_mask   = 0x08;
		break;
	default:
		return -EFAULT;
	}

	vexpi->pidata[pif]->mcaddr  = mcaddr;
	vexpi->pidata[pif]->modaddr = modaddr;

	/*
	 * Set Sensor Interface Mode to 'Pulse/DIR Encoder'
	 * The pulse counter increases at every falling edge of pulse input
	 */
	vexmc_write(vexpi, mcaddr, modaddr, VEXMC_REG_SIF_CTRL, 0x00000200);
	vexmc_write(vexpi, mcaddr, modaddr, VEXMC_REG_SIF_PULSECNT, 0);
	vexmc_write(vexpi, mcaddr, modaddr, VEXMC_REG_SIF_CNTCTRL, 0x00005511);
	vexmc_write(vexpi, mcaddr, modaddr, VEXMC_REG_SIF_CNTMAX, 0xffffffff);
	vexmc_write(vexpi, mcaddr, modaddr, VEXMC_REG_SIF_CNTMIN, 0x00000000);
	vexmc_write(vexpi, mcaddr, modaddr, VEXMC_REG_SIF_CAPCTRL, 0x00010801);

	/*
	 * Enable Sensor Interface A, B of MC0
	 * Enable Sensor Interface B of MC3
	 */
	if (mcen1) {
		reg = vexmc_read(vexpi, GEN, NONE, VEXMC_REG_MEN1);
		vexmc_write(vexpi, GEN, NONE, VEXMC_REG_MEN1, reg | mcen1);
	}
	if (mcen2) {
		reg = vexmc_read(vexpi, GEN, NONE, VEXMC_REG_MEN2);
		vexmc_write(vexpi, GEN, NONE, VEXMC_REG_MEN2, reg | mcen2);
	}

	/* Enable Interrupt */
	reg = vexmc_read(vexpi, mcaddr, INT, VEXMC_REG_MOD_IE);
	vexmc_write(vexpi, mcaddr, INT, VEXMC_REG_MOD_IE, reg | mcmod_ie);

	/* Unmask interrupts */
	reg = vexmc_read(vexpi, GEN, NONE, VEXMC_REG_INTMNS);
	reg = reg & ~mcint_mask;
	vexmc_write(vexpi, GEN, NONE, VEXMC_REG_INTMNS, reg);

	return 0;
}

static int vex_pi_disable(struct vex_pi *vexpi, int pif)
{
	u32 reg;
	enum vexmc_addr mcaddr;
	enum vexmc_module_addr modaddr;
	u32 mcen1 = 0, mcen2 = 0;
	u32 mcmod_ie = 0, mcint_mask = 0;

	switch (pif) {
	case 0:
		mcaddr       = MC0;
		modaddr      = SIFB;
		mcen2        = 0x10;
		mcmod_ie     = 0x20000000;
		mcint_mask   = 0x01;
		break;
	case 1:
		mcaddr       = MC0;
		modaddr      = SIFA;
		mcen1        = 0x01;
		mcmod_ie     = 0x20;
		mcint_mask   = 0x01;
		break;
	case 2:
		mcaddr       = MC3;
		modaddr      = SIFB;
		mcen2        = 0x80; 
		mcmod_ie     = 0x20000000;
		mcint_mask   = 0x08;
		break;
	default:
		return -EFAULT;
	}

	/* Mask interrupts */
	reg = vexmc_read(vexpi, GEN, NONE, VEXMC_REG_INTMNS);
	reg = reg | mcint_mask;
	vexmc_write(vexpi, GEN, NONE, VEXMC_REG_INTMNS, reg);

	/* Disable Interrupt */
	reg = vexmc_read(vexpi, mcaddr, INT, VEXMC_REG_MOD_IE);
	vexmc_write(vexpi, mcaddr, INT, VEXMC_REG_MOD_IE, reg & ~mcmod_ie);

	/*
	 * Disable Sensor Interface A, B of MC0
	 * Disable Sensor Interface B of MC3
	 */
	if (mcen1) {
		reg = vexmc_read(vexpi, GEN, NONE, VEXMC_REG_MEN1);
		vexmc_write(vexpi, GEN, NONE, VEXMC_REG_MEN1, reg & ~mcen1);
	}
	if (mcen2) {
		reg = vexmc_read(vexpi, GEN, NONE, VEXMC_REG_MEN2);
		vexmc_write(vexpi, GEN, NONE, VEXMC_REG_MEN2, reg & ~mcen2);
	}

	return 0;
}

static int vex_pi_open(struct inode *inode, struct file *filp)
{
	struct vex_pi *vexpi;
	struct vex_pi_data *pidata;
	int ret = 0;
	int pif;

	pif = iminor(inode);

	vexpi = container_of(inode->i_cdev, struct vex_pi, cdev);

	pidata = kzalloc(sizeof(*pidata), GFP_KERNEL);
	if (!pidata)
		return -ENOMEM;

	pidata->vexpi = vexpi;
	filp->private_data = pidata;

	dev_dbg(&vexpi->pdev->dev, "minor: 0x%x\n", pif);

	spin_lock(&vexpi->open_lock);

	if (vexpi->pidata[pif] == NULL) {
		init_waitqueue_head(&pidata->waitq);
		vexpi->pidata[pif] = pidata;
		ret = vex_pi_enable(vexpi, pif);
	}
	else {
		kfree(pidata);
		ret = -EBUSY;
	}

	spin_unlock(&vexpi->open_lock);

	return ret;
}

static int vex_pi_close(struct inode *inode, struct file *filp)
{
	int pif;
	struct vex_pi *vexpi;
	struct vex_pi_data *pidata;
	int ret = 0;

	pif = iminor(inode);
	vexpi = container_of(inode->i_cdev, struct vex_pi, cdev);

	spin_lock(&vexpi->open_lock);

	ret = vex_pi_disable(vexpi, pif);
	pidata = filp->private_data;
	vexpi->pidata[pif] = NULL;

	spin_unlock(&vexpi->open_lock);

	kfree(pidata);

	return ret;
}

static ssize_t vex_pi_read(struct file *filp, char __user *buf, size_t len, loff_t *offset)
{
	struct vex_pi_data *pidata = filp->private_data;
	unsigned long flags;
	u64 data[2];
	u32 pcnthw;

	if ((pidata->updated == 0) && (filp->f_flags & O_NONBLOCK))
		return -EAGAIN;

	wait_event_interruptible(pidata->waitq, pidata->updated != 0);

	spin_lock_irqsave(&pidata->vexpi->data_lock, flags);

	data[0] = pidata->pulse_cnt;
	data[1] = pidata->timer;
	pcnthw  = pidata->pulse_cnt_hw;
	pidata->updated = 0;

	spin_unlock_irqrestore(&pidata->vexpi->data_lock, flags);

#if 1
	if (copy_to_user(buf, &pcnthw, sizeof(u32)))
		return -EFAULT;
	return sizeof(u32);
#else
	if (copy_to_user(buf, &data[0], sizeof(u64)*2))
		return -EFAULT;
	return sizeof(u64) * 2;
#endif
}

static unsigned int vex_pi_poll(struct file *filp, poll_table *wait)
{
	struct vex_pi_data *pidata = filp->private_data;
	unsigned int mask = 0;

	poll_wait(filp, &pidata->waitq, wait);

	if (pidata->updated == 1)
		mask = POLLIN | POLLRDNORM;

	return mask;
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,35)
static int vex_pi_ioctl(struct inode *inode, struct file *filp,
	unsigned int cmd, unsigned long arg)
{
	int ret;
	struct vex_pi *vexpi = filp->private_data;

	switch (cmd) {
	default:
		ret = -ENOTTY;
	}

	return ret;
}
#endif

static struct file_operations vex_pi_ops = {
	.owner   = THIS_MODULE,
	.llseek  = no_llseek,
	.open    = vex_pi_open,
	.release = vex_pi_close,
	.read    = vex_pi_read,
	.poll    = vex_pi_poll,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,35)
	//.ioctl   = vex_pi_ioctl,
#endif
};

static int vex_pi_probe(struct platform_device *pdev)
{
	struct pci_dev *pcidev;
	struct vex_pi  *vexpi;
	u32	retval;
	int	error;
	int	minor;

	vexpi = kzalloc(sizeof(*vexpi), GFP_KERNEL);
	if (!vexpi) {
		error = -ENOMEM;
		goto err_kzalloc;
	}

	vexpi->pdev = pdev;
	spin_lock_init(&vexpi->open_lock);
	spin_lock_init(&vexpi->data_lock);

	platform_set_drvdata(pdev, vexpi);

	pcidev = pci_get_bus_and_slot(0, PCI_DEVFN(16,0));
	if (pcidev == NULL) {
		dev_err(&pdev->dev, "Device 00:16.0 not found\n");
		error = -ENODEV;
		goto err_find_pci_dev;
	}
	vexpi->pcidev = pcidev;

	/* get IO memory base address */
	if (pci_read_config_dword(pcidev, 0x14, &retval)) {
		dev_err(&pdev->dev, "Cannot get base address\n");
		error = -EIO;
		goto err_get_pci_reg;
	}
	vexpi->membase = retval;
	dev_dbg(&pdev->dev, "Base address %x\n", vexpi->membase);

	/* get IRQ line number */
	if (pci_read_config_dword(pcidev, 0x3C, &retval)) {
		dev_err(&pdev->dev, "Cannot get base address\n");
		error = -EIO;
		goto err_get_pci_reg;
	}
	vexpi->irq = retval & 0xff;
	dev_dbg(&pdev->dev, "IRQ %u\n", vexpi->irq);

	if (!request_mem_region(vexpi->membase, 0x3ff, DRIVER_NAME)) {
		dev_err(&pdev->dev, "Request memory region error\n");
		error = -EBUSY;
		goto err_request_mem_region;
	}

	vexpi->vmem = pci_iomap(pcidev, 1, 0);
	if (vexpi->vmem == NULL) {
		dev_err(&pdev->dev, "Remap io memory address failed\n");
		error = -ENOMEM;
		goto err_ioremap;
	}

	error = request_irq(vexpi->irq, vex_pi_isr, IRQF_SHARED,
		DRIVER_NAME, vexpi);
	if (error) {
		dev_err(&pdev->dev, "failed to get irq\n");
		goto err_request_irq;
	}

	error = alloc_chrdev_region(&vexpi->devnum, 0, 3, DRIVER_NAME);
	if (error < 0) { 
		dev_err(&pdev->dev, "Register devices failed\n");
		goto err_alloc_chrdev_region;
	}

	vex_pi_major = MAJOR(vexpi->devnum);

	cdev_init(&vexpi->cdev, &vex_pi_ops);
	vexpi->cdev.owner = THIS_MODULE;
	error = cdev_add(&vexpi->cdev, MKDEV(vex_pi_major, 0), 3);
	if (error) {
		dev_err(&pdev->dev, "Could not add cdev\n");
		goto err_cdev_add;
	}

	vexpi_class = class_create(THIS_MODULE, DRIVER_NAME);
	if (IS_ERR(vexpi_class)) {
		dev_err(&pdev->dev, "Could not create class\n");
		error = PTR_ERR(vexpi_class);
		goto err_class_create;
	}

	for (minor = 0; minor < 3; minor++) {
		struct device *dev;
		dev = device_create(vexpi_class, &pdev->dev,
		                    MKDEV(vex_pi_major, minor),
		                    NULL, "vex_pcnt%u", minor);
		if (IS_ERR(dev)) {
			dev_err(&pdev->dev, "Could not create device files\n");
			error = PTR_ERR(dev);
			goto err_device_create;
		}
	}

	vex_pi_setup(vexpi);

	return 0;

err_device_create:
	class_destroy(vexpi_class);
err_class_create:
	cdev_del(&vexpi->cdev);
err_cdev_add:
	unregister_chrdev_region(MKDEV(vex_pi_major, 0), 3);
err_alloc_chrdev_region:
	free_irq(vexpi->irq, vexpi);
err_request_irq:
	pci_iounmap(pcidev, vexpi->vmem);
err_ioremap:
	release_mem_region(vexpi->membase, 0x3ff);
err_request_mem_region:
err_get_pci_reg:
err_find_pci_dev:
	kfree(vexpi);
err_kzalloc:
	return error;
}

/*
 *
 */

static int vex_pi_remove(struct platform_device *pdev)
{
	struct vex_pi *vexpi;
	int i, minor;

	vexpi = platform_get_drvdata(pdev);

	minor = MINOR(vexpi->cdev.dev);
	for (i = minor; i < minor + 3; i++) {
		device_destroy(vexpi_class, MKDEV(vex_pi_major, i));
	}

	class_destroy(vexpi_class);
	cdev_del(&vexpi->cdev);
	unregister_chrdev_region(MKDEV(vex_pi_major, 0), 3);

	free_irq(vexpi->irq, vexpi);
	pci_iounmap(vexpi->pcidev, vexpi->vmem);
	release_mem_region(vexpi->membase, 0x3ff);
	kfree(vexpi);

	return 0;
}

static void vex_pi_device_release(struct device *dev)
{
}

static struct platform_driver vex_pi_driver = {
	.probe  = vex_pi_probe,
	.remove = vex_pi_remove,
	.driver = {
		.name  = DRIVER_NAME,
		.owner = THIS_MODULE,
	},
};

static struct platform_device vex_pi_device = {
	.name = DRIVER_NAME,
	.id   = 0,
	.dev  = {
		.release = vex_pi_device_release,
	},
};

static int __init vex_pi_init(void)
{
	int ret;

	ret = platform_driver_register(&vex_pi_driver);
	if (!ret) {
		ret = platform_device_register(&vex_pi_device);
		if (ret) {
			platform_driver_unregister(&vex_pi_driver);
		}
	}

	return(ret);
}

static void __exit vex_pi_exit(void)
{
	platform_device_unregister(&vex_pi_device);
	platform_driver_unregister(&vex_pi_driver);
}

module_init(vex_pi_init);
module_exit(vex_pi_exit);

MODULE_DESCRIPTION("Vortex86EX pulse counter driver");
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Shawn Lin <shawn@dmp.com.tw>");
