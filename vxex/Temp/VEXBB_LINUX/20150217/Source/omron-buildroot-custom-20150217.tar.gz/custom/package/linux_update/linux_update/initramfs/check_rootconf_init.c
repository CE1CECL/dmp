#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <mtd/mtd-user.h>

#define MTD_ROOTCONF_NAME "/dev/mtd3"

struct omron_rootconf {
	unsigned char trial_run;
	unsigned char trial_run_notify;
	unsigned char reserved[2];
	unsigned char uuid[37];
	unsigned char old_uuid[37];
} __attribute__((packed));

static int rconf_fd = -1;

static void cleanup(void)
{
	if (rconf_fd > 0)
		close(rconf_fd);
}

int rootconf_read(int fd, struct omron_rootconf *rconf)
{
	ssize_t result;

	if (lseek(fd, 0, SEEK_SET) < 0) {
		printf("rewind mtd-rootconf error");
		return -1;
	}

	result = read(fd, rconf, sizeof(*rconf));
	if (result < sizeof(*rconf)) {
		printf("read mtd-rootconf failed\n");
		return -1;
	}

	return 0;
}

int rootconf_write(int fd, struct omron_rootconf *rconf, unsigned int size)
{
	ssize_t result;

	if (lseek(fd, 0, SEEK_SET) < 0) {
		printf("rewind mtd-rootconf error");
		return -1;
	}

	result = write(fd, rconf, size);
	if (result != size) {
		printf("write mtd-rootconf failed\n");
		return -1;
	}

	return 0;
}

int rootconf_verify(struct omron_rootconf *old_rconf, struct omron_rootconf *new_rconf)
{
	if (memcmp(old_rconf, new_rconf, sizeof(*old_rconf))) {
		printf("mtd-rootconf mismatch found\n");
		return -1;
	}

	return 0;
}

int main(int argc, char *argv[])
{
	struct mtd_info_user mtd;
	struct erase_info_user erase;
	struct omron_rootconf ori_rconf, mod_rconf;

	atexit(cleanup);

	if ((rconf_fd = open(MTD_ROOTCONF_NAME, O_RDWR)) < 0) {
		printf("open mtd-rootconf failed\n");
		exit(EXIT_FAILURE);
	}

	if (rootconf_read(rconf_fd, &ori_rconf)) {
		exit(EXIT_FAILURE);
	}
	memcpy(&mod_rconf, &ori_rconf, sizeof(ori_rconf));

	/* no need to change rootconf if there is no trial_run
	 * we do not deal with the undefined condition
	 *   (ori_rconf.trial_run == 0 && ori_rconf.trial_run_notify == 1)
	 */
	if (ori_rconf.trial_run == 0)
		exit(EXIT_SUCCESS);

	/* get mtd information */
	if (ioctl(rconf_fd, MEMGETINFO, &mtd) < 0) {
		printf("cannot get meminfo of mtd-rootconf\n");
		exit(EXIT_FAILURE);
	}

	/* if trial_run and trial_run_notify are set,
	 * clear trial_run_notify for next stage.
	 * only update first two field.
	 */
	if (ori_rconf.trial_run == 1 && ori_rconf.trial_run_notify == 1) {
		mod_rconf.trial_run = 1;
		mod_rconf.trial_run_notify = 0;

		if (rootconf_write(rconf_fd, &mod_rconf, 2))
			exit(EXIT_FAILURE);
	}

	/* rootfs update failed
	 * reset all flags and replace uuid with old uuid
	 * if (ori_rconf.trial_run == 1 && ori_rconf.trial_run_notify == 0)
	 */
	else {
		mod_rconf.trial_run = 0;
		mod_rconf.trial_run_notify = 0;
		memcpy(&mod_rconf.uuid, &mod_rconf.old_uuid, sizeof(mod_rconf.uuid));

		/* erase before write */
		erase.start = 0;
		erase.length = mtd.erasesize;
		if (ioctl(rconf_fd, MEMERASE, &erase) < 0) {
			printf("erase mtd-kernel block error\n");
			exit(EXIT_FAILURE);
		}

		if (rootconf_write(rconf_fd, &mod_rconf, sizeof(mod_rconf)))
			exit(EXIT_FAILURE);
	}

	/* read rootconf for verify data is written */
	if (rootconf_read(rconf_fd, &ori_rconf))
		exit(EXIT_FAILURE);

	/* if verify failed, erase, rewrite rootconf and check again */
	if (rootconf_verify(&ori_rconf, &mod_rconf)) {
		erase.start = 0;
		erase.length = mtd.erasesize;
		if (ioctl(rconf_fd, MEMERASE, &erase) < 0) {
			printf("erase mtd-kernel block error\n");
			exit(EXIT_FAILURE);
		}
		if (rootconf_write(rconf_fd, &mod_rconf, sizeof(mod_rconf)))
			exit(EXIT_FAILURE);
		if (rootconf_read(rconf_fd, &ori_rconf))
			exit(EXIT_FAILURE);
		if (rootconf_verify(&ori_rconf, &mod_rconf))
			exit(EXIT_FAILURE);
	}

	exit(EXIT_SUCCESS);
}
