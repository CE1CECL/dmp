#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

#define MTD_ROOTCONF_NAME "/dev/mtd3"

struct omron_rootconf {
	unsigned char trial_run;
	unsigned char trial_run_notify;
	unsigned char reserved[2];
	unsigned char uuid[37];
	unsigned char old_uuid[37];
} __attribute__((packed));

static int rconf_fd = -1;

static void cleanup(void)
{
	if (rconf_fd > 0)
		close(rconf_fd);
}

static int rootconf_read(int fd, struct omron_rootconf *rconf)
{
	ssize_t result;

	if (lseek(fd, 0, SEEK_SET) < 0) {
		printf("rewind mtd-rootconf error");
		return -1;
	}

	result = read(fd, rconf, sizeof(*rconf));
	if (result < sizeof(*rconf)) {
		printf("read mtd-rootconf failed\n");
		return -1;
	}

	return 0;
}

int main(int argc, char *argv[])
{
	struct omron_rootconf rootconf;
	unsigned char *uuid;

	atexit(cleanup);

	if ((rconf_fd = open(MTD_ROOTCONF_NAME, O_RDONLY)) < 0) {
		printf("open mtd-rootconf failed\n");
		exit(EXIT_FAILURE);
	}

	if (rootconf_read(rconf_fd, &rootconf))
		exit(EXIT_FAILURE);

	if (rootconf.uuid[36] != '\0') {
		printf("invalid UUID in mtd-rootconf\n");
		exit(EXIT_FAILURE);
	}

	uuid = &rootconf.uuid[0];
	printf("%s\n", uuid);

	exit(EXIT_SUCCESS);
}
