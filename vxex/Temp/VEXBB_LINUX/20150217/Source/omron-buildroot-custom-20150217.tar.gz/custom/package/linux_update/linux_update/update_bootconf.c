#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <mtd/mtd-user.h>

#define MTD_BOOTCONF_NAME "/dev/mtd0"

struct omron_bootconf {
	unsigned char boot_flag; 
	unsigned char trial_run;
	unsigned char trial_run_start;
} __attribute__((packed));

static int bconf_fd = -1;

static void safe_read (int fd, const char *fname,void *buf, size_t count)
{
	ssize_t result;
	result = read (fd, buf, count);
	if (count != result) {
		if (result < 0) {
			printf("read file error: %s\n",fname);
			exit (EXIT_FAILURE);
		}
		printf("Short read count returned while reading from %s\n",
			fname);
		exit(EXIT_FAILURE);
	}
}

static void safe_rewind (int fd,const char *fname)
{
	if (lseek(fd, 0L, SEEK_SET) < 0) {
		printf("seek to start error %s", fname);
		exit(EXIT_FAILURE);
	}
}

static void cleanup(void)
{
	if (bconf_fd > 0)
		close(bconf_fd);
}

int main(int argc, char *argv[])
{
	ssize_t result;
	struct mtd_info_user mtd;
	struct erase_info_user erase;
	struct omron_bootconf obconf, nbconf;

	atexit(cleanup);

	if ((bconf_fd = open(MTD_BOOTCONF_NAME, O_RDWR)) < 0) {
		printf("open mtd-bootconf failed\n");
		exit(EXIT_FAILURE);
	}

	if (ioctl(bconf_fd, MEMGETINFO, &mtd) < 0) {
		printf("cannot get meminfo of MTD flash device\n");
		exit(EXIT_FAILURE);
	}

	result = read(bconf_fd, &obconf, sizeof(obconf));
	if (result < sizeof(obconf)) {
		printf("read mtd-bootconf failed\n");
		exit(EXIT_FAILURE);
	}
	memcpy(&nbconf, &obconf, sizeof(obconf));

	if (obconf.trial_run == 1 || obconf.trial_run_start == 1) {
		printf("trial_run and trial_run_start is not zero, "
		       "maybe kernel is updated?\n");
		exit(EXIT_FAILURE);
	}

	/* We will update the other kernel partition by checking boot flag */
	if (obconf.boot_flag == 1) {
		nbconf.boot_flag = 2;
	}
	else if (obconf.boot_flag == 2) {
		nbconf.boot_flag = 1;
	}
	else {
		printf("bootflag is unknown\n");
		exit(EXIT_FAILURE);
	}

#if 1
	/* Write back to mtd-bootconf */
	nbconf.trial_run = 1;
	nbconf.trial_run_start = 0;

	erase.start = 0;
	erase.length = mtd.erasesize;

	if (ioctl(bconf_fd, MEMERASE, &erase) < 0) {
		printf("erase mtd-bootconf block error\n");
		exit(EXIT_FAILURE);
	}

	printf("erase %s done\n", MTD_BOOTCONF_NAME);

	safe_rewind(bconf_fd, MTD_BOOTCONF_NAME);

	result = write(bconf_fd, &nbconf, sizeof(nbconf));
	if (result != sizeof(nbconf)) {
		printf("write mtd-bootconf failed\n");
		exit(EXIT_FAILURE);
	}

	printf("write %s done\n", MTD_BOOTCONF_NAME);

	safe_rewind(bconf_fd, MTD_BOOTCONF_NAME);

	safe_read(bconf_fd, MTD_BOOTCONF_NAME, &obconf, sizeof(obconf));

	if (memcmp(&obconf, &nbconf, sizeof(obconf))) {
		printf("mtd-bootconf mismatch found\n");
		exit(EXIT_FAILURE);
	}

	printf("verify %s done\n", MTD_BOOTCONF_NAME);
#endif

	exit(EXIT_SUCCESS);
}
