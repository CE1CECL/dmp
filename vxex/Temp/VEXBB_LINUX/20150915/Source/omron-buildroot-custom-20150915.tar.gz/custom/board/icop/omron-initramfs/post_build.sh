#!/bin/sh

#rm -rf $TARGET_DIR/etc
#mkdir -p $TARGET_DIR/etc
#touch $TARGET_DIR/etc/hosts
#touch $TARGET_DIR/etc/shadow
#touch $TARGET_DIR/etc/inittab

exit 0
