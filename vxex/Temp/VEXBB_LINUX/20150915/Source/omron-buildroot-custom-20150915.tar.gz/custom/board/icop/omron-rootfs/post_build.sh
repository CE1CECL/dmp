#!/bin/sh

# Install ldd from toolchain
install $HOST_DIR/usr/i486-buildroot-linux-gnu/sysroot/usr/bin/ldd \
$TARGET_DIR/usr/bin/ldd

# Install ldconfig from toolchain
install $HOST_DIR/usr/i486-buildroot-linux-gnu/sysroot/sbin/ldconfig \
$TARGET_DIR/sbin/ldconfig

# Convert bzImage to simple elf format
#rm -f $BINARIES_DIR/omron-bzImage.*
#$HOST_DIR/usr/sbin/mkelfImage --append=root=/dev/hda1 $BINARIES_DIR/bzImage \
#$BINARIES_DIR/omron-bzImage.elf
#$HOST_DIR/usr/bin/convert_simple_elf $BINARIES_DIR/omron-bzImage.elf \
#$BINARIES_DIR/omron-bzImage.self

echo `date +"%Y-%m-%d, %H:%M:%S"` >> $TARGET_DIR/etc/issue

exit 0
