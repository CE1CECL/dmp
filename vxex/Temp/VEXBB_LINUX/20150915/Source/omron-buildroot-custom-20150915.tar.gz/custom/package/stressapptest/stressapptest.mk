################################################################################
#
# stressapptest
#
################################################################################

STRESSAPPTEST_SITE = http://stressapptest.googlecode.com/svn/trunk/
STRESSAPPTEST_SITE_METHOD = svn
STRESSAPPTEST_VERSION = 49

STRESSAPPTEST_CONF_OPT = --prefix=$(TARGET_DIR)/usr

$(eval $(autotools-package))
