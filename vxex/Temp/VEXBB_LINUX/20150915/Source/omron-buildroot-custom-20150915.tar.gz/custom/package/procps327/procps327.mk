################################################################################
#
# procps
#
################################################################################

PROCPS327_VERSION = 3.2.7
PROCPS327_SOURCE = procps-$(PROCPS327_VERSION).tar.gz
PROCPS327_SITE = http://procps.sourceforge.net/
PROCPS327_LICENSE = GPLv2+, libproc and libps LGPLv2+
PROCPS327_LICENSE_FILES = COPYING COPYING.LIB

PROCPS327_DEPENDENCIES = ncurses

define PROCPS327_BUILD_CMDS
	$(TARGET_CONFIGURE_OPTS) $(MAKE) -C $(@D)
endef

define PROCPS327_INSTALL_TARGET_CMDS
	mkdir -p $(addprefix $(TARGET_DIR)/,usr/bin bin sbin) \
		 $(addprefix $(TARGET_DIR)/usr/share/man/,man1 man5 man8)
	$(MAKE) -C $(@D) DESTDIR=$(TARGET_DIR) lib64=lib install=install \
		ldconfig=true install
endef

$(eval $(generic-package))
