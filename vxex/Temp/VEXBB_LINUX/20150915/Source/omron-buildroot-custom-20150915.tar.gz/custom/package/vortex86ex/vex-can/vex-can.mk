VEX_CAN_VERSION = 20141119
VEX_CAN_SITE = $(BR2_EXTERNAL)/package/vortex86ex/vex-can
VEX_CAN_SITE_METHOD = file

VEX_CAN_MAKE_OPTS = KDIR=$(LINUX_DIR)

define VEX_CAN_BUILD_CMDS
	$(MAKE) CC="$(TARGET_CC)" LD="$(TARGET_LD)" \
		$(VEX_CAN_MAKE_OPTS) -C $(@D)
endef

define VEX_CAN_INSTALL_TARGET_CMDS
	$(MAKE) CC="$(TARGET_CC)" LD="$(TARGET_LD)" \
		$(VEX_CAN_MAKE_OPTS) \
		INSTALL_MOD_PATH=$(TARGET_DIR) \
		-C $(@D) install
	install $(@D)/*.sh $(TARGET_DIR)/root
endef

$(eval $(generic-package))

