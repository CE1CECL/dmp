include $(sort $(wildcard $(BR2_EXTERNAL)/package/coreboot-utils/*/*.mk))
