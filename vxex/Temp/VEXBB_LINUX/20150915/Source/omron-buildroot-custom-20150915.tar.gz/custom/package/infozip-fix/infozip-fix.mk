################################################################################
#
# infozip-fix
#
################################################################################

INFOZIP_FIX_VERSION = 30
INFOZIP_FIX_SOURCE = zip$(INFOZIP_VERSION).tgz
INFOZIP_FIX_SITE = ftp://ftp.info-zip.org/pub/infozip/src
INFOZIP_FIX_LICENSE = Info-ZIP
INFOZIP_FIX_LICENSE_FILES = LICENSE
INFOZIP_FIX_TARGET_CFLAGS = $(TARGET_CFLAGS)

ifeq ($(BR2_PACKAGE_BZIP2),y)
INFOZIP_FIX_DEPENDENCIES += bzip2
endif

ifeq ($(BR2_LARGEFILE),y)
INFOZIP_FIX_TARGET_CFLAGS += -DLARGE_FILE_SUPPORT
endif

define INFOZIP_FIX_BUILD_CMDS
	$(MAKE) $(TARGET_CONFIGURE_OPTS) -C $(@D) \
		CFLAGS="$(INFOZIP_FIX_TARGET_CFLAGS) -I. -DUNIX" \
		AS="$(TARGET_CC) -c" \
		-f unix/Makefile generic
endef

define INFOZIP_FIX_INSTALL_TARGET_CMDS
	$(MAKE) $(TARGET_CONFIGURE_OPTS) -C $(@D) -f unix/Makefile install \
		prefix=$(TARGET_DIR)/usr
endef

$(eval $(generic-package))
