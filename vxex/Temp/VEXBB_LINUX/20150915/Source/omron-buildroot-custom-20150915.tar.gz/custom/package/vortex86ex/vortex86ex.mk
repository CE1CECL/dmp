include $(sort $(wildcard $(BR2_EXTERNAL)/package/vortex86ex/*/*.mk))
