################################################################################
#
# convert-simple-elf
#
################################################################################

CONVERT_SIMPLE_ELF_VERSION = 20141227
#CONVERT_SIMPLE_ELF_SOURCE = convert-simple-elf-$(CONVERT_SIMPLE_ELF_VERSION).tar.gz
CONVERT_SIMPLE_ELF_SITE = $(BR2_EXTERNAL)/package/coreboot-utils/convert_simple_elf
CONVERT_SIMPLE_ELF_SITE_METHOD = file
CONVERT_SIMPLE_ELF_LICENSE = GPL

define CONVERT_SIMPLE_ELF_BUILD_CMDS
	$(MAKE_ENV) $(MAKE) -C $(@D)
endef

define CONVERT_SIMPLE_ELF_INSTALL_TARGET_CMDS
	mkdir -p $(addprefix $(TARGET_DIR)/usr/,bin)
	$(INSTALL) -D -m 755 $(@D)/convert_simple_elf $(TARGET_DIR)/usr/bin/convert_simple_elf
endef

define HOST_CONVERT_SIMPLE_ELF_BUILD_CMDS
	$(HOST_MAKE_ENV) $(MAKE) -C $(@D)
endef

define HOST_CONVERT_SIMPLE_ELF_INSTALL_CMDS
	mkdir -p $(addprefix $(HOST_DIR)/usr/,bin)
	$(INSTALL) -D -m 755 $(@D)/convert_simple_elf $(HOST_DIR)/usr/bin/convert_simple_elf
endef

$(eval $(generic-package))
$(eval $(host-generic-package))
