################################################################################
#
# nkf
#
################################################################################

NKF_VERSION = 2.1.3
NKF_SOURCE = nkf-$(NKF_VERSION).tar.gz
NKF_SITE = $(BR2_EXTERNAL)/package/nkf
NKF_SITE_METHOD = file
NKF_LICENSE = zlib/libpng

define NKF_BUILD_CMDS
	$(MAKE) $(TARGET_CONFIGURE_OPTS) -C $(@D)
endef

define NKF_INSTALL_TARGET_CMDS
	mkdir -p $(addprefix $(TARGET_DIR)/usr/,bin)
	$(MAKE) -C $(@D) prefix=$(TARGET_DIR)/usr install
endef

$(eval $(generic-package))
