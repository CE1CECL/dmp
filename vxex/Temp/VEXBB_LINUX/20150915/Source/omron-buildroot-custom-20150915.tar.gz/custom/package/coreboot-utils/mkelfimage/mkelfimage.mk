################################################################################
#
# mkelfimage
#
################################################################################

MKELFIMAGE_VERSION = 20141205
MKELFIMAGE_SITE = $(BR2_EXTERNAL)/package/coreboot-utils/mkelfimage
MKELFIMAGE_SITE_METHOD = file

MKELFIMAGE_CONF_OPT = --prefix=$(TARGET_DIR)/usr --datarootdir=/usr/share

HOST_MKELFIMAGE_CONF_OPT = --prefix=$(HOST_DIR)/usr

$(eval $(autotools-package))
$(eval $(host-autotools-package))
