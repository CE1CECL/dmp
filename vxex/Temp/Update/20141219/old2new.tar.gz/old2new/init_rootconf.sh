#!/bin/bash

BDEV=`./read_bootflag`

if [ "${BDEV}" -eq 1 ] ; then
	ROOTDEV="/dev/hda1"
elif [ "${BDEV}" -eq 2 ]; then
	ROOTDEV="/dev/hda2"
else
	echo "Cannot get proper bootflag"
	exit 1
fi

UUID=`./blkuuid ${ROOTDEV}`
if [ -z "${UUID}" ] ; then
	echo "Cannot get the uuid of ${ROOTDEV}"
	exit 1
fi

printf "\x00\x00\xff\xff%s\x00" ${UUID} > /tmp/rootconf
if [ ! -f "/tmp/rootconf" ] ; then                                              
	echo "'/tmp/rootconf' cannot be created???"                             
	exit 1                                                                  
fi                                                                              

flashcp /tmp/rootconf /dev/mtd3

exit 0
