#!/bin/sh

export PATH="/sbin:/usr/sbin:$PATH"

BZIMAGE_FILE=$1
ROOTFS_FILE=$2

if [ ! -f "${BZIMAGE_FILE}" ] ; then
	echo "* bzimage (${BZIMAGE_FILE}) is not found"
	exit 1
fi

if [ ! -f "${ROOTFS_FILE}" ] ; then
	echo "* rootfs (${ROOTFS_FILE}) is not found"
	exit 1
fi

RFDEV=`./rbconf`
KPARAM=

if [ "$RFDEV" -eq 1 ] ; then
	KPARAM="root=/dev/hda2"
elif [ "$RFDEV" -eq 2 ]; then
	KPARAM="root=/dev/hda1"
else
	echo "* Cannot get proper bootflag"
	exit 1
fi

rm -f ${BZIMAGE_FILE}.elf ${BZIMAGE_FILE}.self
./mkelfImage --append=${KPARAM} ${BZIMAGE_FILE} ${BZIMAGE_FILE}.elf
./convert_simple_elf ${BZIMAGE_FILE}.elf ${BZIMAGE_FILE}.self

echo "* Updating kernel"
./kupdate ${BZIMAGE_FILE}.self
if [ "$?" -ne 0 ]
then
	echo "* kernel update failed"
	exit 1
fi

echo "* Updating rootfs"
./rfupdate ${ROOTFS_FILE}
if [ "$?" -ne 0 ]
then
	echo "* rootfs update failed"
	exit 1
fi

echo "* Updating bootconf"
./wbconf
