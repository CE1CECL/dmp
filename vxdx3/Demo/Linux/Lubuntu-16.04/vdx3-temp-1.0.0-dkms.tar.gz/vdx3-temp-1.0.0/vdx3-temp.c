/*
 * DMP Votex86DX3 temperature sensor driver
 *
 * Copyright (C) 2017 DMP Electronic Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/err.h>
#include <linux/pci.h>
#include <linux/platform_device.h>
#include <linux/hwmon.h>
#include <linux/hwmon-sysfs.h>

#define DRIVER_NAME    "vdx3-temp"
#define DRIVER_VERSION "1.0.0"

#define TEMP_FROM_REG(val) (((222647 * val) - 62760000 - 17210000) / 1000)
#define REG_TEMP 0xa8

struct vdx3_temp {
	struct device *hwmon_dev;
	struct pci_dev *pcidev;

	u16 data;
};

static struct vdx3_temp *vdx3_temp_update_dev(struct device *dev)
{
	struct vdx3_temp *temp = dev_get_drvdata(dev);
	struct pci_dev *pcidev = temp->pcidev;
	u32 reg;

	pci_read_config_dword(pcidev, REG_TEMP, &reg);
	temp->data = reg >> 16 & 0x3ff;

	return temp;
}

static ssize_t vdx3_temp_show(struct device *dev,
			      struct device_attribute *devattr, char *buf)
{
	struct vdx3_temp *temp = vdx3_temp_update_dev(dev);

	return sprintf(buf, "%d\n", TEMP_FROM_REG(temp->data));
}

const static SENSOR_DEVICE_ATTR(nbtemp_input, S_IRUGO, vdx3_temp_show, NULL, 0);

static int vdx3_temp_probe(struct platform_device *pdev)
{
	struct pci_dev *pcidev;
	struct vdx3_temp *temp;
	int retval;

	pcidev = pci_get_bus_and_slot(0, PCI_DEVFN(0, 0));
	if (!pcidev)
		return -ENODEV;

	if ((pcidev->vendor != 0x17f3) || (pcidev->device != 0x6023))
		return -ENODEV;

	temp = devm_kzalloc(&pdev->dev, sizeof(struct vdx3_temp), GFP_KERNEL);
	if (!temp)
		return -ENOMEM;

	temp->pcidev = pcidev;
	platform_set_drvdata(pdev, temp);

	retval = device_create_file(&pdev->dev,
				    &sensor_dev_attr_nbtemp_input.dev_attr);
	if (retval)
		return retval;

	temp->hwmon_dev = hwmon_device_register(&pdev->dev);
	if (IS_ERR(temp->hwmon_dev)) {
		device_remove_file(&pdev->dev,
                                   &sensor_dev_attr_nbtemp_input.dev_attr);
		return PTR_ERR(temp->hwmon_dev);
	}

	return 0;
}

static int vdx3_temp_remove(struct platform_device *pdev)
{
	struct vdx3_temp *temp = platform_get_drvdata(pdev);

	hwmon_device_unregister(temp->hwmon_dev);
	device_remove_file(&pdev->dev,
			   &sensor_dev_attr_nbtemp_input.dev_attr);

	return 0;
}

static struct platform_driver vdx3_temp_driver = {
	.driver.name    = DRIVER_NAME,
	.driver.owner   = THIS_MODULE,
	.probe          = vdx3_temp_probe,
	.remove         = vdx3_temp_remove,
};

static struct platform_device *vdx3_temp_device;

/*----------------------------------------------------------------------------*/

static int __init vdx3_temp_init(void)
{
	int ret;

	vdx3_temp_device = platform_device_alloc(DRIVER_NAME, -1);
	if (!vdx3_temp_device)
		return -ENOMEM;

	ret = platform_device_add(vdx3_temp_device);
	if (ret)
		goto exit_platform_device;

	ret = platform_driver_register(&vdx3_temp_driver);
	if (ret)
		goto exit_platform_device;

	return 0;

exit_platform_device:
	platform_device_put(vdx3_temp_device);
	return ret;
}
module_init(vdx3_temp_init);

static void __exit vdx3_temp_exit(void)
{
	platform_driver_unregister(&vdx3_temp_driver);
	platform_device_unregister(vdx3_temp_device);
}
module_exit(vdx3_temp_exit);

MODULE_AUTHOR("Shawn Lin <shawn@dmp.com.tw>");
MODULE_DESCRIPTION("Vortex86DX3 temperature sensor driver");
MODULE_LICENSE("GPL");
MODULE_ALIAS("platform:" DRIVER_NAME);
MODULE_VERSION(DRIVER_VERSION);
