cmd_arch/x86/kernel/asm-offsets.s := gcc -Wp,-MD,arch/x86/kernel/.asm-offsets.s.d  -nostdinc -isystem /usr/lib/gcc/i686-linux-gnu/4.6/include -I/usr/src/linux-headers-lbm- -I/home/user/linux-3.2.0/arch/x86/include -Iarch/x86/include/generated -Iinclude  -I/home/user/linux-3.2.0/include -include /home/user/linux-3.2.0/include/linux/kconfig.h -Iubuntu/include -I/home/user/linux-3.2.0/ubuntu/include  -I/home/user/linux-3.2.0/. -I. -D__KERNEL__ -Wall -Wundef -Wstrict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -Werror-implicit-function-declaration -Wno-format-security -fno-delete-null-pointer-checks -O2 -m32 -msoft-float -mregparm=3 -freg-struct-return -mpreferred-stack-boundary=2 -march=i686 -mtune=generic -maccumulate-outgoing-args -Wa,-mtune=generic32 -ffreestanding -fstack-protector -DCONFIG_AS_CFI=1 -DCONFIG_AS_CFI_SIGNAL_FRAME=1 -DCONFIG_AS_CFI_SECTIONS=1 -pipe -Wno-sign-compare -fno-asynchronous-unwind-tables -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -Wframe-larger-than=1024 -Wno-unused-but-set-variable -fno-omit-frame-pointer -fno-optimize-sibling-calls -fno-var-tracking-assignments -pg -fno-inline-functions-called-once -Wdeclaration-after-statement -Wno-pointer-sign -fno-strict-overflow -fconserve-stack -DCC_HAVE_ASM_GOTO    -D"KBUILD_STR(s)=\#s" -D"KBUILD_BASENAME=KBUILD_STR(asm_offsets)"  -D"KBUILD_MODNAME=KBUILD_STR(asm_offsets)" -fverbose-asm -S -o arch/x86/kernel/asm-offsets.s /home/user/linux-3.2.0/arch/x86/kernel/asm-offsets.c

source_arch/x86/kernel/asm-offsets.s := /home/user/linux-3.2.0/arch/x86/kernel/asm-offsets.c

deps_arch/x86/kernel/asm-offsets.s := \
    $(wildcard include/config/xen.h) \
    $(wildcard include/config/x86/32.h) \
    $(wildcard include/config/paravirt.h) \
  /home/user/linux-3.2.0/include/linux/crypto.h \
  /home/user/linux-3.2.0/include/linux/atomic.h \
    $(wildcard include/config/arch/has/atomic/or.h) \
    $(wildcard include/config/generic/atomic64.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/atomic.h \
    $(wildcard include/config/m386.h) \
    $(wildcard include/config/x86/64.h) \
  /home/user/linux-3.2.0/include/linux/compiler.h \
    $(wildcard include/config/sparse/rcu/pointer.h) \
    $(wildcard include/config/trace/branch/profiling.h) \
    $(wildcard include/config/profile/all/branches.h) \
    $(wildcard include/config/enable/must/check.h) \
    $(wildcard include/config/enable/warn/deprecated.h) \
  /home/user/linux-3.2.0/include/linux/compiler-gcc.h \
    $(wildcard include/config/arch/supports/optimized/inlining.h) \
    $(wildcard include/config/optimize/inlining.h) \
  /home/user/linux-3.2.0/include/linux/compiler-gcc4.h \
  /home/user/linux-3.2.0/include/linux/types.h \
    $(wildcard include/config/uid16.h) \
    $(wildcard include/config/lbdaf.h) \
    $(wildcard include/config/arch/dma/addr/t/64bit.h) \
    $(wildcard include/config/phys/addr/t/64bit.h) \
    $(wildcard include/config/64bit.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/types.h \
  /home/user/linux-3.2.0/include/asm-generic/types.h \
  /home/user/linux-3.2.0/include/asm-generic/int-ll64.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/bitsperlong.h \
  /home/user/linux-3.2.0/include/asm-generic/bitsperlong.h \
  /home/user/linux-3.2.0/include/linux/posix_types.h \
  /home/user/linux-3.2.0/include/linux/stddef.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/posix_types.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/posix_types_32.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/processor.h \
    $(wildcard include/config/x86/vsmp.h) \
    $(wildcard include/config/smp.h) \
    $(wildcard include/config/cc/stackprotector.h) \
    $(wildcard include/config/m486.h) \
    $(wildcard include/config/x86/debugctlmsr.h) \
    $(wildcard include/config/cpu/sup/amd.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/processor-flags.h \
    $(wildcard include/config/vm86.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/vm86.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/ptrace.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/ptrace-abi.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/segment.h \
  /home/user/linux-3.2.0/include/linux/const.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/page_types.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/page_32_types.h \
    $(wildcard include/config/highmem4g.h) \
    $(wildcard include/config/highmem64g.h) \
    $(wildcard include/config/page/offset.h) \
    $(wildcard include/config/x86/pae.h) \
  /home/user/linux-3.2.0/include/linux/init.h \
    $(wildcard include/config/modules.h) \
    $(wildcard include/config/hotplug.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/paravirt_types.h \
    $(wildcard include/config/x86/local/apic.h) \
    $(wildcard include/config/paravirt/debug.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/desc_defs.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/kmap_types.h \
    $(wildcard include/config/debug/highmem.h) \
  /home/user/linux-3.2.0/include/asm-generic/kmap_types.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/pgtable_types.h \
    $(wildcard include/config/kmemcheck.h) \
    $(wildcard include/config/compat/vdso.h) \
    $(wildcard include/config/proc/fs.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/pgtable_32_types.h \
    $(wildcard include/config/highmem.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/pgtable-2level_types.h \
  /home/user/linux-3.2.0/include/asm-generic/pgtable-nopud.h \
  /home/user/linux-3.2.0/include/asm-generic/pgtable-nopmd.h \
  /home/user/linux-3.2.0/include/asm-generic/ptrace.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/math_emu.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/sigcontext.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/current.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/percpu.h \
    $(wildcard include/config/x86/64/smp.h) \
    $(wildcard include/config/x86/cmpxchg64.h) \
  /home/user/linux-3.2.0/include/linux/kernel.h \
    $(wildcard include/config/preempt/voluntary.h) \
    $(wildcard include/config/debug/atomic/sleep.h) \
    $(wildcard include/config/prove/locking.h) \
    $(wildcard include/config/ring/buffer.h) \
    $(wildcard include/config/tracing.h) \
    $(wildcard include/config/numa.h) \
    $(wildcard include/config/compaction.h) \
    $(wildcard include/config/ftrace/mcount/record.h) \
  /usr/lib/gcc/i686-linux-gnu/4.6/include/stdarg.h \
  /home/user/linux-3.2.0/include/linux/linkage.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/linkage.h \
    $(wildcard include/config/x86/alignment/16.h) \
  /home/user/linux-3.2.0/include/linux/stringify.h \
  /home/user/linux-3.2.0/include/linux/bitops.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/bitops.h \
    $(wildcard include/config/x86/cmov.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/alternative.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/asm.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/cpufeature.h \
    $(wildcard include/config/x86/invlpg.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/required-features.h \
    $(wildcard include/config/x86/minimum/cpu/family.h) \
    $(wildcard include/config/math/emulation.h) \
    $(wildcard include/config/x86/use/3dnow.h) \
    $(wildcard include/config/x86/p6/nop.h) \
  /home/user/linux-3.2.0/include/asm-generic/bitops/find.h \
    $(wildcard include/config/generic/find/first/bit.h) \
  /home/user/linux-3.2.0/include/asm-generic/bitops/sched.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/arch_hweight.h \
  /home/user/linux-3.2.0/include/asm-generic/bitops/const_hweight.h \
  /home/user/linux-3.2.0/include/asm-generic/bitops/fls64.h \
  /home/user/linux-3.2.0/include/asm-generic/bitops/le.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/byteorder.h \
  /home/user/linux-3.2.0/include/linux/byteorder/little_endian.h \
  /home/user/linux-3.2.0/include/linux/swab.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/swab.h \
    $(wildcard include/config/x86/bswap.h) \
  /home/user/linux-3.2.0/include/linux/byteorder/generic.h \
  /home/user/linux-3.2.0/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /home/user/linux-3.2.0/include/linux/log2.h \
    $(wildcard include/config/arch/has/ilog2/u32.h) \
    $(wildcard include/config/arch/has/ilog2/u64.h) \
  /home/user/linux-3.2.0/include/linux/typecheck.h \
  /home/user/linux-3.2.0/include/linux/printk.h \
    $(wildcard include/config/printk.h) \
    $(wildcard include/config/dynamic/debug.h) \
  /home/user/linux-3.2.0/include/linux/dynamic_debug.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/bug.h \
    $(wildcard include/config/bug.h) \
    $(wildcard include/config/debug/bugverbose.h) \
  /home/user/linux-3.2.0/include/asm-generic/bug.h \
    $(wildcard include/config/generic/bug.h) \
    $(wildcard include/config/generic/bug/relative/pointers.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/div64.h \
  /home/user/linux-3.2.0/include/asm-generic/percpu.h \
    $(wildcard include/config/debug/preempt.h) \
    $(wildcard include/config/have/setup/per/cpu/area.h) \
  /home/user/linux-3.2.0/include/linux/threads.h \
    $(wildcard include/config/nr/cpus.h) \
    $(wildcard include/config/base/small.h) \
  /home/user/linux-3.2.0/include/linux/percpu-defs.h \
    $(wildcard include/config/debug/force/weak/per/cpu.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/system.h \
    $(wildcard include/config/ia32/emulation.h) \
    $(wildcard include/config/x86/32/lazy/gs.h) \
    $(wildcard include/config/x86/ppro/fence.h) \
    $(wildcard include/config/x86/oostore.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/cmpxchg.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/cmpxchg_32.h \
    $(wildcard include/config/x86/cmpxchg.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/nops.h \
    $(wildcard include/config/mk7.h) \
  /home/user/linux-3.2.0/include/linux/irqflags.h \
    $(wildcard include/config/trace/irqflags.h) \
    $(wildcard include/config/irqsoff/tracer.h) \
    $(wildcard include/config/preempt/tracer.h) \
    $(wildcard include/config/trace/irqflags/support.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/irqflags.h \
    $(wildcard include/config/debug/lock/alloc.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/paravirt.h \
    $(wildcard include/config/transparent/hugepage.h) \
    $(wildcard include/config/paravirt/spinlocks.h) \
  /home/user/linux-3.2.0/include/linux/cpumask.h \
    $(wildcard include/config/cpumask/offstack.h) \
    $(wildcard include/config/hotplug/cpu.h) \
    $(wildcard include/config/debug/per/cpu/maps.h) \
    $(wildcard include/config/disable/obsolete/cpumask/functions.h) \
  /home/user/linux-3.2.0/include/linux/bitmap.h \
  /home/user/linux-3.2.0/include/linux/string.h \
    $(wildcard include/config/binary/printf.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/string.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/string_32.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/page.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/page_32.h \
    $(wildcard include/config/hugetlb/page.h) \
    $(wildcard include/config/debug/virtual.h) \
    $(wildcard include/config/flatmem.h) \
    $(wildcard include/config/x86/3dnow.h) \
  /home/user/linux-3.2.0/include/asm-generic/memory_model.h \
    $(wildcard include/config/discontigmem.h) \
    $(wildcard include/config/sparsemem/vmemmap.h) \
    $(wildcard include/config/sparsemem.h) \
  /home/user/linux-3.2.0/include/asm-generic/getorder.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/msr.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/msr-index.h \
  /home/user/linux-3.2.0/include/linux/ioctl.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/ioctl.h \
  /home/user/linux-3.2.0/include/asm-generic/ioctl.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/errno.h \
  /home/user/linux-3.2.0/include/asm-generic/errno.h \
  /home/user/linux-3.2.0/include/asm-generic/errno-base.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/cpumask.h \
  /home/user/linux-3.2.0/include/linux/personality.h \
  /home/user/linux-3.2.0/include/linux/cache.h \
    $(wildcard include/config/arch/has/cache/line/size.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/cache.h \
    $(wildcard include/config/x86/l1/cache/shift.h) \
    $(wildcard include/config/x86/internode/cache/shift.h) \
  /home/user/linux-3.2.0/include/linux/math64.h \
  /home/user/linux-3.2.0/include/linux/err.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/atomic64_32.h \
  /home/user/linux-3.2.0/include/asm-generic/atomic-long.h \
  /home/user/linux-3.2.0/include/linux/list.h \
    $(wildcard include/config/debug/list.h) \
  /home/user/linux-3.2.0/include/linux/poison.h \
    $(wildcard include/config/illegal/pointer/value.h) \
  /home/user/linux-3.2.0/include/linux/slab.h \
    $(wildcard include/config/slab/debug.h) \
    $(wildcard include/config/debug/objects.h) \
    $(wildcard include/config/failslab.h) \
    $(wildcard include/config/slub.h) \
    $(wildcard include/config/slob.h) \
    $(wildcard include/config/debug/slab.h) \
    $(wildcard include/config/slab.h) \
  /home/user/linux-3.2.0/include/linux/gfp.h \
    $(wildcard include/config/zone/dma.h) \
    $(wildcard include/config/zone/dma32.h) \
  /home/user/linux-3.2.0/include/linux/mmzone.h \
    $(wildcard include/config/force/max/zoneorder.h) \
    $(wildcard include/config/memory/hotplug.h) \
    $(wildcard include/config/arch/populates/node/map.h) \
    $(wildcard include/config/flat/node/mem/map.h) \
    $(wildcard include/config/cgroup/mem/res/ctlr.h) \
    $(wildcard include/config/no/bootmem.h) \
    $(wildcard include/config/have/memory/present.h) \
    $(wildcard include/config/have/memoryless/nodes.h) \
    $(wildcard include/config/need/node/memmap/size.h) \
    $(wildcard include/config/need/multiple/nodes.h) \
    $(wildcard include/config/have/arch/early/pfn/to/nid.h) \
    $(wildcard include/config/sparsemem/extreme.h) \
    $(wildcard include/config/have/arch/pfn/valid.h) \
    $(wildcard include/config/nodes/span/other/nodes.h) \
    $(wildcard include/config/holes/in/zone.h) \
    $(wildcard include/config/arch/has/holes/memorymodel.h) \
  /home/user/linux-3.2.0/include/linux/spinlock.h \
    $(wildcard include/config/debug/spinlock.h) \
    $(wildcard include/config/generic/lockbreak.h) \
    $(wildcard include/config/preempt.h) \
  /home/user/linux-3.2.0/include/linux/preempt.h \
    $(wildcard include/config/preempt/count.h) \
    $(wildcard include/config/preempt/notifiers.h) \
  /home/user/linux-3.2.0/include/linux/thread_info.h \
    $(wildcard include/config/compat.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/thread_info.h \
    $(wildcard include/config/debug/stack/usage.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/ftrace.h \
    $(wildcard include/config/function/tracer.h) \
    $(wildcard include/config/dynamic/ftrace.h) \
  /home/user/linux-3.2.0/include/linux/bottom_half.h \
  /home/user/linux-3.2.0/include/linux/spinlock_types.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/spinlock_types.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/rwlock.h \
  /home/user/linux-3.2.0/include/linux/lockdep.h \
    $(wildcard include/config/lockdep.h) \
    $(wildcard include/config/lock/stat.h) \
    $(wildcard include/config/prove/rcu.h) \
  /home/user/linux-3.2.0/include/linux/rwlock_types.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/spinlock.h \
  /home/user/linux-3.2.0/include/linux/rwlock.h \
  /home/user/linux-3.2.0/include/linux/spinlock_api_smp.h \
    $(wildcard include/config/inline/spin/lock.h) \
    $(wildcard include/config/inline/spin/lock/bh.h) \
    $(wildcard include/config/inline/spin/lock/irq.h) \
    $(wildcard include/config/inline/spin/lock/irqsave.h) \
    $(wildcard include/config/inline/spin/trylock.h) \
    $(wildcard include/config/inline/spin/trylock/bh.h) \
    $(wildcard include/config/inline/spin/unlock.h) \
    $(wildcard include/config/inline/spin/unlock/bh.h) \
    $(wildcard include/config/inline/spin/unlock/irq.h) \
    $(wildcard include/config/inline/spin/unlock/irqrestore.h) \
  /home/user/linux-3.2.0/include/linux/rwlock_api_smp.h \
    $(wildcard include/config/inline/read/lock.h) \
    $(wildcard include/config/inline/write/lock.h) \
    $(wildcard include/config/inline/read/lock/bh.h) \
    $(wildcard include/config/inline/write/lock/bh.h) \
    $(wildcard include/config/inline/read/lock/irq.h) \
    $(wildcard include/config/inline/write/lock/irq.h) \
    $(wildcard include/config/inline/read/lock/irqsave.h) \
    $(wildcard include/config/inline/write/lock/irqsave.h) \
    $(wildcard include/config/inline/read/trylock.h) \
    $(wildcard include/config/inline/write/trylock.h) \
    $(wildcard include/config/inline/read/unlock.h) \
    $(wildcard include/config/inline/write/unlock.h) \
    $(wildcard include/config/inline/read/unlock/bh.h) \
    $(wildcard include/config/inline/write/unlock/bh.h) \
    $(wildcard include/config/inline/read/unlock/irq.h) \
    $(wildcard include/config/inline/write/unlock/irq.h) \
    $(wildcard include/config/inline/read/unlock/irqrestore.h) \
    $(wildcard include/config/inline/write/unlock/irqrestore.h) \
  /home/user/linux-3.2.0/include/linux/wait.h \
  /home/user/linux-3.2.0/include/linux/numa.h \
    $(wildcard include/config/nodes/shift.h) \
  /home/user/linux-3.2.0/include/linux/seqlock.h \
  /home/user/linux-3.2.0/include/linux/nodemask.h \
  /home/user/linux-3.2.0/include/linux/pageblock-flags.h \
    $(wildcard include/config/hugetlb/page/size/variable.h) \
  include/generated/bounds.h \
  /home/user/linux-3.2.0/include/linux/memory_hotplug.h \
    $(wildcard include/config/memory/hotremove.h) \
    $(wildcard include/config/have/arch/nodedata/extension.h) \
  /home/user/linux-3.2.0/include/linux/notifier.h \
  /home/user/linux-3.2.0/include/linux/errno.h \
  /home/user/linux-3.2.0/include/linux/mutex.h \
    $(wildcard include/config/debug/mutexes.h) \
    $(wildcard include/config/have/arch/mutex/cpu/relax.h) \
  /home/user/linux-3.2.0/include/linux/rwsem.h \
    $(wildcard include/config/rwsem/generic/spinlock.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/rwsem.h \
  /home/user/linux-3.2.0/include/linux/srcu.h \
  /home/user/linux-3.2.0/include/linux/topology.h \
    $(wildcard include/config/sched/smt.h) \
    $(wildcard include/config/sched/mc.h) \
    $(wildcard include/config/sched/book.h) \
    $(wildcard include/config/use/percpu/numa/node/id.h) \
  /home/user/linux-3.2.0/include/linux/smp.h \
    $(wildcard include/config/use/generic/smp/helpers.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/smp.h \
    $(wildcard include/config/x86/io/apic.h) \
    $(wildcard include/config/x86/32/smp.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/mpspec.h \
    $(wildcard include/config/x86/numaq.h) \
    $(wildcard include/config/mca.h) \
    $(wildcard include/config/eisa.h) \
    $(wildcard include/config/x86/mpparse.h) \
    $(wildcard include/config/acpi.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/mpspec_def.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/x86_init.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/bootparam.h \
  /home/user/linux-3.2.0/include/linux/screen_info.h \
  /home/user/linux-3.2.0/include/linux/apm_bios.h \
  /home/user/linux-3.2.0/include/linux/edd.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/e820.h \
    $(wildcard include/config/efi.h) \
    $(wildcard include/config/intel/txt.h) \
    $(wildcard include/config/hibernation.h) \
    $(wildcard include/config/memtest.h) \
  /home/user/linux-3.2.0/include/linux/ioport.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/ist.h \
  /home/user/linux-3.2.0/include/video/edid.h \
    $(wildcard include/config/x86.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/apicdef.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/apic.h \
    $(wildcard include/config/x86/x2apic.h) \
  /home/user/linux-3.2.0/include/linux/pm.h \
    $(wildcard include/config/pm.h) \
    $(wildcard include/config/pm/sleep.h) \
    $(wildcard include/config/pm/runtime.h) \
    $(wildcard include/config/pm/clk.h) \
    $(wildcard include/config/pm/generic/domains.h) \
  /home/user/linux-3.2.0/include/linux/workqueue.h \
    $(wildcard include/config/debug/objects/work.h) \
    $(wildcard include/config/freezer.h) \
  /home/user/linux-3.2.0/include/linux/timer.h \
    $(wildcard include/config/timer/stats.h) \
    $(wildcard include/config/debug/objects/timers.h) \
  /home/user/linux-3.2.0/include/linux/ktime.h \
    $(wildcard include/config/ktime/scalar.h) \
  /home/user/linux-3.2.0/include/linux/time.h \
    $(wildcard include/config/arch/uses/gettimeoffset.h) \
  /home/user/linux-3.2.0/include/linux/jiffies.h \
  /home/user/linux-3.2.0/include/linux/timex.h \
  /home/user/linux-3.2.0/include/linux/param.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/param.h \
  /home/user/linux-3.2.0/include/asm-generic/param.h \
    $(wildcard include/config/hz.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/timex.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/tsc.h \
    $(wildcard include/config/x86/tsc.h) \
  /home/user/linux-3.2.0/include/linux/debugobjects.h \
    $(wildcard include/config/debug/objects/free.h) \
  /home/user/linux-3.2.0/include/linux/completion.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/fixmap.h \
    $(wildcard include/config/provide/ohci1394/dma/init.h) \
    $(wildcard include/config/x86/visws/apic.h) \
    $(wildcard include/config/x86/f00f/bug.h) \
    $(wildcard include/config/x86/cyclone/timer.h) \
    $(wildcard include/config/pci/mmconfig.h) \
    $(wildcard include/config/x86/mrst.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/acpi.h \
    $(wildcard include/config/acpi/numa.h) \
  /home/user/linux-3.2.0/include/acpi/pdc_intel.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/numa.h \
    $(wildcard include/config/numa/emu.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/topology.h \
    $(wildcard include/config/x86/ht.h) \
  /home/user/linux-3.2.0/include/asm-generic/topology.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/numa_32.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/mmu.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/trampoline.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/io.h \
  /home/user/linux-3.2.0/include/asm-generic/iomap.h \
    $(wildcard include/config/has/ioport.h) \
    $(wildcard include/config/pci.h) \
  /home/user/linux-3.2.0/include/linux/vmalloc.h \
    $(wildcard include/config/mmu.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/io_apic.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/irq_vectors.h \
  /home/user/linux-3.2.0/include/linux/percpu.h \
    $(wildcard include/config/need/per/cpu/embed/first/chunk.h) \
    $(wildcard include/config/need/per/cpu/page/first/chunk.h) \
  /home/user/linux-3.2.0/include/linux/pfn.h \
  /home/user/linux-3.2.0/include/linux/mmdebug.h \
    $(wildcard include/config/debug/vm.h) \
  /home/user/linux-3.2.0/include/linux/slub_def.h \
    $(wildcard include/config/slub/stats.h) \
    $(wildcard include/config/slub/debug.h) \
    $(wildcard include/config/sysfs.h) \
  /home/user/linux-3.2.0/include/linux/kobject.h \
  /home/user/linux-3.2.0/include/linux/sysfs.h \
  /home/user/linux-3.2.0/include/linux/kobject_ns.h \
  /home/user/linux-3.2.0/include/linux/kref.h \
  /home/user/linux-3.2.0/include/linux/kmemleak.h \
    $(wildcard include/config/debug/kmemleak.h) \
  /home/user/linux-3.2.0/include/linux/uaccess.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/uaccess.h \
    $(wildcard include/config/x86/wp/works/ok.h) \
    $(wildcard include/config/x86/intel/usercopy.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/uaccess_32.h \
    $(wildcard include/config/debug/strict/user/copy/checks.h) \
  /home/user/linux-3.2.0/include/linux/sched.h \
    $(wildcard include/config/sched/debug.h) \
    $(wildcard include/config/no/hz.h) \
    $(wildcard include/config/lockup/detector.h) \
    $(wildcard include/config/detect/hung/task.h) \
    $(wildcard include/config/core/dump/default/elf/headers.h) \
    $(wildcard include/config/sched/autogroup.h) \
    $(wildcard include/config/virt/cpu/accounting.h) \
    $(wildcard include/config/bsd/process/acct.h) \
    $(wildcard include/config/taskstats.h) \
    $(wildcard include/config/audit.h) \
    $(wildcard include/config/cgroups.h) \
    $(wildcard include/config/inotify/user.h) \
    $(wildcard include/config/fanotify.h) \
    $(wildcard include/config/epoll.h) \
    $(wildcard include/config/posix/mqueue.h) \
    $(wildcard include/config/keys.h) \
    $(wildcard include/config/perf/events.h) \
    $(wildcard include/config/schedstats.h) \
    $(wildcard include/config/task/delay/acct.h) \
    $(wildcard include/config/fair/group/sched.h) \
    $(wildcard include/config/rt/group/sched.h) \
    $(wildcard include/config/cgroup/sched.h) \
    $(wildcard include/config/blk/dev/io/trace.h) \
    $(wildcard include/config/preempt/rcu.h) \
    $(wildcard include/config/tree/preempt/rcu.h) \
    $(wildcard include/config/rcu/boost.h) \
    $(wildcard include/config/compat/brk.h) \
    $(wildcard include/config/sysvipc.h) \
    $(wildcard include/config/auditsyscall.h) \
    $(wildcard include/config/generic/hardirqs.h) \
    $(wildcard include/config/rt/mutexes.h) \
    $(wildcard include/config/block.h) \
    $(wildcard include/config/task/xacct.h) \
    $(wildcard include/config/cpusets.h) \
    $(wildcard include/config/futex.h) \
    $(wildcard include/config/fault/injection.h) \
    $(wildcard include/config/latencytop.h) \
    $(wildcard include/config/function/graph/tracer.h) \
    $(wildcard include/config/have/hw/breakpoint.h) \
    $(wildcard include/config/have/unstable/sched/clock.h) \
    $(wildcard include/config/irq/time/accounting.h) \
    $(wildcard include/config/cfs/bandwidth.h) \
    $(wildcard include/config/stack/growsup.h) \
    $(wildcard include/config/mm/owner.h) \
  /home/user/linux-3.2.0/include/linux/capability.h \
  /home/user/linux-3.2.0/include/linux/rbtree.h \
  /home/user/linux-3.2.0/include/linux/mm_types.h \
    $(wildcard include/config/split/ptlock/cpus.h) \
    $(wildcard include/config/want/page/debug/flags.h) \
    $(wildcard include/config/cmpxchg/local.h) \
    $(wildcard include/config/aio.h) \
    $(wildcard include/config/mmu/notifier.h) \
  /home/user/linux-3.2.0/include/linux/auxvec.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/auxvec.h \
  /home/user/linux-3.2.0/include/linux/prio_tree.h \
  /home/user/linux-3.2.0/include/linux/page-debug-flags.h \
    $(wildcard include/config/page/poisoning.h) \
    $(wildcard include/config/page/debug/something/else.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/cputime.h \
  /home/user/linux-3.2.0/include/asm-generic/cputime.h \
  /home/user/linux-3.2.0/include/linux/sem.h \
  /home/user/linux-3.2.0/include/linux/ipc.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/ipcbuf.h \
  /home/user/linux-3.2.0/include/asm-generic/ipcbuf.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/sembuf.h \
  /home/user/linux-3.2.0/include/linux/rcupdate.h \
    $(wildcard include/config/rcu/torture/test.h) \
    $(wildcard include/config/tree/rcu.h) \
    $(wildcard include/config/tiny/rcu.h) \
    $(wildcard include/config/tiny/preempt/rcu.h) \
    $(wildcard include/config/debug/objects/rcu/head.h) \
    $(wildcard include/config/preempt/rt.h) \
  /home/user/linux-3.2.0/include/linux/rcutree.h \
  /home/user/linux-3.2.0/include/linux/signal.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/signal.h \
  /home/user/linux-3.2.0/include/asm-generic/signal-defs.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/siginfo.h \
  /home/user/linux-3.2.0/include/asm-generic/siginfo.h \
  /home/user/linux-3.2.0/include/linux/pid.h \
  /home/user/linux-3.2.0/include/linux/proportions.h \
  /home/user/linux-3.2.0/include/linux/percpu_counter.h \
  /home/user/linux-3.2.0/include/linux/seccomp.h \
    $(wildcard include/config/seccomp.h) \
    $(wildcard include/config/have/arch/seccomp/filter.h) \
    $(wildcard include/config/seccomp/filter.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/seccomp.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/seccomp_32.h \
  /home/user/linux-3.2.0/include/linux/unistd.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/unistd.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/unistd_32.h \
  /home/user/linux-3.2.0/include/linux/rculist.h \
  /home/user/linux-3.2.0/include/linux/rtmutex.h \
    $(wildcard include/config/debug/rt/mutexes.h) \
  /home/user/linux-3.2.0/include/linux/plist.h \
    $(wildcard include/config/debug/pi/list.h) \
  /home/user/linux-3.2.0/include/linux/resource.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/resource.h \
  /home/user/linux-3.2.0/include/asm-generic/resource.h \
  /home/user/linux-3.2.0/include/linux/hrtimer.h \
    $(wildcard include/config/high/res/timers.h) \
    $(wildcard include/config/timerfd.h) \
  /home/user/linux-3.2.0/include/linux/timerqueue.h \
  /home/user/linux-3.2.0/include/linux/task_io_accounting.h \
    $(wildcard include/config/task/io/accounting.h) \
  /home/user/linux-3.2.0/include/linux/latencytop.h \
  /home/user/linux-3.2.0/include/linux/cred.h \
    $(wildcard include/config/debug/credentials.h) \
    $(wildcard include/config/security.h) \
    $(wildcard include/config/user/ns.h) \
  /home/user/linux-3.2.0/include/linux/key.h \
    $(wildcard include/config/sysctl.h) \
  /home/user/linux-3.2.0/include/linux/sysctl.h \
  /home/user/linux-3.2.0/include/linux/selinux.h \
    $(wildcard include/config/security/selinux.h) \
  /home/user/linux-3.2.0/include/linux/llist.h \
    $(wildcard include/config/arch/have/nmi/safe/cmpxchg.h) \
  /home/user/linux-3.2.0/include/linux/aio.h \
  /home/user/linux-3.2.0/include/linux/aio_abi.h \
  /home/user/linux-3.2.0/include/linux/uio.h \
  /home/user/linux-3.2.0/include/linux/hardirq.h \
  /home/user/linux-3.2.0/include/linux/ftrace_irq.h \
    $(wildcard include/config/ftrace/nmi/enter.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/hardirq.h \
    $(wildcard include/config/x86/thermal/vector.h) \
    $(wildcard include/config/x86/mce/threshold.h) \
  /home/user/linux-3.2.0/include/linux/irq.h \
    $(wildcard include/config/s390.h) \
    $(wildcard include/config/irq/release/method.h) \
    $(wildcard include/config/generic/pending/irq.h) \
  /home/user/linux-3.2.0/include/linux/irqreturn.h \
  /home/user/linux-3.2.0/include/linux/irqnr.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/irq.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/irq_regs.h \
  /home/user/linux-3.2.0/include/linux/irqdesc.h \
    $(wildcard include/config/irq/preflow/fasteoi.h) \
    $(wildcard include/config/sparse/irq.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/hw_irq.h \
    $(wildcard include/config/irq/remap.h) \
  /home/user/linux-3.2.0/include/linux/profile.h \
    $(wildcard include/config/profiling.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/sections.h \
    $(wildcard include/config/debug/rodata.h) \
  /home/user/linux-3.2.0/include/asm-generic/sections.h \
  /home/user/linux-3.2.0/include/linux/suspend.h \
    $(wildcard include/config/vt.h) \
    $(wildcard include/config/vt/console/sleep.h) \
    $(wildcard include/config/suspend.h) \
    $(wildcard include/config/hibernate/callbacks.h) \
    $(wildcard include/config/arch/save/page/keys.h) \
  /home/user/linux-3.2.0/include/linux/swap.h \
    $(wildcard include/config/migration.h) \
    $(wildcard include/config/memory/failure.h) \
    $(wildcard include/config/swap.h) \
    $(wildcard include/config/cgroup/mem/res/ctlr/swap.h) \
  /home/user/linux-3.2.0/include/linux/memcontrol.h \
    $(wildcard include/config/cgroup/mem/cont.h) \
  /home/user/linux-3.2.0/include/linux/cgroup.h \
  /home/user/linux-3.2.0/include/linux/cgroupstats.h \
  /home/user/linux-3.2.0/include/linux/taskstats.h \
  /home/user/linux-3.2.0/include/linux/prio_heap.h \
  /home/user/linux-3.2.0/include/linux/idr.h \
  /home/user/linux-3.2.0/include/linux/cgroup_subsys.h \
    $(wildcard include/config/cgroup/debug.h) \
    $(wildcard include/config/cgroup/cpuacct.h) \
    $(wildcard include/config/cgroup/device.h) \
    $(wildcard include/config/cgroup/freezer.h) \
    $(wildcard include/config/net/cls/cgroup.h) \
    $(wildcard include/config/blk/cgroup.h) \
    $(wildcard include/config/cgroup/perf.h) \
  /home/user/linux-3.2.0/include/linux/vm_event_item.h \
  /home/user/linux-3.2.0/include/linux/node.h \
    $(wildcard include/config/memory/hotplug/sparse.h) \
    $(wildcard include/config/hugetlbfs.h) \
  /home/user/linux-3.2.0/include/linux/sysdev.h \
  /home/user/linux-3.2.0/include/linux/mm.h \
    $(wildcard include/config/ia64.h) \
    $(wildcard include/config/ksm.h) \
    $(wildcard include/config/debug/pagealloc.h) \
  /home/user/linux-3.2.0/include/linux/debug_locks.h \
    $(wildcard include/config/debug/locking/api/selftests.h) \
  /home/user/linux-3.2.0/include/linux/range.h \
  /home/user/linux-3.2.0/include/linux/bit_spinlock.h \
  /home/user/linux-3.2.0/include/linux/shrinker.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/pgtable.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/pgtable_32.h \
    $(wildcard include/config/highpte.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/pgtable_32_types.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/pgtable-2level.h \
  /home/user/linux-3.2.0/include/asm-generic/pgtable.h \
  /home/user/linux-3.2.0/include/linux/page-flags.h \
    $(wildcard include/config/pageflags/extended.h) \
    $(wildcard include/config/arch/uses/pg/uncached.h) \
  /home/user/linux-3.2.0/include/linux/huge_mm.h \
  /home/user/linux-3.2.0/include/linux/vmstat.h \
    $(wildcard include/config/vm/event/counters.h) \
  /home/user/linux-3.2.0/include/linux/kbuild.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/sigframe.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/ucontext.h \
  /home/user/linux-3.2.0/include/asm-generic/ucontext.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/suspend.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/suspend_32.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/desc.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/ldt.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/i387.h \
    $(wildcard include/config/as/fxsaveq.h) \
  /home/user/linux-3.2.0/include/linux/kernel_stat.h \
  /home/user/linux-3.2.0/include/linux/interrupt.h \
    $(wildcard include/config/irq/forced/threading.h) \
    $(wildcard include/config/generic/irq/probe.h) \
  /home/user/linux-3.2.0/include/trace/events/irq.h \
  /home/user/linux-3.2.0/include/linux/tracepoint.h \
    $(wildcard include/config/tracepoints.h) \
  /home/user/linux-3.2.0/include/linux/jump_label.h \
    $(wildcard include/config/jump/label.h) \
  /home/user/linux-3.2.0/arch/x86/include/asm/jump_label.h \
  /home/user/linux-3.2.0/include/trace/define_trace.h \
    $(wildcard include/config/event/tracing.h) \
  /home/user/linux-3.2.0/include/linux/regset.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/user.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/user_32.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/xsave.h \
  /home/user/linux-3.2.0/arch/x86/kernel/asm-offsets_32.c \
    $(wildcard include/config/lguest.h) \
    $(wildcard include/config/lguest/guest.h) \
  /home/user/linux-3.2.0/include/linux/lguest.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/lguest_hcall.h \
  /home/user/linux-3.2.0/arch/x86/kernel/../../../drivers/lguest/lg.h \
  /home/user/linux-3.2.0/include/linux/lguest_launcher.h \
  /home/user/linux-3.2.0/arch/x86/include/asm/lguest.h \

arch/x86/kernel/asm-offsets.s: $(deps_arch/x86/kernel/asm-offsets.s)

$(deps_arch/x86/kernel/asm-offsets.s):
