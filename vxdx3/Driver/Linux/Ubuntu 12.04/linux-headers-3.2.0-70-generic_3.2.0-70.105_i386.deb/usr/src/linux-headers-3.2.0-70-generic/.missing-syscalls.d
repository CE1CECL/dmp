-:  /home/user/linux-3.2.0/include/linux/kconfig.h \
 include/generated/autoconf.h \
 /home/user/linux-3.2.0/arch/x86/include/asm/types.h \
 /home/user/linux-3.2.0/include/asm-generic/types.h \
 /home/user/linux-3.2.0/include/asm-generic/int-ll64.h \
 /home/user/linux-3.2.0/arch/x86/include/asm/bitsperlong.h \
 /home/user/linux-3.2.0/include/asm-generic/bitsperlong.h \
 /home/user/linux-3.2.0/arch/x86/include/asm/unistd.h \
 /home/user/linux-3.2.0/arch/x86/include/asm/unistd_32.h
