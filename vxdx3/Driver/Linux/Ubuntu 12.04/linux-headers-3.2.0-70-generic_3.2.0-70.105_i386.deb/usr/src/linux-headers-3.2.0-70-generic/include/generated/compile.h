/* This file is auto generated, version 105 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#105 SMP Fri Oct 31 11:44:11 CST 2014"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ubuntu"
#define LINUX_COMPILER "gcc version 4.6.3 (Ubuntu/Linaro 4.6.3-1ubuntu5) "
