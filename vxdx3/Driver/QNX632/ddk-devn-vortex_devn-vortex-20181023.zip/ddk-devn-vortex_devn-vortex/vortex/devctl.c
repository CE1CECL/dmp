/*
 * Copyright 2003, QNX Software Systems Ltd. All Rights Reserved.
 *
 * This source code may contain confidential information of QNX Software
 * Systems Ltd.  (QSSL) and its licensors. Any use, reproduction,
 * modification, disclosure, distribution or transfer of this software,
 * or any software which includes or is based upon any of this code, is
 * prohibited unless expressly authorized by QSSL by written agreement. For
 * more information (including whether this source code file has been
 * published) please email licensing@qnx.com.
 */

#include <vortex.h>

/* Adds one to a MAC address */
static void
bump_macaddr(uint8_t *mcaddr)
{
	int	i;

	for (i = 5; i >= 0; i--) 
	{
		if (mcaddr[i] + 1 < 0x100) 
		{
			mcaddr[i]++;
			while (i++ < 6)
				mcaddr[i] = 0;
			return;
		}
	}
}

/*
 * Returns non-zero if the device needs to be reset because the
 * hash table has changed.
 */
int
vortex_mcast_add(vortex_dev_t *vortex, uint8_t *mcast)
{
	uint32_t	crc;

	crc = nic_calc_crc_le(mcast, 6);
	crc = (crc >> 26);
	return (vortex->multicast_counts[crc]++ == 0);
}

/*
 * Returns non-zero if the device needs to be reset because the
 * hash table has changed.  Returns -1 if the bit was not in the table.
 */
int
vortex_mcast_remove(vortex_dev_t *vortex, uint8_t *mcast)
{
	int		rc;
	uint32_t	crc;

	crc = nic_calc_crc_le(mcast, 6);
	crc = (crc >> 26);
	switch (vortex->multicast_counts[crc]) 
	{
	case 0:
		return -1;
	case 1:
		rc = 1;
	default:
		rc = 0;
	}

	vortex->multicast_counts[crc]--;

	return rc;
}

static int
handle_multicast(vortex_dev_t *vortex, io_net_msg_join_mcast_t *msg)
{
	uint8_t	tmp_mcaddr[6];
	int		rc;
	int		reset = 0;

	switch (msg->type) 
	{
	case _IO_NET_JOIN_MCAST:
		if (msg->flags & _IO_NET_MCAST_ALL) 
		{
			if (vortex->n_allmulti++ == 0) 
			{
				/* Turning on promiscuous multicast */
				reset = 1;
			}
		} 
		else 
		{
			if (nic_ether_mcast_valid(msg) == -1)
				return EINVAL;

			memcpy(tmp_mcaddr, LLADDR(&msg->mc_min.addr_dl), 6);
			while (1) 
			{
				reset |= vortex_mcast_add(vortex, tmp_mcaddr);
				if (!memcmp(tmp_mcaddr,
				    LLADDR(&msg->mc_max.addr_dl), 6))
					break;
				bump_macaddr(tmp_mcaddr);
			}
		}
		break;

	case _IO_NET_REMOVE_MCAST:
		if (msg->flags & _IO_NET_MCAST_ALL) 
		{
			switch (vortex->n_allmulti) 
			{
				case 0:
					break;
				case 1:
					/* Turning off promiscuous multicast */
					reset = 1;
					/* Fallthrough */
				default:
					vortex->n_allmulti--;
					break;
			}
		} 
		else 
		{
			memcpy(tmp_mcaddr, LLADDR(&msg->mc_min.addr_dl), 6);
			while (1) 
			{
				rc = vortex_mcast_remove(vortex, tmp_mcaddr);
				if (rc == -1)
					return ENOENT;
				reset |= rc;
				if (!memcmp(tmp_mcaddr,
				    LLADDR(&msg->mc_max.addr_dl), 6))
					break;
				bump_macaddr(tmp_mcaddr);
			}
		}
		break;

	default:
		if (vortex->cfg.verbose)
			nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
			          "devn-vortex: message 0x%x not supported",
			           msg->type);
		return EINVAL;
	}

	if (reset) 
	{
		pthread_mutex_lock(&vortex->tx_mutex);
		pthread_mutex_lock(&vortex->rx_mutex);

		vortex_reset(vortex);

		pthread_mutex_unlock(&vortex->rx_mutex);
		pthread_mutex_unlock(&vortex->tx_mutex);
	}

	return EOK;
}

/*
 * vortex_devctl(hdl, dcdm, data, size, ret)
 *
 *  Purpose: Called by io-net when a devctl() is performed on the 
 *           device entry io-net exports on our drivers behalf
 *           (ie: /dev/io-net/en0). 
 */
int
vortex_devctl(void *hdl, int dcmd, void *data, size_t size, union _io_net_dcmd_ret_cred *ret)
{	          
	vortex_dev_t *vortex = (vortex_dev_t *) hdl;
	int		status;
	npkt_t	*list, *npkt;
	int		reset = 0;

	status = EOK;
	          
	switch (dcmd) 
	{
		case DCMD_IO_NET_TX_FLUSH:
			pthread_mutex_lock(&vortex->tx_mutex);
			list = vortex_collect_tx_packets(vortex);
			pthread_mutex_unlock(&vortex->tx_mutex);
			while (npkt = list) 
			{
				list = npkt->next;
				vortex->ion->tx_done(vortex->reg_hdl, npkt);
			}
			break;

		case DCMD_IO_NET_GET_STATS:
			memcpy(data, &vortex->stats, sizeof (vortex->stats));
			break;

		case DCMD_IO_NET_GET_CONFIG:
			memcpy(data, &vortex->cfg, sizeof (vortex->cfg));
			break;

		case DCMD_IO_NET_PROMISCUOUS:
			/*
			 * Make sure only root access
			 */
			if (ret->ret_cred.cred->euid) 
				return EPERM;

			if (*(int *)data) 
			{
				if (vortex->n_prom++ == 0) 
				{
					vortex->cfg.flags |= NIC_FLAG_PROMISCUOUS;
					reset = 1;
				}
			} 
			else 
			{
				switch (vortex->n_prom) 
				{
				case 0:
					break;
				case 1:
					vortex->cfg.flags &= ~NIC_FLAG_PROMISCUOUS;
					reset = 1;
				/* Fallthrough */
				default:
					vortex->n_prom--;
					break;
				}
			}

			if (reset) 
			{
				pthread_mutex_lock(&vortex->tx_mutex);
				pthread_mutex_lock(&vortex->rx_mutex);

				vortex_reset(vortex);

				pthread_mutex_unlock(&vortex->rx_mutex);
				pthread_mutex_unlock(&vortex->tx_mutex);
			}
			break;

		case DCMD_IO_NET_CHANGE_MCAST:
			if (vortex->cfg.flags & NIC_FLAG_MULTICAST) 
			{
				status = handle_multicast(vortex, (io_net_msg_join_mcast_t *)data);
			} 
			else 
			{
				if (vortex->cfg.verbose > 3)
					nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
			  		          "devn-vortex: devctl() MCAST ENOTSUP");
				status = ENOTSUP;
			}
			break;

		default:
			status = ENOTSUP;
			break;
	}
	          	
	return status;
}
