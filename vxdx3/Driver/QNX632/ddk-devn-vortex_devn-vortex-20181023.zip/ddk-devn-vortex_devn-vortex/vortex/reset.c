/*
 * Copyright 2003, QNX Software Systems Ltd. All Rights Reserved.
 *
 * This source code may contain confidential information of QNX Software
 * Systems Ltd.  (QSSL) and its licensors. Any use, reproduction,
 * modification, disclosure, distribution or transfer of this software,
 * or any software which includes or is based upon any of this code, is
 * prohibited unless expressly authorized by QSSL by written agreement. For
 * more information (including whether this source code file has been
 * published) please email licensing@qnx.com.
 */

#include <vortex.h>

/*
 * vortex_reset_init_block(vortex, ladr)
 *
 *  Purpose: Configure the initialization block stored in the vortex
 *           structure and point the hardware at this structure.
 */
static int
vortex_reset_init_block( void *handle )
{
	vortex_init_block_t ib;
	int			cnt;
	vortex_dev_t *vortex = (vortex_dev_t *)handle;
	int			iobase;
	int			i;

	iobase = vortex->iobase;

	memset(&ib, 0, sizeof(vortex_init_block_t));

	if (vortex->cfg.flags & NIC_FLAG_PROMISCUOUS)
		ib.mode_dlen |= ENDIAN_LE32(VORTEX_IB_PROMISCUOUS);
	else
	    ib.mode_dlen = 0;

	memcpy(ib.padr, vortex->cfg.current_address, ETH_MAC_LEN);

	if (vortex->cfg.flags & NIC_FLAG_MULTICAST) 
	{
		if (vortex->n_allmulti) 
		{
			/* Turn on all the bits */
			for (i = 0;
			    i < sizeof (ib.ladr) / sizeof (ib.ladr[0]); i++) {
				ib.ladr[i] = ~0;
			}
		}
		else 
		{
			/* If the index's multicast_count is not 0, set that bit */
			for (i = 0; i < VORTEX_MULTICAST_ENTRIES; i++) 
			{
				if (vortex->multicast_counts[i])
					ib.ladr[i >> 3] |= (1 << (i & 7));
			}
		}
	}

	for(cnt = 0; !(vortex->num_rx_descriptors & (1 << cnt)); cnt++)
		;

	ib.rdra       = ENDIAN_LE32(drvr_mphys((void *)vortex->rfd) + vortex->bmstr);
	ib.mode_dlen |= ENDIAN_LE32((cnt << 20));
	for(cnt = 0; !(vortex->num_tx_descriptors & (1 << cnt)); cnt++)
		;

	ib.tdra       = ENDIAN_LE32(drvr_mphys((void *)vortex->tfd) + vortex->bmstr);
	ib.mode_dlen |= ENDIAN_LE32((cnt << 28));

	memcpy(vortex->ib, &ib, sizeof(vortex_init_block_t));

	return 0;
}

/*
 * vortex_reset_rings(count)
 *
 *  Purpose:  Init all the counts and indexes used to track data
 *            in the rings and packet queues.
 */
static int
vortex_reset_rings( void *handle)
{
	vortex_dev_t	*vortex = (vortex_dev_t*)handle;
	r6040_tx_rx_desc_t	*tfd;
	r6040_tx_rx_desc_t	*rfd;
	int		cnt;
	npkt_t		*npkt;
	net_iov_t	*iov;
	      
	/* reset rx producer consumer indexes */
	vortex->rx_cidx  = 0;
	vortex->rx_pidx  = 0;
	vortex->tfd_pidx = vortex->num_tx_descriptors - 1;
	vortex->tfd_cidx = vortex->num_tx_descriptors - 1;
	vortex->tx_dfree = vortex->num_tx_descriptors;

	/* set up tx descriptor entries */
	for (cnt = 0, tfd = (r6040_tx_rx_desc_t *)vortex->tfd;
	     cnt < vortex->num_tx_descriptors; cnt++, tfd++) 
	{
		tfd->status = 0;
		tfd->len = 0;
		tfd->buf = 0;
		
		if (cnt < (vortex->num_tx_descriptors -1))
			tfd->ndesc = ENDIAN_LE32(vortex->ion->mphys((void*)(tfd + 1)));
		else
			tfd->ndesc = ENDIAN_LE32(vortex->ion->mphys((void*)vortex->tfd)); 	
	}

	/* set up rx descriptor entries */
	for (cnt = 0, rfd = (r6040_tx_rx_desc_t *)vortex->rfd; 
	     cnt < vortex->num_rx_descriptors; cnt++, rfd++) 
	{
		npkt = vortex->rx_pktq[cnt];
		iov  = TAILQ_FIRST(&npkt->buffers)->net_iov;
		
		CACHE_INVAL(&vortex->cachectl, iov->iov_base,
		    iov->iov_phys, iov->iov_len);
		
		rfd->buf    = ENDIAN_LE32(iov->iov_phys + vortex->bmstr);
		rfd->len    = 0;
		rfd->status = ENDIAN_LE16(R6040_OWN);
		
		if (cnt < (vortex->num_rx_descriptors -1))
			rfd->ndesc = ENDIAN_LE32(vortex->ion->mphys((void*)(rfd + 1))); 
		else
			rfd->ndesc = ENDIAN_LE32(vortex->ion->mphys((void*)vortex->rfd));			
	}
	      
	return 0;
}

/*
 * vortex_reset(vortex, ladr)
 *
 *  Purpose: Reset the physical card and driver data structures.
 *
 *  WARNING: Protected by tx & rx mutexes
 */
int
vortex_reset( void *handle )
{
	int		  cnt;
	int i     = 0;
	ushort_t  temp;
	npkt_t	*npkt, *head;
	vortex_dev_t	*vortex = (vortex_dev_t *)handle;
	int		base = vortex->iobase;

	vortex->reseting = 1;
	          
	/* halt the R6040 card */
	
	// Stop MAC
    r6040_write16(base + MIER , MIER_CLEAN_MASK); /* Mask Off Interrupt */
    r6040_write16(base + MCR1 , MCR1_MRST);       /* Reset RDC MAC */

	do
	{
		r6040_read16(base + MCR1, &temp);
	} while((++i < 2048) && (temp & MCR1_MRST));
	usleep(1000); 

	// Reset internal state machine
	r6040_write16(base + MMBC , 0x02);
	r6040_write16(base + MMBC , 0x00);
	usleep(5000);

	/* check for used tx buffers and free them */
	
	head = NULL;
	for (cnt = 0; cnt < vortex->num_tx_descriptors; cnt++) 
	{
		npkt = vortex->tx_pktq[cnt];
		vortex->tx_pktq[cnt] = NULL;
		if (npkt) 
		{
			npkt->next = head;
			head = npkt;
		}
	}

	while (head) 
	{
		npkt = head;
		head = head->next;
		npkt->next = NULL;
		vortex->ion->tx_done(vortex->reg_hdl, npkt);
	}

	vortex_reset_rings( vortex );
	vortex_reset_init_block( vortex );

	/* re-init the card */
	vortex_init_config_card(vortex);
	
	vortex->reseting = 0;
	
	return 0;
}
