/*
 * Copyright 2003, QNX Software Systems Ltd. All Rights Reserved.
 *
 * This source code may contain confidential information of QNX Software
 * Systems Ltd.  (QSSL) and its licensors. Any use, reproduction,
 * modification, disclosure, distribution or transfer of this software,
 * or any software which includes or is based upon any of this code, is
 * prohibited unless expressly authorized by QSSL by written agreement. For
 * more information (including whether this source code file has been
 * published) please email licensing@qnx.com.
 */

#include <vortex.h>

/*
 * vortex_receive_add_packet(vortex, npkt)
 *
 *  Purpose: Put a packet into the packet queue and setup the rx 
 *           descriptor ring to use this packet. 
 */
static int
vortex_receive_add_packet( void *handle , npkt_t *npkt)
{
	vortex_dev_t *vortex = (vortex_dev_t*) handle;
	int		pidx;
	volatile r6040_tx_rx_desc_t	*rfd;
	net_buf_t	*buf;
	net_iov_t	*iov;
	          
	pidx = vortex->rx_pidx;
	rfd  = &vortex->rfd[pidx];

	vortex->rx_pktq[pidx] = npkt;
	buf = TAILQ_FIRST(&npkt->buffers);
	iov = buf->net_iov;

	/* advance rx producer index */
	vortex->rx_pidx = (pidx + 1) % vortex->num_rx_descriptors;

	CACHE_INVAL(&vortex->cachectl,
	    iov->iov_base, iov->iov_phys, iov->iov_len);
	
	rfd->buf    = ENDIAN_LE32(iov->iov_phys + vortex->bmstr);
	rfd->len    = 0;
	rfd->status = ENDIAN_LE16(R6040_OWN);

	return 0;
}

/*
 * vortex_receive(vortex, npkt)
 *
 *  Purpose: Function called by event handler when new packet(s)
 *           are received. 
 */
int
vortex_receive( void *handle )
{
	vortex_dev_t	*vortex = (vortex_dev_t *)handle;
	npkt_t		*new;
	npkt_t		*npkt;

	nic_stats_t    		  *gstats = &vortex->stats;
	nic_ethernet_stats_t  *estats = &vortex->stats.un.estats;

	int		cidx;
	int		i;
	
	int		pkt_len;
	int		ret = 1;
	ushort_t		status;
	volatile r6040_tx_rx_desc_t	*rfd;
	net_buf_t *buf;
	          
	for(i = 0; i < vortex->num_rx_descriptors; i++) 
	{
		cidx   = vortex->rx_cidx;
		npkt   = vortex->rx_pktq[cidx];
		rfd    = &vortex->rfd[cidx];
		status = ENDIAN_LE16(rfd->status);

		if (status & R6040_OWN) 
			/* chip owns this descriptor */
			break;
 
		/* don't include CRC */
		pkt_len = ENDIAN_LE16(rfd->len) - 4;   
		/* advance consumer index */
		vortex->rx_cidx = (cidx + 1) % vortex->num_rx_descriptors;
		vortex->rx_pktq[cidx] = NULL;

		if (!(status & R6040_OK) || (pkt_len > ETH_MAX_PKT_LEN)) 
	    {  
			if (status & R6040_RX_OBL)
				estats->internal_rx_errors++;
			if (status & R6040_RX_CRCERR)
				estats->fcs_errors++;
			if (status & R6040_RX_RUNT)
				estats->short_packets++;
			if (status & R6040_RX_DRIBBLE)
				estats->dribble_bits++;
			if (status & R6040_RX_LONG)
				estats->oversized_packets++;

			vortex_receive_add_packet(vortex, npkt);
			continue;
		}

		npkt->framelen = pkt_len;
		vortex->stats.octets_rxed_ok += pkt_len;

		buf = TAILQ_FIRST(&npkt->buffers);
		buf->net_iov->iov_len = npkt->framelen;
		gstats->rxed_ok++;

		pthread_mutex_lock(&vortex->rx_free_pkt_q_mutex);
		/* take a packet off the free queue */
		if ((new = vortex->rx_free_pkt_q))
		{
			vortex->rx_free_pkt_q = new->next;
			new->next = NULL;
			vortex->num_rx_free--;
			
			pthread_mutex_unlock(&vortex->rx_free_pkt_q_mutex);
		} 
		else 
		{
			pthread_mutex_unlock(&vortex->rx_free_pkt_q_mutex);
			
			if (!(new = vortex_alloc_npkt(vortex, 1532))) 
			{
				errno = ENOBUFS;
				nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
				    "devn-vortex: Packet Allocation failure.");
				break;
			}
		}
		
		npkt->flags  = _NPKT_UP | R6040_KEEP_PACKET;
		npkt->iface = 0;

		if (vortex->cfg.flags & NIC_FLAG_PROMISCUOUS)
			npkt->flags |= _NPKT_PROMISC;

		if (npkt = vortex->ion->tx_up_start(vortex->reg_hdl, npkt, 0, 0, vortex->cell, vortex->cfg.lan, 0, vortex))
		{		
			vortex->ion->free(npkt->org_data);
			vortex->ion->free(npkt);
		}

		npkt = new;

		vortex_receive_add_packet(vortex, npkt);
	}
	          
	return ret;
}

/*
 * vortex_receive(vortex, npkt)
 *
 *  Purpose: Used by io-net when a packet that was pushed up the
 *           stack is ready to be used again.
 */
int
vortex_receive_complete(npkt_t *npkt, void *hdl, void *func_hdl)
{
	vortex_dev_t *vortex = (vortex_dev_t *)hdl;
	net_buf_t	 *buf;
	          
	pthread_mutex_lock(&vortex->rx_free_pkt_q_mutex);
	
	if (vortex->num_rx_free < DEFAULT_NUM_RX_DESCRIPTORS && 
	    ((npkt->flags & _NPKT_ORG_MASK) == R6040_KEEP_PACKET)) 
	{
		npkt->ref_cnt = 1;
		npkt->tot_iov = 1;
		npkt->req_complete = 0;
		npkt->flags = _NPKT_UP | R6040_KEEP_PACKET ;
		npkt->iface = 0;

		buf = TAILQ_FIRST(&npkt->buffers);
		buf->net_iov->iov_len = R6040_PACKET_MTU_SIZE;
		buf->niov = 1;

		npkt->next = vortex->rx_free_pkt_q;
		vortex->rx_free_pkt_q = npkt;
		vortex->num_rx_free++;
		
		pthread_mutex_unlock(&vortex->rx_free_pkt_q_mutex);
	} 
	else 
	{
		pthread_mutex_unlock(&vortex->rx_free_pkt_q_mutex);
		
		vortex->ion->free(npkt->org_data);
		vortex->ion->free(npkt);
	}
	          
	return 0;
}
