/*
 * Copyright  2000-2003, QNX Software Systems Ltd.  All Rights Reserved
 *
 * This source code has been published by QNX Software Systems Ltd.
 * (QSSL).  However, any use, reproduction, modification, distribution
 * or transfer of this software, or any software which includes or is
 * based upon any of this code, is only permitted under the terms of
 * the QNX Open Community License version 1.0 (see licensing.qnx.com for
 * details) or as otherwise expressly authorized by a written license 
 * agreement from QSSL.  For more information, please email 
 * licensing@qnx.com.
 *
 */

#include <vortex.h>

/*
 * vortex_advertise(vortex, npkt)
 *
 *  Purpose: Called by the driver at startup to inform io-net of its
 *		existence.  Also used by io-net when the stack layout 
 *		changes.
 */
int
vortex_advertise(int reg_hdl, void *func_hdl)
{	          
	npkt_t			*npkt;
	net_buf_t		*nb;
	net_iov_t		*iov;
	vortex_dev_t	*vortex = (vortex_dev_t*) func_hdl;
	io_net_msg_dl_advert_t	*ap;
	          
	npkt = vortex->ion->alloc_up_npkt(sizeof(*nb) + sizeof *iov, (void **)&nb);
	if (npkt == NULL)
		return 0;

	ap = vortex->ion->alloc(sizeof(*ap), 0);
	if (ap == NULL) 
	{
		vortex->ion->free(npkt);
		return 0;
	}

	TAILQ_INSERT_HEAD(&npkt->buffers, nb, ptrs);

	iov = (net_iov_t *)(nb + 1);

	nb->niov      = 1;
	nb->net_iov   = iov;
	iov->iov_base = ap;
	iov->iov_len  = sizeof *ap;

	memset(ap, 0x00, sizeof *ap);
	ap->type   = _IO_NET_MSG_DL_ADVERT;
	ap->iflags = (IFF_MULTICAST | IFF_BROADCAST | IFF_RUNNING);
	
	ap->mtu_min       = 0;
	ap->mtu_max       = vortex->cfg.mtu;
	ap->mtu_preferred = vortex->cfg.mtu;
	strcpy(ap->up_type, vortex->cfg.uptype);
	itoa(vortex->cfg.lan, ap->up_type + 2, 10);

	strcpy(ap->dl.sdl_data, ap->up_type);

	ap->dl.sdl_len    = sizeof(struct sockaddr_dl);
	ap->dl.sdl_family = AF_LINK;
	ap->dl.sdl_index  = vortex->cfg.lan;
	ap->dl.sdl_type   = IFT_ETHER;
	ap->dl.sdl_nlen   = strlen(ap->dl.sdl_data); /* not null terminated */
	ap->dl.sdl_alen   = 6;
	memcpy(ap->dl.sdl_data + ap->dl.sdl_nlen, vortex->cfg.current_address, 6);

	npkt->org_data = ap;
	npkt->flags   |= _NPKT_MSG;
	npkt->iface    = 0;
	npkt->framelen = sizeof *ap;
	npkt->tot_iov  = 1;

	if (vortex->ion->reg_tx_done(vortex->reg_hdl, npkt, vortex) == -1) 
	{
		vortex->ion->free(ap);
		vortex->ion->free(npkt);
		return(0);
	}

	if (vortex->ion->tx_up(vortex->reg_hdl,
	    npkt, 0, 0, vortex->cell, vortex->cfg.lan, 0) == 0) 
		vortex->ion->tx_done(vortex->reg_hdl, npkt);
	          
	return 0;
}
