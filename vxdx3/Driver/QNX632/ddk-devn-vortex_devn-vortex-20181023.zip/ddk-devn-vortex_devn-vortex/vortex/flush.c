/*
 * Copyright 2003, QNX Software Systems Ltd. All Rights Reserved.
 *
 * This source code may contain confidential information of QNX Software
 * Systems Ltd.  (QSSL) and its licensors. Any use, reproduction,
 * modification, disclosure, distribution or transfer of this software,
 * or any software which includes or is based upon any of this code, is
 * prohibited unless expressly authorized by QSSL by written agreement. For
 * more information (including whether this source code file has been
 * published) please email licensing@qnx.com.
 */



#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "vortex.h"

/*
 * vortex_flush( count )
 *
 *  Purpose: Exported function for io-net. Flushes all the outstanding
 *           packets in the tx queue.
 */
int
vortex_flush(int reg_hdl, void *hdl)
{	          
	vortex_dev_t	*vortex = (vortex_dev_t *) hdl;
	npkt_t		*npkt;
	npkt_t		*tmp;

	npkt             = vortex->tx_nhead;
	vortex->tx_nhead = vortex->tx_ntail = NULL;
	          
	for(; npkt; npkt = tmp) 
	{
		tmp = npkt->next;
		vortex->ion->tx_done(vortex->reg_hdl, npkt);
	}
	          
	return 0;
}
