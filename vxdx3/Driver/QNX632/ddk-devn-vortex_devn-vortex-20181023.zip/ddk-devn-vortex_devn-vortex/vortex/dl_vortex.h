/*
 * Copyright 2003, QNX Software Systems Ltd. All Rights Reserved.
 *
 * This source code may contain confidential information of QNX Software
 * Systems Ltd.  (QSSL) and its licensors. Any use, reproduction,
 * modification, disclosure, distribution or transfer of this software,
 * or any software which includes or is based upon any of this code, is
 * prohibited unless expressly authorized by QSSL by written agreement. For
 * more information (including whether this source code file has been
 * published) please email licensing@qnx.com.
 */



extern int io_net_dll_entry_vortex();

static const struct dll_syms _vortex_symbols[] = 
{
    {"io_net_dll_entry", &io_net_dll_entry_vortex},
    {NULL, NULL}
};

#define DLL_VORTEX_LIST   "devn-vortex.so", _vortex_symbols
