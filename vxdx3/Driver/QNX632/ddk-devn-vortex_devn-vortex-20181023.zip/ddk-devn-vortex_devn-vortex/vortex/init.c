/*
 * Copyright 2003, QNX Software Systems Ltd. All Rights Reserved.
 *
 * This source code may contain confidential information of QNX Software
 * Systems Ltd.  (QSSL) and its licensors. Any use, reproduction,
 * modification, disclosure, distribution or transfer of this software,
 * or any software which includes or is based upon any of this code, is
 * prohibited unless expressly authorized by QSSL by written agreement. For
 * more information (including whether this source code file has been
 * published) please email licensing@qnx.com.
 */

#include <vortex.h>


extern uint32_t VortexDevices[];
extern io_net_registrant_t vortex_entry;

/* local prototypes */
static void vortex_init_stop_thread( void *handle );
static int vortex_detect(void *dll_hdl, io_net_self_t *ion, char *options);

static int vortex_init_alloc_memory( void *handle );
static int vortex_start_driver(void *dll_hdl, io_net_self_t *ion, void *handle );
static void vortex_init_stop_thread( void *handle );
static int vortex_register_device( void *handle );

static void vortex_set_multicast_address(void *handle, int num_addrs, char *address_list);


static unsigned known_device_ids[] = {PCI_VENDOR_ID_RDC,
									  PCI_DEVICE_ID_RDC_R6040,
									  0 };

static uchar_t  MacAddress[6] = {0x00, 0x00, 0x60, 0x00, 0x00, 0x01};


/*
 * vortex_set_multicast_address()
 *
 *  Purpose: Set the multicast address.
 */
static void 
vortex_set_multicast_address(void *handle, int num_addrs, char *address_list)
{
	vortex_dev_t  *vortex = (vortex_dev_t *) handle;
	
    ulong_t IoAddr;
    ushort_t *Addr;
    int i;

    uchar_t  Address[8];
    uchar_t  *ptr;
    ushort_t Dummy;

    IoAddr = vortex->iobase + MID1L;
    Addr   = (ushort_t*) address_list;

    /* Set MultiCast Address */
    for (i = 0; (i < num_addrs) && (i < 4); i++)
    {
    	r6040_write16(IoAddr, Addr[0]);
		IoAddr += 2;
		r6040_write16(IoAddr, Addr[1]);
		IoAddr += 2;
		r6040_write16(IoAddr, Addr[2]);
		IoAddr += 4;
	    Addr += 3;	/* Point to next multicast address */
    }

	/* Set non-use multicast address register */
    for (i = num_addrs; i < 4; i++)
	{
		r6040_write16(IoAddr, 0xFFFF);
    	IoAddr += 2;
    	r6040_write16(IoAddr, 0xFFFF);
    	IoAddr += 2;
    	r6040_write16(IoAddr, 0xFFFF);
    	IoAddr += 4;
    }

     IoAddr = vortex->iobase + MID1L;
     ptr    = Address;
     for (i = 0; i < R6040_LENGTH_OF_ADDRESS/2; i++)
     {
     	r6040_read16(IoAddr, &Dummy);
        WRITEMEM16(ptr, Dummy);
	    ptr    += 2;
        IoAddr += 2;
     }

     IoAddr = vortex->iobase + MID2L;
     ptr    = Address;
     for (i = 0; i < R6040_LENGTH_OF_ADDRESS/2; i++)
     {
     	r6040_read16(IoAddr, &Dummy);
        //WRITEMEM32(ptr, Dummy);  // QQQ
        WRITEMEM16(ptr, Dummy);
	    ptr    += 2;
        IoAddr += 2;
     }

	 IoAddr = vortex->iobase + MID3L;
     ptr    = Address;
     for (i = 0; i < R6040_LENGTH_OF_ADDRESS/2; i++)
     {
     	r6040_read16(IoAddr, &Dummy);
        //WRITEMEM32(ptr, Dummy);
        WRITEMEM16(ptr, Dummy);
	    ptr    += 2;
        IoAddr += 2;
     }
}

/*
 * vortex_init_alloc_memory( vortex )
 *
 *  Purpose: Allocate all the dynamic memory for the driver.  This
 *           includes packet queues and physical memory rings for
 *           sharing data with the hardware.
 */
static int
vortex_init_alloc_memory( void *handle )
{
	vortex_dev_t  *vortex = (vortex_dev_t *) handle;
	int	 cnt;

	/* allocate rx pkt array  */
	vortex->rx_pktq = calloc(vortex->num_rx_descriptors, sizeof(vortex->rx_pktq));
	if (vortex->rx_pktq == NULL)
		return 1;

	/* allocate tx pkt array */
	vortex->tx_pktq = calloc(vortex->num_tx_descriptors, sizeof(vortex->tx_pktq));
	if (vortex->tx_pktq == NULL) 
	{
		free(vortex->rx_pktq);
		return 1;
	}

	/* allocate iblock, and descriptors */
	vortex->mem_size = vortex->num_rx_descriptors * sizeof(r6040_tx_rx_desc_t) +
	                   vortex->num_tx_descriptors * sizeof(r6040_tx_rx_desc_t) + 
	                   sizeof(vortex_init_block_t);

	vortex->mem = mmap(NULL, vortex->mem_size, PROT_READ | PROT_WRITE | PROT_NOCACHE, 
	                   MAP_ANON | MAP_PHYS, NOFD, 0);
	if (vortex->mem == MAP_FAILED) 
	{
		free(vortex->rx_pktq);
		free(vortex->tx_pktq);
		return 1;
	}

	vortex->tfd = (r6040_tx_rx_desc_t *)vortex->mem;
	vortex->rfd = (r6040_tx_rx_desc_t *)(vortex->tfd + vortex->num_tx_descriptors);
	vortex->ib  = (vortex_init_block_t *)(vortex->rfd + vortex->num_rx_descriptors);

	for(cnt = 0; cnt < vortex->num_rx_descriptors; cnt++) 
	{
		vortex->rx_pktq[cnt] = vortex_alloc_npkt(vortex, 1532);  // 1514 ?
	}

	vortex->rx_free_pkt_q = NULL;
	vortex->num_rx_free = 0;

	return 0;
}

/*
 * vortex_init_config_card( vortex )
 *
 *  Purpose:  Setup the registers on the card that only need
 *            to be configured once at startup. 
 */
int
vortex_init_config_card( void *handle )
{
	vortex_dev_t   *vortex = (vortex_dev_t *)handle;
	int            iobase  = vortex->iobase;
	int            i = 0;
	ushort_t       temp;
	ulong_t        address = 0;
	ushort_t *addr = (ushort_t *)MacAddress;
	
	/* backup MAC address before reset card */
	r6040_read16(iobase + MID0L, &addr[0]);
	r6040_read16(iobase + MID0M, &addr[1]);
	r6040_read16(iobase + MID0H, &addr[2]);

    // Reset the card
	// Stop MAC
    r6040_write16(iobase + MIER , MIER_CLEAN_MASK); /* Mask Off Interrupt */
    r6040_write16(iobase + MCR1 , MCR1_MRST);       /* Reset RDC MAC */

    do 
    {
		r6040_read16(iobase + MCR1, &temp);
    } while((++i < 2048) && (temp & MCR1_MRST));
	usleep(1000); 

	// Reset internal state machine
	r6040_write16(iobase + MMBC , 0x02);
	r6040_write16(iobase + MMBC , 0x00);
	usleep(5000);

	r6040_write16(iobase + MMBC , 0x04); //set the XMTF bit
	if (vortex->mdcs > 0x30)
		r6040_write16(iobase + MDCSC, vortex->mdcs);

	// Set MAC Address
	r6040_write16(iobase + MID0L, addr[0]);
    r6040_write16(iobase + MID0M, addr[1]);
    r6040_write16(iobase + MID0H, addr[2]);   
	
	// Set Multicast Address Register
	vortex_set_multicast_address(vortex, 0, 0);

	// Init descriptor
	address = ENDIAN_LE32(vortex->ion->mphys((void*)vortex->tfd));
	r6040_write16(iobase + MTDSA0, LSB(address));
    r6040_write16(iobase + MTDSA1, MSB(address));
    
    address = 0;
    address = ENDIAN_LE32(vortex->ion->mphys((void*)vortex->rfd));
    r6040_write16(iobase + MRDSA0, LSB(address));
    r6040_write16(iobase + MRDSA1, MSB(address));	
	
	// Buffer Size Register
	r6040_write16(iobase + MRBSR , MAX_BUF_SIZE);

#if 0
	// RX Descriptor count for flow control
	r6040_write16(iobase + MRDCR, ((DEFAULT_NUM_RX_DESCRIPTORS - 1) << 8) + DEFAULT_NUM_RX_DESCRIPTORS);
#endif

	// PHY Mode Check
    if (PHY_MODE == 0x3100)
    {
        for (i = 0; i < 3; i++)
        {
            vortex->Phy_Mode = vortex_phy_checkmode(vortex);
            if (vortex->Phy_Mode != LINK_FAILED)
                break;
        }

        if (i == 3)
            vortex->Phy_Mode = HALF_DUPLEX;
    }
    
	// MAC Bus Control Register
	r6040_write16(iobase + MBCR , MBCR_DEFAULT);
	
	//MAC TX/RX Enable
	vortex->Mac_Control = 0;       /* Clear promiscous & duplex */
    vortex->Mac_Control = (MCR0_XMTEN | MCR0_RCVEN);
    if(vortex->Phy_Mode == FULL_DUPLEX)
       vortex->Mac_Control |= vortex->Phy_Mode;

	r6040_write16(iobase + MCR0 , vortex->Mac_Control);

	/* Enable RX interrupt only */
	r6040_write16(iobase + MIER , MIER_RXENDE | MIER_RXDNAE);

	return 0;
}

/*
 * vortex_init_stop_thread( vortex )
 *
 *  Purpose: Shutdown the driver thread and free resources that were 
 *           created by vortex_init_start_thread(). 
 */
static void
vortex_init_stop_thread( void *handle )
{
	vortex_dev_t  *vortex = (vortex_dev_t  *)handle;
	      
	if (vortex->iid > 0)
		InterruptDetach(vortex->iid);

	if (vortex->coid > 0)
		ConnectDetach(vortex->coid);

	if (vortex->chid > 0)
		ChannelDestroy(vortex->chid);

	pthread_mutex_destroy(&vortex->rx_mutex);
	pthread_mutex_destroy(&vortex->rx_free_pkt_q_mutex);
	pthread_mutex_destroy(&vortex->tx_mutex);

	if (vortex->tid > 0)
		pthread_cancel(vortex->tid); 
}

/*
 * vortex_init_start_thread( vortex )
 *
 *  Purpose: Allocate resources and start driver interface thread.
 *           to handle events from interrupts and timers. 
 */
static int
vortex_init_start_thread( void *handle )
{
	vortex_dev_t		*vortex = (vortex_dev_t *)handle;
	pthread_attr_t		pattr;
	struct sched_param	param;
	struct sigevent		event;
	int			        ret;
	          
	pthread_attr_init(&pattr);
	pthread_attr_setschedpolicy(&pattr, SCHED_RR);
	param.sched_priority = NIC_PRIORITY;
	pthread_attr_setschedparam(&pattr, &param);
	pthread_attr_setinheritsched(&pattr, PTHREAD_EXPLICIT_SCHED);

	if (pthread_mutex_init(&vortex->rx_free_pkt_q_mutex, NULL) != EOK) 
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
		    "devn-vortex:  Unable to initialize RX Free Queue mutex");
		return -1;
	}

	if (pthread_mutex_init(&vortex->rx_mutex, NULL) != EOK) 
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
		    "devn-vortex:  Unable to initialize RX mutex");
		goto error1;
	}

	if (pthread_mutex_init(&vortex->tx_mutex, NULL) != EOK) 
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
		    "devn-vortex:  Unable to initialize TX mutex");
		goto error2;
	}

	vortex->cachectl.fd = NOFD;

	if (cache_init(0, &vortex->cachectl, NULL) == -1) 
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
		    "devn-vortex: cache_init() failed");
		goto error3;
	}

	vortex->chid = ChannelCreate(_NTO_CHF_DISCONNECT | _NTO_CHF_UNBLOCK);
	if (vortex->chid == -1) 
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
		    "devn-vortex:  Unable to create channel");
		goto error4;
	}

	vortex->coid = ConnectAttach(0, 0, vortex->chid, _NTO_SIDE_CHANNEL, 0);
	if (vortex->coid == -1) 
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
		    "devn-vortex:  Unable to create connection");
		goto error5;
	}

	event.sigev_notify   = SIGEV_PULSE;
	event.sigev_coid     = vortex->coid;
	event.sigev_code     = NIC_INTERRUPT_EVENT;
	event.sigev_priority = NIC_PRIORITY;

	vortex->iid = InterruptAttachEvent(vortex->cfg.irq[0], 
	    							   &event, _NTO_INTR_FLAGS_TRK_MSK);
	    							   
	if (vortex->iid == -1) 
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
		    "devn-vortex:  Unable to attach interrupt");
		goto error6;
	}

	/* create the interface thread */
	ret = pthread_create(&vortex->tid, &pattr, (void *)vortex_event_handler, vortex);
	if (ret) 
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
		    "devn-vortex:  Unable to create interface thread");
		goto error7;
	}
	
	return EOK;
	
error7:
	InterruptDetach(vortex->iid);
error6:
	ConnectDetach(vortex->chid);
error5:
	ChannelDestroy(vortex->chid);
error4:
	cache_fini(&vortex->cachectl);
error3:
	pthread_mutex_destroy(&vortex->tx_mutex);
error2:
	pthread_mutex_destroy(&vortex->rx_mutex);
error1:
	pthread_mutex_destroy(&vortex->rx_free_pkt_q_mutex);
	          
	return -1;
}

/*
 * vortex_register_device( vortex )
 *
 *  Purpose: Once everything is setup and ready, register the device 
 *           with io-net. 
 */
static int
vortex_register_device( void *handle )
{
	vortex_dev_t  *vortex = (vortex_dev_t  *)handle;
	uint16_t	  lan;
	int		      ret;
	          
	if (vortex->cfg.verbose)
		nic_dump_config( &vortex->cfg );

	vortex_entry.func_hdl = (void *) vortex;

	vortex_entry.top_type = vortex->cfg.uptype;

	if (vortex->cfg.lan != -1 ) 
	{
	  	vortex_entry.flags |= _REG_ENDPOINT_ARG;
		lan = vortex->cfg.lan;
	}

	vortex_entry.func_hdl = (void *)(vortex);

	ret = vortex->ion->reg(vortex->dll_hdl, &vortex_entry, 
	                       &vortex->reg_hdl, &vortex->cell, &lan);

	vortex->cfg.lan = lan;

	if (ret != EOK) 
		return ret;

	vortex->cfg.lan = lan;

	return EOK;
}

/*
 * vortex_init_start_driver(dll_hdl, ion, args)
 *
 *  Purpose: Start the driver for the given args. Initilize the card,
 *           setup memory, interrupts and register with io-net.
 */
static int
vortex_start_driver(void *dll_hdl, io_net_self_t *ion, void *handle )
{	          
	int			   cnt;
	int			   ret;
	
	vortex_dev_t   *vortex = (vortex_dev_t*)handle;

	/* Store these for use later */
	vortex->ion     = ion;
	vortex->dll_hdl = dll_hdl;
	          
	if ( vortex->cfg.duplex )
		vortex->line_duplex = 1;

	vortex->line_speed  = vortex->cfg.media_rate;
	vortex->line_duplex = vortex->cfg.duplex;
	
	if ( vortex->cfg.media == -1 ) 
	{
		vortex->cfg.media   = NIC_MEDIA_802_3;
		vortex->stats.media = vortex->cfg.media;
	} 
	else
	{
		vortex->stats.media = vortex->cfg.media;
	}

	vortex->cfg.mac_length = ETH_MAC_LEN;
	if (vortex->cfg.mtu == 0 || vortex->cfg.mtu > ETH_MAX_PKT_LEN)
		vortex->cfg.mtu = ETH_MAX_PKT_LEN;

	if (!vortex->num_rx_descriptors)
		vortex->num_rx_descriptors = DEFAULT_NUM_RX_DESCRIPTORS;

	if (!vortex->num_tx_descriptors) 
		vortex->num_tx_descriptors = DEFAULT_NUM_TX_DESCRIPTORS;

	vortex->tx_dfree = vortex->num_tx_descriptors;
	vortex->rx_max   = vortex->num_rx_descriptors;

	/*
	 * if mmap is set, override vortex->iobase with a mmap_device_memory
	 * rather than mmap_device_io and all _should just work_ :-)
	 */
	if ( vortex->mmap )
	{
		if ( vortex->cfg.verbose )
			nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,"devn-vortex: (Override) Mapping device memory");

		vortex->iobase = (uint32_t)mmap_device_memory(NULL, vortex->cfg.mem_window_size[0],
													  PROT_READ | PROT_WRITE | PROT_NOCACHE, MAP_SHARED,
													  vortex->cfg.mem_window_base[0]);

		if (vortex->iobase == (uintptr_t)MAP_FAILED) 
		{
			nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR, "devn-vortex: Unable to mmap_device_memory");
			return ENODEV;
		}
	} 
	else 
	{
		/* Map in the IO space memory for this card */
		if ( vortex->cfg.verbose )
			nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR, "devn-vortex: Mapping device IO");

		vortex->iobase = mmap_device_io (vortex->cfg.io_window_size[0], vortex->cfg.io_window_base[0]);

		if (vortex->iobase == (uintptr_t)MAP_FAILED)
		{ 
		    nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR, "devn-vortex: Unable to mmap_device_io");
			return ENODEV;
		}
	}

	/* Allocate the memory for the card and driver to use */
	if (ret = vortex_init_alloc_memory( vortex )) 
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR, "devn-vortex: Unable to allocate initial memory.");
		return ENODEV;
	}

	/* Start the driver thread to handle hardware/timer events */
	if (ret = vortex_init_start_thread( vortex )) 
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR, "devn-vortex: Unable to start driver thread.");
		return ENODEV;
	}

	/* Todo
	 *  - fix init and reset procedures
	 */
	vortex_init_config_card( vortex );

	/* read MAC address */
	for(cnt = 0; cnt < 6; cnt++)
	{ 
		vortex->cfg.permanent_address[cnt] = MacAddress[cnt];
	}
	          
	/* Override with MAC address from syspage, if available */
	nic_get_syspage_mac(vortex->cfg.permanent_address);

	/* check for command line override */
	if (memcmp(vortex->cfg.current_address, "\0\0\0\0\0\0", 6) == 0) 
		memcpy(vortex->cfg.current_address, vortex->cfg.permanent_address, ETH_MAC_LEN);

	/* Reset the card and all driver internal counters */ 
	pthread_mutex_lock(&vortex->tx_mutex);
	pthread_mutex_lock(&vortex->rx_mutex);
	vortex_reset( vortex );
	pthread_mutex_unlock(&vortex->rx_mutex);
	pthread_mutex_unlock(&vortex->tx_mutex);

	/* wait 1/2 second for init complete */
	delay(500);                   

	if (vortex->reseting) 
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR, "devn-vortex: Card not coming out of reset.");
		vortex_init_stop_thread( vortex );
		free(vortex->tx_pktq);
		free(vortex->rx_pktq);
		munmap(vortex->mem, vortex->mem_size);
		return ENODEV;
	}

	delay(200);

	vortex_mii_init( vortex );

	ret = vortex_register_device( vortex );
	if (ret) 
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR, "devn-vortex: Unable to register device.");
		vortex_init_stop_thread( vortex );
		free(vortex->tx_pktq);
		free(vortex->rx_pktq);
		munmap(vortex->mem, vortex->mem_size);
		return ENODEV;
	}

	vortex_advertise(vortex->reg_hdl, vortex);

	return EOK;
}

#define DIV_ROUND_UP(n, d) (((n) + (d) - 1) / (d))

/*
 * vortex_platform_init(vortex)
 *
 *  Purpose: Initialze Vortex86 platform registers
 */
static int
vortex_platform_init(vortex_dev_t *vortex)
{
	int val;
	int phdl;
	unsigned int bus, dev_func;
	unsigned char buff;

	// Accessing other PCI configuration space.
	phdl = pci_attach ( 0 );
	if ( phdl == -1 )
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,"devn-vortex: Unable to initialize PCI init ");
			return 0;
	}

	// VID and DID of NB are 17F3h and 6023h for DX3 board
	val = pci_find_device (0x6023, 0x17F3, 0, &bus, &dev_func);
	if (val == PCI_DEVICE_NOT_FOUND){
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,"devn-vortex: Unable to find device VID:");
		return 0;
	}

	/* check DRAM clock strap */
	pci_read_config8( bus, dev_func, 0x66, 1, &buff);
	nic_slogf(_SLOGC_NETWORK, _SLOG_DEBUG1,"devn-vortex: dram_ns = %u",  buff);
	vortex->mdcs = DIV_ROUND_UP(1000, (1000 * 8 / (buff * 25 / 6))) - 1;
	nic_slogf(_SLOGC_NETWORK, _SLOG_DEBUG1,"devn-vortex: mdcs = %u",  vortex->mdcs);

	dev_func++; // NB function 1

	buff=0x8; //value DMP suggested
	pci_write_config8( bus, dev_func, 0xce, 1, &buff); //DDR3 Control Option Register 5 is 0xCE
	usleep(10000);
	pci_read_config8( bus, dev_func, 0xce, 1, &buff); //read back the value
	nic_slogf(_SLOGC_NETWORK, _SLOG_DEBUG1,"devn-vortex: offset 0xce, value %x",  buff);

	pci_detach( phdl );

	return 0;
}

/*
 * vortex_init(dll_hdl, dpp, ion, options )
 *
 *  Purpose: Entry point for io-net.  Will be called for each driver 
 *           io-net loads (-d option).
 */
int
vortex_init(void *dll_hdl, dispatch_t *dpp, io_net_self_t *ion, char *options)
{	          
	int rval;
	dpp = dpp;             
	                  
	if (rval = vortex_detect(dll_hdl, ion, options)) 
	{
		errno = rval;
		
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR, 
		          "devn-vortex: failed to detect the device with returned value: %d ", rval);
		
		return -1;
	}

	return 0;
}

int
vortex_detect(void *dll_hdl, io_net_self_t *ion, char *options)
{
	nic_config_t	cfg;
	unsigned	single_id = 0;
	unsigned	bus, dev_func;
	int		devid, idx;
	int		pci_hdl;
	int		instance;
	int		rc = EOK;

	memset(&cfg, 0, sizeof (cfg));

	if (options != NULL) 
	{
		cfg.vendor_id = cfg.device_id = cfg.device_index = 0xffffffff;
		if (vortex_parse_options(NULL, options, &cfg, 0) != 0)
			return errno;
		if (cfg.device_id != 0xffffffff)
			single_id = cfg.device_id;
		if (cfg.vendor_id == 0xffffffff)
			cfg.vendor_id = PCI_VENDOR_ID_RDC;
	} 
	else 
	{
		cfg.vendor_id = PCI_VENDOR_ID_RDC;
		cfg.device_index = -1;
	}

	if ((pci_hdl = pci_attach(0)) < 0) 
	{
		rc = errno;
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
		    "devn-vortex: Could not attach to PCI server");
		return rc;
	}

	errno = ENODEV;

	instance = 0;

	for (devid = 0; known_device_ids[devid] != 0; devid++) 
	{
		idx = ((cfg.device_index == 0xffffffff) ? 0 : cfg.device_index);
		
		while (1) 
		{
			if (pci_find_device(known_device_ids[devid],
			    cfg.vendor_id, idx, &bus, &dev_func) != PCI_SUCCESS)
				break;
			
			rc = EOK;
			if (vortex_create_instance(dll_hdl, ion, instance,
			    options, cfg.vendor_id, single_id ? single_id :
			    known_device_ids[devid], idx) == -1) 
			{
				rc = errno;
				goto done;
			}
			
			if (cfg.device_index != -1) 
			{
				/* Only looking at a specific index */
				break;
			}

			instance++;
			idx++;
		}
		
		if (single_id)
			break;
	}

done:
	pci_detach(pci_hdl);

    return rc;
}

/* Private vortex arguments table */
static char *vortex_opts[] = {
	"receive",
	"transmit",
	"hpna",
	"mmap",
	NULL
};

int
vortex_parse_options( vortex_dev_t *vortex, const char *optstring, nic_config_t *cfg, int instance)
{
	char	*value;
	int	    opt;
	char	*options, *freeptr;
	char	*c;
	int	rc   = 0;
	int	err  = EOK;

	if (optstring == NULL)
		return 0;

	/* getsubopt() is destructive */
	freeptr = options = strdup(optstring);

	while (options && *options != '\0') 
	{
		c = options;
		if ((opt = getsubopt(&options, vortex_opts, &value)) == -1) 
		{
			if (nic_parse_options(cfg, value) == EOK)
				continue;
			goto error;
		}

		switch (opt) 
		{
			case 0:
				if (vortex != NULL)
					vortex->num_rx_descriptors = strtoul(value, 0, 0);
				continue;
			case 1:
				if (vortex != NULL)
					vortex->num_tx_descriptors = strtoul(value, 0, 0);
				continue;
			case 2:
				if (vortex != NULL) 
				{
					if ( value )
						vortex->force_hpna = strtoul(value, 0, 0);
					else
						vortex->force_hpna++;
				}
				continue;
			case 3:
				if (vortex != NULL) 
				{
					if ( value )
						vortex->mmap = strtol(value, 0, 0);
					else
						vortex->mmap++;
#ifdef __X86__
					nic_slogf(_SLOGC_NETWORK, _SLOG_WARNING,
						      "devn-vortex: mmap option not supported on x86");
					vortex->mmap = 0;
#endif
				}
				continue;
		}

error:
		nic_slogf(_SLOGC_NETWORK, _SLOG_WARNING,
				  "devn-vortex: unknown option %s", c);
		err = EINVAL;
		rc = -1;
	}

	free(freeptr);

	errno = err;

	return rc;
}

int vortex_create_instance(void *dll_hdl, io_net_self_t *ion, int instance,
    char *options, unsigned vendor_id, unsigned device_id, int device_index)
{
	nic_config_t		 *cfg;
	vortex_dev_t		 *vortex;
	struct pci_dev_info	 pci_info;
	uint16_t		rev;
	
	if ((vortex = calloc(sizeof (*vortex), 1)) == NULL)
		return -1;

	vortex_platform_init(vortex);

	/* Ethernet stats we are interested in */
	vortex->stats.un.estats.valid_stats = NIC_ETHER_STAT_INTERNAL_TX_ERRORS |
										  NIC_ETHER_STAT_INTERNAL_RX_ERRORS |
										  NIC_ETHER_STAT_NO_CARRIER |
										  NIC_ETHER_STAT_TX_DEFERRED |
									 	  NIC_ETHER_STAT_XCOLL_ABORTED |
										  NIC_ETHER_STAT_LATE_COLLISIONS |
										  NIC_ETHER_STAT_SINGLE_COLLISIONS |
										  NIC_ETHER_STAT_ALIGN_ERRORS |
										  NIC_ETHER_STAT_OVERSIZED_PACKETS |
										  NIC_ETHER_STAT_SHORT_PACKETS |
										  NIC_ETHER_STAT_DRIBBLE_BITS  |
										  NIC_ETHER_STAT_FCS_ERRORS; 

	/* Generic networking stats we are interested in */
	vortex->stats.valid_stats = NIC_STAT_TX_FAILED_ALLOCS | 
	                            NIC_STAT_RX_FAILED_ALLOCS;

	cfg = &vortex->cfg;

	/* set some defaults for the command line options */
	cfg->flags         = NIC_FLAG_MULTICAST;
	cfg->device_index  = device_index;
	pci_info.VendorId  = cfg->vendor_id = vendor_id;
	pci_info.DeviceId  = cfg->device_id = device_id;
	cfg->media_rate    = -1;
	cfg->priority      = NIC_PRIORITY;
	cfg->iftype        = IFT_ETHER;
	cfg->lan           = -1;
	cfg->media         = -1;
	cfg->duplex        = -1;
	strcpy(cfg->uptype, "en");
	
	vortex->cfg.revision       = NIC_CONFIG_REVISION;
	vortex->stats.revision     = NIC_STATS_REVISION;
	vortex->mmap               = 0;
	vortex->force_hpna         = 0;
	vortex->num_tx_descriptors = DEFAULT_NUM_TX_DESCRIPTORS;
	vortex->num_rx_descriptors = DEFAULT_NUM_RX_DESCRIPTORS;

	if (vortex_parse_options(vortex, options, cfg, instance) == -1)
		return -1;

	if (vortex->cfg.mtu == 0 || vortex->cfg.mtu > ETH_MAX_PKT_LEN)
		/* TODO Add oversized packet support */
		vortex->cfg.mtu = ETH_MAX_PKT_LEN;

	if (vortex->cfg.mru == 0 || vortex->cfg.mru > ETH_MAX_PKT_LEN)
		/* TODO Add oversized packet support */
		vortex->cfg.mru = ETH_MAX_PKT_LEN;

	if (cfg->flags & NIC_FLAG_PROMISCUOUS)
		vortex->n_prom = 1;

	vortex->force_advertise = -1;

	if (cfg->media_rate != -1 || cfg->duplex != -1) 
	{
		if (cfg->media_rate == 100*1000) 
		{
			if (cfg->duplex)
				vortex->force_advertise = MDI_100bTFD | MDI_100bT;
			else
				vortex->force_advertise = MDI_100bT;
		} 
		else 
		{
			if (cfg->duplex)
				vortex->force_advertise = MDI_10bTFD | MDI_10bT;
			else
				vortex->force_advertise = MDI_10bT;
		}
	}

	if ((vortex->pci_handle = pci_attach(0)) == -1) 
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
		          "devn-vortex: unable to locate pci server");
		return -1;
	}

	vortex->pci_dev_hdl = pci_attach_device(NULL,
	                                        PCI_MASTER_ENABLE | PCI_INIT_ALL, 
	                                        device_index, &pci_info);
	if (vortex->pci_dev_hdl == NULL) 
		goto fail;

	pci_read_config(vortex->pci_dev_hdl,
              	    offsetof (struct _pci_config_regs, Revision_ID),
	                1, sizeof(rev), &rev);

	vortex->cfg.device_revision = rev;

	if (cfg->num_irqs == 0) 
	{
		cfg->irq[0] = pci_info.Irq;
		cfg->num_irqs = 1;
	}

	if (cfg->num_io_windows == 0) 
	{
		cfg->io_window_base[0] = PCI_IO_ADDR(pci_info.CpuBaseAddress[0]);
		cfg->io_window_size[0] = pci_info.BaseAddressSize[0];
		cfg->num_io_windows    = 1;
	}

	if (cfg->num_mem_windows == 0) 
	{
		cfg->mem_window_base[0] = PCI_MEM_ADDR(pci_info.CpuBaseAddress[1]);
		cfg->mem_window_size[0] = pci_info.BaseAddressSize[1];
		cfg->num_mem_windows    = 1;
	}

	if (cfg->rom_base == 0)
		cfg->rom_base = PCI_ROM_ADDR(pci_info.CpuRom);

	vortex->bmstr = pci_info.CpuBmstrTranslation;

	vortex->num_rx_descriptors &= ~3;
	vortex->num_rx_descriptors = DEFAULT_NUM_RX_DESCRIPTORS;


	vortex->num_tx_descriptors &= ~3;
	vortex->num_tx_descriptors = DEFAULT_NUM_TX_DESCRIPTORS;

	if (( vortex_start_driver (dll_hdl, ion, vortex)) == EOK) 
	{
		strcpy(vortex->cfg.device_description, "DMP vortex-R6040");
		return (EOK);
	}

	pci_detach_device(vortex->pci_dev_hdl);

fail:
	pci_detach(vortex->pci_handle);

	return -1;
}

