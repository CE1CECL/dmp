/*
 * Copyright 2003, QNX Software Systems Ltd. All Rights Reserved.
 *
 * This source code may contain confidential information of QNX Software
 * Systems Ltd.  (QSSL) and its licensors. Any use, reproduction,
 * modification, disclosure, distribution or transfer of this software,
 * or any software which includes or is based upon any of this code, is
 * prohibited unless expressly authorized by QSSL by written agreement. For
 * more information (including whether this source code file has been
 * published) please email licensing@qnx.com.
 */

#include <vortex.h>

/* exported symbol for io-net */
io_net_dll_entry_t io_net_dll_entry = 
{
	2, 
	vortex_init, 
	NULL 
};

/* callback functions for io-net to use to interface with driver */
io_net_registrant_funcs_t VortexFuncs = 
{
	8,
	NULL, 
	vortex_transmit_packets, 
	vortex_receive_complete,
	vortex_shutdown1,
	vortex_shutdown2,
	vortex_advertise,
	vortex_devctl, 
	vortex_flush, 
	NULL
};

/* io-net configuration structure, used during io-net registration */ 
io_net_registrant_t vortex_entry = 
{
	_REG_PRODUCER_UP | _REG_TRACK_MCAST,
	"devn-vortex",
	"en",
	NULL,
	NULL,
	&VortexFuncs,
	0
};

/* Array of PCI device id's this driver supports */
uint32_t  VortexDevices[] = {PCI_VENDOR_ID_RDC,
                             PCI_DEVICE_ID_RDC_R6040,
			                 0 };

/* Purpose: Helper function to read/write the given register via the given 
 *          data port. 
 *
*/
 
int r6040_read8s(char *data, int len, int addr)
{
	in8s(data, len, addr);
	return(EOK);
}

int r6040_read16s(ushort_t *data, int len, int addr)
{
	in16s(data, len, addr);
	return(EOK);
}

int r6040_write8s(char *data, int len, int addr)
{
	out8s(data, len, addr);
	return(EOK);
}

int r6040_write16s(ushort_t *data, int len, int addr)
{
	out16s(data, len, addr);
	return(EOK);
}

int r6040_write8(_uint32 reg_addr, _uint8 val)
{
	out8(reg_addr, val);
	return(EOK);
}

int r6040_read8(_uint32 reg_addr, _uint8 *ival )
{
	*ival = in8(reg_addr);
	return(EOK);
}

int r6040_write16(_uint32 reg_addr, _uint16 val)
{
	out16(reg_addr, val);
	return(EOK);
}

int r6040_read16(_uint32 reg_addr, _uint16 *ival)
{
	*ival = in16(reg_addr);
	return(EOK);
}

npkt_t *
vortex_alloc_npkt(vortex_dev_t *vortex, int len)
{
	npkt_t		*npkt;
    net_buf_t	*nb;
    net_iov_t	*iov;
    char		*ptr;
	int		linesize = vortex->cachectl.cache_line_size;

	if ((npkt = vortex->ion->alloc_up_npkt(sizeof(net_buf_t) +
	    sizeof(net_iov_t), (void **)&nb)) == NULL)
		return NULL;

	if ((ptr = vortex->ion->alloc(len + linesize*2, 0)) == NULL) 
	{
		vortex->ion->free(npkt);
		return NULL;
	}

	npkt->org_data = ptr;

	/* Pad buffer to begin on a cache line boundary */
	if (linesize != 0)
		ptr = (char *)((unsigned)(ptr + (linesize-1)) & ~(linesize-1));

	TAILQ_INSERT_HEAD(&npkt->buffers, nb, ptrs);

	iov = (net_iov_t *)(nb + 1);

	nb->niov    = 1;
	nb->net_iov = iov;

	iov->iov_base = (void *)ptr;
	iov->iov_len  = len;
	iov->iov_phys = (paddr_t)vortex->ion->mphys(iov->iov_base);

	npkt->next         = NULL;
	npkt->tot_iov      = 1;
	npkt->ref_cnt      = 1;
	npkt->req_complete = 0;

	return npkt;
}
