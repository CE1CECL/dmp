/*
 * Copyright 2003, QNX Software Systems Ltd. All Rights Reserved.
 *
 * This source code may contain confidential information of QNX Software
 * Systems Ltd.  (QSSL) and its licensors. Any use, reproduction,
 * modification, disclosure, distribution or transfer of this software,
 * or any software which includes or is based upon any of this code, is
 * prohibited unless expressly authorized by QSSL by written agreement. For
 * more information (including whether this source code file has been
 * published) please email licensing@qnx.com.
 */



#include <vortex.h>

/*
 * vortex_shutdown1(hdl, dcdm, data, size, ret)
 *
 *  Purpose: Called by io-net when the device is being shutdown.
 *           This simply stops all the interrupts and keeps the
 *           device from sending or receiving any additional data.
 */
int
vortex_shutdown1(int reg_hdl, void *hdl)
{
	vortex_dev_t	*vortex = (vortex_dev_t  *)hdl;
	
	int base = vortex->iobase;
	int i    = 0;
	ushort_t  temp;
	          
	if (vortex->cfg.verbose)
		nic_slogf(_SLOGC_NETWORK, _SLOG_INFO,
		    "devn-vortex: Starting Shutdown1(hdl=%08x)",
		    (uint32_t)reg_hdl);

	// Turn on the STOP bit in the Command register.
	// Stop MAC
    r6040_write16(base + MIER , MIER_CLEAN_MASK); /* Mask Off Interrupt */
    r6040_write16(base + MCR1 , MCR1_MRST);       /* Reset RDC MAC */

	do
	{
		r6040_read16(base + MCR1, &temp);
	} while((++i < 2048) && (temp & MCR1_MRST));
	usleep(1000); 

	// Reset internal state machine
	r6040_write16(base + MMBC , 0x02);
	r6040_write16(base + MMBC , 0x00);
	usleep(5000);

	if (vortex->cfg.verbose)
		nic_slogf(_SLOGC_NETWORK, _SLOG_INFO,
		    "devn-vortex: Finished Shutdown1(hdl=%08x)",
		    (uint32_t)reg_hdl);
	          
	return 0;
}

/*
 * vortex_shutdown2(hdl, dcdm, data, size, ret)
 *
 *  Purpose: Called by io-net when the device is being shutdown.
 *           This function cleans up all the resources that have 
 *           been allocated.
 */
int
vortex_shutdown2(int reg_hdl, void *hdl)
{
	vortex_dev_t	*vortex = (vortex_dev_t  *)hdl;
	int		cnt;
	npkt_t		*npkt;
	int		local_verbose;

	local_verbose = vortex->cfg.verbose;

	if (local_verbose)
		nic_slogf(_SLOGC_NETWORK, _SLOG_INFO,
		    "devn-vortex: Starting Shutdown2(hdl=%08x)",
		    (uint32_t)reg_hdl);

	InterruptDetach(vortex->iid);
	ConnectDetach(vortex->coid);
	ChannelDestroy(vortex->chid);

	pthread_cancel (vortex->tid);
	pthread_join(vortex->tid, NULL);

	vortex_flush(vortex->reg_hdl, vortex);

	for (cnt = 0; cnt < vortex->num_tx_descriptors; cnt++) {
		if (npkt = vortex->tx_pktq[cnt]) {
			if (npkt->flags & R6040_KEEP_PACKET) {
				vortex->ion->free(npkt->org_data);
				vortex->ion->free(npkt);
			} else
				vortex->ion->tx_done(vortex->reg_hdl, npkt);

			vortex->tx_pktq[cnt] = NULL;
		}
	}

	for (cnt = 0; cnt < vortex->num_rx_descriptors; cnt++) {
		if (npkt = vortex->rx_pktq[cnt]) {
			vortex->ion->free(npkt->org_data);
			vortex->ion->free(npkt);
		}
	}

	/* free up the rx free packet queue */
	for (; npkt = vortex->rx_free_pkt_q;) {
		vortex->rx_free_pkt_q = npkt->next;
		vortex->ion->free(npkt->org_data);
		vortex->ion->free(npkt);
	}

	pthread_mutex_destroy(&vortex->rx_mutex);
	pthread_mutex_destroy(&vortex->tx_mutex);
	pthread_mutex_destroy(&vortex->rx_free_pkt_q_mutex);

	cache_fini(&vortex->cachectl);

	munmap(vortex->mem, vortex->mem_size);

	pci_detach_device(vortex->pci_dev_hdl);

	free(vortex->rx_pktq);
	free(vortex->tx_pktq);
	free(vortex);

	if (local_verbose)
		nic_slogf(_SLOGC_NETWORK, _SLOG_INFO, "devn-vortex: Finshed Shutdown2(hdl=%08x)", (uint32_t)reg_hdl);

	return 0;
}
