/*
 * Copyright 2003, QNX Software Systems Ltd. All Rights Reserved.
 *
 * This source code may contain confidential information of QNX Software
 * Systems Ltd.  (QSSL) and its licensors. Any use, reproduction,
 * modification, disclosure, distribution or transfer of this software,
 * or any software which includes or is based upon any of this code, is
 * prohibited unless expressly authorized by QSSL by written agreement. For
 * more information (including whether this source code file has been
 * published) please email licensing@qnx.com.
 */



#include <vortex.h>

/*
 * vortex_mdi_read(vortex, phy_id, location )
 *
 * Purpose: Callback for the MDI library.  Reads the value from location
 *          for the given phy_id. 
 */
static uint16_t
vortex_mdi_read(void *handle, uint8_t phy_id, uint8_t location)
{
	vortex_dev_t  *vortex = (vortex_dev_t*) handle;
	int	iobase = vortex->iobase;

	int i = 0;
	ushort_t  data, temp;

	data = MMDIO_READ + ((ushort_t) phy_id << 8) + (ushort_t) location;
	r6040_write16(iobase + MMDIO, data);

	do
	{
		r6040_read16(iobase + MMDIO, &temp);
	} while ((++i < 2048) && (temp & MMDIO_READ));

	r6040_read16(iobase + MMRD, &temp);

	return temp;
}

/*
 * vortex_mdi_write(vortex, phy_id, location, value) 
 *
 * Purpose: Callback for the MDI library.  Writes the value to the location
 *          for the given phy_id. 
 */
static void
vortex_mdi_write( void *handle, uint8_t phy_id, uint8_t location, uint16_t value)
{
	vortex_dev_t  *vortex = (vortex_dev_t*) handle;
	int	 iobase = vortex->iobase;
	int  i = 0;
	ushort_t  data, temp;

	r6040_write16(iobase + MMWD, value);
	
    data = MMDIO_WRITE + ((ushort_t) phy_id << 8) + (ushort_t) location;
	r6040_write16(iobase + MMDIO, data);

	do
	{
		r6040_read16(iobase + MMDIO, &temp);
	} while((++i < 2048) && (temp & MMDIO_WRITE));
}

/*
 * vortex_phy_checkmode( vortex )
 *
 *  Purpose: Check the Status of PHY CHIP.
 *
 */
int 
vortex_phy_checkmode(void *handle)
{
	vortex_dev_t  *vortex = (vortex_dev_t*) handle;
	
    int phy_dat;

	/* PHY Link Status Check */
	phy_dat = vortex_mdi_read(vortex, 1, vortex->ether_phy);
	if (!(phy_dat & 0x0004))
	{
		nic_slogf(_SLOGC_NETWORK, _SLOG_ERROR,
		    "devn-vortex:  vortex_phy_checkmode()==> LINK_FAILED");
		    
	    return LINK_FAILED;	/* Link Failed */
    }

	/* PHY Chip Auto-Negotiation Status */
	phy_dat = vortex_mdi_read(vortex, 1, vortex->ether_phy);
	if (phy_dat & 0x0020)
	{
		/* Auto Negotiation Mode */
		phy_dat = vortex_mdi_read(vortex, 5, vortex->ether_phy);
		// phy_dat = vortex_mdi_read(vortex, 4, vortex->ether_phy);  // QQQ
		phy_dat &= vortex_mdi_read(vortex, 4, vortex->ether_phy);

		if (phy_dat & 0x140)
		    phy_dat = FULL_DUPLEX;
		else
		    phy_dat = HALF_DUPLEX;
	}
	else 
	{
		/* Force Mode */
		phy_dat = vortex_mdi_read(vortex, 0, vortex->ether_phy);

		if (phy_dat & 0x100)
		   phy_dat = FULL_DUPLEX;
		else
		   phy_dat = HALF_DUPLEX;
	}

	return phy_dat;
}

static void
vortex_mdi_callback( void *handle, uint8_t phyAddr, uint8_t linkState)
{
	vortex_dev_t  *vortex = (vortex_dev_t*)handle;

	/*
	 * Note that the link state indicator of the HPNA interface is
	 * unreliable.  The link appears to keep coming and going, even
	 * though the interface is working all along.  So the strategy
	 * is to switch to the ethernet interface if the ethernet is
	 * up, if the ethernet link goes down, switch to the HPNA.
	 */
	if (linkState == MDI_LINK_UP) 
	{
		if (phyAddr == vortex->ether_phy && !vortex->force_hpna) 
		{

			MDI_GetActiveMedia(vortex->mdi, phyAddr, &vortex->mdi_active);

			switch (vortex->mdi_active) 
			{
			case MDI_10bT:  
				vortex->cfg.media_rate = 10000L;
				vortex->cfg.duplex     = 0;
				break;

			case MDI_10bTFD:
				vortex->cfg.media_rate = 10000L;
				vortex->cfg.duplex     = 1;
				break;

			case MDI_100bTFD:
				vortex->cfg.media_rate = 100000L;
				vortex->cfg.duplex     = 1;
				break;

			case MDI_100bT4: 
				vortex->cfg.media_rate = 100000L;
				vortex->cfg.duplex     = 0;
				break;

			case MDI_100bT: 
				vortex->cfg.media_rate = 100000L;
				vortex->cfg.duplex     = 0;
				break;
			default:
				vortex->cfg.media_rate = 0L;
				vortex->cfg.duplex     = 0;
				break;
			}
		}
	} 
	else 
	{
		vortex->cfg.media_rate = 0L;

		if (vortex->line_speed == -1 && vortex->line_duplex == -1) 
		{
			MDI_AutoNegotiate(vortex->mdi, phyAddr, NoWait);
		}
		if (phyAddr == vortex->ether_phy && vortex->hpna_phy != -1) 
		{
			// TODO
		}
	}

	if (vortex->cfg.verbose >= 1) 
	{
		char *s;

		if (linkState == MDI_LINK_UP) 
		{
			switch (vortex->mdi_active) 
			{
			case MDI_10bTFD:
				s = "10 BaseT Full Duplex";
				vortex->cfg.flags      = 1;
				vortex->cfg.media_rate = 10000L;
				break;
				
			case MDI_10bT:
				s = "10 BaseT Half Duplex";
				vortex->cfg.duplex     = 0;
				vortex->cfg.media_rate = 10000L;
				break;
			
			case MDI_100bTFD:
				s = "100 BaseT Full Duplex";
				vortex->cfg.duplex     = 1;
				vortex->cfg.media_rate = 100000L;
				break;
			
			case MDI_100bT:
				s = "100 BaseT Half Duplex";
				vortex->cfg.duplex     = 0;
				vortex->cfg.media_rate = 100000L;
				break;
				
			case MDI_100bT4:
				s = "100 BaseT4";
				vortex->cfg.duplex     = 0;
				vortex->cfg.media_rate = 100000L;
				break;
			default:
				s = "Unknown Link";
				vortex->cfg.duplex     = 0;
				vortex->cfg.media_rate = 0L;
				break;
			}
			vortex->cfg.flags &= ~NIC_FLAG_LINK_DOWN;
			if ( vortex->cfg.verbose )
				nic_slogf(_SLOGC_NETWORK, _SLOG_INFO, "devn-vortex: %s link up (%s)", 
					      phyAddr == vortex->ether_phy ? "Ethernet" : "HPNA", s);
		} 
		else 
		{
			if ( vortex->cfg.verbose )
				nic_slogf(_SLOGC_NETWORK, _SLOG_INFO, "devn-vortex: %s link down, check cabling", 
					      phyAddr == vortex->ether_phy ? "Ethernet" : "HPNA");
			vortex->cfg.media_rate = vortex->cfg.duplex = -1;
			vortex->cfg.flags     |= NIC_FLAG_LINK_DOWN;
		}
	}
}

/*
 * vortex_mii_init( vortex ) 
 *
 * Purpose: Uses the MDI library to setup callbacks and search for
 *           a phy connected to the chipset. 
 */
void
vortex_mii_init( void *handle )
{
	vortex_dev_t	*vortex = (vortex_dev_t*) handle;
	struct  sigevent	mdiEvent;
	
	uint8_t	 phyNo, mediaCapable;
	int		 found = -1;
	int		 speed, mode, ret;
	      
	if (vortex->mdi)
		MDI_DeRegister((mdi_t **)&vortex->mdi);

	/* Fill in the ConnectionId for mdiEvent (MDI_Register(...)) */
	memset(&mdiEvent, 0, sizeof(struct sigevent));
	mdiEvent.sigev_coid = vortex->coid;

	MDI_Register_Extended(vortex, vortex_mdi_write, vortex_mdi_read,
	                      vortex_mdi_callback, (mdi_t **)&vortex->mdi, &mdiEvent,
	                      NIC_MDI_PRIORITY,
	                      3); /* 3 second interval */

	vortex->hpna_phy = vortex->ether_phy = -1;

	/* Look for a PHY */
	for (phyNo = 1; phyNo < 32; phyNo++) 
	{
		if (MDI_FindPhy(vortex->mdi, phyNo % 32) == MDI_SUCCESS) 
		{
			found        = phyNo % 32;
			mediaCapable = vortex_mdi_read(vortex, found, MDI_BMSR) >> 11;

			if ((mediaCapable & MDI_10bTFD) || (mediaCapable & MDI_100bTFD)) 
			{
				vortex->ether_phy = found;
				if ( vortex->cfg.verbose )
					nic_slogf(_SLOGC_NETWORK, _SLOG_INFO, "devn-vortex: PHY found: 0x%x",vortex->ether_phy);
			} 
			else  
			{
				if ( vortex->force_hpna ) 
				{
					/* HPNA cannot do Full Duplex */
					vortex->hpna_phy = found;
					if ( vortex->cfg.verbose )
						nic_slogf(_SLOGC_NETWORK, _SLOG_INFO, "devn-vortex: HPNA PHY found: 0x%x",vortex->hpna_phy);
				}
			}

			if ( ret = MDI_InitPhy(vortex->mdi, found) != MDI_SUCCESS ) 
				continue;

			vortex->cfg.connector = NIC_CONNECTOR_MII;

			if ((found >= 30) && (!vortex->force_hpna)) 
			{	
				/* Internal PHYs are either at 30 or 31 */
				if ( vortex->cfg.verbose )
					nic_slogf(_SLOGC_NETWORK, _SLOG_INFO, "devn-vortex: Using internal Phy detected at address 0x%x", found);
				
				vortex->use_int_phy = 1;
			} 
			else 
			{
				if ((vortex->hpna_phy) && (vortex->force_hpna))
			    {
					if ( vortex->cfg.verbose )
						nic_slogf(_SLOGC_NETWORK, _SLOG_INFO, 
						         "devn-vortex: Using HPNA Phy detected at address 0x%x", vortex->hpna_phy);
			    }
			}

			/*
			 * Some PHYs need to be explicitly RESET in
			 * order for them to work properly.
			 */
			if (vortex->use_int_phy) 
			{
				if ( vortex->cfg.verbose > 3 )
					nic_slogf(_SLOGC_NETWORK, _SLOG_INFO, "devn-vortex: Resetting Phy 0x%x", found);
			
				MDI_ResetPhy(vortex->mdi, found, NoWait);
				delay (100);
				MDI_SyncPhy(vortex->mdi, found);
			}

			if (phyNo <= 32 )
				continue;

			break;
		}
	}

	if (vortex->ether_phy == -1)
		vortex->ether_phy = vortex->hpna_phy;

	if (found == -1) 
	{ 
		/* No PHY for you! 10Mbit */
		MDI_DeRegister((mdi_t **)&vortex->mdi);
		
		vortex->cfg.media_rate = vortex->line_speed = 10000;
		vortex->cfg.connector  = NIC_CONNECTOR_UTP;
	} 
	else 
	{	
		/* reset APEP */

		if (vortex->line_speed == -1 && vortex->line_duplex == -1) 
		{
			ret = MDI_EnableMonitor(vortex->mdi, 1);
			if ( vortex->cfg.verbose > 3 ) 
				vortex_mii_retcode ( ret, "MDI_EnableMonitor" );
		}
		else 
		{
			if (vortex->force_hpna == 1 || vortex->hpna_phy != -1) 
			{
                // TODO
			}
			speed = vortex->line_speed / 1000;
			if (speed == 100) 
			{
				mode = vortex->line_duplex ? MDI_100bTFD : MDI_100bT;
			}
			else 
			{
				mode = vortex->line_duplex ? MDI_10bTFD : MDI_10bT;
			}

			if (vortex->hpna_phy != -1) 
			{
				ret = MDI_SetSpeedDuplex(vortex->mdi, vortex->hpna_phy, speed, vortex->line_duplex);
				if ( vortex->cfg.verbose > 3 ) 
					vortex_mii_retcode ( ret, "MDI_SetSpeedDuplex" );

				ret = MDI_GetActiveMedia(vortex->mdi, vortex->hpna_phy, &vortex->mdi_active);
				if ( vortex->cfg.verbose > 3 )
					vortex_mii_retcode ( ret, "MDI_GetActiveMedia" );
			}
		}
	}

	return;
}

void
vortex_mii_retcode( uchar_t in, const char *func ) 
{
	char	*s = NULL;

	switch (in) 
	{
	case MDI_FAILURE:
		s = "MDI_FAILURE"; 
		break;
	case MDI_SUCCESS:
		s = "MDI_SUCCESS"; 
		break;
	case MDI_LINK_UP:    
		s = "MDI_LINK_UP";
		break;
	case MDI_LINK_DOWN:
		s = "MDI_LINK_DOWN";
		break;
	case MDI_LINK_UNKNOWN:
		s = "MDI_LINK_UNKNOWN";
		break;
	case MDI_RESET_PHY:
		s = "MDI_RESET_PHY";
		break;
	case MDI_AUTONEG: 
		s = "MDI_AUTONEG";
		break;
	case MDI_BADPARAM:
		s = "MDI_BADPARAM";
		break;
	case MDI_NOMEM: 
		s = "MDI_NOMEM";
		break;
	case MDI_UNSUPPORTED:
		s = "MDI_UNSUPPORTED";
		break;
	case MDI_INVALID_MEDIA:
		s = "MDI_INVALID_MEDIA";
		break;
	case MDI_PROXY_FAILURE:
		s = "MDI_PROXY_FAILURE";
		break;
	case MDI_TIMER_FAILURE:
		s = "MDI_TIMER_FAILURE";
		break;
	default:
		s = "MDI_UNKNOWN_RETURN_CODE";
		break;
	}
	
	if ( s != NULL )
		nic_slogf(_SLOGC_NETWORK, _SLOG_INFO, "devn-vortex: %s returned: %s (%d)", func, s, in);
}
