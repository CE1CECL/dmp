/*
 * Copyright 2003, QNX Software Systems Ltd. All Rights Reserved.
 *
 * This source code may contain confidential information of QNX Software
 * Systems Ltd.  (QSSL) and its licensors. Any use, reproduction,
 * modification, disclosure, distribution or transfer of this software,
 * or any software which includes or is based upon any of this code, is
 * prohibited unless expressly authorized by QSSL by written agreement. For
 * more information (including whether this source code file has been
 * published) please email licensing@qnx.com.
 */

#ifndef NIC_VORTEX_H_INCLUDED
#define NIC_VORTEX_H_INCLUDED

#include <ctype.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/siginfo.h>
#include <sys/syspage.h>
#include <sys/neutrino.h>
#include <sys/dcmd_io-net.h>
#include <sys/slogcodes.h>

#include <hw/pci.h>
#include <hw/inout.h>
#include <hw/pci_devices.h>

#include <net/if.h>
#include <net/if_dl.h>
#include <net/if_types.h>
#include <sys/io-net.h>
#include <drvr/mdi.h>
#include <drvr/eth.h>
#include <drvr/nicsupport.h>
#include <sys/cache.h>

/* Vendor ID and Device ID for R6040 */
#define PCI_VENDOR_ID_RDC		 0x17f3
#define PCI_DEVICE_ID_RDC_R6040	 0x6040

#define NIC_INTERRUPT_EVENT	0
#define NIC_PRIORITY		21
#define NIC_MDI_PRIORITY	10


#define VORTEX_FRAGMENTS		 2
#define VORTEX_MULTICAST_ENTRIES	 64

#define VORTEX_IB_PROMISCUOUS	 0x8000

/*  For RDC Setting */

#define PCI_CONFIG_ADDRESS_REG           0x0CF8
#define PCI_CONFIG_DATA_REG              0x0CFC

#define PCI_CONFIG_COMMAND_REG           0x04
#define PCI_CONFIG_IO_MAPPED_REG         0x10
#define PCI_CONFIG_MEMORY_MAPPED_REG     0x14
#define PCI_CONFIG_INT_REG               0x3C

#define PCI_CONFIG_REG_ENABLE            0x80000000

#define MCR0        0x00    // (MAC_CONTROL0)
#define MCR1        0x04    // (MAC_CONTROL1)
#define MBCR        0x08    // (MAC_BUS_CONTROL)
#define MTICR       0x0C    // (MAC_TX_INTR_CONTROL)
#define MRICR       0x10    // (MAC_RX_INTR_CONTROL)
#define MTPR        0x14    // (MAC_TX_POLL_COMMAND)
#define MRBSR       0x18    // (MAC_RX_BUFFER_SIZE)
#define MRDCR       0x1A    // (MAC_RX_DESCRIPTOR_CONTROL)
#define MLSR        0x1C    // (MAC_LAST_STATUS)
#define MMDIO       0x20    // (MAC_MDIO_CONTROL)
#define MMRD        0x24    // (MAC_MDIO_READ_DATA)
#define MMWD        0x28    // (MAC_MDIO_WRITE_DATA)
#define MTDSA0      0x2C    // (MAC_TX_DESCRIPTOR_START_ADDRESS0)
#define MTDSA1      0x30    // (MAC_TX_DESCRIPTOR_START_ADDRESS1)
#define MRDSA0      0x34    // (MAC_RX_DESCRIPTOR_START_ADDRESS0)
#define MRDSA1      0x38    // (MAC_RX_DESCRIPTOR_START_ADDRESS1)
#define MISR        0x3C    // (MAC_INTR_STATUS)
#define MIER        0x40    // (MAC_INTR_ENABLE)
#define MECISR      0x44     //(MAC_EVENT_COUNT_INT_STATUS)
#define MECIER      0x48    // (MAC_EVENT_COUNT_INT_ENABLE)
#define MRCNT       0x50    // (MAC_SUCCESSFULLY_RX_PACKET_COUNTER)
#define MECNT0      0x52    // (MAC_EVENT_COUNTER0)
#define MECNT1      0x54    // (MAC_EVENT_COUNTER1)
#define MECNT2      0x56    // (MAC_EVENT_COUNTER2)
#define MECNT3      0x58    // (MAC_EVENT_COUNTER3)
#define MTCNT       0x5A    // (MAC_SUCCESSFULLY_TX_PACKET_COUNTER)
#define MECNT4      0x5C    // (MAC_EVENT_COUNTER4)
#define MPCNT       0x5E    // (MAC_PAUSE_FRAME_COUNTER)
#define MAR0        0x60    // (MAC_HASH_TABLE_WORD0)
#define MAR1        0x62    // (MAC_HASH_TABLE_WORD1)
#define MAR2        0x64    // (MAC_HASH_TABLE_WORD2)
#define MAR3        0x66    // (MAC_HASH_TABLE_WORD3)
#define MID0L       0x68    // (MAC_MUITICAST_ADDRESS0_LOW)
#define MID0M       0x6A    // (MAC_MUITICAST_ADDRESS0_MIDDEL)
#define MID0H       0x6C    // (MAC_MUITICAST_ADDRESS0_HIGH)
#define MID1L       0x70    // (MAC_MUITICAST_ADDRESS1_LOW)
#define MID1M       0x72    // (MAC_MUITICAST_ADDRESS1_MIDDEL)
#define MID1H       0x74    // (MAC_MUITICAST_ADDRESS1_HIGH)
#define MID2L       0x78    // (MAC_MUITICAST_ADDRESS2_LOW)
#define MID2M       0x7A    // (MAC_MUITICAST_ADDRESS2_MIDDEL)
#define MID2H       0x7C    // (MAC_MUITICAST_ADDRESS2_HIGH)
#define MID3L       0x80    // (MAC_MUITICAST_ADDRESS3_LOW)
#define MID3M       0x82    // (MAC_MUITICAST_ADDRESS3_MIDDEL)
#define MID3H       0x84    // (MAC_MUITICAST_ADDRESS3_HIGH)
#define MPSCCR      0x88    // (MAC_PHY_STATUS_CHANGE_CONFIG)
#define MPSR        0x8A    // (MAC_PHY_STATUS)
#define MPSR2       0x8C    // (MAC_PHY_STATUS2)
#define MMBC		0xAC
#define MDCSC		0xB6
#define MID			0xBC
#define MACID       0xBE    // (MAC_IDENTIFER)

// Constants for the MAC Bus Control Register
#define MBCR_DEFAULT	0x012A

// Constants for the MAC CONTROL Register0.
#define MCR0_FULLD     0x8000
#define MCR0_TXEIE     0x4000
#define MCR0_XMTEN     0x1000
#define MCR0_FCEN      0x0200
#define MCR0_AMCP      0x0100
#define MCR0_RXEIE     0x0080
#define MCR0_FBCP      0x0040
#define MCR0_PROM      0x0020
#define MCR0_ADRB      0x0010
#define MCR0_ALONG     0x0008
#define MCR0_ARUNT     0x0004
#define MCR0_RCVEN     0x0002
#define MCR0_ACRCER    0x0001

// Constants for the MAC CONTROL Register1.
#define MCR1_AUCP      0x8000
#define MCR1_WIDX      0x4000
#define MCR1_MRST      0x0001

// Constants for the MAC MDIO CONTROL Register.
#define MMDIO_WRITE    0x4000
#define MMDIO_READ     0x2000

// Constants for the MAC INTR MASK
// Configure which ISR settings actually cause interrupts.
#define MIER_CLEAN_MASK    0x0000        // Clean all interrupt
#define MIER_MCHGE         0x0200        // PHY link changed interrupt enable
#define MIER_ECNTOE        0x0100        // Event counter overflow interrupt enable
#define MIER_TXEIEN        0x0080        // Tx early interrupt enable
#define MIER_TXENDE        0x0010        // TX packet finish interrupt enable
#define MIER_RXEIE         0x0008        // RX early interrupt enable
#define MIER_RXFFE         0x0004        // RX FIFO full interrupt enable
#define MIER_RXDNAE        0x0002        // RX descriptor Unavailable interrupt enable
#define MIER_RXENDE        0x0001        // RX packet finish interrupt enable

// Constants for the MAC_INTR_STATUS register.
// Indicate the cause of an interrupt.
#define MISR_EMPTY       0x0000        // No bits set in ISR
#define MISR_RXEND       0x0001        // Receive packet finish interrupt status
#define MISR_RXDUA       0x0002        // RX descriptor Unavailable interrupt status
#define MISR_RXFF        0x0004        // RX FIFO full interrupt status
#define MISR_RXEI        0x0008        // RX early interrupt status
#define MISR_TXEND       0x0010        // Tx packet finish interrupt status
#define MISR_TXEI        0x0080        // TX early interrupt status
#define MISR_ECNTO       0x0100        // Event counter overflow interrupt status
#define MISR_PCHG        0x0200        // PHY media changed interrupt status

// Constants for the MAC_COMMAND register.
// Start/stop the card, start transmissions, and select
// which page of registers was seen through the ports.
#define CR_STOP         (uchar_t)0x01        // reset the card
#define CR_START        (uchar_t)0x02        // start the card
#define CR_XMIT         (uchar_t)0x04        // begin transmission
#define CR_NO_DMA       (uchar_t)0x20        // stop remote DMA

#define CR_PS0          (uchar_t)0x40        // low bit of page number
#define CR_PS1          (uchar_t)0x80        // high bit of page number
#define CR_PAGE0        (uchar_t)0x00        // select page 0
#define CR_PAGE1        CR_PS0               // select page 1
#define CR_PAGE2        CR_PS1               // select page 2

#define CR_DMA_WRITE    (UCHAR)0x10          // Write
#define CR_DMA_READ     (UCHAR)0x08          // Read
#define CR_SEND         (UCHAR)0x18          // send

// Constants for the MAC_XMIT_STATUS register.
// Indicate the result of a packet transmission.
#define TSR_XMIT_OK     (uchar_t)0x01        // transmit with no errors
#define TSR_COLLISION   (uchar_t)0x04        // collided at least once
#define TSR_ABORTED     (uchar_t)0x08        // too many collisions
#define TSR_NO_CARRIER  (uchar_t)0x10        // carrier lost
#define TSR_NO_CDH      (uchar_t)0x40        // no collision detect heartbeat

// Constants for the MAC_RCV_CONFIG register.
// Configure what type of packets are received.
#define RCR_REJECT_ERR  (uchar_t)0x00        // reject error packets
#define RCR_BROADCAST   (uchar_t)0x04        // receive broadcast packets
#define RCR_MULTICAST   (uchar_t)0x08        // receive multicast packets
#define RCR_ALL_PHYS    (uchar_t)0x10        // receive ALL directed packets
#define RCR_MONITOR     (uchar_t)0x20        // don't collect packets

// Constants for the MAC_XMIT_CONFIG register.
// Configures how packets are transmitted.
#define TCR_NO_LOOPBACK (uchar_t)0x00        // normal operation
#define TCR_LOOPBACK    (uchar_t)0x02        // loopback (set when NIC is stopped)

#define TCR_INHIBIT_CRC (uchar_t)0x01        // inhibit appending of CRC

#define TCR_NIC_LBK     (uchar_t)0x02        // loopback through the NIC
#define TCR_SNI_LBK     (uchar_t)0x04        // loopback through the SNI
#define TCR_COAX_LBK    (uchar_t)0x06        // loopback to the coax

// Constants for the MAC_DATA_CONFIG register.
// Set data transfer sizes.
#define DCR_BYTE_WIDE   (uchar_t)0x00        // byte-wide DMA transfers
#define DCR_WORD_WIDE   (uchar_t)0x01        // word-wide DMA transfers

#define DCR_LOOPBACK    (uchar_t)0x00        // loopback mode (TCR must be set)
#define DCR_NORMAL      (uchar_t)0x08        // normal operation

#define DCR_FIFO_2_BYTE (uchar_t)0x00        // 2-byte FIFO threshhold
#define DCR_FIFO_4_BYTE (uchar_t)0x20        // 4-byte FIFO threshhold
#define DCR_FIFO_8_BYTE (uchar_t)0x40        // 8-byte FIFO threshhold
#define DCR_FIFO_12_BYTE (uchar_t)0x60       // 12-byte FIFO threshhold
#define DCR_AUTO_INIT   (uchar_t)0x10        // Auto-init to remove packets from ring

// Constants for the MAC_INTR_MASK register.
// Configure which ISR settings actually cause interrupts.
#define IMR_RCV         (uchar_t)0x01        // packet received with no errors
#define IMR_XMIT        (uchar_t)0x02        // packet transmitted with no errors
#define IMR_RCV_ERR     (uchar_t)0x04        // error on packet reception
#define IMR_XMIT_ERR    (uchar_t)0x08        // error on packet transmission
#define IMR_OVERFLOW    (uchar_t)0x10        // receive buffer overflow
#define IMR_COUNTER     (uchar_t)0x20        // MSB set on tally counter

// RX/TX descriptor status bits
//
#define R6040_OWN			0x8000  // rx / tx : 1: the MAC; 0: the CPU
#define R6040_OK			0x4000  // rx / tx : success

#define R6040_RX_PHYERR		0x0800  // rx: PHY Error package
#define R6040_RX_DRIBBLE	0x0400  // rx: Dribble packet
#define R6040_RX_OBL	    0x0200  // rx: Over Buffer Length
#define R6040_RX_LONG	    0x0100  // rx: Long package
#define R6040_RX_RUNT	    0x0080  // rx: Runt packet
#define R6040_RX_CRCERR	    0x0040  // rx: CRC Error packet
#define R6040_RX_BROADCAST	0x0020  // rx: Broadcast packet
#define R6040_RX_MULTICAST	0x0010  // rx: Multicast packet
#define R6040_RX_MCH	    0x0008  // rx: Multicast Hit
#define R6040_RX_MIDH	    0x0004  // rx: MID table is hit

#define R6040_TX_DISCRC	    0x0200  // tx: Disable the appended CRC field
#define R6040_TX_TXFUR	    0x0040  // tx: FIFO Under-Run
#define R6040_TX_LATEC	    0x0020  // tx: Late Collision
#define R6040_TX_EXCEEDC	0x0010  // tx: Exceed Collision

// Constant for the register: MRBSR
#define MAX_BUF_SIZE	0x600

// PHY CHIP Address
#define PHY1_ADDR	1	    // For MAC1
#define PHY2_ADDR	2	    // For MAC2
#define PHY_MODE	0x3100	// PHY CHIP Register 0
#define PHY_CAP		0x01E1	// PHY CHIP Register 4

typedef struct _vortex_init_block {
	ulong_t			mode_dlen;
	uchar_t			padr[6];
	uchar_t			rsvd[2];
	uchar_t			ladr[8];
	ulong_t			rdra;
	ulong_t			tdra;
} vortex_init_block_t;

typedef struct _r6040_tx_rx_desc{
	ushort_t	status;     /* 0-1 */
	ushort_t	len;		/* 2-3 */
	ulong_t		buf;		/* 4-7 */
	ulong_t		ndesc;		/* 8-B */
	ushort_t	hidx;		/* C-D */
	ushort_t	rev1;		/* E-F */
	ushort_t	rev2;		/* 10-11 */
	ushort_t	rev3;		/* 12-13 */
	ushort_t	padding[6]; /* 14-1F */
} r6040_tx_rx_desc_t;

typedef struct _vortex_ext {
	nic_config_t		cfg;                /* New libdrvr config structure */
	nic_stats_t			stats;              /* New libdrvr status structure */
	struct cache_ctrl	cachectl;
	int				mmap;               /* mmap_device_memory() override */
	int				force_advertise; 
	int				chid;
	int				coid;
	int				tid;
	int				iid;
	void			*dll_hdl;
	int				reg_hdl;
	uint16_t		cell;
	uint16_t		_pad1;

	mdi_t			*mdi;
	int				pci_handle;
	void			*pci_dev_hdl;
	int				iobase;
	int				bmstr;
	uint_t			reseting;
	caddr_t			mem;
	uint_t			mem_size;
	int				line_speed;
	int				line_duplex;
	uint_t			tx_dfree;
	vortex_init_block_t		*ib;
	int				multicast_counts[VORTEX_MULTICAST_ENTRIES];
	int				n_allmulti;
	int				n_prom;

	io_net_self_t	*ion;

	int				priority;
	int				negotiate;

	/* PHY/MDI */
	int				ether_phy;
	int				hpna_phy;
	int				force_hpna;
	int				mdi_active;
	int				use_int_phy;
	int             Phy_Mode;
	ushort_t        Mac_Control;
	ushort_t        mdcs;

	/* RX */
	volatile r6040_tx_rx_desc_t	*rfd;
	npkt_t			**rx_pktq;
	int				rx_pidx;
	int				rx_cidx;
	int				num_rx_descriptors;
	int				rx_max;
	pthread_mutex_t	rx_mutex;

	/* TX */
	volatile r6040_tx_rx_desc_t	*tfd;
	int				tfd_pidx;
	int				tfd_cidx;
	npkt_t			**tx_pktq;
	npkt_t			*tx_nhead;
	npkt_t			*tx_ntail;
	int				num_tx_descriptors;
	pthread_mutex_t	tx_mutex;

	/* RX free Queue */
	npkt_t			*rx_free_pkt_q;
	pthread_mutex_t	rx_free_pkt_q_mutex;
	int				num_rx_free;
} vortex_dev_t;

/* One nibbles worth of npkt_t flags are for packet originator's use */
#define R6040_KEEP_PACKET		0x00100000

/* Upper 8 bits are scratch flags for packet holder's use */
#define R6040_DEFRAG_PACKET		0x80000000

#define R6040_PACKET_MTU_SIZE		1514

#define DEFAULT_NUM_RX_DESCRIPTORS	128
#define DEFAULT_NUM_TX_DESCRIPTORS	128

// Size of the ethernet address
#define R6040_LENGTH_OF_ADDRESS 6

// The status of link.
typedef enum {
    LINK_FAILED = 0xFFFF,
    HALF_DUPLEX = 0x0000,
    FULL_DUPLEX = 0x8000
} LINK_STATU;

// Macros for writing shared memory structures - no need for byte flipping
//
#define READMEM8(   _reg_, _val_ ) ((_val_) = *((volatile uchar_t *)(_reg_)))
#define WRITEMEM8(  _reg_, _val_ ) (*((volatile uchar_t *)(_reg_)) = (_val_))
#define READMEM16(  _reg_, _val_ ) ((_val_) = *((volatile short *)(_reg_)))
#define WRITEMEM16( _reg_, _val_ ) (*((volatile short *)(_reg_)) = (_val_))
#define READMEM32(  _reg_, _val_ ) ((_val_) = *((volatile long *)(_reg_)))
#define WRITEMEM32( _reg_, _val_ ) (*((volatile long *)(_reg_)) = (_val_))

// Macros to extract high and low bytes of a word.
//
#define MSB(Value) ((ushort_t)((((u_long)Value) >> 16) & 0xffff))
#define LSB(Value) ((ushort_t)(((u_long)Value) & 0xffff))


/* shutdown.c */
int vortex_shutdown1(int, void *hdl);
int vortex_shutdown2(int, void *hdl);

/* devctl.c */
int vortex_devctl(void *hdl, int dcmd, void *data, size_t size, union _io_net_dcmd_ret_cred *ret);

/* receive.c */
int vortex_receive( void *handle );
int vortex_receive_complete(npkt_t *npkt, void *, void *);

/* transmit.c */
int vortex_transmit_packets(npkt_t *npkt, void *);
npkt_t *vortex_collect_tx_packets( void *handle );

/* event.c */
void *vortex_event_handler(void *data);

/* vortex.c */
npkt_t *vortex_alloc_npkt(vortex_dev_t *vortex, int size);
int r6040_read8s(char *data, int len, int addr);
int r6040_read16s(ushort_t *data, int len, int addr);
int r6040_write8s(char *data, int len, int addr);
int r6040_write16s(ushort_t *data, int len, int addr);
int r6040_write8(_uint32 reg_addr, _uint8 val);
int r6040_read8(_uint32 reg_addr, _uint8 *ival );
int r6040_write16(_uint32 reg_addr, _uint16 val);
int r6040_read16(_uint32 reg_addr, _uint16 *ival);

/* reset.c */
int vortex_reset( void *handle );

/* advertise.c */
int vortex_advertise(int reg_hdl, void *func_hdl);

/* flush.c */
int vortex_flush(int, void *hdl);

/* init.c */
int vortex_init(void *, dispatch_t *, io_net_self_t *, char *options);
int vortex_parse_options( vortex_dev_t *vortex, const char *optstring, nic_config_t *cfg, int instance);
int vortex_create_instance(void *dll_hdl, io_net_self_t *ion, int instance,
                  char *options, unsigned vendor_id, unsigned device_id, int device_index);
int vortex_init_config_card( void *handle );           
    

/* mii.c */
void vortex_mii_init( void *handle );
void vortex_mii_retcode( uchar_t in, const char *func );
int vortex_phy_checkmode(void *handle);

#endif
