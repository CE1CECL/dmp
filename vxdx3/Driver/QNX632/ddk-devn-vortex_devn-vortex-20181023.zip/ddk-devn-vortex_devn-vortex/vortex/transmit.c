/*
 * Copyright 2003, QNX Software Systems Ltd. All Rights Reserved.
 *
 * This source code may contain confidential information of QNX Software
 * Systems Ltd.  (QSSL) and its licensors. Any use, reproduction,
 * modification, disclosure, distribution or transfer of this software,
 * or any software which includes or is based upon any of this code, is
 * prohibited unless expressly authorized by QSSL by written agreement. For
 * more information (including whether this source code file has been
 * published) please email licensing@qnx.com.
 */

#include <stddef.h>
#include <string.h>

#include "vortex.h"

static npkt_t *
vortex_defrag(vortex_dev_t *vortex, npkt_t *npkt)
{
	npkt_t		*dpkt;
	uint8_t		*dst;
	net_iov_t	*iov;
	net_buf_t	*dbuf, *buf;
	int			i, len;

	if ((dpkt = vortex_alloc_npkt(vortex, npkt->framelen)) == NULL) 
	{
		vortex->stats.tx_failed_allocs++;
		npkt->flags |= _NPKT_NOT_TXED;
		goto bye;
	}

	/* Set _NPKT_UP so we know it couldn't have originated elsewhere */
	dpkt->flags = R6040_DEFRAG_PACKET;

	dpkt->tot_iov = 1;
	dpkt->framelen = npkt->framelen;

	dbuf = TAILQ_FIRST(&dpkt->buffers);
	dst = dbuf->net_iov->iov_base;

	for (len = 0, buf = TAILQ_FIRST(&npkt->buffers); buf != NULL;
	    buf = TAILQ_NEXT(buf, ptrs)) 
	{
		for (i = 0, iov = buf->net_iov; i < buf->niov; i++, iov++)
		{
			memcpy(dst, iov->iov_base, iov->iov_len);
			dst += iov->iov_len;
			len += iov->iov_len;
		}
	}

	dbuf->net_iov->iov_len = len;

bye:
	npkt->next = NULL;
	vortex->ion->tx_done(vortex->reg_hdl, npkt);
    
	return dpkt;
}

/*
 * vortex_transmit_packets()
 *
 * Description: entry point for Tx from the upper level
 */
int
vortex_transmit_packets(npkt_t *npkt, void *rx_down_hdl)
{
	vortex_dev_t	*vortex = rx_down_hdl;
	net_buf_t		*buf;
	net_iov_t		*iov;
	int			i;
	int			ret = TX_DOWN_OK;
	int			pidx, fpidx;
	volatile r6040_tx_rx_desc_t	 *tfd = NULL;
	npkt_t	*list = NULL, *npkt2;
	
	int iError = 0;
	          
	if (npkt->flags & _NPKT_MSG)
	{
		errno = EINVAL;
		ret = TX_DOWN_FAILED;
	          	
		goto done;
	} 
	else
	{
		/* Data message */
		if (npkt->tot_iov >= VORTEX_FRAGMENTS) 
		{        
			npkt = vortex_defrag(vortex, npkt);
			if (npkt == NULL) 
			{          
				errno = ENOMEM;
				return TX_DOWN_FAILED;
			}
		} 
		else 
		{	          
			/* Don't assume contents of scratch flags */
			npkt->flags &= ~R6040_DEFRAG_PACKET;
		}

		iError = pthread_mutex_lock(&vortex->tx_mutex);
	          
		if (vortex->num_tx_descriptors - vortex->tx_dfree > 4)
		{
			list = vortex_collect_tx_packets(vortex);
		}
          
		if (vortex->tx_dfree + 1 < npkt->tot_iov) 
		{	    
			pthread_mutex_unlock(&vortex->tx_mutex);
			npkt->flags |= _NPKT_NOT_TXED;
			errno = ENOBUFS;
			ret   = TX_DOWN_FAILED;
			goto done;
		}
	          
		vortex->tx_dfree -= npkt->tot_iov;
		pidx  = vortex->tfd_pidx;
		fpidx = (pidx + 1) % vortex->num_tx_descriptors;

		for (buf = TAILQ_FIRST(&npkt->buffers); buf; 
		     buf = TAILQ_NEXT(buf, ptrs)) 
		{
	          
			for (i = 0, iov = buf->net_iov;
			     i < buf->niov; i++, iov++) 
			{ 
				pidx = (pidx + 1) % vortex->num_tx_descriptors;
				tfd  = &vortex->tfd[pidx];					
	          
				CACHE_FLUSH(&vortex->cachectl,
				    iov->iov_base, iov->iov_phys, iov->iov_len);

				tfd->buf = ENDIAN_LE32(iov->iov_phys | vortex->bmstr);
				
				if (iov->iov_len < ETH_MIN_PKT_LEN)
					tfd->len = ENDIAN_LE16(ETH_MIN_PKT_LEN);
				else
					tfd->len = ENDIAN_LE16(iov->iov_len);

				tfd->status = ENDIAN_LE16(R6040_OWN);
			}
		}

		vortex->stats.octets_txed_ok += npkt->framelen;
	          
		vortex->tx_pktq[fpidx]     = npkt;
		vortex->tfd_pidx           = pidx;

		/* trigger the adapter */
		r6040_write16(vortex->iobase + MTPR, 0x0001);
	          		
		pthread_mutex_unlock(&vortex->tx_mutex);

		while (npkt = list) 
		{	    
			list = npkt->next;
			vortex->ion->tx_done(vortex->reg_hdl, npkt);
		}	        
	          
		return TX_DOWN_OK;
	}

done:
	
	while (npkt2 = list) 
	{       
		list = npkt2->next;
		vortex->ion->tx_done(vortex->reg_hdl, npkt2);
	}

	if (npkt->flags & R6040_DEFRAG_PACKET) 
	{	          
		/* This was a defrag packet we allocated */
		vortex->ion->free(npkt->org_data);
		vortex->ion->free(npkt);
	} 
	else
	{        
		vortex->ion->tx_done(vortex->reg_hdl, npkt);
	}
	          
	return ret;
}

/*
 * vortex_collect_tx_packets(vortex)
 *
 *  Purpose: Go thru and clean up the tx descriptors after
 *           a packet has been sent.  Also give back packets
 *           to io-net to finish the transmit. 
 */
npkt_t *
vortex_collect_tx_packets(void *handle)
{
	vortex_dev_t	*vortex = (vortex_dev_t *) handle;
	npkt_t		*npkt;
	int		nidx;
	ushort_t	status;
	npkt_t		*list = NULL;

	nic_stats_t           *gstats = &vortex->stats;
	nic_ethernet_stats_t  *estats = &vortex->stats.un.estats;

	while (vortex->tx_dfree != vortex->num_tx_descriptors) 
	{
		nidx   = (vortex->tfd_cidx + 1) % vortex->num_tx_descriptors;

		/* find descriptor with end of packet set */
		status = ENDIAN_LE16(vortex->tfd[nidx].status);
		if (status & R6040_OWN)
		{        
			return list;
		}
			
		if (status & R6040_OK) 
		{          
			gstats->txed_ok++;

			estats->single_collisions = status & 0x000f;
		} 
		else 
		{          
			if (status & R6040_TX_TXFUR) 
				estats->internal_tx_errors++;
			if (status & R6040_TX_LATEC) 
				estats->late_collisions++;
		}
	          
		npkt = vortex->tx_pktq[nidx];
		vortex->tx_dfree += 1;
		vortex->tfd_cidx = (vortex->tfd_cidx + 1) % vortex->num_tx_descriptors;
		vortex->tx_pktq[nidx] = NULL;
	          
		if (npkt->flags & R6040_DEFRAG_PACKET) 
		{	          
			/* This was a defrag packet we allocated */
			vortex->ion->free(npkt->org_data);
			vortex->ion->free(npkt);
		} 
		else 
		{	          
			npkt->next = list;
			list = npkt;
		}
	}
	          
	return list;
}
