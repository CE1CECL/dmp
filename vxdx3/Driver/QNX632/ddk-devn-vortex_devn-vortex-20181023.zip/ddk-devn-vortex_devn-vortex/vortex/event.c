/*
 * Copyright 2003, QNX Software Systems Ltd. All Rights Reserved.
 *
 * This source code may contain confidential information of QNX Software
 * Systems Ltd.  (QSSL) and its licensors. Any use, reproduction,
 * modification, disclosure, distribution or transfer of this software,
 * or any software which includes or is based upon any of this code, is
 * prohibited unless expressly authorized by QSSL by written agreement. For
 * more information (including whether this source code file has been
 * published) please email licensing@qnx.com.
 */

#include <vortex.h>

/*
 * vortex_process_interrupt(vortex)
 *
 *  Purpose: Process the hardware interrupt.  Main pump for receiving
 *           packet data.  Also handles hardware reported error conditions.
 */
static void
vortex_process_interrupt(void *handle)
{	          	
	int		      iobase;
	ushort_t      evcnt3;
	ushort_t      status;
	vortex_dev_t  *vortex = (vortex_dev_t *) handle;

	iobase = vortex->iobase;

	/* Mask Off RDC MAC interrupt */
	r6040_write16(iobase + MIER, MIER_CLEAN_MASK);

	/* Move InterruptUnmask() here for other interrupt-sharing device */
	InterruptUnmask(vortex->cfg.irq[0], vortex->iid);

	/* Check MAC Interrupt status */
	r6040_read16(iobase  + MISR, &status);      /* Read INTR status and clear */

	pthread_mutex_lock(&vortex->rx_mutex);

	/* RX descriptor unavailable interrupt */
	if (status & MISR_RXDUA)
	{
		r6040_read16(iobase + MECNT3, &evcnt3);
		vortex->stats.un.estats.internal_rx_errors += (evcnt3 & 0xff);
	}

	/* RX packet received interrupt */
	if (status & MISR_RXEND)
	{
		vortex_receive(vortex);
	}

	pthread_mutex_unlock(&vortex->rx_mutex);

	/* Enable RX interrupt */
	r6040_write16(iobase + MIER, MIER_RXENDE | MIER_RXDNAE);
}

/*
 * vortex_event_handler(vortex)
 *
 *  Purpose: Entry point for the event handling thread.  Waits
 *           for hardware interrupt pulses as well as timer
 *           pulses for the MDI (MII) timer and responds accordingly.
 */
void *
vortex_event_handler(void *data)
{
	struct _pulse  pulse;
	iov_t		   iov;
	int		       rcvid;
	vortex_dev_t   *vortex = (vortex_dev_t *) data;

	SETIOV(&iov, &pulse, sizeof(pulse));

	while (1) 
	{
		rcvid = MsgReceivev(vortex->chid, &iov, 1, NULL);
		if (rcvid == -1) 
		{
			if (errno == ESRCH) 
				pthread_exit(NULL);
			continue;
		}

		switch(pulse.code) 
		{
		case NIC_INTERRUPT_EVENT:
			vortex_process_interrupt(vortex);
			break;
		
		case MDI_TIMER:
			MDI_MonitorPhy(vortex->mdi);
			break;
		
		default:
			if (rcvid) 
				MsgReplyv(rcvid, ENOTSUP, &iov, 1);
			break;
		}
	}
}
