

Directories:

Readme.txt:	this file.

\bsp:

  bsp-x86-bios-1.0.0-20070912-binsrc.zip: original BSP package for x86
  init_intrinfo_8259.c:	modified file to fix keyboard problem
  startup-bios:	built bsp executable to be used by system startup.

\network driver
  
  dmp_qnx_netdrv.rar:	r6040 network driver source package
  devn-vortex.so:	built network driver to be used under QNX  

\build file and image

  dmp_f.build:		build file for building the system image
  dmp_f.ifs:		built system image by the build file
  

Steps to start the system with a built floppy disk

1) Install the floppy disk, and boot with it

2) Install the network after the system starts up
   Run "io-net -d vortex -p tcpip"

3) Configure the IP address
   Run "ifconfig en0 'Machine IP Address' "

4) Try the network function and enjoy
   
   Run "ping 'Other Machine IP Address' "

   or

   Run "ftp 'FTP server IP Address' "

