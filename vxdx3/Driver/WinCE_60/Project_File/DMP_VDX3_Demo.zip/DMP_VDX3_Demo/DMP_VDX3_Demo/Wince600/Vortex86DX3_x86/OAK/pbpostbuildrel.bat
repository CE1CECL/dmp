if exist C:\WINCE600\OSDesigns\DMP_VDX3_Demo\DMP_VDX3_Demo\RelDir\Vortex86DX3_x86_Release\nlscfg.inf del /f /q C:\WINCE600\OSDesigns\DMP_VDX3_Demo\DMP_VDX3_Demo\RelDir\Vortex86DX3_x86_Release\nlscfg.inf
xcopy /q /c C:\WINCE600\OSDesigns\DMP_VDX3_Demo\DMP_VDX3_Demo\Wince600\Vortex86DX3_x86\oak\Files\nlscfg.inf C:\WINCE600\OSDesigns\DMP_VDX3_Demo\DMP_VDX3_Demo\RelDir\Vortex86DX3_x86_Release
