//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//

#ifndef _PCICFG_H_
#define _PCICFG_H_

//
// PCI Device class code
//

#define PCI_MASS_STORAGE        0x01        // Mass storage controller
#define PCI_NETWORK             0x02        // Network controller
#define PCI_DISPLAY             0x03        // Display controller
#define PCI_MULTIMEDIA          0x04        // Multimedia device
#define PCI_MEMORY              0x05        // Memory controller
#define PCI_BRIDGE              0x06        // Bridge device
#define PCI_COMMUNICATION       0x07        // Simple communication controllers
#define PCI_SYSTEM_PERIPHERIAL  0x08        // Base system peripherals
#define PCI_INPUT               0x09        // Input device
#define PCI_DOCKING_STATION     0x0A        // Docking stations
#define PCI_PROCESSORS          0x0B        // Processors
#define PCI_SERIAL_BUS          0x0C        // Serial bus controllers

//
// Network controller's Sub-Class Code
//
#define PCI_ETHERNET            0x00        // Ethernet controller
#define PCI_TOKEN_RING          0x01        // Token ring controller
#define PCI_FDDI                0x02        // FDDI controller
#define PCI_ATM                 0x03        // ATM controller
#define PCI_OTHER_NETWORK       0x80        // Other network controller

//
// Display controller's Sub-Class Code and Prog.I/F
//
#define PCI_VGA_DISPLAY         0x0000      // VGA compatible controller
#define PCI_8514_DISPLAY        0x0001      // 8514 compatible controller
#define PCI_XGA_DISPLAY         0x0100      // XGA compatible controller
#define PCI_OTHER_DISPLAY       0x8000      // Other display controller

//
// Bridge device's Sub-Class Code
//
#define PCI_HOST_PCI            0x00        // Host/PCI bridge
#define PCI_PCI_ISA             0x01        // PCI/ISA bridge
#define PCI_PCI_EISA            0x02        // PCI/EISA bridge
#define PCI_PCI_MC              0x03        // PCI/Micro channel bridge
#define PCI_PCI_BRIDGE          0x04        // PCI/PCI bridge
#define PCI_PCI_PCMCIA          0x05        // PCI/PCMCIA bridge
#define PCI_PCI_NuBus           0x06        // PCI/NuBus bridge
#define PCI_PCI_CardBus         0x07        // PCI/CardBus bridge

//
// PCI device standard configuration register number
//
#define PCI_CONFIG_ID               (0 << 2)
#define PCI_CONFIG_COMMAND_STATUS   (1 << 2)
#define PCI_CONFIG_CLASS_REVISION   (2 << 2)
#define PCI_CONFIG_HEAD             (3 << 2)
#define PCI_CONFIG_BASE0            (4 << 2)
#define PCI_CONFIG_BASE1            (5 << 2)
#define PCI_CONFIG_BASE2            (6 << 2)
#define PCI_CONFIG_BASE3            (7 << 2)
#define PCI_CONFIG_BASE4            (8 << 2)
#define PCI_CONFIG_BASE5            (9 << 2)
#define PCI_CONFIG_ROM              (12 << 2)
#define PCI_CONFIG_INTERRUPT        (15 << 2)


//
// PCI to PCI bridge configuration extension register number
//
#define PCIBRIDGE_BUS_NUMBER        (6 << 2)
#define PCIBRIDGE_IO                (7 << 2)
#define PCIBRIDGE_MEMORY            (8 << 2)
#define PCIBRIDGE_PREFETCHABLE      (9 << 2)
#define PCIBRIDGE_BASE_UPPER32      (10 << 2)
#define PCIBRIDGE_LIMIT_UPPER32     (11 << 2)
#define PCIBRIDGE_IO_UPPER16        (12 << 2)
#define PCIBRIDGE_ROM               (14 << 2)
#define PCIBRIDGE_CONTROL_INT       (15 << 2)

//
// PCI CardBus Bridge configuratoin extension register number
//
#define PCICARDBUS_BUS_NUMBER       (6 << 2)
#define PCICARDBUS_MEMBASE0         (7 << 2)
#define PCICARDBUS_MEMLIMIT0        (8 << 2)
#define PCICARDBUS_MEMBASE1         (9 << 2)
#define PCICARDBUS_MEMLIMIT1        (10 << 2)
#define PCICARDBUS_IOBASE0          (11 << 2)
#define PCICARDBUS_IOLIMIT0         (12 << 2)
#define PCICARDBUS_IOBASE1          (13 << 2)
#define PCICARDBUS_IOLIMIT1         (14 << 2)
#define PCICARDBUS_CONTROL_INT      (15 << 2)
#define PCICARDBUS_LEGACYBASE       (16 << 2)

//
// PCI mamory space classification code
//
#define PCI_MEM_32  0x0    // Memory located anywhere in 32 bit address
#define PCI_MEM_20  0x1    // Memory located anywhere in first 1M address
#define PCI_MEM_64  0x2    // Memory located anywhere in 64 bit address

//
// PCI Bridge decode type
//

#define PCI_SECONDARY_MEM32         0x0
#define PCI_SECONDARY_MEM64         0x1
#define PCI_SECONDARY_IO16          0x0
#define PCI_SECONDARY_IO32          0x1


//
// PCI configuration address register details
//
typedef
union _PCI_ADDRESS {

   struct {

      DWORD LoReserved : 2;         // Must be 00
      DWORD RegisterNumber : 6;
      DWORD FunctionNumber : 3;
      DWORD DeviceNumber : 5;
      DWORD BusNumber : 8;
      DWORD HiReserved : 8;         // Must be 80

   };

   DWORD reg;

} PCI_ADDRESS,*PPCI_ADDRESS;


//
// PCI ID register
//
typedef
union _PCI_ID {

   struct {

      DWORD VendorID : 16;
      DWORD DeviceID : 16;

  };

  DWORD reg;

} PCI_ID,*PPCI_ID ;


//
// PCI command register details
//
typedef
struct _PCI_COMMAND {

   WORD IOAccessEnable : 1;
   WORD MemoryAccessEnable : 1;
   WORD MasterEnable : 1;
   WORD SpecialCycleRecognition : 1;
   WORD MemoryWriteInvalidEnable : 1;
   WORD VGAPaletteSnoopEnable : 1;
   WORD ParityErrorResponse : 1;
   WORD WaitCycleEnable : 1;
   WORD SystemErrorEnable : 1;
   WORD FastBackToBackEnable : 1;
   WORD Reserved : 6;

} PCI_COMMAND,*PPCI_COMMAND ;


//
// PCI status register details
//
typedef
struct _PCI_STATUS {

   WORD Reserved : 5;
   WORD Capable66MHz : 1;
   WORD UDFSupported : 1;
   WORD CapableFastBackToBack : 1;
   WORD DataParityReported : 1;
   WORD DeviceSelectTiming : 2;
   WORD SignaledTargetAbort : 1;
   WORD ReceivedTargetAbort : 1;
   WORD ReceivedMasterAbort : 1;
   WORD SignaledSystemError : 1;
   WORD DetectedParityError : 1;

} PCI_STATUS,*PPCI_STATUS ;


//
// PCI status and command register
//
typedef
union _PCI_SC {

   struct {
      PCI_COMMAND Command;
      PCI_STATUS  Status;
   };

   DWORD reg;

} PCI_SC,*PPCI_SC ;


//
// PCI class code and revision register
//
typedef
union _PCI_CR {

   struct {
      BYTE  RevisionID;
      BYTE  ProgIF;
      BYTE  SubClassCode;
      BYTE  ClassCode;
   };

   DWORD reg;

} PCI_CR,*PPCI_CR ;


//
// PCI head type register details
//
typedef
struct _PCI_HEADTYPE {

   BYTE HeadType : 7;
   BYTE MultiFunctionDevice : 1;

} PCI_HEADTYPE,*PPCI_HEADTYPE ;


//
// PCI BIST register details
//
typedef
struct _PCI_BIST {

   BYTE CompletionCode : 4;
   BYTE Reserved : 2;
   BYTE StartBIST : 1;
   BYTE BISTCapable : 1;

}PCI_BIST,*PPCI_BIST ;


//
// PCI Bist, Head type, Latency timer and Cache line size register
//
typedef
union _PCI_BHLC {

   struct {

      BYTE CacheLineSize;
      BYTE LatencyTimer;
      PCI_HEADTYPE HeadType;
      PCI_BIST BIST;

   };

   DWORD reg;

}PCI_BHLC,*PPCI_BHLC ;


//
// PCI Max Lat, Min Gnt, INT pin and INT line register
//
typedef
union _PCI_INT {

   struct {

      BYTE InterruptLine;
      BYTE InterruptPin;
      BYTE MinGnt;
      BYTE MaxLat;

   };

   DWORD reg;

}PCI_INT,*PPCI_INT ;


//
// PCI base address register details
//
typedef
union _PCI_BASE {


   struct {

      DWORD : 1;
      DWORD Type : 2;
      DWORD Prefectchable : 1;
      DWORD MemBaseAddress : 28;

   };


   struct {

      DWORD Indicator : 1;
      DWORD : 1;
      DWORD IoBaseAddress : 30;

   };


   DWORD reg;

}PCI_BASE,*PPCI_BASE ;


//
// PCI bridge bus number register
//
typedef
union _BRIDGE_BUS {

   struct {

      BYTE PrimaryBusNumber;
      BYTE SecondaryBusNumber;
      BYTE SubordinateBusNumber;
      BYTE SecondaryLatencyTimer;
   };

   DWORD reg;
}BRIDGE_BUS,*PBRIDGE_BUS ;

//
// PCI bridge I/O range register detail
//
typedef
struct _BRIDGE_IORANGE{

   BYTE DecodeType : 4;
   BYTE Address    : 4;

}BRIDGE_IORANGE,*PBRIDGE_IORANGE;

//
// PCI bridge I/O mapping register
//
typedef
union _BRIDGE_IO {

   struct {

      BRIDGE_IORANGE IoBase;
      BRIDGE_IORANGE IoLimit;
      PCI_STATUS SecondaryStatus;
   };

   DWORD reg;
}BRIDGE_IO,*PBRIDGE_IO ;


//
// PCI bridge memory range register detail
//
typedef
struct _BRIDGE_MEMRANGE {

   WORD DecodeType : 4;
   WORD Address    : 12;

}BRIDGE_MEMRANGE,*PBRIDGE_MEMRANGE ;

//
// PCI bridge memory mapping register
//
typedef
union _BRIDGE_MEM {

   struct {

      BRIDGE_MEMRANGE MemoryBase;
      BRIDGE_MEMRANGE MemoryLimit;
   };

   DWORD reg;
}BRIDGE_MEM,*PBRIDGE_MEM ;


typedef
struct _PCI_DEVICE {
    ULONG Bus;
    ULONG Device;
    ULONG Function;
    ULONG VendorID;
} PCI_DEVICE,*PPCI_DEVICE;

#define PCIBUS_PREFETCH_MEMBASE_VALNAME TEXT("PrefetchMemBase")
#define PCIBUS_PREFETCH_MEMBASE_VALTYPE REG_DWORD

#define PCIBUS_PREFETCH_MEMLEN_VALNAME TEXT("PrefetchMemLen")
#define PCIBUS_PREFETCH_MEMLEN_VALTYPE REG_DWORD

#define PCIBUS_BUSNUMBERBASE_VALNAME TEXT("BusNumberBase")
#define PCIBUS_BUSNUMBERBASE_VALTYPE REG_DWORD

#define PCIBUS_BUSNUMBERLENGTH_VALNAME TEXT("BusNumberLength")
#define PCIBUS_BUSNUMBERLENGTH_VALTYPE REG_DWORD

typedef struct _PCI_DEV_INFO_EX {
    PCI_DEV_INFO pciDevice;
    DWORD        dwBusNumberBase;
    DWORD        dwBusNumberLength;
    PCI_RSRC_LIST PrefetchMemBase;
    PCI_RSRC_LIST PrefetchMemLen;
} PCI_DEV_INFO_EX, *PPCI_DEV_INFO_EX;
    
#endif // End of _PCICFG_H_
