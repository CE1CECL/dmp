//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//

#ifndef _PCIPROTO_H_
#define _PCIPROTO_H_

#include "pcicfg.h"
//
// Prototypes from PCIbus.c
//
DWORD
RegMatch(
    PPCI_DEV_INFO Info
    );

BOOL
RegGetInfo(
    PPCI_DEV_INFO pInfo
    );

BOOL    
RegGetExtraDeviceInfo(
    PPCI_DEV_INFO_EX pInfo
    );

void
PCIInitInfo(
    LPCWSTR RegPath,
    DWORD Bus,
    DWORD Device,
    DWORD Function,
    PPCI_COMMON_CONFIG pCfg,
    PPCI_DEV_INFO pInfo
    );
    
BOOL
LoadConfigEntry(
    PPCI_DEV_INFO pInfo
    );

void
UnloadConfigEntrys(
    void
    );


//
// Prototypes from PCIcfg.c
//
BOOL
PCIRequestResources(
    PPCI_DEV_INFO pInfo
    );

BOOL
PCIGetBARs(
    PPCI_DEV_INFO pInfo
    );

BOOL
PCIInitDevice(
    PPCI_DEV_INFO pInfo
    );

BOOL
PCICfg(
    PPCI_DEV_INFO_EX pInfo
    );

VOID
DumpPciConfig(
    PPCI_DEV_INFO pInfo
);


//
// Prototypes from PCIreg.c
//
extern DWORD
RegReadValues(
             IN  HKEY     hKey,
             IN  TCHAR   *tszSubKeyName, OPTIONAL
             IN  PVOID   (*pfMemAlloc)(DWORD), OPTIONAL
             IN  VOID    (*pfMemFree)(PVOID, DWORD), OPTIONAL
             ...);

BOOL IsSystemPhase1();
    
#endif // End of _PCIPROTO_H_
