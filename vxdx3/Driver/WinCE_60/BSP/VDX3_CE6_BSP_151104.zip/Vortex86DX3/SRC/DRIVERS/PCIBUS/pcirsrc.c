//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
///////////////////////////////////////////////////////////////////////////////
//
// PCIrsrc.c
//
// PCI resource management functions.
//
///////////////////////////////////////////////////////////////////////////////
 
#include <windows.h>
#include "PCIrsrc.h"

#define ALIGN(Addr, Size) ((DWORD)(Addr) & ~(Size - 1))


__inline static void
InsertRsrc(
    PPCI_RSRC Ptr, 
    PPCI_RSRC Rsrc
    ) 
{
    Rsrc->Next = Ptr;
    Rsrc->Prev = Ptr->Prev;
    Ptr->Prev->Next = Rsrc;
    Ptr->Prev = Rsrc;
}


__inline static void
RemoveRsrc(
    PPCI_RSRC Rsrc
    )
{
    Rsrc->Prev->Next = Rsrc->Next;
    Rsrc->Next->Prev = Rsrc->Prev;
}


PPCI_RSRC
PCIRsrc_New(
    DWORD Bus,
    DWORD Device,
    DWORD Function,
    DWORD Offset,
    DWORD Base,
    DWORD Size,
    BOOL Bridge,
    DWORD SecBus,
    BOOL Placed,
    PPCI_CFG_INFO ConfigInfo
    )
{
    PPCI_RSRC Rsrc;

    Rsrc = (PPCI_RSRC)LocalAlloc(0, sizeof(PCI_RSRC));

    if (!Rsrc) return NULL;
    
    Rsrc->Bus = Bus;
    Rsrc->Device = Device;
    Rsrc->Function = Function;
    Rsrc->Offset = Offset;
    Rsrc->Base = Base;
    Rsrc->Size = Size;
    Rsrc->Bridge = Bridge;
    Rsrc->SecBus = SecBus;
    Rsrc->Placed = Placed;
    Rsrc->ConfigInfo = ConfigInfo;
    Rsrc->Next = Rsrc;
    Rsrc->Prev = Rsrc;

    return Rsrc;
}


void
PCIRsrc_Add(
    PPCI_RSRC Head,
    PPCI_RSRC Rsrc
    )
{
    PPCI_RSRC Ptr;

    // Find place to insert Rsrc.  Sort first on Placed then Size.
    for (Ptr = Head->Next; Ptr != Head; Ptr = Ptr->Next) {
        if (Rsrc->Placed) {
            if (!Ptr->Placed) break;

            if (Rsrc->Size > Ptr->Size) break;
        } else {
            if (Ptr->Placed) continue;

            if (Rsrc->Size > Ptr->Size) break;
        }
    }
            
    // Insert Rsrc node
    InsertRsrc(Ptr, Rsrc); 
}


PPCI_RSRC
PCIRsrc_GetNext(
    PPCI_RSRC Head,
    DWORD Bus
    )
{
    PPCI_RSRC Ptr;

    for (Ptr = Head->Next; Ptr != Head; Ptr = Ptr->Next) {
        if (Ptr->Bus == Bus) {
            RemoveRsrc(Ptr);

            return Ptr;
        }
    }

    // No Rsrc nodes with Bus found
    return NULL; 
}


static BOOL
PlaceRsrc(
    PPCI_RSRC Head,
    PPCI_RSRC Rsrc
    )
{
    PPCI_RSRC Ptr;
    DWORD Address, RsrcLim;

    for (Ptr = Head->Next; Ptr != Head; Ptr = Ptr->Next) {
        if (Rsrc->Base < Ptr->Base) break;
    }

    // Insert Rsrc node
    InsertRsrc(Ptr, Rsrc);

    // Make sure resource fits after previous resource
    if (Rsrc->Prev == Head) {
        Address = Head->Base;
    } else {
        Address = Rsrc->Prev->Base + Rsrc->Prev->Size;
    }
        
    if (Address > Rsrc->Base) {
        RemoveRsrc(Rsrc);
        return FALSE;
    }
        
    // Make sure resource fits before next resource
    if (Rsrc->Next == Head) {
        Address = Head->Base + Head->Size;
    } else {
        Address = Rsrc->Next->Base;
    }

    RsrcLim = Rsrc->Base + Rsrc->Size;

    // Check for wrap (0 OK)
    if ((RsrcLim < Rsrc->Base) && (Rsrc->Base != 0)) {
        RemoveRsrc(Rsrc);
        return FALSE;
    }
        
    if ((Address != 0) && (RsrcLim > Address)) {
        RemoveRsrc(Rsrc);
        return FALSE;
    }

    return TRUE;
}


BOOL
PCIRsrc_Place(
    PPCI_RSRC Head,
    PPCI_RSRC Rsrc
    )
{
    DWORD RsrcLim, HeadLim;
    
    // For already placed resources, simply insert into list and
    // check to make sure it fits
    if (Rsrc->Placed) {
        return PlaceRsrc(Head, Rsrc);    
    } 
    else if (Rsrc->Size) {
        Rsrc->Base = ALIGN(Head->Base, Rsrc->Size);

        if (Rsrc->Base < Head->Base) {
            // Base address not naturally aligned, increment to fit in window
            Rsrc->Base += Rsrc->Size;
        }
            
        while (TRUE) {
            RsrcLim = Rsrc->Base + Rsrc->Size;
            HeadLim = Head->Base + Head->Size;

            // Check for wrap condition (0 is OK)
            if ((RsrcLim < Rsrc->Base) && (RsrcLim != 0)) return FALSE;
            if ((HeadLim < Head->Base) && (HeadLim != 0)) return FALSE;

            // Check to make sure resource fits
            if (RsrcLim > HeadLim) return FALSE;

            // Place resource, return if successful
            if (PlaceRsrc(Head, Rsrc)) return TRUE;

            Rsrc->Base += Rsrc->Size;
        }
    }

    return FALSE;
}


void
PCIRsrc_DelList(
    PPCI_RSRC Head
    )
{
    PPCI_RSRC Ptr;

    while ((Ptr = Head->Next) != Head) {
        // Remove Rsrc node from list
        Head->Next = Ptr->Next;
        Ptr->Next->Prev = Head;

        LocalFree(Ptr);
    }

    LocalFree(Head);
}


void
PCIRsrc_PrintList(
    PPCI_RSRC Head
    )
{
    PPCI_RSRC Ptr;
    
    for (Ptr = Head->Next; Ptr != Head; Ptr = Ptr->Next) {
        if (Ptr->Bridge) {
            RETAILMSG(1, (L"    BRIDGE: Bus/Device/Function %d/%d/%d, Offset 0x%X, Base 0x%X, Size 0x%X, SecBus %d, %s\r\n",
                Ptr->Bus, Ptr->Device, Ptr->Function, Ptr->Offset, Ptr->Base, Ptr->Size, Ptr->SecBus, (Ptr->Placed) ? L"Placed" : L""));
        } else {
            RETAILMSG(1, (L"    DEVICE: Bus/Device/Function %d/%d/%d, Offset 0x%X, Base 0x%X, Size 0x%X, %s\r\n",
                Ptr->Bus, Ptr->Device, Ptr->Function, Ptr->Offset, Ptr->Base, Ptr->Size, (Ptr->Placed) ? L"Placed" : L""));
        }
    }
}

