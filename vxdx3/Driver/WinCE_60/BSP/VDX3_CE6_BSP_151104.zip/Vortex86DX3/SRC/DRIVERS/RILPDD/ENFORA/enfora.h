//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//

#include "precomp.h"

// The constant below is part of a heuristic used in the RIL driver which does not track calls.
// The value of this constant helps rule out ME DEACT notifications from the distant past in
// relation to the current deactivation session.

#define STALE_MEDEACT_THRESHOLD 5000 // in ms

class  CResponseTI : public CResponse
{
public:
    CResponseTI() {};
    ~CResponseTI() {};
    CResponseTI(const CResponseTI &Rsp) : CResponse(Rsp) {};
	
private:
    BOOL    ParseCallProgressInformation(LPCSTR& rszPointer);
    BOOL    ParseNotificationOEM
		  (
			LPCSTR& szPointer, 
			BOOL& fExpectCRLF,
			BOOL fDataOnNotificationPort		
#ifdef RIL_WATSON_REPORT		
			, BOOL& fErrorNotification
#endif
		  );
    BOOL    ParseSIMToolkitCmdOrRspOEM(LPCSTR& rszPointer, const DWORD dwNotifyCode, RILSIMTOOLKITCMD*& pCmd, DWORD& dwCmdSize);
    void      Pre_ParseOKOrErrorOEM(const char* szPointer);
};

#define DEFAULT_COM_MASK (EV_RXCHAR | EV_RLSD | EV_ERR | EV_BREAK)
#define ENCODING_TECHARSET ENCODING_GSMDEFAULT_HEX

#define DOWNLINK_V0LUME_NORMALIZE	51

void StartSIMRecordReadThread();
