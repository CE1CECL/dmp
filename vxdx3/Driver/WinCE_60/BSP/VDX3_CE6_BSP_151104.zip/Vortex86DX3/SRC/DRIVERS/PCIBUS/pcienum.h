//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
#ifndef __PCIENUM_H_
#define __PCIENUM_H_

typedef struct _PCI_POWER_MANAGEMENT_BLOCK {
    UINT8   CapabilityID;
    UINT8   NextItemPtr;
    UINT16  PMC;
    UINT16  PMCSR;
    UINT8   PMCSR_BSE;
    UINT8   Data;
} PCI_POWER_MANAGEMENT_BLOCK,*PPCI_POWER_MANAGEMENT_BLOCK;

#ifdef __cplusplus

#define MAX_INITPARAM 0x20
#include <DefBus.h>
class PciDeviceFolder : public DeviceFolder{
public:
    PciDeviceFolder(LPCTSTR lpBusName,LPCTSTR lpTemplateRegPath,DWORD dwBusType, DWORD BusNumber,PCI_SLOT_NUMBER SlotNumber,HANDLE hParent);
    ~PciDeviceFolder();
    // PCI Power Handling;
    BOOL SetPowerState(CEDEVICE_POWER_STATE newPowerState);
    BOOL SetAlwaysBackup(BOOL fBackup = FALSE) {  return (m_fAlwaysBackup = fBackup); };
    
    virtual BOOL PowerUp();
    virtual BOOL PowerDown();
    CEDEVICE_POWER_STATE  GetPowerState() { return m_CurPowerState; };
    CEDEVICE_POWER_STATE  GetSleepPowerState() { return m_CurSleepPowerState; };
private:
    BOOL BackupConfiguration();
    BOOL RestoreConfiguration();
    BOOL SetPciPowerState(CEDEVICE_POWER_STATE newPowerState);
    BOOL FindPCIPowerMgrInterface();

    CEDEVICE_POWER_STATE m_CurSleepPowerState;
    BOOL    m_ConfigureIsBackuped;
    BOOL    m_fAlwaysBackup;
    PPCI_COMMON_CONFIG m_pCfg;
    DWORD   m_dwPowerMgrOffset;
    PCI_POWER_MANAGEMENT_BLOCK m_PowerMgrBlock;
};

#define PCI_ALWAYSBACKUP TEXT("CfgAlwaysBackup")
class PciBusEnum : public  DefaultBusDriver {
public:
    PciBusEnum(LPCTSTR lpActiveRegPath,LPCTSTR lpInstanceRegPath);
    ~PciBusEnum();
    virtual BOOL Init(); 
    virtual BOOL PostInit() ;
    virtual BOOL PowerUp() ;
    virtual BOOL PowerDown();
    virtual DWORD GetBusNamePrefix(LPTSTR lpReturnBusName,DWORD dwSizeInUnit);
private:
    virtual BOOL AssignChildDriver();
    virtual BOOL ActiveAllChildDriver();
    LPTSTR  m_lpActiveRegPath;
    CRegistryEdit m_DeviceKey;
    CRegistryEdit m_ActiveKey;
    DWORD   m_dwBusType;
    LPTSTR  m_lpBusName;
    DWORD   m_dwBusNumber;
    DWORD   m_dwDeviceIndex;
    DWORD   m_dwCfgAlwaysBackup;
    
    CEDEVICE_POWER_STATE m_PowerState;
    BOOL    m_isBackupConfigure;
    
    LPTSTR  m_lpStrInitParam;
    DWORD   m_dwNumOfInitParam;
    LPTSTR  m_lpInitParamArray[MAX_INITPARAM];
    
};

#endif

#ifdef __cplusplus
extern "C" {
#endif
HANDLE CreatePciBus(LPCTSTR lpActiveRegPath,LPCTSTR lpInstanceRegPath);
void DeletePciBus(HANDLE hInstance);
#ifdef __cplusplus
};
#endif

#endif

