//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this sample source code is subject to the terms of the Microsoft
// license agreement under which you licensed this sample source code. If
// you did not accept the terms of the license agreement, you are not
// authorized to use this sample source code. For the terms of the license,
// please see the license agreement between you and Microsoft or, if applicable,
// see the LICENSE.RTF on your install media or the root of your tools installation.
// THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
//
// -----------------------------------------------------------------------------
//
//      THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
//      ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//      THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//      PARTICULAR PURPOSE.
//  
// -----------------------------------------------------------------------------
#include <windows.h>
#include <x86ioctl.h>
#include <oal.h>
#include <pc.h>

const OAL_IOCTL_HANDLER g_oalIoCtlTable [] = {
#include <ioctl_tab.h>
};

LPCWSTR g_oalIoCtlPlatformType = L"VDX";           // changeable by IOCTL
LPCWSTR g_oalIoCtlPlatformOEM  = L"VDX";           // constant, should've never changed
LPCSTR  g_oalDeviceNameRoot    = "VDX";            // ASCII, initial value

LPCWSTR g_pszDfltProcessorName = L"i486";

const DWORD g_dwBSPMsPerIntr = 1;           // interrupt every ms

//
// perform RAM auto-detect if RAM ends at CEPC_EXTRA_RAM_START, for 
// size CEPC_EXTRA_RAM_SIZE.
//
const DWORD g_dwRAMAutoDetectStart = CEPC_EXTRA_RAM_START;
const DWORD g_dwRAMAutoDetectSize  = CEPC_EXTRA_RAM_SIZE;
