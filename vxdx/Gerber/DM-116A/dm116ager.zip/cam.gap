! GAPFile Version 3.0
GAPFile Version 3.0
Units: Mills
*CAP_LIBRARY 
*END_CAP_LIBRARY

*APERTURES2 217
10  Round d:142.00
11  Thermal Simple od:142.00 id:106.50 sa:45 a:0.0
12  Round d:122.00
13  Round d:128.00
14  Round d:70.00
15  Thermal Simple od:70.00 id:52.50 sa:45 a:0.0
16  Square s:50.00 a:0.0
17  Round d:50.00
18  Square s:60.00 a:0.0
19  Round d:56.00
20  Round d:28.00
21  Thermal Simple od:10.00 id:7.50 sa:45 a:0.0
22  Round d:22.00
23  Round d:55.00
24  Thermal Simple od:55.00 id:41.25 sa:45 a:0.0
25  Round d:35.00
26  Round d:45.00
27  Rectangle Sq w:40.00 h:32.00 a:0.0
28  Rectangle Sq w:32.00 h:40.00 a:0.0
29  Rectangle Sq w:46.00 h:38.00 a:0.0
30  Rectangle Sq w:38.00 h:46.00 a:0.0
31  Rectangle Sq w:27.00 h:60.00 a:0.0
32  Rectangle Sq w:60.00 h:27.00 a:0.0
33  Rectangle Sq w:33.00 h:66.00 a:0.0
34  Rectangle Sq w:66.00 h:33.00 a:0.0
35  Rectangle Sq w:177.00 h:39.00 a:0.0
36  Rectangle Sq w:39.00 h:177.00 a:0.0
37  Rectangle Sq w:183.00 h:45.00 a:0.0
38  Rectangle Sq w:45.00 h:183.00 a:0.0
39  Round d:118.00
40  Round d:40.00
41  Round d:80.00
42  Round d:48.00
43  Thermal Simple od:48.00 id:36.00 sa:45 a:0.0
44  Round d:34.00
45  Rectangle Sq w:55.00 h:90.00 a:0.0
46  Rectangle Sq w:90.00 h:55.00 a:0.0
47  Rectangle Sq w:61.00 h:96.00 a:0.0
48  Rectangle Sq w:96.00 h:61.00 a:0.0
49  Rectangle Sq w:55.00 h:70.00 a:0.0
50  Rectangle Sq w:70.00 h:55.00 a:0.0
51  Rectangle Sq w:61.00 h:76.00 a:0.0
52  Rectangle Sq w:76.00 h:61.00 a:0.0
53  Rectangle Sq w:50.00 h:70.00 a:0.0
54  Rectangle Sq w:70.00 h:50.00 a:0.0
55  Rectangle Sq w:56.00 h:76.00 a:0.0
56  Rectangle Sq w:76.00 h:56.00 a:0.0
57  Round d:85.00
58  Thermal Simple od:85.00 id:63.75 sa:45 a:0.0
59  Round d:65.00
60  Round d:75.00
61  Square s:65.00 a:0.0
62  Square s:71.00 a:0.0
63  Rectangle Sq w:71.00 h:80.00 a:0.0
64  Rectangle Sq w:80.00 h:71.00 a:0.0
65  Rectangle Sq w:77.00 h:86.00 a:0.0
66  Rectangle Sq w:86.00 h:77.00 a:0.0
67  Round d:120.00
68  Thermal Simple od:120.00 id:90.00 sa:45 a:0.0
69  Round d:100.00
70  Round d:110.00
71  Square s:100.00 a:0.0
72  Thermal Simple od:75.00 id:56.25 sa:45 a:0.0
73  Round d:61.00
74  Rectangle Sq w:118.00 h:47.00 a:0.0
75  Rectangle Sq w:47.00 h:118.00 a:0.0
76  Rectangle Sq w:124.00 h:53.00 a:0.0
77  Rectangle Sq w:53.00 h:124.00 a:0.0
78  Rectangle Sq w:50.00 h:50.00 a:0.0
79  Rectangle Sq w:56.00 h:56.00 a:0.0
80  Rectangle Sq w:36.00 h:36.00 a:0.0
81  Rectangle Sq w:42.00 h:42.00 a:0.0
82  Square s:52.00 a:0.0
83  Square s:58.00 a:0.0
84  Rectangle Sq w:40.00 h:50.00 a:0.0
85  Rectangle Sq w:50.00 h:40.00 a:0.0
86  Rectangle Sq w:46.00 h:56.00 a:0.0
87  Rectangle Sq w:56.00 h:46.00 a:0.0
88  Rectangle Sq w:63.00 h:51.00 a:0.0
89  Rectangle Sq w:51.00 h:63.00 a:0.0
90  Rectangle Sq w:69.00 h:57.00 a:0.0
91  Rectangle Sq w:57.00 h:69.00 a:0.0
92  Round d:90.00
93  Thermal Simple od:90.00 id:67.50 sa:45 a:0.0
94  Square s:70.00 a:0.0
95  Square s:90.00 a:0.0
96  Square s:80.00 a:0.0
97  Rectangle Sq w:14.00 h:44.00 a:0.0
98  Rectangle Sq w:44.00 h:14.00 a:0.0
99  Rectangle Sq w:20.00 h:50.00 a:0.0
100  Rectangle Sq w:50.00 h:20.00 a:0.0
101  Round d:140.00
102  Thermal Simple od:140.00 id:105.00 sa:45 a:0.0
103  Round d:125.00
104  Round d:131.00
105  Rectangle Sq w:24.00 h:40.00 a:0.0
106  Rectangle Sq w:40.00 h:24.00 a:0.0
107  Rectangle Sq w:30.00 h:46.00 a:0.0
108  Rectangle Sq w:46.00 h:30.00 a:0.0
109  Rectangle Sq w:83.00 h:118.00 a:0.0
110  Rectangle Sq w:118.00 h:83.00 a:0.0
111  Rectangle Sq w:89.00 h:124.00 a:0.0
112  Rectangle Sq w:124.00 h:89.00 a:0.0
113  Rectangle Sq w:32.00 h:80.00 a:0.0
114  Rectangle Sq w:80.00 h:32.00 a:0.0
115  Rectangle Sq w:38.00 h:86.00 a:0.0
116  Rectangle Sq w:86.00 h:38.00 a:0.0
117  Rectangle Sq w:20.00 h:45.00 a:0.0
118  Rectangle Sq w:45.00 h:20.00 a:0.0
119  Rectangle Sq w:26.00 h:51.00 a:0.0
120  Rectangle Sq w:51.00 h:26.00 a:0.0
121  Rectangle Sq w:100.00 h:60.00 a:0.0
122  Rectangle Sq w:60.00 h:100.00 a:0.0
123  Rectangle Sq w:106.00 h:66.00 a:0.0
124  Rectangle Sq w:66.00 h:106.00 a:0.0
125  Rectangle Sq w:12.00 h:50.00 a:0.0
126  Rectangle Sq w:50.00 h:12.00 a:0.0
127  Rectangle Sq w:18.00 h:56.00 a:0.0
128  Rectangle Sq w:56.00 h:18.00 a:0.0
129  Rectangle Sq w:26.00 h:56.00 a:0.0
130  Rectangle Sq w:56.00 h:26.00 a:0.0
131  Rectangle Sq w:24.00 h:75.00 a:0.0
132  Rectangle Sq w:75.00 h:24.00 a:0.0
133  Rectangle Sq w:30.00 h:81.00 a:0.0
134  Rectangle Sq w:81.00 h:30.00 a:0.0
135  Thermal Simple od:80.00 id:60.00 sa:45 a:0.0
136  Round d:60.00
137  Round d:66.00
138  Round d:145.00
139  Thermal Simple od:145.00 id:108.75 sa:45 a:0.0
140  Round d:126.00
141  Thermal Simple od:131.00 id:98.25 sa:45 a:0.0
142  Round d:91.00
143  Round d:97.00
144  Round d:254.00
145  Thermal Simple od:254.00 id:190.50 sa:45 a:0.0
146  Round d:234.00
147  Round d:270.00
148  Round d:160.00
149  Thermal Simple od:160.00 id:120.00 sa:45 a:0.0
150  Round d:146.00
151  Rectangle Sq w:14.00 h:80.00 a:0.0
152  Rectangle Sq w:80.00 h:14.00 a:0.0
153  Rectangle Sq w:20.00 h:86.00 a:0.0
154  Rectangle Sq w:86.00 h:20.00 a:0.0
155  Square s:55.00 a:0.0
156  Round d:148.00
157  Thermal Simple od:148.00 id:111.00 sa:45 a:0.0
158  Rectangle Sq w:12.00 h:70.00 a:0.0
159  Rectangle Sq w:70.00 h:12.00 a:0.0
160  Rectangle Sq w:18.00 h:76.00 a:0.0
161  Rectangle Sq w:76.00 h:18.00 a:0.0
162  Round d:16.00
163  Round d:74.00
164  Thermal Simple od:74.00 id:55.50 sa:45 a:0.0
165  Round d:43.00
166  Round d:49.00
167  Round d:103.00
168  Thermal Simple od:103.00 id:77.25 sa:45 a:0.0
169  Round d:63.00
170  Round d:69.00
171  Rectangle Sq w:110.00 h:200.00 a:0.0
172  Rectangle Sq w:200.00 h:110.00 a:0.0
173  Rectangle Sq w:116.00 h:206.00 a:0.0
174  Rectangle Sq w:206.00 h:116.00 a:0.0
175  Rectangle Sq w:20.00 h:80.00 a:0.0
176  Rectangle Sq w:80.00 h:20.00 a:0.0
177  Rectangle Sq w:26.00 h:86.00 a:0.0
178  Rectangle Sq w:86.00 h:26.00 a:0.0
179  Round d:113.00
180  Thermal Simple od:113.00 id:84.75 sa:45 a:0.0
181  Round d:73.00
182  Round d:79.00
183  Round d:217.00
184  Thermal Simple od:217.00 id:162.75 sa:45 a:0.0
185  Round d:197.00
186  Round d:203.00
187  Round d:14.00
188  Round d:20.00
189  Round d:46.00
190  Round d:200.00
191  Thermal Simple od:200.00 id:150.00 sa:45 a:0.0
192  Round d:157.00
193  Round d:167.00
194  Round d:51.00
195  Round d:57.00
196  Square s:51.00 a:0.0
197  Square s:57.00 a:0.0
198  Thermal Simple od:110.00 id:82.50 sa:45 a:0.0
199  Round d:58.00
200  Round d:64.00
201  Round d:78.00
202  Thermal Simple od:78.00 id:58.50 sa:45 a:0.0
203  Round d:6.00
204  Round d:8.00
205  Round d:10.00
206  Round d:16.00
207  Round d:5.00
208  Round d:7.87
209  Round d:4.00
210  Round d:25.00
211  Round d:5.98
212  Round d:12.01
213  Round d:4.02
214  Round d:11.81
215  Round d:20.00
216  Round d:2.00
217  Round d:30.00
218  Round d:15.00
219  Round d:14.00
220  Round d:7.00
221  Round d:24.00
222  Round d:12.00
223  Round d:22.00
224  Round d:7.50
225  Round d:50.00
226  Round d:100.00
*END_APERTURES


