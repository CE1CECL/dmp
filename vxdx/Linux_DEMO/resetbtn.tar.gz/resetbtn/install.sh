#!/bin/sh

cp hooks/resetbtn /etc/initramfs-tools/hooks/
cp scripts/resetbtn /etc/initramfs-tools/scripts/local-bottom/

update-initramfs -u

echo "Done"
