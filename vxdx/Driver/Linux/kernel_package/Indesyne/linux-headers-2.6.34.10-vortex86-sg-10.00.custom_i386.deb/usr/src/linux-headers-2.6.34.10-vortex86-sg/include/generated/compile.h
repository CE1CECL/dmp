/* This file is auto generated, version 1 */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#1 Tue Oct 1 01:20:30 CST 2013"
#define LINUX_COMPILE_TIME "01:20:30"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "lauryn-laptop"
#define LINUX_COMPILE_DOMAIN
#define LINUX_COMPILER "gcc version 4.4.3 (Ubuntu 4.4.3-4ubuntu5.1) "
