#define UTS_RELEASE "2.6.34.10-vortex86-sg"
