#!/bin/sh

SYSTEM=`uname -s`
CURRENTDATE=`date +%F-%H-%M-%N`
echo
echo "XGI $SYSTEM driver installation for package `cat version`"
echo 

#############################################
## 0. Get the distribution information
#############################################

#check OS
if [ $SYSTEM = "SunOS" ] ; then
	Distrib="Solaris" 
else 
	Distrib="other"
fi

echo $Distrib
Ver=`grep -i "X Window System Version" /var/log/Xorg.0.log|cut -d ' ' -f5`
echo $Ver

		configother=/etc/X11/.xorg.conf.xgi

  if [ -f $configother ] ; then

     echo "Driver has alreday setup, Please make uninstall first and then reinstallate."
     exit 0
  else
		cp libc.so.6.debian /usr/lib/libc.so.6
		cp libc.so.6.debian /lib/libc.so.6
		cp ld-linux.so.2.debian /usr/lib/ld-linux.so.2
		cp ld-linux.so.2.debian /lib/ld-linux.so.2
        	cp  /etc/X11/.xorg.conf /etc/X11/.xorg.conf.xgi
        	cp  /etc/X11/.xorg.conf /etc/X11/xorg.conf
  fi



#############################################
## 1. Copy 2D driver
#############################################
driver_bin="xgiz_drv.o"
driver_share_bin="xgiz_drv.so"

if [ $Distrib = "Solaris" ] ; then
   SunOSVer=`uname -r`
   #echo $SunOSVer
   if [ $SunOSVer = "5.10" ] ; then
	if [ $Ver = "1.3.0" ] ; then
	      cp xgiz_drv.so.72 xgiz_drv.so
   	      driver_bin="xgiz_drv.so"
        else
	      cp xgiz_drv.so.70 xgiz_drv.so
   	      driver_bin="xgiz_drv.so"
	fi
   fi
fi

if [ "$MACHTYPE" = "" ] ; then
	MACHTYPE=i386
fi

MACH=`echo $MACHTYPE | sed 's/-.*$//g'` ;

if [ "$MACH" = "x86_64" ] ; then
	# 64 bit
	driver_path=${X11R6}/lib64/modules/drivers
	if [ ! -d $driver_path ] ; then
		driver_path=${X11R6}/lib/modules/drivers
	fi
else
	# 32 bit
	 driver_path=${X11R6}/lib/modules/drivers
	### 2008/07/22 claire add for support Solaris 10 U3 (xorg 6.9.0)
	if [ $Distrib = "Solaris" ] ; then
		SunOSDVer=`uname -r`  
 		if [ $SunOSDVer = "5.10" ] ; then
	 	driver_path=/usr/X11/lib/modules/drivers
		fi
	fi
fi
DRV="${driver_path}/$driver_bin"
SHARE_DRV="${driver_path}/$driver_share_bin"
if [ ! -d "$driver_path" ] ; then
	echo "Cannot open X11 installation path $driver_path. Exit." 1>&2
	exit -1 ;
fi

if [ -f $driver_bin ] ; then
	#install -m 644 $driver_bin $driver_path
	cp $driver_bin $driver_path
	echo "Driver $driver_bin copy to ${driver_path} done."
else
	echo "There is no $driver_bin existing." 1>&2
	exit -1 ;
fi


# Probe HW and generate /etc/sysconfig/hwconf
if [ -f /usr/sbin/kudzu ] ; then
	kudzu -q
fi

################################################
## 2. Get XGI chip information
################################################
#
# Get register info.to check if the current 
# adapter is XG20 or XG21, 2005/11/1, JILL
#

XGICards="Cards.xgi"
XGIPCI="pcitable.xgi"
XGICards_SUSE="Cards.xgi.suse"
XGIIdentity="Identity.xgi"


if [ $Distrib = "Solaris" ] ; then 
        XGICards="Cards_Freebsd.xgi"
        XGIPCI="pcitable_Freebsd.xgi"
        XGIIdentity="Identity_Freebsd.xgi"

else
        XGICards="Cards_Freebsd.xgi"
        XGIPCI="pcitable_Freebsd.xgi"
        XGIIdentity="Identity_Freebsd.xgi"

fi


################################################
## 3. modify configuration
################################################

#
# Other distributions
#
# 	if [ $Ver = "1.3.0" ] ; then
		XORG_CFG="/etc/X11/xorg.conf"
		XORG_BAK="/etc/X11/.xorg.conf.xgi"
#	fi	
	
	CFG=$XORG_CFG
	BAK=$XORG_BAK
	
	if [ -f $XORG_CFG ] ; then
		CFG=$XORG_CFG
		BAK=$XORG_BAK
		XSERVER_MODULE="XOrg"
	fi

	
	#

# Remove all "Device" Section before add XGI device Section
#
src="/tmp/conf.tmp"
des="/tmp/conf.tmp.bak"
cp /etc/X11/xorg.conf /tmp/conf.tmp
cp /etc/X11/xorg.conf /tmp/conf.tmp.bak



#
# add Device Section for XGI drivers
#
        ##remove device claire add 20081126
	perl modyconfig.plx 1 $src	
	echo "Modify $CFG ..."
	#xgicard=`cat $XGICards | grep ^NAME | cut -d " " -f4`
	xgicard=`grep -i "NAME" $XGICards |cut -d " " -f4`
	#xgidrv=`cat $XGICards | grep ^DRIVER | cut -d " " -f2`
	xgidrv=`grep -i "DRIVER" $XGICards | cut -d " " -f2`
	perl xgicfg.plx $src $BAK $xgicard $xgidrv	
	echo "X-windows (X11) seting config file is /etc/X11/xorg.conf."

if [ ! -f $src ] ; then
	echo "Cannot find X configuration file $CFG . Please run xorgconfig for XOrg or xf86config for Xfree." 1>&2 
	exit -1 ;
fi

mv $CFG $BAK
mv $src $CFG
	
# Finish Configuration


