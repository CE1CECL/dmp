#!/bin/sh

SYSTEM=`uname -s`
CURRENTDATE=`date +%F-%H-%M-%N`
echo
echo "XGI $SYSTEM driver installation for package `cat version`"
echo 

#############################################
## 0. Get the distribution information
#############################################
Distrib_SE="/etc/SuSE-release"
Distrib_MD="/etc/mandrake-release"
Distrib_FC="/etc/fedora-release"
Distrib_RF="/etc/redflag-release"
Distrib_RH="/etc/redhat-release"
Distrib_TB="/etc/turbolinux-release"
Distrib="other"

#check OS
if [ -f $Distrib_RF ] ; then
	Distrib="redflag"
elif [ -f $Distrib_MD ] ; then
	Distrib="mandrake"
elif [ -f $Distrib_FC ] ; then
	Distrib="fedora"
elif [ -f $Distrib_SE ] ; then
	Distrib="suse"
elif [ -f $Distrib_RH ] ; then
	Distrib="redhat" 
elif [ -f $Distrib_TB ] ; then
	Distrib="turbolinux" 
elif [ $SYSTEM = "FreeBSD" ] ; then
	Distrib="FreeBSD" 
elif [ $SYSTEM = "SCO_SV" ] ; then
        Distrib="SCO_SV"
else 
	Distrib="other"
fi

echo $Distrib
#############################################
## 1. Copy 2D driver
#############################################
driver_bin="xgiz_drv.o"
  


if [ "$X11R6" = "" ] ; then
	# echo "The system do not contains the X11R6 environment variable." 1>&2
	# echo "Use /usr/X11R6 as default X11R6 path." 1>&2
	# echo
	# echo
	X11R6=/usr/X11R6
	export X11R6
fi

if [ "$MACHTYPE" = "" ] ; then
	MACHTYPE=i386
fi

MACH=`echo $MACHTYPE | sed 's/-.*$//g'` ;

if [ "$MACH" = "x86_64" ] ; then
	# 64 bit
	driver_path=${X11R6}/lib64/modules/drivers

       
	if [ ! -d $driver_path ] ; then
		driver_path=${X11R6}/lib/modules/drivers
	fi
else
	# 32 bit	
	 driver_path=${X11R6}/lib/modules/drivers
         


fi


DRV="${driver_path}/$driver_bin"
SHARE_DRV="${driver_path}/$driver_share_bin"

if [ ! -d "$driver_path" ] ; then
	echo "Cannot open X11 installation path $driver_path. Exit." 1>&2
	exit -1 ;
fi

if [ -f $driver_bin ] ; then 
	cp $driver_bin $driver_path
	#install -m 644 $driver_bin $driver_path
	 echo "Driver $driver_bin copy to ${driver_path} done."
else
	echo "There is no $driver_bin existing." 1>&2
	exit -1 ;
fi



# Probe HW and generate /etc/sysconfig/hwconf
if [ -f /usr/sbin/kudzu ] ; then
	kudzu -q
fi




#===============================================================

#
# Other distributions
#

	XORGSCO_CFG="/etc/xorg.conf"
#	XORGSCO_BAK="/etc/.xorg.conf.bak"
	XORGSCO_BAK="/etc/.xorg.conf.xgi"
	CFG=$XORGSCO_CFG
	BAK=$XORGSCO_BAK
	cp $CFG $BAK
	XSERVER_MODULE="Xorg"

	


#
# add Device Section for XGI drivers
#
	
	
	#echo "$CFG $BAK"	
	#perl xgicfg.plx $CFG $BAK
	echo "Modify $CFG ..."
	perl xgicfg_sco.plx $CFG $BAK 
	
	
# Finish Configuration


