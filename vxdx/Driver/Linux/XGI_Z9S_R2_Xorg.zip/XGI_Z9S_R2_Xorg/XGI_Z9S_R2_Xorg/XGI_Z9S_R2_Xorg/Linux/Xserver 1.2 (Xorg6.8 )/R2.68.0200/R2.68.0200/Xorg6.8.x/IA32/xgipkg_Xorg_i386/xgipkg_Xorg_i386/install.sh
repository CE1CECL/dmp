#!/bin/sh

SYSTEM=`uname -s`
CURRENTDATE=`date +%F-%H-%M-%N`
echo
echo "XGI $SYSTEM driver installation for package `cat version`"
echo 

#############################################
## 0. Get the distribution information
#############################################
Distrib_SE="/etc/SuSE-release"
Distrib_MD="/etc/mandrake-release"
Distrib_FC="/etc/fedora-release"
Distrib_RF="/etc/redflag-release"
Distrib_RH="/etc/redhat-release"
Distrib_TB="/etc/turbolinux-release"
Distrib="other"

#check OS
if [ -f $Distrib_RF ] ; then
	Distrib="redflag"
elif [ -f $Distrib_MD ] ; then
	Distrib="mandrake"
elif [ -f $Distrib_FC ] ; then
	Distrib="fedora"
elif [ -f $Distrib_SE ] ; then
	Distrib="suse"
elif [ -f $Distrib_RH ] ; then
	Distrib="redhat" 
elif [ -f $Distrib_TB ] ; then
	Distrib="turbolinux" 
elif [ $SYSTEM = "FreeBSD" ] ; then
	Distrib="FreeBSD" 
elif [ $SYSTEM = "SCO_SV" ] ; then
        Distrib="SCO_SV"
else 
	Distrib="other"
fi

echo $Distrib


if [ $Distrib = "SCO_SV" ] ; then
	 if [ -f /etc/.xorg.conf.xgi ] ; then
	    echo " Driver has already setup. Please make uninstll first and then reinstallate "
      exit 0;
	 else
	 cp -a /etc/xorg.conf /etc/.xorg.conf.xgi
   sh install_sco.sh
   fi
else
   if [ -f /etc/X11/.xorg.conf.xgi ] ; then
      echo " Driver has already setup. Please make uninstll first and then reinstallate "
      exit -1;
   else   
      cp -a /etc/X11/xorg.conf /etc/X11/.xorg.conf.xgi
      sh install_nor.sh
   fi
fi
