#!/usr/bin/perl


use strict;
################Global Variables###################################
my $row;           # for check every row
my @X86C;          # open the xorg.conf file
###############HASH Structure######################################
my $i;             #for index
############################Misc###################################
my $title;         #print title
my @temp;          #some temp array for hash ,or for split string
###################### Control Variable ######################
my $dual_var   = 0; #1: enable 0:disable
my $mirror_var = 0;
my $extend_var = 0; #add Option to ServerLayout
###################################################################
#open a file called "xorg.conf" 
open(INP, "/etc/X11/xorg.conf") || die("Cannot open /etc/X11/xorg.conf.\n");

## Feng, 2007/08/08, Use parameter to set up the config file and Mode  ##

# Get parameters
#
# arg1 = 1:Independent Mode; 2:Mirror Mode; 3: Extended Mode
#        default is 1
# arg2 = A string of config file name
#        default is /etc/xorg.conf
                                                                                                 
my @params = @ARGV;
#print STDERR "@params\n";
## Check the arguments unmbers
if(($#ARGV+1 < 1) || ($#ARGV+1 > 2)) {
    die("Usage: <Mode_number> [<Config_file>]\n");
}

## Get each argument
my $arg1 = shift(@params);
my $arg2 = shift(@params);
#print STDERR "arg1=$arg1, arg2=$arg2\n";
## Set Mode type using arg1 
#if ($arg1 ne "") {
#    if ($arg1 == "1") {
#        ## Independent Mode
#        $dual_var = 1;
#    } elsif ($arg1 == "2") {
#        ## Mirror Mode
#        $mirror_var = 1;
#    } elsif ($arg1 == "3") {
#        ## Extended Mode
#        $extend_var = 1;
#    } else {
#        die("Unknown Mode number: $arg1\n");
#    }
#} else {
#    die("You should give the mode number\n");
#}

## Set config file name using arg2
if ($#ARGV == 1) {
    $arg2 == "/etc/xorg.conf";
} elsif ($arg2 eq "") {
    print STDERR "Use the default config file: /etc/xorg.conf\n";
    $arg2 = "/etc/xorg.conf";
}
print STDERR "arg2= $arg2\n";

#open(INP, "/etc/xorg.conf") || die("Cannot open xorg.conf\n");
open(INP, "$arg2") || die("Cannot open $arg2\n");
@X86C = <INP>; 
close INP; 
## Feng, End ##

###################################################################
#$title = $X86C[0];
#print "$title\n";  # print the file header

#my $SL_sec=0;      # ServerLayout first line number 
#my $SL_end ;       # ServerLayout End
#my $SL_get=0;      # Get EndSection flag

#my $Monitor_sec=0; # Monitor CRT1 first line number
#my $Monitor_end;   # Monitor 'EndSection'
#my $Monitor_get=0; # Get EndSection flag

my $Device_sec=0;  # Device first line number
my $Device_end ;   # Device 'EndSection'
my $Device_get=0 ; # Get EndSection flag

#my $Screen_sec=0;  # Screen first line
#my $Screen_end ;   # Screen 'EndSection'
#my $Screen_get=0 ; # Get EndSection flag
##############################################################

#1. Read data till the end of the file 
for($row=1; $row < @X86C; $row++)
{

     if($X86C[$row] =~ /Section "Device"/)
     {
       $Device_sec = $row ;

       #print "$X86C[$row] \n";
     }
     elsif(($Device_sec != 0) && ($Device_get == 0) && ($X86C[$row] =~ /EndSection/))
     {
       $Device_get = 1;
       $Device_end = $row ;
     } 

}

#2. Write data to new XF86Config
#open FF,">X86C.log";
open FF, ">$arg2";

for($row=0; $row < @X86C; $row++)
{
    if(($row eq ($Device_sec -1))) #remove Device Section
    {
    	#print "$Device_sec \n";
	#print "$Device_end \n"; 
	  for($i=$Device_sec; $i<($Device_end+1); $i++)
       {
         #print "$Device_end \n";
         if($i == $Device_end) 
         { 
           $row=$i;
	   #print FF "$X86C[$i]"; 
           #print "$Device_sec \n";
	  }
       }
     print FF "\n";
    }
    else
    {   # print "$row";
	 print FF "$X86C[$row]";}
}
 
close FF;
