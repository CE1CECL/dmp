#!/usr/bin/perl	
##modify pci.ids for add xgi information
#20090430
#Claire Hsu
#for pci.ids

use strict;
################Global Variables###################################
my $row;           # for check every row
my @X86C;          # open the pci.ids file
###############HASH Structure######################################
my $i;             #for index
############################Misc###################################
my $title;         #print title
my @temp;          #some temp array for hash ,or for split string
###################### Control Variable ######################
#open a file called "pci.ids" 
#open(INP, "/usr/share/hwdata/pci.ids") || die("Cannot open pci.ids.\n");

                                                                                                 
my @params = @ARGV;
#print STDERR "@params\n";

## Check the arguments unmbers

## Get each argument
my $arg1 = shift(@params);
my $arg2 = shift(@params);
#print STDERR "arg1=$arg1, arg2=$arg2\n";



#print STDERR "arg2= $arg2\n";

#open(INP, "$arg2") || die("Cannot open $arg2\n");
open(INP, "$arg1") || die("Cannot open $arg1\n");
#open(INP, "$src") || die("Cannot open $src\n");
@X86C = <INP>; 
close INP; 

###################################################################
#$title = $X86C[0];
#print "$title\n";  # print the file header
my $sec=0;       
my $get=0;
my $end=0;
##############################################################

#1. Read data till the end of the file 
for($row=1; $row < @X86C; $row++)
{
     if($X86C[$row] =~ /18ca/) 
     {       
       #print "$row \n";
       $sec = $row ;
       #print "$sec \n" ;       
     }
     #elsif(($sec != 0) 
     #{
     #  $end = $row ;
     #  print "$end \n" ;
     #  print "$X86C[$end] \n";
     # } 

}

#2. Write data to new pci.ids
#open FF, ">$arg2";
open FF, ">$arg1";

for($row=0; $row < @X86C; $row++)
{
    if(  ($row eq ($sec+1)) ) 
    {    
          print FF "	0020  Volari Z7/Z9/Z9s series VGA";
	  print FF "\n";
	  print FF "	0021  Volari Z9/Z9s/Z9M series VGA";
	  print FF "\n";
	  print FF "	0027  Volari Z11/Z11M series VGA";
	  print FF "\n";
	  #print FF "        0040 Volari V3XT/V5/V8";
	  #print FF "\n";
	  #print FF "        0047 Volari 8300 (chip:XP10, codename:XG47)";
	  #print FF "\n";
     } 
    else
      { print FF "$X86C[$row]";}
 
}
 
close FF;
