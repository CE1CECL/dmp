#!/bin/sh



XSERVER_MODULE="XFree86"

XFREE86_CFG="/etc/X11/XF86Config"
XFREE86_BAK="/etc/X11/.XF86Config.bak"

XORG_CFG="/etc/X11/xorg.conf"
XORG_BAK="/etc/X11/.xorg.conf.bak"

RF_XFREE86_CFG="/etc/X11/XF86Config-4"
RF_XFREE86_BAK="/etc/X11/.XF86Config-4.bak"

CFG=$XFREE86_CFG
BAK=$XFREE86_BAK

if [ -f $XFREE86_CFG ] ; then
	CFG=$XFREE86_CFG
	BAK=$XFREE86_BAK
	XSERVER_MODULE="XFree86"
fi

if [ -f $XORG_CFG ] ; then
	CFG=$XORG_CFG
	BAK=$XORG_BAK
	XSERVER_MODULE="XOrg"
fi

if [ -f $RF_XFREE86_CFG ] ; then
	CFG=$RF_XFREE86_CFG
	BAK=$RF_XFREE86_BAK
	XSERVER_MODULE="XFree86"
fi

driver_bin="xgiz_drv.o"
driver_share_bin="xgiz_drv.so"
# check FreeBSD for claire add 2007/03/20
SYSTEM=`uname -s`



if [ "$X11R6" = "" ] ; then
	# echo "The system do not contains the X11R6 environment variable." 1>&2
	# echo "Use /usr/X11R6 as default X11R6 path." 1>&2
	# echo
	# echo
	X11R6=/usr/X11R6
	export X11R6
fi

if [ "$MACHTYPE" = "" ] ; then
	MACHTYPE=i386
fi

MACH=`echo $MACHTYPE | sed 's/-.*$//g'` ;

if [ "$MACH" = "x86_64" ] ; then
	# 64 bit

	driver_path=${X11R6}/lib64/modules/drivers
  
	if [ ! -d $driver_path ] ; then
		driver_path=${X11R6}/lib/modules/drivers
	fi
else
	# 32 bit
	driver_path=${X11R6}/lib/modules/drivers

fi


DRV="${driver_path}/$driver_bin"
DRV_SHARE="${driver_path}/$driver_share_bin"

if [ ! -d "$driver_path" ] ; then
	echo "Cannot open X11 installation path $driver_path. Exit." 1>&2
	exit -1 ;
fi



echo "Uninstall XGI $XSERVER_MODULE driver (Y/N)?"
read RESULT
if [ "${RESULT}" = "Y" -o "${RESULT}" = "y" ]; then
      cp /etc/.xorg.conf.xgi /etc/xorg.conf
      rm -rf /etc/.xorg.conf.xgi


      
	if [ -f "${DRV}" ] ; then
		/bin/rm ${DRV}
		echo "${DRV} is removed."
	fi

	if [ -f "${DRV_SHARE}" ] ; then
		/bin/rm ${DRV_SHARE}
		echo "${DRV_SHARE} is removed."
	fi
fi
