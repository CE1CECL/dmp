#!/bin/sh

SYSTEM=`uname -s`
CURRENTDATE=`date +%F-%H-%M-%N`
echo
echo "XGI $SYSTEM driver installation for package `cat version`"
echo

#############################################
## 0. Get the distribution information
#############################################
#check OS
if [ $SYSTEM = "SunOS" ] ; then
        Distrib="Solaris"
else
        Distrib="other"
fi

echo $Distrib
Ver=`grep -i "X Window System Version" /var/log/Xorg.0.log|cut -d ' ' -f5`
echo $Ver


XSERVER_MODULE="XFree86"

XFREE86_CFG="/etc/X11/XF86Config"
XFREE86_BAK="/etc/X11/.XF86Config.bak"
	XORG_CFG="/etc/X11/xorg.conf"
	XORG_BAK="/etc/X11/.xorg.conf.xgi"

RF_XFREE86_CFG="/etc/X11/XF86Config-4"
RF_XFREE86_BAK="/etc/X11/.XF86Config-4.bak"

CFG=$XFREE86_CFG
BAK=$XFREE86_BAK

if [ -f $XFREE86_CFG ] ; then
	CFG=$XFREE86_CFG
	BAK=$XFREE86_BAK
	XSERVER_MODULE="XFree86"
fi

if [ -f $XORG_CFG ] ; then
	CFG=$XORG_CFG
	BAK=$XORG_BAK
	XSERVER_MODULE="XOrg"
fi

if [ -f $RF_XFREE86_CFG ] ; then
	CFG=$RF_XFREE86_CFG
	BAK=$RF_XFREE86_BAK
	XSERVER_MODULE="XFree86"
fi

driver_bin="xgiz_drv.o"
driver_share_bin="xgiz_drv.so"
SYSTEM=`uname -s`
if [ $SYSTEM = "SunOS" ] ; then
	driver_bin="xgiz_drv.so"

fi
if [ "$X11R6" = "" ] ; then
	# echo "The system do not contains the X11R6 environment variable." 1>&2
	# echo "Use /usr/X11R6 as default X11R6 path." 1>&2
	# echo
	# echo
	X11R6=/usr/X11R6
	export X11R6
fi

if [ "$MACHTYPE" = "" ] ; then
	MACHTYPE=i386
fi

MACH=`echo $MACHTYPE | sed 's/-.*$//g'` ;

if [ "$MACH" = "x86_64" ] ; then
	# 64 bit

	driver_path=${X11R6}/lib64/modules/drivers
	if [ ! -d $driver_path ] ; then
		driver_path=${X11R6}/lib/modules/drivers
	fi
else
	# 32 bit
	driver_path=${X11R6}/lib/modules/drivers
	#### 2008/07/22 claire add for uninstall Solaries 10_U3
	if [ $SYSTEM = "SunOS" ] ; then
		X11R6=/usr/X11
		export X11R6
		driver_path=${X11R6}/lib/modules/drivers
	fi

fi


DRV="${driver_path}/$driver_bin"
DRV_SHARE="${driver_path}/$driver_share_bin"

if [ ! -d "$driver_path" ] ; then
	echo "Cannot open X11 installation path $driver_path. Exit." 1>&2
	exit -1 ;
fi



echo "Uninstall XGI $XSERVER_MODULE driver (Y/N)?"
read RESULT
if [ "${RESULT}" = "Y" -o "${RESULT}" = "y" ]; then
	if [ $SYSTEM = "SunOS" ] ; then
     		cp /etc/X11/.xorg.conf.xgi /etc/X11/xorg.conf
		rm -rf /etc/X11/.xorg.conf.xgi
     	fi   
      
	if [ -f "${DRV}" ] ; then
		/bin/rm ${DRV}
		echo "${DRV} is removed."
	fi

	if [ -f "${DRV_SHARE}" ] ; then
		/bin/rm ${DRV_SHARE}
		echo "${DRV_SHARE} is removed."
	fi
fi
