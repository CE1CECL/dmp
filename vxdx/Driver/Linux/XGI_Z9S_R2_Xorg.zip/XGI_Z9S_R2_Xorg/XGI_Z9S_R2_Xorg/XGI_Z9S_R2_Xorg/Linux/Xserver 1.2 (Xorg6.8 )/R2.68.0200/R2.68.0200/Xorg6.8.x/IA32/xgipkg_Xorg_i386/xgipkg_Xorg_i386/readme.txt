XGI Linux Driver Package User Installation Guide

Decemeber 23, 2008  by claire Hsu (xgi0235)

Contents

1. System Requirement
2. Hardware  Requirement
3. Insallation with run
4. Insallation with TGZ
5. X Configuration


===========================================
1. System Requirement
===========================================

Supported Linux Distribution:
    RHEL4.5 x86-i386/x86-64
    Fedora Core 1-4 i386/x86-64    
    Mandrake 9.2    
    SuSE Pro 9.3_i386
    SuSE 10 x86-i386/x86-64
    FreeBSD5.4_i386
    TurboLinux FUJI version 11_i386
    Asianux 2.0 (Miracle Linux 4.0) 
    Debian 5.3
    
Kernel Version:
    (Suppose 2.4.18~2.4.22 are OK)
    2.6.9-55-EL (RHEL4.5 x86-i386)
    2.6.9-55.Elsmp (RHEL4.5 x86-64)
    2.6.11.4-20a    (SuSE 9.3_i386)
    2.6.13-15	    (SuSE 10)
    2.6.11-1.1369   (FC4)
   
 
XOrg Version:
	6.8.2


===========================================
2. Hardware  Requirement
===========================================
VGA adapter card:
    XGI Volari Z7/Z9/Z9s/Z9M/Z11

===========================================
3. Insallation with run
===========================================
Driver file:
   1. xgi_xg27_x86_64_xorg_#_#_#.run --> RHEL4_64bit
   2. xgi_xg27_x86_xorg_#_#_#.run --> RHEL4_32bit



Usage:

run:
	-Install 
	  Run "sh xgi_xg27_xxxx_<version>.run"
          ex: sh xgi_xg27_x86_64_xorg_2_68_01.run
              sh xgi_xg27_x86_xorg_2_68_01.run
	
	-Uninstall	
	  Run "sh xgi_xxxx_#_#_#.run --noexec --target xgi
          ex: $sh xgi_xg27_x86_64_xorg_2_68_01.run --noexec --target xgi
	      $sh uninstall.sh
              $sh xgi_xg27_x86_xorg_2_68_01.run --noexec --target xgi
	      $sh uninstall.sh
	            


===========================================
4. Insallation with TGZ
===========================================
Usage:

	$ tar xvfzp xgipkg.tgz
	$ sh install.sh
	
Reference Environment
	
	X11R6 - use as the root path for X11R6 system.
	
Installation action 

	1. copy xgi_drv.o  to ${X11R6}/lib/modules/drivers for driver of Xorg
	2. modify /etc/X11/xorg.conf to enable it.		
	
Uninstallation action
	
	$ sh uninstall.sh
	
	1. remove xgi_drv.o from ${X11R6}/lib/modules/drivers for driver of Xorg
	2. Recover the /etc/X11/xorg.conf to recover the original status.
	
===========================================
4. X Configuration
===========================================	
Tune the xorg.conf configuration file to taste.
    a. Open the file in a text editor such as emacs or vi.
    b. Check if the frequencies(HorizSync and VertRefresh in the Monitor section of X configure file) for the target system's monitor are correct. 
       These are usually expressed as a horizontal(HorizSync) and vertical synchronization(VertRefresh) rate. 
       These values are added to the xorg.conf file under the "Monitor" section:

        Section "Monitor"
                Identifier   "Monitor0"
                VendorName   "Monitor Vendor"
                ModelName    "Monitor Model"
                HorizSync    30-107
                VertRefresh  48-120
        EndSection
      
       The shorter the ranges of HorizSync and VertRefresh defined in the configure file are , The less the modes X support are.
       The user can use the utility such as Xconfigurator to update the horizontal(HorizSync) and vertical synchronization(VertRefresh) rate for the monitor
       , or simply edit the X configuration file (xorg.conf or XFree86) by hand.