XGI Linux Driver Package User Installation Guide

Decemeber 16, 2007  by claire Hsu (xgi0235)

Contents

1. System Requirement
2. Hardware  Requirement
3. Insallation with run
4. Insallation with TGZ
5. X Configuration

note:
if OS is ubuntu 8.10 or ubuntu 9.04,
Before installing, please use console mode (command mode, Full multiuser mode), to create xorg.conf file.
Create xorg.conf file please use X -configure.


===========================================
1. System Requirement
===========================================

Supported Linux Distribution:
    Fedora core 9~11
    FreeBSD 7.0~7.2

    OpenSuSE 11.0 x86-64/x86-i386
    Ubuntu 8.04~9.04 x86-64/x86-i386
    
Kernel Version:
    7.0-release (FreeBSD)
    2.6.23.1-42.fc8
    2.6.25.5-1.2-default (OpenSuSE)
    2.6.25.5-1.2-pae
    2.6.27-7-server (Ubuntu 8.04)

    (Suppose 2.6.23~2.6.27 are OK)
    

    
XOrg Version:
	1.4.0
	1.5.0
	1.6.0


===========================================
2. Hardware  Requirement
===========================================
VGA adapter card:
    XGI Volari Z7/Z9/Z9s/Z9M/Z11

===========================================
3. Insallation with RPM
===========================================
Driver file:
   1. xgi_xg27_x86_64_xorg8_#_#_#.run --> FC8_64bit
   2. xgi_xg27_x86_xorg8_#_#_#.run --> FC8_32bit



Usage:
 

run:
	-Install 
	  Run "sh xgi_xg27_xxxx_<version>.run"
          ex: sh xgi_xg27_x86_64_xorg8_2_80_01.run
              sh xgi_xg27_x86_xorg8_2_80_01.run
	
	-Uninstall	
	  Run "sh xgi_xxxx_#_#_#.run --noexec --target xgi
          ex: $sh xgi_xg27_x86_64_xorg8_2_80_01.run --noexec --target xgi
	      $sh uninstall.sh
              $sh xgi_xg27_x86_xorg8_2_80_01.run --noexec --target xgi
	      $sh uninstall.sh
===========================================
4. Insallation with TGZ
===========================================
Usage:

	$ tar xvfzp xgipkg.tgz
	$ sh install.sh
	
Reference Environment
	
	X11R7 - use as the root path for X11R7 system.
	
Installation action 

	1. copy xgi_drv.o to ${X11R7}/lib/modules/drivers for driver of XFree86
	2. modify /etc/X11/xorg.conf to enable it.		
	
Uninstallation action
	
	$ sh uninstall.sh
	
	1. remove xgi_drv.o from ${X11R7}/lib/modules/drivers for driver of XFree86
	2. Recover the /etc/X11/xorg.conf to recover the original status.
	
===========================================
4. X Configuration
===========================================	
Tune the xorg.conf (or XF86Config if you are running XFree86) configuration file to taste.
    a. Open the file in a text editor such as emacs or vi.
    b. Check if the frequencies(HorizSync and VertRefresh in the Monitor section of X configure file) for the target system's monitor are correct. 
       These are usually expressed as a horizontal(HorizSync) and vertical synchronization(VertRefresh) rate. 
       These values are added to the xorg.conf file under the "Monitor" section:

        Section "Monitor"
                Identifier   "Monitor0"
                VendorName   "Monitor Vendor"
                ModelName    "Monitor Model"
                HorizSync    30-107
                VertRefresh  48-120
        EndSection
      
       The shorter the ranges of HorizSync and VertRefresh defined in the configure file are , The less the modes X support are.
       The user can use the utility such as Xconfigurator to update the horizontal(HorizSync) and vertical synchronization(VertRefresh) rate for the monitor
       , or simply edit the X configuration file (xorg.conf or XFree86) by hand.