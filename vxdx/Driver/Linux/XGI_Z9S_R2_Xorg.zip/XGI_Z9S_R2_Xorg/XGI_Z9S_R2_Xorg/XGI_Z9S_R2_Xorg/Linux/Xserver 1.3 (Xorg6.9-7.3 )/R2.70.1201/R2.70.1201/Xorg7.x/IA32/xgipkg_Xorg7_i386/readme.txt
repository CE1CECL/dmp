XGI Linux Driver Package User Installation Guide

Decemeber 12, 2007  by claire Hsu (xgi0235)

Contents

1. System Requirement
2. Hardware  Requirement
3. Insallation with run
4. Insallation with TGZ
5. X Configuration


===========================================
1. System Requirement
===========================================

Supported Linux Distribution:
    RHEL5.2 x86-64/x86-i386
    SLES 10 SP1 x86-64/x86-i386
    SLES 10 SP2 x86-64/x86-i386
    Fedora Core 5-7 x86-64/x86-i386
    FreeBSD 6.2 i386
    Solaris 10 U3
    Solaris 10 U5
    Ubuntu 7.1
    Slackware 12.0
    Debian 4.0 r4 x86-64/i386
    
    
Kernel Version:
    2.6.18-8-e15 (RHEL5.2)
    2.6.18-92-e15
    2.6.16.46-0.11-smp (SLES 10)
    2.6.16.60-0.21-smp 
    2.6.18-1.2798 (FC6)
    2.6.9-34-Elsmp
    2.6.21-1.3194.fc7
    6.2 (FreeBSD 6.2)
    5.10 (Solaris 10)
    2.6.22-14-Server (Ubuntu 7.1)
    2.6.18-6-686 (Debian 4.0)
    2.6.18-6-amd64
    2.6.24.5-smp (Slackware 12.0)
    (Suppose 2.6.16~2.6.24 are OK)
    
    
XOrg Version:
	6.9~7.2(Xorg 7.3)


===========================================
2. Hardware  Requirement
===========================================
VGA adapter card:
    XGI Volari Z7/Z9/Z9s/Z9M/Z11

===========================================
3. Insallation with run
===========================================
Driver file:
   1. xgi_xg27_x86_64_xorg7_#_#_#.run --> RHEL5.2_64bit
   2. xgi_xg27_x86_xorg7_#_#_#.run --> RHEL5.2_32bit


Usage:

run:
	-Install 
	  Run "sh xgi_xg27_xxxx_<version>.run"
          ex: sh xgi_xg27_x86_64_xorg7_2_70_01.run
              sh xgi_xg27_x86_xorg7_2_70_01.run
	
	-Uninstall	
	  Run "sh xgi_xxxx_#_#_#.run --noexec --target xgi
          ex: $sh xgi_xg27_x86_64_xorg7_2_70_01.run --noexec --target xgi
	      $sh uninstall.sh
              $sh xgi_xg27_x86_xorg7_2_70_01.run --noexec --target xgi
	      $sh uninstall.sh

===========================================
4. Insallation with TGZ
===========================================
Usage:

	$ tar xvfzp xgipkg.tgz
	$ sh install.sh
	
Reference Environment
	
	X11R7 - use as the root path for X11R7 system.
	
Installation action 

	1. copy xgi_drv.so to ${X11R7}/lib/modules/drivers for driver of XFree86
	2. modify /etc/X11/xorg.conf to enable it.		
	
Uninstallation action
	
	$ sh uninstall.sh
	
	1. remove xgi_drv.so from ${X11R7}/lib/modules/drivers for driver of XFree86
	2. Recover the /etc/X11/xorg.conf to recover the original status.
	
===========================================
4. X Configuration
===========================================	
Tune the xorg.conf (or XF86Config if you are running XFree86) configuration file to taste.
    a. Open the file in a text editor such as emacs or vi.
    b. Check if the frequencies(HorizSync and VertRefresh in the Monitor section of X configure file) for the target system's monitor are correct. 
       These are usually expressed as a horizontal(HorizSync) and vertical synchronization(VertRefresh) rate. 
       These values are added to the xorg.conf file under the "Monitor" section:

        Section "Monitor"
                Identifier   "Monitor0"
                VendorName   "Monitor Vendor"
                ModelName    "Monitor Model"
                HorizSync    30-107
                VertRefresh  48-120
        EndSection
      
       The shorter the ranges of HorizSync and VertRefresh defined in the configure file are , The less the modes X support are.
       The user can use the utility such as Xconfigurator to update the horizontal(HorizSync) and vertical synchronization(VertRefresh) rate for the monitor
       , or simply edit the X configuration file (xorg.conf or XFree86) by hand.