#!/bin/sh

SYSTEM=`uname -s`

#############################################
## 0. Get the distribution information
#############################################
Distrib_SE="/etc/SuSE-release"
Distrib_MD="/etc/mandrake-release"
Distrib_FC="/etc/fedora-release"
Distrib_RF="/etc/redflag-release"
Distrib_RH="/etc/redhat-release"
Distrib_TB="/etc/turbolinux-release"
Distrib="other"

#check OS
if [ -f $Distrib_RF ] ; then
	Distrib="redflag"
elif [ -f $Distrib_MD ] ; then
	Distrib="mandrake"
elif [ -f $Distrib_FC ] ; then
	Distrib="fedora"
elif [ -f $Distrib_SE ] ; then
	Distrib="suse"
elif [ -f $Distrib_RH ] ; then
	Distrib="redhat" 
elif [ -f $Distrib_TB ] ; then
	Distrib="turbolinux" 
elif [ $SYSTEM = "FreeBSD" ] ; then
	Distrib="FreeBSD" 
else 
	Distrib="other"
fi


XSERVER_MODULE="XFree86"

XFREE86_CFG="/etc/X11/XF86Config"
XFREE86_BAK="/etc/X11/.XF86Config.bak"

XORG_CFG="/etc/X11/xorg.conf"
#XORG_BAK="/etc/X11/.xorg.conf.bak"
XORG_BAK="/etc/X11/.xorg.conf.xgi"

RF_XFREE86_CFG="/etc/X11/XF86Config-4"
RF_XFREE86_BAK="/etc/X11/.XF86Config-4.bak"

CFG=$XFREE86_CFG
BAK=$XFREE86_BAK

if [ -f $XFREE86_CFG ] ; then
	CFG=$XFREE86_CFG
	BAK=$XFREE86_BAK
	XSERVER_MODULE="XFree86"
fi

if [ -f $XORG_CFG ] ; then
	CFG=$XORG_CFG
	BAK=$XORG_BAK
	XSERVER_MODULE="XOrg"
fi

if [ -f $RF_XFREE86_CFG ] ; then
	CFG=$RF_XFREE86_CFG
	BAK=$RF_XFREE86_BAK
	XSERVER_MODULE="XFree86"
fi

driver_bin="xgiz_drv.o"
driver_share_bin="xgiz_drv.so"





if [ "$X11R6" = "" ] ; then
	# echo "The system do not contains the X11R6 environment variable." 1>&2
	# echo "Use /usr/X11R6 as default X11R6 path." 1>&2
	# echo
	# echo
	X11R6=/usr/X11R6
	export X11R6
fi

if [ "$MACHTYPE" = "" ] ; then
	MACHTYPE=i386
fi

MACH=`echo $MACHTYPE | sed 's/-.*$//g'` ;

if [ "$MACH" = "x86_64" ] ; then
	# 64 bit

	driver_path=${X11R6}/lib64/modules/drivers
       
	if [ ! -d $driver_path ] ; then
		driver_path=${X11R6}/lib/modules/drivers
	fi
else
	# 32 bit
	driver_path=${X11R6}/lib/modules/drivers

fi


DRV="${driver_path}/$driver_bin"
DRV_SHARE="${driver_path}/$driver_share_bin"

if [ ! -d "$driver_path" ] ; then
	echo "Cannot open X11 installation path $driver_path. Exit." 1>&2
	exit -1 ;
fi



echo "Uninstall XGI $XSERVER_MODULE driver (Y/N)?"
read RESULT
if [ "${RESULT}" = "Y" -o "${RESULT}" = "y" ]; then
	if [ $Distrib != "FreeBSD" ] ;then
####modify for claire 2007/06/26 for support SUSE_92
	   if [ $Distrib = "suse" ] ; then
		X -version > /root/xgisuse.log 2>&1
		suse_ver=`grep -i "X Window System Version 6.8.1" /root/xgisuse.log`
		#echo $suse_ver	
		#echo ${#suse_ver}
        	if [ ${#suse_ver} > 1 ] ; then
		   config=/etc/X11/xorg.conf
                   cp /etc/X11/.xorg.conf.xgi $config
                   rm -rf /etc/X11/.xorg.conf.xgi
		else
		 cp  /etc/X11/.xorg.conf.xgi /etc/X11/xorg.conf
	         rm -rf /etc/X11/.xorg.conf.xgi
		fi
	     
     	   else
          	cp /etc/X11/.xorg.conf.xgi /etc/X11/xorg.conf
	        rm -rf /etc/X11/.xorg.conf.xgi
     	   fi
    	else 		
    		cp /root/xorg.conf.new /etc/X11/xorg.conf  
   	        #20080513 claire add for Freebsd 6.8.2 remove .xorg.conf.xgi file
	        rm -rf /etc/X11/.xorg.conf.xgi
              
        fi
      
	if [ -f "${DRV}" ] ; then
		/bin/rm ${DRV}
		echo "${DRV} is removed."
	fi

	if [ -f "${DRV_SHARE}" ] ; then
		/bin/rm ${DRV_SHARE}
		echo "${DRV_SHARE} is removed."
	fi

fi
