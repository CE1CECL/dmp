# claire, 2008/5/29
# Remove all "SubSection "Display" Modes
#
Distrib_SE="/etc/SuSE-release"
if [ -f $Distrib_SE ] ; then
        Distrib="suse"
fi

CFG="/etc/X11/xorg.conf"
BAK="/etc/X11/.xorg.conf.xgi"
src="/etc/X11/conf.tmp"
des="/etc/X11/conf.tmp.bak"
#des=$CFG
install -m 755 $CFG $src
install -m 755 $CFG $des

#cp $CFG $src


if [ "$Distrib" = "suse" ] ; then

   	echo "removemodes suse"
	a=`grep -n '^Section "Modes"' $src|cut -d ':' -f1`
	a1=`grep -n 'Modeline 	"1600x1200"' $src|cut -d ':' -f1`
	if [ "${#a1}" -gt 0 ] ; then

		while [ "${#a}" -gt 0 ]
		do
	        a1=`grep -n 'Modeline 	"1600x1200"' $src|cut -d ':' -f1`
               # echo $a1
       	 	b=`echo $a1|cut -d ' ' -f1`
        	i=$b
                #echo $i
                	#while [ "$test" = "Modeline" ]
                	while [ "$test" = 'Modeline 	"1600x1200"' ]
                	do
                        	test=`sed -n -e "$i"p $src`
                        	i=$(($i+1))
                        	echo $i
                	done

         	i=$(($i-1))


        	sed ""$b","$i"d" $src > $des
        	tmp=$src
        	src=$des
        	des=$tmp
        	test=
	        a=`grep -n 'Modeline 	"1600x1200"' $src|cut -d ':' -f1`
		#echo "51" $a
		done
		install -D -m 777 $src $CFG
		rm -rf $src
		rm -rf $des
		fi

   		exit 0
else                                                                               
a=`grep -n '^Section "Screen"' $src|cut -d ':' -f1`
a1=`grep -n 'Modes' $src|cut -d ':' -f1`

if [ "${#a1}" -gt 0 ] ; then

while [ "${#a}" -gt 0 ]
do
        a1=`grep -n 'Modes' $src|cut -d ':' -f1`
        b=`echo $a1|cut -d ' ' -f1`
        i=$b
        	while [ "$test" = "Modes" ]
        	do
                	test=`sed -n -e "$i"p $src`
                	i=$(($i+1))
                        echo $i
        	done

         i=$(($i-1))
                                                                                 
        sed ""$b","$i"d" $src > $des
        tmp=$src
        src=$des
        des=$tmp
        test=
        a=`grep -n 'Modes' $src|cut -d ':' -f1`

done
install -D -m 755 $src $CFG
rm -rf $src
rm -rf $des
fi
fi
