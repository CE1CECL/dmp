setup -s

