if exist N:\CE50F_VDX\CE50F_VDX\RelDir\Vortex86DX_50F_x86_Release\nlscfg.inf del /f /q N:\CE50F_VDX\CE50F_VDX\RelDir\Vortex86DX_50F_x86_Release\nlscfg.inf
xcopy /q /c N:\CE50F_VDX\CE50F_VDX\WINCE500\Vortex86DX_50F_x86\oak\Files\nlscfg.inf N:\CE50F_VDX\CE50F_VDX\RelDir\Vortex86DX_50F_x86_Release
