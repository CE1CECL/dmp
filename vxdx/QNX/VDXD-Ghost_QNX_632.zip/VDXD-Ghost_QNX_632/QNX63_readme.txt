


Using ghost83 to your storage,  parameter should be �� ghost83 qnx6.gho �VIR�� for non-FAT format.   

