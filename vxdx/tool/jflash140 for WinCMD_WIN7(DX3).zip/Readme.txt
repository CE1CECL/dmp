Example:

C:\>jflash140 w XXXX.ROM

New version supports VDX3 processor.