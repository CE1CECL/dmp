Example:

C:\>jflash w XXXX.ROM

New version supports VDX3 processor.