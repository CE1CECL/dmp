** This image is compatible with SX/DX series.
** Other architectures may not properly work with it.
** However, it is worth to try. Have fun!!

Requisitions:
1.A 128MB DOM
2.ICOP-0094
3.A USB-to-IDE Adapter

Restoration:
ghost32.exe -IB -IAL

Have fun!! :)

Regards,

Sean (306)
